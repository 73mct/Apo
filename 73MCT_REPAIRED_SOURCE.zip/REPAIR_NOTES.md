# 73MCT repair package

This package contains a source-level repair of the supplied 73MCT Android/Kotlin project.
It keeps the existing Android application ID (`com.pocketflip.overlay`) and the included
signing key, and increments the app version to `12.2-73MCT-REPAIRED` (versionCode 14).

## Main repairs

- Every coin selection receives a generation number. Metadata, socket and image callbacks
  are ignored unless both the selected CA and generation still match.
- Selecting a new CA clears the previous quote immediately. An unsuccessful load shows an
  error instead of leaving the old coin visible or tradable.
- Market refresh is separated from initial metadata loading. The app uses the Shrine socket
  as its push path, tries a validated Solana pool quote when available, and falls back to a
  fresh DexScreener HTTP quote when the push/on-chain path is not producing data.
- The floating panel shows the current data source/state. BUY/SELL operations are rejected
  unless the selected CA matches and the quote is valid and no older than 15 seconds.
- Pump.fun account detection now requires the exact program owner and Anchor discriminator.
  Dual-vault reserve calculations require the selected mint and wrapped-SOL mint to match.
- The recorded market-cap path is written/read through one serial writer, avoiding concurrent
  writes and reads to the same path file.
- Replay keeps timestamp guides and fill-price ticks visible after each fill is reached.
- P&L chart cards use recorded market-cap history where available and overlay actual BUY/SELL
  fills by timestamp. BUY fills get a horizontal price-level guide and vertical time guide.
- Partial sells retain precise fractions internally; full-close actions do not leave a tiny
  residual position due to percentage rounding.
- The GitHub Actions workflow now installs JDK/Android SDK/Gradle and runs `assembleDebug`.

## Build on GitHub

The repository must contain the extracted project at its root, so that `app/`, `build.gradle`,
`settings.gradle`, and `.github/workflows/build-apk.yml` are visible in the repository file list.

**Important:** GitHub does not execute a workflow that is still hidden inside a ZIP file. If
your repo currently contains only the ZIP, you can either extract it and upload the extracted
contents to the repository root, or create `.github/workflows/build-apk.yml` as a separate file
first. The workflow is also designed to extract the ZIP automatically once the workflow itself
is present in the repository.

After the source and workflow are committed:

1. Open the repository's **Actions** tab.
2. Open **Build 73MCT Android APK** and select the newest run.
3. Wait for the run to finish successfully. Open its **Artifacts** section.
4. Download **73MCT-debug-apk** and extract it to get `app-debug.apk`.
5. Install that APK on the phone.

The workflow builds a debug APK using the project's included `app/debug.keystore`. Do not
uninstall your existing app first if you want to preserve its local paper-trading records.
An in-place update should preserve app data when the installed app was signed with the same
included key. Android will reject an update if the currently installed app was signed with a
different key; back up your records before replacing it in that situation.

## Important limits

This is not a guarantee of uninterrupted external market data. The app depends on third-party
services (Shrine, DexScreener and public Solana RPC endpoints), which can be unavailable,
rate-limited, delayed, or unable to quote a particular pool. In those cases, the app now marks
quotes stale/errors and disables paper BUY/SELL instead of silently treating an old quote as live.

I could not perform a full Android Gradle build or device/emulator run in this environment:
the container did not have the Android SDK/Gradle installation needed for that. The changes
were inspected at source level, and a standalone Kotlin parser attempt was blocked by the
missing Android/OkHttp/Socket.IO classpath; it is not a successful compile test. The first
GitHub Actions run is the required build verification. Please review its build log if it fails.
