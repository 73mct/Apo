package com.pocketflip.overlay

import android.content.Context
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** One recorded market cap reading. */
class PathPoint(val t: Long, val mc: Double)

/**
 * Records the market cap of the coin in your panel about once a second (a reading is stored
 * at least every 5 seconds even when the price is flat). The trade replay reads this back.
 * It only LISTENS to the live price; it never changes prices, balance or trades.
 * Files live in the app's private folder and anything older than 14 days is deleted.
 */
object PathStore {
    @Volatile private var dir: File? = null
    private val lock = Any()
    private val pending = HashMap<String, StringBuilder>()
    private val lastT = HashMap<String, Long>()
    private val lastMc = HashMap<String, Double>()
    private val lastFlush = HashMap<String, Long>()
    private val writer = Executors.newSingleThreadExecutor()

    private const val MAX_BYTES = 600_000L
    private const val KEEP_DAYS = 14L

    fun init(context: Context) {
        if (dir != null) return
        val d = File(context.applicationContext.filesDir, "paths")
        d.mkdirs()
        dir = d
        writer.execute {
            try {
                val limit = System.currentTimeMillis() - KEEP_DAYS * 24L * 3600L * 1000L
                d.listFiles()?.forEach { if (it.lastModified() < limit) it.delete() }
            } catch (_: Throwable) {
            }
        }
    }

    private fun safe(ca: String) = ca.filter { it.isLetterOrDigit() }.take(80)

    /** Called on every live refresh; keeps itself cheap. */
    fun record(ca: String, mc: Double) {
        if (dir == null || ca.isBlank() || mc <= 0.0 || mc.isNaN() || mc.isInfinite()) return
        val now = System.currentTimeMillis()
        var doFlush = false
        synchronized(lock) {
            val lt = lastT[ca] ?: 0L
            if (now - lt < 1000L) return
            if (mc == lastMc[ca] && now - lt < 5000L) return
            lastT[ca] = now
            lastMc[ca] = mc
            pending.getOrPut(ca) { StringBuilder() }.append(now).append(',').append(mc).append('\n')
            val lf = lastFlush[ca] ?: 0L
            if (now - lf > 15_000L) {
                lastFlush[ca] = now
                doFlush = true
            }
        }
        if (doFlush) writer.execute { writeOut() }
    }

    /** Queue a flush behind any active write. All disk access is owned by this one writer. */
    fun flush() {
        try { writer.execute { writeOut() } } catch (_: Throwable) { }
    }

    /** Flush all pending samples and wait until the serialized write has completed. */
    fun flushAndWait() {
        try {
            writer.submit { writeOut() }.get(5, TimeUnit.SECONDS)
        } catch (_: Throwable) {
            // A later read still runs on the same queue and will retry the pending batch.
        }
    }

    private fun writeOut() {
        val d = dir ?: return
        val batch: Map<String, String> = synchronized(lock) {
            val m = pending.mapValues { it.value.toString() }.filter { it.value.isNotEmpty() }
            pending.clear()
            m
        }
        for ((ca, text) in batch) {
            try {
                val f = File(d, safe(ca) + ".csv")
                f.appendText(text)
                if (f.length() > MAX_BYTES) {
                    val lines = f.readLines()
                    val keep = lines.takeLast((lines.size * 0.6).toInt())
                    f.writeText(keep.joinToString("\n") + "\n")
                }
            } catch (_: Throwable) {
            }
        }
    }

    /** All readings of [ca] between [fromMs] and [toMs], oldest first. Call off the main thread. */
    fun read(ca: String, fromMs: Long, toMs: Long): List<PathPoint> {
        val d = dir ?: return emptyList()
        return try {
            // The flush and file read execute in one queue task, so no second thread can
            // append/truncate the same CSV while it is being read.
            writer.submit<List<PathPoint>> {
                writeOut()
                val f = File(d, safe(ca) + ".csv")
                if (!f.exists()) return@submit emptyList<PathPoint>()
                val out = ArrayList<PathPoint>()
                f.forEachLine { line ->
                    val i = line.indexOf(',')
                    if (i > 0) {
                        val t = line.substring(0, i).toLongOrNull()
                        val m = line.substring(i + 1).toDoubleOrNull()
                        if (t != null && m != null && m > 0.0 && t >= fromMs && t <= toMs) {
                            out.add(PathPoint(t, m))
                        }
                    }
                }
                out.sortBy { it.t }
                out
            }.get(10, TimeUnit.SECONDS)
        } catch (_: Throwable) {
            emptyList()
        }
    }
}
