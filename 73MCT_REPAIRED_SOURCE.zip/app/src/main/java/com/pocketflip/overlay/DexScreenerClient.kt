package com.pocketflip.overlay

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

object DexScreenerClient {
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val bitmapCache = object : LruCache<String, Bitmap>(32) {}
    private val base58Regex = Regex("[1-9A-HJ-NP-Za-km-z]{32,44}")
    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    private const val WSOL_MINT = "So11111111111111111111111111111111111111112"
    private const val SPL_TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
    private const val TOKEN_2022_PROGRAM = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
    private const val RAYDIUM_V4_PROGRAM = "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8"
    private const val PUMPFUN_PROGRAM = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
    private val PUMPFUN_BONDING_CURVE_DISCRIMINATOR = byteArrayOf(
        0x17, 0xB7.toByte(), 0xF8.toByte(), 0x37, 0x60, 0xD8.toByte(), 0xAC.toByte(), 0x60
    )

    // Persistent HTTP/2 & WebSocket client (zero TCP/TLS handshake overhead on subsequent polls!)
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val SOLANA_HTTP_RPCS = arrayOf(
        "https://solana-rpc.publicnode.com",
        "https://api.mainnet-beta.solana.com"
    )
    private val rpcIndex = AtomicInteger(0)

    private enum class PoolKind {
        PUMPFUN_CURVE,
        DUAL_SPL_VAULTS
    }

    private data class LivePoolConfig(
        val ca: String,
        val pairAddress: String,
        val kind: PoolKind,
        val tokenVault: String,
        val solVault: String,
        var baseRatio: Double,
        var baseMc: Double,
        var basePriceUsd: Double
    )

    private val poolConfigMap = ConcurrentHashMap<String, LivePoolConfig>()
    private val tokenMetaMap = ConcurrentHashMap<String, TokenInfo>()
    private val poolInitExecutor = Executors.newFixedThreadPool(2)
    private val poolInitInFlight = ConcurrentHashMap.newKeySet<String>()
    private val poolInitAttemptAtMs = ConcurrentHashMap<String, Long>()

    @Volatile
    private var shrineSocket: Socket? = null

    @Volatile
    private var subscribedCa: String = ""

    @Volatile
    private var activeSelectionCa: String = ""

    @Volatile
    private var activeSelectionGeneration: Long = -1L

    @Volatile
    private var shrineSocketCreatedAtMs: Long = 0L

    fun extractSolanaCa(rawClipboard: String): String {
        val trimmed = rawClipboard.trim()
        val match = base58Regex.find(trimmed)
        return match?.value ?: trimmed
    }

    /** Register the only coin selection allowed to own the shared live subscription. */
    @Synchronized
    fun setActiveSelection(ca: String, generation: Long) {
        val normalized = ca.trim()
        val changed = normalized != activeSelectionCa || generation != activeSelectionGeneration
        activeSelectionCa = normalized
        activeSelectionGeneration = generation
        if (changed) closeRealtimeSocketsLocked()
    }

    private fun isActiveSelection(ca: String, generation: Long): Boolean =
        activeSelectionCa == ca && activeSelectionGeneration == generation

    /** Load metadata for a selected mint. Results from an older selection may never own the live socket. */
    fun fetchInitialTokenMetadata(
        rawCa: String,
        generation: Long,
        onRealtimeUpdate: (TokenInfo) -> Unit
    ): TokenInfo? {
        val ca = extractSolanaCa(rawCa)
        if (ca.length !in 32..44 || !isActiveSelection(ca, generation)) return null

        val existing = tokenMetaMap[ca]
        val now = System.currentTimeMillis()
        if (existing != null && existing.ca == ca && now - existing.updatedAtMs in 0..5_000L) {
            ensureWebSocketsRunning(ca, generation, onRealtimeUpdate)
            return existing
        }

        val fetched = fetchFreshDexScreenerToken(ca)
        val parsed = fetched ?: run {
            val cached = existing?.takeIf { it.ca == ca && now - it.updatedAtMs in 0..15_000L }
                ?: return null
            Pair(cached, poolConfigMap[ca]?.pairAddress.orEmpty())
        }
        val pairAddress = parsed.second
        val token = parsed.first

        tokenMetaMap[ca] = token
        // The network request may have completed after the user selected another CA.
        // Cache metadata for this mint, but never initialize/replace the active socket in that case.
        if (isActiveSelection(ca, generation)) {
            // Start the push feed immediately. Pool discovery can involve several RPC calls,
            // so it runs independently and must not delay the first usable token quote.
            ensureWebSocketsRunning(ca, generation, onRealtimeUpdate)
            if (pairAddress.isNotEmpty()) schedulePoolDiscovery(ca, pairAddress, token, generation)
        }
        return token
    }

    /**
     * Polls the detected on-chain pool. Returns null when no trustworthy pool quote is available;
     * callers should then use the independent DexScreener HTTP fallback.
     */
    fun pollLiveOnChainPrice(
        rawCa: String,
        generation: Long,
        onRealtimeUpdate: (TokenInfo) -> Unit
    ): TokenInfo? {
        val ca = extractSolanaCa(rawCa)
        if (ca.length !in 32..44 || !isActiveSelection(ca, generation)) return null
        val meta = tokenMetaMap[ca] ?: return null
        ensureWebSocketsRunning(ca, generation, onRealtimeUpdate)
        val cfg = poolConfigMap[ca] ?: return null
        val updated = when (cfg.kind) {
            PoolKind.PUMPFUN_CURVE -> pollPumpFunBondingCurve(cfg, meta)
            PoolKind.DUAL_SPL_VAULTS -> pollDualSplVaults(cfg, meta)
        } ?: return null
        if (!isActiveSelection(ca, generation)) return null
        if (updated.ca != ca || updated.priceUsd <= 0.0 || updated.marketCap <= 0.0 ||
            !updated.priceUsd.isFinite() || !updated.marketCap.isFinite()) return null
        val fresh = updated.copy(updatedAtMs = System.currentTimeMillis())
        tokenMetaMap[ca] = fresh
        return fresh
    }

    /** Independent HTTP fallback used when the socket or on-chain pool is unavailable. */
    fun refreshDexScreenerToken(rawCa: String): TokenInfo? {
        val ca = extractSolanaCa(rawCa)
        if (ca.length !in 32..44) return null
        val fetched = fetchFreshDexScreenerToken(ca) ?: return null
        val parsed = fetched.first
        if (parsed.ca != ca || parsed.priceUsd <= 0.0 || parsed.marketCap <= 0.0) return null
        tokenMetaMap[ca] = parsed
        val generation = activeSelectionGeneration
        if (isActiveSelection(ca, generation) && fetched.second.isNotBlank()) {
            schedulePoolDiscovery(ca, fetched.second, parsed, generation)
        }
        return parsed
    }

    private fun fetchFreshDexScreenerToken(ca: String): Pair<TokenInfo, String>? {
        val t = System.currentTimeMillis()
        val directUrl = "https://api.dexscreener.com/token-pairs/v1/solana/$ca?_t=$t"
        val pairObj = fetchBestSolanaPairJson(directUrl, isArray = true, requestedCa = ca)
            ?: fetchBestSolanaPairJson("https://api.dexscreener.com/latest/dex/tokens/$ca?_t=$t", isArray = false, requestedCa = ca)
            ?: return null
        val parsed = parsePairToTokenInfo(pairObj, ca) ?: return null
        if (parsed.ca != ca) return null
        return Pair(parsed, pairObj.optString("pairAddress", ""))
    }

    /**
     * Decodes Pump.fun Bonding Curve account (`pairAddress`) bytes 8..23:
     * bytes 8..15  = virtualTokenReserves (u64 LE, 6 decimals)
     * bytes 16..23 = virtualSolReserves   (u64 LE, 9 decimals)
     * Price in SOL = (virtualSolReserves / 1e9) / (virtualTokenReserves / 1e6)
     * Market Cap USD = Price in SOL * 1,000,000,000 * solUsdPrice
     */
    private fun pollPumpFunBondingCurve(cfg: LivePoolConfig, meta: TokenInfo): TokenInfo? {
        val reqObj = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "getAccountInfo")
            put("params", JSONArray().apply {
                put(cfg.pairAddress)
                put(JSONObject().apply {
                    put("encoding", "base64")
                    put("commitment", "processed")
                })
            })
        }
        val resp = postSolanaRpc(reqObj.toString()) ?: return null
        val accVal = resp.optJSONObject("result")?.optJSONObject("value") ?: return null
        return applyPumpCurveAccountBytes(cfg, meta, accVal)
    }

    private fun applyPumpCurveAccountBytes(cfg: LivePoolConfig, meta: TokenInfo, accVal: JSONObject): TokenInfo? {
        val dataArr = accVal.optJSONArray("data") ?: return null
        val b64 = dataArr.optString(0, "")
        if (b64.isEmpty()) return null
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        if (bytes.size < 24) return null

        val vTokenRaw = readU64Le(bytes, 8)
        val vSolRaw = readU64Le(bytes, 16)
        if (vTokenRaw <= 0.0 || vSolRaw <= 0.0) return null

        val currentRatio = vSolRaw / vTokenRaw
        if (cfg.baseRatio <= 0.0) {
            cfg.baseRatio = currentRatio
        }

        // Exact on-chain Pump.fun Market Cap formula: (vSol / 1e9) / (vToken / 1e6) * 1e9 * solUsdPrice
        val priceInSol = (vSolRaw / 1_000_000_000.0) / (vTokenRaw / 1_000_000.0)
        val directMcUsd = priceInSol * 1_000_000_000.0 * meta.solUsdPrice
        val directPriceUsd = priceInSol * meta.solUsdPrice

        val updated = if (directMcUsd in 500.0..50_000_000_000.0) {
            meta.copy(
                marketCap = directMcUsd,
                priceUsd = directPriceUsd,
                updatedAtMs = System.currentTimeMillis()
            )
        } else {
            val mult = currentRatio / cfg.baseRatio
            meta.copy(
                marketCap = cfg.baseMc * mult,
                priceUsd = cfg.basePriceUsd * mult,
                updatedAtMs = System.currentTimeMillis()
            )
        }
        tokenMetaMap[cfg.ca] = updated
        return updated
    }

    /**
     * Reads both the pool's SPL Token Vault and WSOL Vault in a single `getMultipleAccounts` call
     * with "commitment": "processed" (works for PumpSwap, Raydium AMM/CPMM/CLMM, Meteora, Orca).
     */
    private fun pollDualSplVaults(cfg: LivePoolConfig, meta: TokenInfo): TokenInfo? {
        val reqObj = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "getMultipleAccounts")
            put("params", JSONArray().apply {
                put(JSONArray().apply {
                    put(cfg.tokenVault)
                    put(cfg.solVault)
                })
                put(JSONObject().apply {
                    put("encoding", "base64")
                    put("commitment", "processed")
                })
            })
        }
        val resp = postSolanaRpc(reqObj.toString()) ?: return null
        val arr = resp.optJSONObject("result")?.optJSONArray("value") ?: return null
        if (arr.length() < 2) return null

        val tokAcc = arr.optJSONObject(0) ?: return null
        val solAcc = arr.optJSONObject(1) ?: return null

        val tokReserve = decodeSplAccountBalance(tokAcc)
        val solReserve = decodeSplAccountBalance(solAcc).let {
            if (it > 0.0) it else (solAcc.optLong("lamports", 0L).toDouble())
        }

        if (tokReserve <= 0.0 || solReserve <= 0.0) return null
        val currentRatio = solReserve / tokReserve
        if (cfg.baseRatio <= 0.0) {
            cfg.baseRatio = currentRatio
            return meta
        }

        val mult = currentRatio / cfg.baseRatio
        if (mult.isNaN() || mult.isInfinite() || mult <= 0.0001 || mult >= 10000.0) return null

        val updated = meta.copy(
            marketCap = cfg.baseMc * mult,
            priceUsd = cfg.basePriceUsd * mult,
            updatedAtMs = System.currentTimeMillis()
        )
        tokenMetaMap[cfg.ca] = updated
        return updated
    }

    /**
     * Pool discovery is deliberately asynchronous: metadata can be shown immediately while
     * one or more Solana RPC requests identify the pool's vaults. If DexScreener later points
     * at a migrated pool, the old pool config is invalidated and rediscovered.
     */
    private fun schedulePoolDiscovery(ca: String, pairAddress: String, token: TokenInfo, generation: Long) {
        if (ca.isBlank() || pairAddress.isBlank()) return
        val oldConfig = poolConfigMap[ca]
        if (oldConfig?.pairAddress == pairAddress) return
        if (oldConfig != null && oldConfig.pairAddress != pairAddress) {
            poolConfigMap.remove(ca, oldConfig)
            poolInitAttemptAtMs.remove(ca)
        }

        val now = System.currentTimeMillis()
        val lastAttempt = poolInitAttemptAtMs[ca] ?: 0L
        if (now - lastAttempt < 45_000L || !poolInitInFlight.add(ca)) return
        poolInitAttemptAtMs[ca] = now
        poolInitExecutor.execute {
            try {
                if (isActiveSelection(ca, generation)) initOnChainPoolForPair(ca, pairAddress, token)
            } catch (t: Throwable) {
                android.util.Log.w("73MCT-Pool", "Pool discovery failed for $ca: ${t.javaClass.simpleName}: ${t.message}")
            } finally {
                poolInitInFlight.remove(ca)
            }
        }
    }

    /**
     * Inspects `pairAddress` on-chain once to determine whether it's a Pump.fun Bonding Curve,
     * a Raydium v4 AMM pool, or a PumpSwap/CPMM/Meteora pool owning two SPL token vaults.
     */
    private fun initOnChainPoolForPair(ca: String, pairAddress: String, initialMeta: TokenInfo) {
        try {
            val req = JSONObject().apply {
                put("jsonrpc", "2.0")
                put("id", 1)
                put("method", "getAccountInfo")
                put("params", JSONArray().apply {
                    put(pairAddress)
                    put(JSONObject().apply {
                        put("encoding", "base64")
                        put("commitment", "processed")
                    })
                })
            }
            val resp = postSolanaRpc(req.toString()) ?: return
            val valObj = resp.optJSONObject("result")?.optJSONObject("value") ?: return
            val ownerProgram = valObj.optString("owner", "")
            val dataArr = valObj.optJSONArray("data")
            val b64 = dataArr?.optString(0, "") ?: ""
            val bytes = if (b64.isNotEmpty()) Base64.decode(b64, Base64.DEFAULT) else ByteArray(0)

            // Case 1: Pump.fun bonding curve. Both the exact owner and Anchor account
            // discriminator must match; account length alone is never proof of its type.
            val isPumpCurve = ownerProgram == PUMPFUN_PROGRAM &&
                bytes.size >= 49 && bytes.copyOfRange(0, 8).contentEquals(PUMPFUN_BONDING_CURVE_DISCRIMINATOR)
            if (isPumpCurve) {
                val vTok = readU64Le(bytes, 8)
                val vSol = readU64Le(bytes, 16)
                if (vTok > 0.0 && vSol > 0.0) {
                    val cfg = LivePoolConfig(
                        ca = ca,
                        pairAddress = pairAddress,
                        kind = PoolKind.PUMPFUN_CURVE,
                        tokenVault = pairAddress,
                        solVault = pairAddress,
                        baseRatio = vSol / vTok,
                        baseMc = initialMeta.marketCap,
                        basePriceUsd = initialMeta.priceUsd
                    )
                    poolConfigMap[ca] = cfg
                    applyPumpCurveAccountBytes(cfg, initialMeta, valObj)
                    return
                }
            }

            // Case 2: Raydium AMM v4 (752 bytes, baseVault at 336..368, quoteVault at 368..400)
            if (ownerProgram == RAYDIUM_V4_PROGRAM && bytes.size >= 400) {
                val vaultA = encodeBase58(bytes.copyOfRange(336, 368))
                val vaultB = encodeBase58(bytes.copyOfRange(368, 400))
                setupDualVaultConfig(ca, pairAddress, vaultA, vaultB, initialMeta)
                return
            }

            // Case 3: PumpSwap / Raydium CPMM / Meteora / Orca — discover vaults via getTokenAccountsByOwner(pairAddress)
            val vaults = findPoolVaultsByOwner(pairAddress, ca)
            if (vaults != null) {
                setupDualVaultConfig(ca, pairAddress, vaults.first, vaults.second, initialMeta)
            }
        } catch (t: Throwable) {
            android.util.Log.w("73MCT-Pool", "Pool account inspection failed for $ca: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun findPoolVaultsByOwner(pairAddress: String, tokenMintCa: String): Pair<String, String>? {
        var tokVault = ""
        var wsolVault = ""

        for (prog in arrayOf(SPL_TOKEN_PROGRAM, TOKEN_2022_PROGRAM)) {
            val req = JSONObject().apply {
                put("jsonrpc", "2.0")
                put("id", 1)
                put("method", "getTokenAccountsByOwner")
                put("params", JSONArray().apply {
                    put(pairAddress)
                    put(JSONObject().apply { put("programId", prog) })
                    put(JSONObject().apply {
                        put("encoding", "jsonParsed")
                        put("commitment", "processed")
                    })
                })
            }
            val res = postSolanaRpc(req.toString()) ?: continue
            val arr = res.optJSONObject("result")?.optJSONArray("value") ?: continue
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val pubkey = item.optString("pubkey", "")
                val info = item.optJSONObject("account")
                    ?.optJSONObject("data")
                    ?.optJSONObject("parsed")
                    ?.optJSONObject("info") ?: continue
                val mint = info.optString("mint", "")
                if (mint == tokenMintCa && pubkey.isNotEmpty()) {
                    tokVault = pubkey
                } else if (mint == WSOL_MINT && pubkey.isNotEmpty()) {
                    wsolVault = pubkey
                }
            }
        }

        if (tokVault.isNotEmpty() && wsolVault.isNotEmpty()) {
            return Pair(tokVault, wsolVault)
        }
        return null
    }

    private fun setupDualVaultConfig(
        ca: String,
        pairAddress: String,
        vault1: String,
        vault2: String,
        initialMeta: TokenInfo
    ) {
        val req = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "getMultipleAccounts")
            put("params", JSONArray().apply {
                put(JSONArray().apply {
                    put(vault1)
                    put(vault2)
                })
                put(JSONObject().apply {
                    put("encoding", "base64")
                    put("commitment", "processed")
                })
            })
        }
        val res = postSolanaRpc(req.toString()) ?: return
        val arr = res.optJSONObject("result")?.optJSONArray("value") ?: return
        if (arr.length() < 2) return
        val acc1 = arr.optJSONObject(0) ?: return
        val acc2 = arr.optJSONObject(1) ?: return

        val mint1 = decodeSplAccountMintBase58(acc1)
        val mint2 = decodeSplAccountMintBase58(acc2)
        val bal1 = decodeSplAccountBalance(acc1)
        val bal2 = decodeSplAccountBalance(acc2)
        if (bal1 <= 0.0 || bal2 <= 0.0) return

        // Never infer a token/SOL ratio merely from vault order. Confirm both mints.
        val isVault1Token = mint1 == ca && mint2 == WSOL_MINT
        val isVault2Token = mint2 == ca && mint1 == WSOL_MINT
        if (!isVault1Token && !isVault2Token) return
        val tokVault = if (isVault1Token) vault1 else vault2
        val solVault = if (isVault1Token) vault2 else vault1
        val tokReserve = if (isVault1Token) bal1 else bal2
        val solReserve = if (isVault1Token) bal2 else bal1

        poolConfigMap[ca] = LivePoolConfig(
            ca = ca,
            pairAddress = pairAddress,
            kind = PoolKind.DUAL_SPL_VAULTS,
            tokenVault = tokVault,
            solVault = solVault,
            baseRatio = solReserve / tokReserve,
            baseMc = initialMeta.marketCap,
            basePriceUsd = initialMeta.priceUsd
        )
    }

    /** Shrine Socket.IO push feed for the selected mint. HTTP/RPC watchdogs are independent fallbacks. */
    @Synchronized
    private fun ensureWebSocketsRunning(
        ca: String,
        generation: Long,
        onRealtimeUpdate: (TokenInfo) -> Unit
    ) {
        if (!isActiveSelection(ca, generation)) return
        // Socket.IO owns reconnection. Keep the same socket while it is reconnecting rather
        // than creating a new client every watchdog tick. If it remains disconnected for
        // 15 seconds, replace it once so a dead manager cannot stall the data feed forever.
        val existingSocket = shrineSocket
        val socketAge = System.currentTimeMillis() - shrineSocketCreatedAtMs
        if (subscribedCa == ca && existingSocket != null &&
            (existingSocket.connected() || socketAge < 15_000L)) return

        if (subscribedCa != ca || existingSocket != null) closeRealtimeSocketsLocked()
        if (!isActiveSelection(ca, generation)) return
        subscribedCa = ca

        try {
            val options = IO.Options().apply {
                transports = arrayOf("websocket")
                reconnection = true
                reconnectionAttempts = Int.MAX_VALUE
                reconnectionDelay = 1000
                reconnectionDelayMax = 10000
            }
            val socket = IO.socket("https://sol.shrine.trade", options)
            shrineSocket = socket
            shrineSocketCreatedAtMs = System.currentTimeMillis()

            socket.on(Socket.EVENT_CONNECT) {
                if (isActiveSelection(ca, generation) && shrineSocket === socket) {
                    socket.emit("subscribe", JSONObject().put("mint", ca))
                }
            }
            socket.on("token_update") { args ->
                try {
                    val update = args.firstOrNull() as? JSONObject ?: return@on
                    if (!isActiveSelection(ca, generation) || subscribedCa != ca || shrineSocket !== socket) return@on
                    val eventCa = update.optString("mint", update.optString("ca", ca))
                    if (eventCa.isNotBlank() && eventCa != ca) return@on
                    val old = tokenMetaMap[ca] ?: return@on
                    val priceUsd = update.optDouble("priceUSD", 0.0)
                    val marketCapUsd = update.optDouble("mcapUSD", 0.0)
                    if (priceUsd <= 0.0 || marketCapUsd <= 0.0 ||
                        priceUsd.isNaN() || marketCapUsd.isNaN() ||
                        priceUsd.isInfinite() || marketCapUsd.isInfinite()) return@on
                    val updated = old.copy(
                        priceUsd = priceUsd,
                        marketCap = marketCapUsd,
                        updatedAtMs = System.currentTimeMillis()
                    )
                    tokenMetaMap[ca] = updated
                    onRealtimeUpdate(updated)
                } catch (t: Throwable) {
                    android.util.Log.w("73MCT-Socket", "Ignored malformed Shrine update for $ca: ${t.message}")
                }
            }
            socket.connect()
        } catch (t: Throwable) {
            android.util.Log.w("73MCT-Socket", "Could not start realtime feed for $ca: ${t.javaClass.simpleName}: ${t.message}")
            shrineSocket = null
            subscribedCa = ""
        }
    }


    /** Must be called with the client monitor held. */
    private fun closeRealtimeSocketsLocked() {
        try { shrineSocket?.disconnect() } catch (_: Throwable) { }
        try { shrineSocket?.close() } catch (_: Throwable) { }
        shrineSocket = null
        shrineSocketCreatedAtMs = 0L
        subscribedCa = ""
    }

    private fun decodeSplAccountBalance(accountObj: JSONObject): Double {
        return try {
            val dataArr = accountObj.optJSONArray("data") ?: return 0.0
            val b64 = dataArr.optString(0, "")
            if (b64.isEmpty()) return 0.0
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            if (bytes.size < 72) return 0.0
            readU64Le(bytes, 64)
        } catch (_: Throwable) {
            0.0
        }
    }

    private fun decodeSplAccountMintBase58(accountObj: JSONObject): String {
        return try {
            val dataArr = accountObj.optJSONArray("data") ?: return ""
            val b64 = dataArr.optString(0, "")
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            if (bytes.size < 32) return ""
            encodeBase58(bytes.copyOfRange(0, 32))
        } catch (_: Throwable) {
            ""
        }
    }

    private fun readU64Le(bytes: ByteArray, offset: Int): Double {
        if (bytes.size < offset + 8) return 0.0
        val buf = ByteBuffer.wrap(bytes, offset, 8).order(ByteOrder.LITTLE_ENDIAN)
        return buf.long.toULong().toDouble()
    }

    private fun encodeBase58(input: ByteArray): String {
        val alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
        var zeros = 0
        while (zeros < input.size && input[zeros].toInt() == 0) zeros++
        val copy = input.copyOf()
        val encoded = CharArray(copy.size * 2)
        var outputStart = encoded.size
        var startAt = zeros
        while (startAt < copy.size) {
            var remainder = 0
            for (i in startAt until copy.size) {
                val digit256 = copy[i].toInt() and 0xFF
                val temp = remainder * 256 + digit256
                copy[i] = (temp / 58).toByte()
                remainder = temp % 58
            }
            if (copy[startAt].toInt() == 0) startAt++
            encoded[--outputStart] = alphabet[remainder]
        }
        while (outputStart < encoded.size && encoded[outputStart] == alphabet[0]) outputStart++
        repeat(zeros) { encoded[--outputStart] = alphabet[0] }
        return String(encoded, outputStart, encoded.size - outputStart)
    }

    private fun postSolanaRpc(jsonBody: String): JSONObject? {
        val url = SOLANA_HTTP_RPCS[rpcIndex.incrementAndGet().and(1)]
        return try {
            val req = Request.Builder()
                .url(url)
                .post(jsonBody.toRequestBody(JSON_MEDIA))
                .header("Cache-Control", "no-cache")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    android.util.Log.w("73MCT-RPC", "Solana RPC $url returned HTTP ${resp.code}")
                    return null
                }
                val bodyStr = resp.body?.string() ?: return null
                JSONObject(bodyStr)
            }
        } catch (t: Throwable) {
            android.util.Log.w("73MCT-RPC", "Solana RPC request failed: ${t.javaClass.simpleName}: ${t.message}")
            null
        }
    }

    private fun fetchBestSolanaPairJson(url: String, isArray: Boolean, requestedCa: String): JSONObject? {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("Cache-Control", "no-cache")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    android.util.Log.w("73MCT-Dex", "DexScreener returned HTTP ${resp.code} for $requestedCa")
                    return null
                }
                val raw = resp.body?.string() ?: return null
                val arr = if (isArray) JSONArray(raw) else JSONObject(raw).optJSONArray("pairs")
                if (arr == null || arr.length() == 0) return null

                var best: JSONObject? = null
                var maxLiq = -1.0
                for (i in 0 until arr.length()) {
                    val p = arr.optJSONObject(i) ?: continue
                    val chain = p.optString("chainId")
                    if (chain.isNotEmpty() && chain != "solana") continue
                    val baseCa = p.optJSONObject("baseToken")?.optString("address", "") ?: ""
                    val quoteCa = p.optJSONObject("quoteToken")?.optString("address", "") ?: ""
                    if (baseCa != requestedCa && quoteCa != requestedCa) continue
                    // Prefer pairs where the selected mint is the base token, then the deepest pool.
                    val liq = p.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
                    val candidateScore = liq + if (baseCa == requestedCa) 1.0e15 else 0.0
                    if (candidateScore > maxLiq || best == null) {
                        maxLiq = candidateScore
                        best = p
                    }
                }
                best
            }
        } catch (t: Throwable) {
            android.util.Log.w("73MCT-Dex", "DexScreener parse/request failed for $requestedCa: ${t.javaClass.simpleName}: ${t.message}")
            null
        }
    }

    private fun parsePairToTokenInfo(pair: JSONObject, originalCa: String): TokenInfo? {
        val baseToken = pair.optJSONObject("baseToken") ?: return null
        val quoteToken = pair.optJSONObject("quoteToken") ?: return null
        val baseAddress = baseToken.optString("address", "")
        val quoteAddress = quoteToken.optString("address", "")
        val targetIsBase = baseAddress == originalCa
        val targetIsQuote = quoteAddress == originalCa
        if (!targetIsBase && !targetIsQuote) return null

        val pairBasePriceUsd = pair.optString("priceUsd", "").toDoubleOrNull()
            ?.takeIf { it > 0.0 && it.isFinite() } ?: return null
        val priceNative = pair.optString("priceNative", "").toDoubleOrNull()
            ?.takeIf { it > 0.0 && it.isFinite() } ?: 0.0
        val priceUsd = if (targetIsBase) pairBasePriceUsd else {
            if (priceNative <= 0.0) return null
            pairBasePriceUsd / priceNative
        }
        if (priceUsd <= 0.0 || !priceUsd.isFinite()) return null

        val targetToken = if (targetIsBase) baseToken else quoteToken
        val name = targetToken.optString("name", "Solana Token").ifBlank { "Solana Token" }
        val symbol = targetToken.optString("symbol", "TOKEN").ifBlank { "TOKEN" }

        val solUsd = if (targetIsBase && priceNative > 0.0) {
            val implied = pairBasePriceUsd / priceNative
            if (implied in 10.0..2000.0) implied else TradeRepository.settings.solUsdPrice
        } else {
            TradeRepository.settings.solUsdPrice
        }

        // DexScreener's marketCap/fdv refer to the base token. For a quote-side mint,
        // use its derived price only as a fallback because the pair's FDV is not its FDV.
        val pairMc = if (targetIsBase) {
            when {
                pair.has("marketCap") && !pair.isNull("marketCap") -> pair.optDouble("marketCap", 0.0)
                pair.has("fdv") && !pair.isNull("fdv") -> pair.optDouble("fdv", 0.0)
                else -> 0.0
            }
        } else 0.0
        val mc = if (pairMc > 0.0 && pairMc.isFinite()) pairMc else priceUsd * 1_000_000_000.0
        if (mc <= 0.0 || !mc.isFinite()) return null

        val vol24 = pair.optJSONObject("volume")?.optDouble("h24", 0.0) ?: 0.0
        val liqUsd = pair.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
        val imageUrl = pair.optJSONObject("info")?.optString("imageUrl", "") ?: ""

        return TokenInfo(
            ca = originalCa,
            name = name,
            symbol = symbol,
            priceUsd = priceUsd,
            solUsdPrice = solUsd,
            marketCap = mc,
            liquidityUsd = liqUsd,
            volume24h = vol24,
            imageUrl = imageUrl,
            updatedAtMs = System.currentTimeMillis()
        )
    }

    fun loadTokenBitmap(url: String, onLoaded: (Bitmap?) -> Unit) {
        if (url.isEmpty()) {
            onLoaded(null)
            return
        }
        val cached = bitmapCache.get(url)
        if (cached != null) {
            onLoaded(cached)
            return
        }
        imageExecutor.execute {
            try {
                val req = Request.Builder().url(url).build()
                httpClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val bytes = resp.body?.bytes()
                        if (bytes != null) {
                            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            if (bmp != null) bitmapCache.put(url, bmp)
                            onLoaded(bmp)
                            return@execute
                        }
                    }
                }
            } catch (_: Throwable) {}
            onLoaded(null)
        }
    }
}
