package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.max
import kotlin.math.min
import java.util.UUID

object TradeRepository {
    private const val PREFS_NAME = "pocketflip_native_store"
    private const val KEY_SETTINGS = "settings_json"
    private const val KEY_POSITIONS = "positions_json"
    private const val KEY_JOURNAL = "journal_v2_json"  // one entry per finished trade
    private const val KEY_ORDERS = "paper_orders_v1_json"
    private const val KEY_TOKEN_TAXES = "token_taxes_v1_json"

    private var prefs: SharedPreferences? = null
    var settings: AppSettings = AppSettings()
        private set

    private val positionsMap = LinkedHashMap<String, OpenPosition>()
    private val journalList = ArrayList<ClosedTradeLog>()
    private val ordersMap = LinkedHashMap<String, PaperOrder>()
    private val tokenTaxMap = LinkedHashMap<String, Pair<Double, Double>>()
    private val lastEvaluatedQuoteMsByCa = HashMap<String, Long>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        loadFromPrefs()
    }

    fun addListener(listener: () -> Unit) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun notifyChanged() = notifyListeners()

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l.invoke()
            } catch (_: Throwable) {}
        }
    }

    @Synchronized
    fun getPosition(ca: String): OpenPosition? = positionsMap[ca]

    @Synchronized
    fun getAllPositions(): List<OpenPosition> = ArrayList(positionsMap.values)

    @Synchronized
    fun getJournal(): List<ClosedTradeLog> = ArrayList(journalList)

    @Synchronized
    fun getOrders(ca: String? = null): List<PaperOrder> = ordersMap.values
        .filter { ca.isNullOrBlank() || it.ca == ca }
        .sortedByDescending { it.createdAtMs }
        .map { it.copy() }

    @Synchronized
    fun getActiveOrders(ca: String? = null): List<PaperOrder> = getOrders(ca).filter { it.isActive }

    /** Returns stored, user-verified taxes for a mint. Unknown taxes remain zero; we never guess them. */
    @Synchronized
    fun withStoredTokenTaxes(token: TokenInfo): TokenInfo {
        val stored = tokenTaxMap[token.ca] ?: return token
        return token.copy(buyTaxPct = stored.first, sellTaxPct = stored.second)
    }

    @Synchronized
    fun getTokenTaxes(ca: String): Pair<Double, Double> = tokenTaxMap[ca] ?: (0.0 to 0.0)

    @Synchronized
    fun setTokenTaxes(ca: String, buyTaxPct: Double, sellTaxPct: Double) {
        val key = ca.trim()
        if (key.isBlank()) return
        val buy = buyTaxPct.coerceIn(0.0, 99.0)
        val sell = sellTaxPct.coerceIn(0.0, 99.0)
        tokenTaxMap[key] = buy to sell
        saveToPrefs()
        notifyListeners()
    }

    @Synchronized
    fun setActiveCa(ca: String) {
        settings.activeCa = ca.trim()
        saveToPrefs()
        notifyListeners()
    }

    @Synchronized
    fun updateSettings(
        newBalance: Double,
        platformFeePct: Double,
        priorityFeeSol: Double,
        slippagePct: Double,
        buyPresets: List<Double>,
        sellPresets: List<Double>
    ) {
        settings.solBalance = newBalance.coerceAtLeast(0.0)
        settings.platformFeePct = platformFeePct.coerceIn(0.0, 25.0)
        settings.priorityFeeSol = priorityFeeSol.coerceIn(0.0, 2.0)
        settings.slippagePct = slippagePct.coerceIn(0.0, 50.0)
        if (buyPresets.size in 4..8 && buyPresets.all { it > 0.0 }) settings.buyPresets = buyPresets.take(8)
        if (sellPresets.size in 4..8 && sellPresets.all { it in 1.0..100.0 }) settings.sellPresets = sellPresets.take(8)
        saveToPrefs()
        notifyListeners()
    }

    @Synchronized
    fun syncLiveTokenData(token: TokenInfo) {
        if (token.solUsdPrice > 5.0) {
            settings.solUsdPrice = token.solUsdPrice
        }
        val pos = positionsMap[token.ca]
        if (pos != null) {
            pos.lastMc = token.marketCap
            pos.lastPriceUsd = token.priceUsd
            if (token.marketCap > pos.peakMc) pos.peakMc = token.marketCap
            if (pos.maeMc <= 0.0 || token.marketCap < pos.maeMc) pos.maeMc = token.marketCap
        }
        notifyListeners()
    }

    @Synchronized
    fun executeBuy(
        tokenInput: TokenInfo,
        buySol: Double,
        executionType: String = "MANUAL",
        orderId: String = ""
    ): Result<OpenPosition> {
        if (buySol <= 0.0 || !buySol.isFinite()) {
            return Result.failure(IllegalArgumentException("Enter a valid SOL buy amount"))
        }
        val token = withStoredTokenTaxes(tokenInput)
        val totalCostSol = buySol + settings.priorityFeeSol
        if (totalCostSol > settings.solBalance) {
            return Result.failure(
                IllegalStateException("Insufficient SOL! Need ${String.format("%.3f", totalCostSol)} SOL (incl. fee)")
            )
        }

        val priceUsd = token.priceUsd.coerceAtLeast(0.0000000001)
        val solUsd = settings.solUsdPrice.coerceAtLeast(10.0)
        val automated = executionType.startsWith("ORDER_")
        // Manual fills use the observed quote. The configured slippage tolerance applies only to orders.
        val appliedSlippage = if (automated) settings.slippagePct else 0.0
        val platformFee = settings.platformFeePct.coerceIn(0.0, 25.0)
        val taxPct = token.buyTaxPct.coerceIn(0.0, 99.0)
        val tradeUsd = buySol * solUsd
        // A transparent approximation only. This is not a constant-product pool simulation.
        val impactPct = if (automated && token.liquidityUsd > 0.0)
            ((tradeUsd / (2.0 * token.liquidityUsd)) * 100.0).coerceIn(0.0, 20.0) else 0.0
        val effectiveSol = buySol * (1.0 - platformFee / 100.0) * (1.0 - appliedSlippage / 100.0)
        val afterImpact = effectiveSol / (1.0 + impactPct / 100.0)
        val afterTax = afterImpact * (1.0 - taxPct / 100.0)
        val tokensBought = (afterTax * solUsd) / priceUsd
        if (tokensBought <= 0.0 || !tokensBought.isFinite()) {
            return Result.failure(IllegalStateException("Could not calculate a valid simulated fill"))
        }

        settings.solBalance = max(0.0, settings.solBalance - totalCostSol)
        val now = System.currentTimeMillis()
        val feeSol = settings.priorityFeeSol + buySol * (platformFee / 100.0)
        val buyFill = Fill(
            side = "BUY", timeMs = now, mc = token.marketCap, priceUsd = priceUsd, sol = totalCostSol,
            executionType = executionType, orderId = orderId, taxPct = taxPct, feeSol = feeSol,
            slippagePct = appliedSlippage, impactPct = impactPct
        )

        val existing = positionsMap[token.ca]
        val updated = if (existing == null) {
            OpenPosition(
                ca = token.ca, name = token.name, symbol = token.symbol, imageUrl = token.imageUrl,
                entryMc = token.marketCap, entryPriceUsd = priceUsd, solInvested = totalCostSol,
                initialSolInvested = totalCostSol, tokensHeld = tokensBought, remainingPct = 100.0,
                realizedPnlSol = 0.0, openedAtMs = now, lastMc = token.marketCap,
                lastPriceUsd = priceUsd, peakMc = token.marketCap, realizedSolOut = 0.0,
                fills = mutableListOf(buyFill), maeMc = token.marketCap
            )
        } else {
            val totalTokens = existing.tokensHeld + tokensBought
            val prevWeight = if (totalTokens > 0.0) existing.tokensHeld / totalTokens else 0.0
            val newWeight = if (totalTokens > 0.0) tokensBought / totalTokens else 0.0
            existing.entryMc = existing.entryMc * prevWeight + token.marketCap * newWeight
            existing.entryPriceUsd = existing.entryPriceUsd * prevWeight + priceUsd * newWeight
            existing.tokensHeld = totalTokens
            existing.solInvested += totalCostSol
            existing.initialSolInvested += totalCostSol
            existing.remainingPct = 100.0
            existing.lastMc = token.marketCap
            existing.lastPriceUsd = priceUsd
            if (token.marketCap > existing.peakMc) existing.peakMc = token.marketCap
            if (existing.maeMc <= 0.0 || token.marketCap < existing.maeMc) existing.maeMc = token.marketCap
            existing.fills.add(buyFill)
            existing
        }

        positionsMap[token.ca] = updated
        saveToPrefs()
        notifyListeners()
        return Result.success(updated)
    }

    @Synchronized
    fun executeSell(
        tokenInput: TokenInfo,
        sellPctInput: Double,
        executionType: String = "MANUAL",
        orderId: String = ""
    ): Result<SellResult> {
        val token = withStoredTokenTaxes(tokenInput)
        val pos = positionsMap[token.ca]
            ?: return Result.failure(IllegalStateException("No open position for ${token.symbol}"))
        if (pos.tokensHeld <= 0.0) return Result.failure(IllegalStateException("No tokens left to sell"))

        val pct = sellPctInput.coerceIn(0.1, 100.0)
        val fraction = pct / 100.0
        val tokensSold = pos.tokensHeld * fraction
        val solCostBasis = pos.solInvested * fraction
        val currentPriceUsd = if (token.priceUsd > 0.0) token.priceUsd else pos.lastPriceUsd
        val currentMc = if (token.marketCap > 0.0) token.marketCap else pos.lastMc
        if (currentPriceUsd <= 0.0 || currentMc <= 0.0) {
            return Result.failure(IllegalStateException("No usable price for this sell"))
        }
        val solUsd = settings.solUsdPrice.coerceAtLeast(10.0)
        val automated = executionType.startsWith("ORDER_")
        val appliedSlippage = if (automated) settings.slippagePct else 0.0
        val platformFee = settings.platformFeePct.coerceIn(0.0, 25.0)
        val taxPct = token.sellTaxPct.coerceIn(0.0, 99.0)
        val grossSolOut = (tokensSold * currentPriceUsd) / solUsd
        val tradeUsd = tokensSold * currentPriceUsd
        val impactPct = if (automated && token.liquidityUsd > 0.0)
            ((tradeUsd / (2.0 * token.liquidityUsd)) * 100.0).coerceIn(0.0, 20.0) else 0.0
        val feeMultiplier = (1.0 - platformFee / 100.0) * (1.0 - appliedSlippage / 100.0) *
            (1.0 - taxPct / 100.0) * (1.0 - impactPct / 100.0)
        val feeSol = settings.priorityFeeSol + grossSolOut * (platformFee / 100.0)
        val netSolOut = max(0.0, grossSolOut * feeMultiplier - settings.priorityFeeSol)

        settings.solBalance += netSolOut
        val slicePnl = netSolOut - solCostBasis
        val multipleX = if (pos.entryMc > 0.0) currentMc / pos.entryMc else 1.0
        val now = System.currentTimeMillis()
        val closing = pct >= 99.9
        val remainingAfter = if (closing) 0.0 else max(0.0, pos.remainingPct * (1.0 - fraction))

        pos.fills.add(
            Fill(
                side = "SELL", timeMs = now, mc = currentMc, priceUsd = currentPriceUsd,
                sol = netSolOut, pct = pct, pnlSol = slicePnl, remainingAfterPct = remainingAfter,
                executionType = executionType, orderId = orderId, taxPct = taxPct,
                feeSol = feeSol, slippagePct = appliedSlippage, impactPct = impactPct
            )
        )
        pos.realizedSolOut += netSolOut
        pos.realizedPnlSol += slicePnl
        if (currentMc > pos.peakMc) pos.peakMc = currentMc
        if (pos.maeMc <= 0.0 || currentMc < pos.maeMc) pos.maeMc = currentMc

        var tradePnl = pos.realizedPnlSol
        if (closing) {
            val sells = pos.fills.filter { it.side == "SELL" }
            val sellSol = sells.sumOf { it.sol }
            val avgExitMc = if (sellSol > 0.0) sells.sumOf { it.mc * it.sol } / sellSol else currentMc
            val solIn = pos.initialSolInvested
            val solOut = pos.realizedSolOut
            tradePnl = solOut - solIn
            val mfePct = if (pos.entryMc > 0.0) ((max(pos.peakMc, currentMc) / pos.entryMc) - 1.0) * 100.0 else 0.0
            val maePct = if (pos.entryMc > 0.0 && pos.maeMc > 0.0) ((pos.maeMc / pos.entryMc) - 1.0) * 100.0 else 0.0
            val rMultiple = if (pos.stopLossMc > 0.0 && pos.entryMc > pos.stopLossMc) {
                val riskPct = (pos.entryMc - pos.stopLossMc) / pos.entryMc
                if (riskPct > 0.0) ((avgExitMc / pos.entryMc) - 1.0) / riskPct else null
            } else null
            val log = ClosedTradeLog(
                id = "tr_$now", ca = pos.ca, name = pos.name, symbol = pos.symbol,
                imageUrl = if (token.imageUrl.isNotEmpty()) token.imageUrl else pos.imageUrl,
                entryMc = pos.entryMc, avgExitMc = avgExitMc,
                peakMc = max(pos.peakMc, max(pos.entryMc, currentMc)), solIn = solIn,
                solOut = solOut, pnlSol = tradePnl,
                multipleX = if (pos.entryMc > 0.0) avgExitMc / pos.entryMc else 1.0,
                holdDurationMs = (now - pos.openedAtMs).coerceAtLeast(1000L),
                openedAtMs = pos.openedAtMs, closedAtMs = now, fills = ArrayList(pos.fills),
                mfePct = mfePct, maePct = maePct, rMultiple = rMultiple, stopLossMc = pos.stopLossMc
            )
            journalList.add(0, log)
            positionsMap.remove(pos.ca)
        } else {
            pos.tokensHeld -= tokensSold
            pos.solInvested -= solCostBasis
            pos.remainingPct = remainingAfter
        }

        saveToPrefs()
        notifyListeners()
        return Result.success(
            SellResult(
                symbol = pos.symbol, soldPct = pct, solOut = netSolOut, slicePnlSol = slicePnl,
                multipleX = multipleX, remainingPct = remainingAfter, closed = closing, tradePnlSol = tradePnl
            )
        )
    }

    /** Sells the fraction of the current bag whose estimated net proceeds recover the unrecovered initial stake. */
    @Synchronized
    fun sellInitial(token: TokenInfo): Result<SellResult> {
        val pos = positionsMap[token.ca]
            ?: return Result.failure(IllegalStateException("No open position for ${token.symbol}"))
        val amountToRecover = (pos.initialSolInvested - pos.realizedSolOut).coerceAtLeast(0.0)
        if (amountToRecover <= 0.000001) {
            return Result.failure(IllegalStateException("Initial stake has already been recovered"))
        }
        val livePrice = if (token.priceUsd > 0.0) token.priceUsd else pos.lastPriceUsd
        if (livePrice <= 0.0 || settings.solUsdPrice <= 0.0) {
            return Result.failure(IllegalStateException("No live price available to calculate Sell Initial"))
        }
        val t = withStoredTokenTaxes(token)
        val grossBagSol = (pos.tokensHeld * livePrice) / settings.solUsdPrice.coerceAtLeast(10.0)
        val netFactor = (1.0 - settings.platformFeePct.coerceIn(0.0, 25.0) / 100.0) *
            (1.0 - t.sellTaxPct.coerceIn(0.0, 99.0) / 100.0)
        val netBeforePriorityFee = grossBagSol * netFactor
        val estimatedFullBagOut = max(0.0, netBeforePriorityFee - settings.priorityFeeSol)
        if (estimatedFullBagOut <= 0.0 || netBeforePriorityFee <= 0.0) {
            return Result.failure(IllegalStateException("Current bag value is too low to estimate recovery"))
        }
        // Priority fee is charged once per sell, not proportionally. Solve for the fraction
        // that should net the unrecovered principal after that fixed cost.
        val pct = ((amountToRecover + settings.priorityFeeSol) / netBeforePriorityFee * 100.0)
            .coerceIn(0.1, 100.0)
        return executeSell(t, pct, "SELL_INITIAL", "")
    }

    @Synchronized
    fun createOrder(
        token: TokenInfo,
        type: String,
        triggerMc: Double = 0.0,
        amountSol: Double = 0.0,
        sellPct: Double = 100.0,
        totalOrders: Int = 1,
        intervalSeconds: Long = 0L,
        minMc: Double = 0.0,
        maxMc: Double = 0.0
    ): Result<PaperOrder> {
        val allowed = setOf("TAKE_PROFIT", "STOP_LOSS", "LIMIT_BUY", "DCA_BUY", "DCA_SELL")
        if (token.ca.isBlank() || token.marketCap <= 0.0) return Result.failure(IllegalStateException("Load a token with a valid market cap first"))
        if (type !in allowed) return Result.failure(IllegalArgumentException("Unsupported paper order type"))
        if (type in setOf("TAKE_PROFIT", "STOP_LOSS", "LIMIT_BUY") && triggerMc <= 0.0) {
            return Result.failure(IllegalArgumentException("Enter a valid trigger market cap"))
        }
        if (type in setOf("TAKE_PROFIT", "STOP_LOSS", "DCA_SELL") && getPosition(token.ca) == null) {
            return Result.failure(IllegalStateException("Open a position before creating a sell order"))
        }
        if (type in setOf("LIMIT_BUY", "DCA_BUY") && amountSol <= 0.0) return Result.failure(IllegalArgumentException("Enter a valid SOL amount"))
        if (type in setOf("TAKE_PROFIT", "STOP_LOSS", "DCA_SELL") && sellPct !in 0.1..100.0) {
            return Result.failure(IllegalArgumentException("Sell percentage must be between 0.1 and 100"))
        }
        if (minMc > 0.0 && maxMc > 0.0 && minMc > maxMc) {
            return Result.failure(IllegalArgumentException("Minimum market cap cannot exceed maximum market cap"))
        }
        if (type.startsWith("DCA_") && totalOrders !in 2..20) {
            return Result.failure(IllegalArgumentException("DCA requires 2–20 orders"))
        }
        if (type == "TAKE_PROFIT" && ordersMap.values.count { it.isActive && it.ca == token.ca && it.type == type } >= 4) {
            return Result.failure(IllegalStateException("You can have up to four active take-profit levels per token"))
        }
        if (type == "STOP_LOSS" && ordersMap.values.any { it.isActive && it.ca == token.ca && it.type == type }) {
            return Result.failure(IllegalStateException("This token already has an active stop-loss order"))
        }
        val slices = totalOrders.coerceIn(if (type.startsWith("DCA_")) 2 else 1, 20)
        val interval = intervalSeconds.coerceIn(0L, 86_400L)
        val now = System.currentTimeMillis()
        val sellTokensPerOrder = if (type == "DCA_SELL") {
            val livePosition = positionsMap[token.ca] ?: return Result.failure(IllegalStateException("Open a position before creating a DCA sell"))
            (livePosition.tokensHeld * sellPct.coerceIn(0.1, 100.0) / 100.0) / slices
        } else 0.0
        val order = PaperOrder(
            id = "ord_${UUID.randomUUID()}", ca = token.ca, symbol = token.symbol, type = type,
            triggerMc = triggerMc.coerceAtLeast(0.0), amountSol = amountSol,
            sellPct = sellPct.coerceIn(0.1, 100.0), totalOrders = slices,
            intervalSeconds = interval, minMc = minMc.coerceAtLeast(0.0), maxMc = maxMc.coerceAtLeast(0.0),
            createdAtMs = now, nextExecutionAtMs = if (type.startsWith("DCA_")) now else 0L,
            sellTokensPerOrder = sellTokensPerOrder
        )
        ordersMap[order.id] = order
        if (type == "STOP_LOSS") {
            positionsMap[token.ca]?.stopLossMc = triggerMc
        }
        saveToPrefs()
        notifyListeners()
        return Result.success(order.copy())
    }

    @Synchronized
    fun cancelOrder(orderId: String): Boolean {
        val order = ordersMap[orderId] ?: return false
        if (!order.isActive) return false
        order.status = "CANCELLED"
        order.lastMessage = "Cancelled by user"
        saveToPrefs()
        notifyListeners()
        return true
    }

    /** Called only on a newly updated quote for the token page currently being watched. */
    @Synchronized
    fun evaluateOrders(tokenInput: TokenInfo): List<String> {
        val token = withStoredTokenTaxes(tokenInput)
        if (token.marketCap <= 0.0 || token.marketDataUpdatedAtMs <= 0L ||
            System.currentTimeMillis() - token.marketDataUpdatedAtMs > 10_000L) return emptyList()
        val lastSeen = lastEvaluatedQuoteMsByCa[token.ca] ?: 0L
        if (token.marketDataUpdatedAtMs <= lastSeen) return emptyList()
        lastEvaluatedQuoteMsByCa[token.ca] = token.marketDataUpdatedAtMs
        val messages = ArrayList<String>()
        val candidates = ordersMap.values.filter { it.isActive && it.ca == token.ca }.toList()
        for (orderSnapshot in candidates) {
            val order = ordersMap[orderSnapshot.id] ?: continue
            val withinRange = (order.minMc <= 0.0 || token.marketCap >= order.minMc) &&
                (order.maxMc <= 0.0 || token.marketCap <= order.maxMc)
            var shouldExecute = false
            when (order.type) {
                "TAKE_PROFIT" -> shouldExecute = token.marketCap >= order.triggerMc
                "STOP_LOSS" -> shouldExecute = token.marketCap <= order.triggerMc
                "LIMIT_BUY" -> shouldExecute = token.marketCap <= order.triggerMc
                "DCA_BUY", "DCA_SELL" -> shouldExecute = withinRange &&
                    (order.nextExecutionAtMs <= 0L || System.currentTimeMillis() >= order.nextExecutionAtMs)
            }
            if (!shouldExecute) continue

            val resultMessage: String
            val execution = when (order.type) {
                "TAKE_PROFIT", "STOP_LOSS" -> executeSell(
                    token, order.sellPct, "ORDER_${order.type}", order.id
                ).map { it }
                "DCA_SELL" -> {
                    val position = getPosition(token.ca)
                    val perSlicePct = if (position != null && order.sellTokensPerOrder > 0.0 && position.tokensHeld > 0.0)
                        (min(order.sellTokensPerOrder, position.tokensHeld) / position.tokensHeld * 100.0).coerceIn(0.1, 100.0)
                    else order.sellPct
                    executeSell(token, perSlicePct, "ORDER_DCA_SELL", order.id).map { it }
                }
                "LIMIT_BUY" -> executeBuy(token, order.amountSol, "ORDER_LIMIT_BUY", order.id).map { it }
                "DCA_BUY" -> executeBuy(
                    token, order.amountSol / order.totalOrders.coerceAtLeast(1), "ORDER_DCA_BUY", order.id
                ).map { it }
                else -> Result.failure(IllegalStateException("Unsupported order"))
            }

            if (execution.isSuccess) {
                order.completedOrders += 1
                val done = !order.type.startsWith("DCA_") || order.completedOrders >= order.totalOrders ||
                    (order.type == "DCA_SELL" && getPosition(token.ca) == null)
                order.status = if (done) "COMPLETED" else "ACTIVE"
                order.lastMessage = "Filled ${order.completedOrders}/${order.totalOrders} at ${Formatters.compactUsd(token.marketCap)}"
                if (!done) order.nextExecutionAtMs = System.currentTimeMillis() + order.intervalSeconds.coerceAtLeast(1L) * 1000L
                resultMessage = "${order.type.replace('_', ' ')} filled · ${Formatters.compactUsd(token.marketCap)}"
            } else {
                val reason = execution.exceptionOrNull()?.message ?: "Fill failed"
                order.status = "FAILED"
                order.lastMessage = reason
                resultMessage = "${order.type.replace('_', ' ')} failed · $reason"
            }
            messages.add(resultMessage)
        }
        if (messages.isNotEmpty()) {
            saveToPrefs()
            notifyListeners()
        }
        return messages
    }

    @Synchronized
    fun computeUnrealizedPnlSol(pos: OpenPosition, livePriceUsd: Double, sellTaxPct: Double = 0.0): Double {
        val solUsd = settings.solUsdPrice.coerceAtLeast(10.0)
        val grossSol = (pos.tokensHeld * livePriceUsd) / solUsd
        val feeMult = (1.0 - settings.platformFeePct / 100.0) * (1.0 - sellTaxPct.coerceIn(0.0, 99.0) / 100.0)
        val netSolVal = max(0.0, grossSol * feeMult - settings.priorityFeeSol)
        return netSolVal - pos.solInvested
    }

    /**
     * Imports a 73MCT Desktop snapshot without replacing the phone's wallet balance,
     * settings, or existing journal entries. Desktop closed trades are namespaced by ID
     * so repeated syncs are idempotent and Android can open them in its native PnL Card flow.
     * Returns Pair(imported closed trades, imported open positions).
     */
    @Synchronized
    fun mergeDesktopSnapshot(snapshot: JSONObject): Pair<Int, Int> {
        if (snapshot.optInt("schema", 0) != 1) return 0 to 0
        var importedTrades = 0
        var importedPositions = 0
        var anyChange = false

        val incomingTheses = snapshot.optJSONObject("theses")
        fun importThesis(ca: String, openedAtMs: Long) {
            if (ca.isBlank() || openedAtMs <= 0L) return
            val thesis = incomingTheses?.optJSONObject(ca) ?: return
            val text = thesis.optString("text", "").trim()
            if (text.isBlank()) return
            val tagsJson = thesis.optJSONArray("tags")
            val tags = ArrayList<String>()
            if (tagsJson != null) for (i in 0 until tagsJson.length()) {
                val tag = tagsJson.optString(i).trim()
                if (tag.isNotEmpty()) tags.add(tag)
            }
            ThesisStore.save(ca, openedAtMs, text, tags)
        }

        val incomingTrades = snapshot.optJSONArray("closedTrades") ?: JSONArray()
        for (i in 0 until incomingTrades.length()) {
            val o = incomingTrades.optJSONObject(i) ?: continue
            val sourceId = o.optString("id", "").trim()
            if (sourceId.isEmpty()) continue
            val ca = o.optString("ca", "")
            val openedAtMs = o.optLong("openedAtMs", 0L)
            // Import the thesis even if the trade record itself was already imported in an earlier sync.
            importThesis(ca, openedAtMs)
            val stableId = if (sourceId.startsWith("desktop_")) sourceId else "desktop_$sourceId"
            if (journalList.any { it.id == stableId }) continue
            val fills = fillsFromJson(o.optJSONArray("fills"))
            val trade = ClosedTradeLog(
                id = stableId,
                ca = ca,
                name = o.optString("name", "Token"),
                symbol = o.optString("symbol", "TOK"),
                imageUrl = o.optString("imageUrl", ""),
                entryMc = o.optDouble("entryMc", 0.0),
                avgExitMc = o.optDouble("avgExitMc", 0.0),
                peakMc = o.optDouble("peakMc", 0.0),
                solIn = o.optDouble("solIn", 0.0),
                solOut = o.optDouble("solOut", 0.0),
                pnlSol = o.optDouble("pnlSol", 0.0),
                multipleX = o.optDouble("multipleX", 1.0),
                holdDurationMs = o.optLong("holdDurationMs", 1000L),
                openedAtMs = openedAtMs,
                closedAtMs = o.optLong("closedAtMs", 0L),
                fills = fills
            )
            journalList.add(trade)
            importedTrades++
            anyChange = true
        }

        // The incoming desktop snapshot is the complete desktop-owned open-position set.
        // Remove stale desktop mirrors first (e.g. a position closed on the PC), but never
        // remove a phone-originated position even if it has the same contract address.
        val incomingPositions = snapshot.optJSONArray("positions") ?: JSONArray()
        val incomingByCa = LinkedHashMap<String, JSONObject>()
        for (i in 0 until incomingPositions.length()) {
            val o = incomingPositions.optJSONObject(i) ?: continue
            val ca = o.optString("ca", "").trim()
            if (ca.isNotEmpty()) incomingByCa[ca] = o
        }
        val staleDesktop = positionsMap.values
            .filter { it.source == "desktop" && !incomingByCa.containsKey(it.ca) }
            .map { it.ca }
        for (ca in staleDesktop) {
            positionsMap.remove(ca)
            anyChange = true
        }

        for ((ca, o) in incomingByCa) {
            val existing = positionsMap[ca]
            // Phone-owned state always wins on address collision.
            if (existing != null && existing.source != "desktop") continue
            importThesis(ca, o.optLong("openedAtMs", 0L))
            val pos = OpenPosition(
                ca = ca,
                name = o.optString("name", "Token"),
                symbol = o.optString("symbol", "TOK"),
                imageUrl = o.optString("imageUrl", ""),
                entryMc = o.optDouble("entryMc", 0.0),
                entryPriceUsd = o.optDouble("entryPriceUsd", 0.0),
                solInvested = o.optDouble("solInvested", 0.0),
                initialSolInvested = o.optDouble("initialSolInvested", 0.0),
                tokensHeld = o.optDouble("tokensHeld", 0.0),
                remainingPct = o.optDouble("remainingPct", 100.0),
                realizedPnlSol = o.optDouble("realizedPnlSol", 0.0),
                openedAtMs = o.optLong("openedAtMs", System.currentTimeMillis()),
                lastMc = o.optDouble("lastMc", 0.0),
                lastPriceUsd = o.optDouble("lastPriceUsd", 0.0),
                peakMc = o.optDouble("peakMc", 0.0),
                realizedSolOut = o.optDouble("realizedSolOut", 0.0),
                fills = fillsFromJson(o.optJSONArray("fills")).toMutableList(),
                source = "desktop"
            )
            if (pos.fills.isEmpty()) {
                pos.fills.add(Fill("BUY", pos.openedAtMs, pos.entryMc, pos.entryPriceUsd, pos.initialSolInvested))
            }
            val changed = existing == null || existing != pos
            if (changed) {
                positionsMap[ca] = pos
                importedPositions++
                anyChange = true
            }
        }

        // Apply the desktop profile name only when the phone still has its untouched default.
        val desktopName = snapshot.optJSONObject("profile")?.optString("name", "")?.trim().orEmpty()
        if (desktopName.isNotEmpty() && ProfileStore.name == "Trader") ProfileStore.name = desktopName

        if (anyChange) {
            journalList.sortByDescending { it.closedAtMs }
            saveToPrefs()
            notifyListeners()
        }
        return importedTrades to importedPositions
    }

    @Synchronized
    fun updateTradeReview(id: String, emotion: String, rating: Int, setup: String, note: String): Boolean {
        val index = journalList.indexOfFirst { it.id == id }
        if (index < 0) return false
        val current = journalList[index]
        journalList[index] = current.copy(
            emotion = emotion.trim().take(40),
            rating = rating.coerceIn(0, 5),
            setup = setup.trim().take(80),
            note = note.trim().take(1000)
        )
        saveToPrefs()
        notifyListeners()
        return true
    }

    @Synchronized
    fun deleteTrade(id: String) {
        journalList.removeAll { it.id == id }
        saveToPrefs()
        notifyListeners()
    }

    @Synchronized
    fun clearJournal() {
        journalList.clear()
        saveToPrefs()
        notifyListeners()
    }

    private fun fillsToJson(list: List<Fill>): JSONArray {
        val arr = JSONArray()
        for (f in list) {
            arr.put(JSONObject().apply {
                put("side", f.side)
                put("timeMs", f.timeMs)
                put("mc", f.mc)
                put("priceUsd", f.priceUsd)
                put("sol", f.sol)
                put("pct", f.pct)
                put("pnlSol", f.pnlSol)
                put("remainingAfterPct", f.remainingAfterPct)
                put("executionType", f.executionType)
                put("orderId", f.orderId)
                put("taxPct", f.taxPct)
                put("feeSol", f.feeSol)
                put("slippagePct", f.slippagePct)
                put("impactPct", f.impactPct)
            })
        }
        return arr
    }

    private fun fillsFromJson(arr: JSONArray?): List<Fill> {
        val out = ArrayList<Fill>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                Fill(
                    side = o.optString("side", "BUY"),
                    timeMs = o.optLong("timeMs", 0L),
                    mc = o.optDouble("mc", 0.0),
                    priceUsd = o.optDouble("priceUsd", 0.0),
                    sol = o.optDouble("sol", 0.0),
                    pct = o.optDouble("pct", 0.0),
                    pnlSol = o.optDouble("pnlSol", 0.0),
                    remainingAfterPct = o.optDouble("remainingAfterPct", 0.0),
                    executionType = o.optString("executionType", "MANUAL"),
                    orderId = o.optString("orderId", ""),
                    taxPct = o.optDouble("taxPct", 0.0),
                    feeSol = o.optDouble("feeSol", 0.0),
                    slippagePct = o.optDouble("slippagePct", 0.0),
                    impactPct = o.optDouble("impactPct", 0.0)
                )
            )
        }
        return out
    }

    private fun saveToPrefs() {
        val p = prefs ?: return
        val settingsObj = JSONObject().apply {
            put("solBalance", settings.solBalance)
            put("solUsdPrice", settings.solUsdPrice)
            put("platformFeePct", settings.platformFeePct)
            put("priorityFeeSol", settings.priorityFeeSol)
            put("slippagePct", settings.slippagePct)
            put("activeCa", settings.activeCa)
            put("buyPresets", JSONArray(settings.buyPresets))
            put("sellPresets", JSONArray(settings.sellPresets))
        }

        val posArr = JSONArray()
        for (pos in positionsMap.values) {
            posArr.put(JSONObject().apply {
                put("ca", pos.ca)
                put("name", pos.name)
                put("symbol", pos.symbol)
                put("imageUrl", pos.imageUrl)
                put("entryMc", pos.entryMc)
                put("entryPriceUsd", pos.entryPriceUsd)
                put("solInvested", pos.solInvested)
                put("initialSolInvested", pos.initialSolInvested)
                put("tokensHeld", pos.tokensHeld)
                put("remainingPct", pos.remainingPct)
                put("realizedPnlSol", pos.realizedPnlSol)
                put("openedAtMs", pos.openedAtMs)
                put("lastMc", pos.lastMc)
                put("lastPriceUsd", pos.lastPriceUsd)
                put("peakMc", pos.peakMc)
                put("realizedSolOut", pos.realizedSolOut)
                put("maeMc", pos.maeMc)
                put("stopLossMc", pos.stopLossMc)
                put("source", pos.source)
                put("fills", fillsToJson(pos.fills))
            })
        }

        val journalArr = JSONArray()
        for (item in journalList) {
            journalArr.put(JSONObject().apply {
                put("id", item.id)
                put("ca", item.ca)
                put("name", item.name)
                put("symbol", item.symbol)
                put("imageUrl", item.imageUrl)
                put("entryMc", item.entryMc)
                put("avgExitMc", item.avgExitMc)
                put("peakMc", item.peakMc)
                put("solIn", item.solIn)
                put("solOut", item.solOut)
                put("pnlSol", item.pnlSol)
                put("multipleX", item.multipleX)
                put("holdDurationMs", item.holdDurationMs)
                put("openedAtMs", item.openedAtMs)
                put("closedAtMs", item.closedAtMs)
                put("emotion", item.emotion)
                put("rating", item.rating)
                put("setup", item.setup)
                put("note", item.note)
                put("mfePct", item.mfePct)
                put("maePct", item.maePct)
                if (item.rMultiple != null) put("rMultiple", item.rMultiple)
                put("stopLossMc", item.stopLossMc)
                put("fills", fillsToJson(item.fills))
            })
        }

        val ordersArr = JSONArray()
        for (order in ordersMap.values) ordersArr.put(JSONObject().apply {
            put("id", order.id); put("ca", order.ca); put("symbol", order.symbol); put("type", order.type)
            put("triggerMc", order.triggerMc); put("amountSol", order.amountSol); put("sellPct", order.sellPct)
            put("totalOrders", order.totalOrders); put("intervalSeconds", order.intervalSeconds)
            put("minMc", order.minMc); put("maxMc", order.maxMc); put("createdAtMs", order.createdAtMs)
            put("nextExecutionAtMs", order.nextExecutionAtMs); put("completedOrders", order.completedOrders)
            put("status", order.status); put("lastMessage", order.lastMessage)
            put("sellTokensPerOrder", order.sellTokensPerOrder)
        })
        val taxObj = JSONObject()
        for ((ca, tax) in tokenTaxMap) taxObj.put(ca, JSONObject().put("buy", tax.first).put("sell", tax.second))

        p.edit()
            .putString(KEY_SETTINGS, settingsObj.toString())
            .putString(KEY_POSITIONS, posArr.toString())
            .putString(KEY_JOURNAL, journalArr.toString())
            .putString(KEY_ORDERS, ordersArr.toString())
            .putString(KEY_TOKEN_TAXES, taxObj.toString())
            .apply()
    }

    private fun loadFromPrefs() {
        val p = prefs ?: return
        try {
            val sRaw = p.getString(KEY_SETTINGS, null)
            if (!sRaw.isNullOrEmpty()) {
                val o = JSONObject(sRaw)
                val buys = ArrayList<Double>()
                val bArr = o.optJSONArray("buyPresets")
                if (bArr != null && bArr.length() >= 4) {
                    for (i in 0 until min(8, bArr.length())) buys.add(bArr.optDouble(i, 0.5))
                    if (buys.size == 4) buys.addAll(listOf(0.1, 0.25, 1.5, 2.0))
                } else {
                    buys.addAll(listOf(0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 2.5))
                }
                val sells = ArrayList<Double>()
                val sArr = o.optJSONArray("sellPresets")
                if (sArr != null && sArr.length() >= 4) {
                    for (i in 0 until min(8, sArr.length())) sells.add(sArr.optDouble(i, 25.0))
                    if (sells.size == 4) sells.addAll(listOf(10.0, 20.0, 75.0, 90.0))
                } else {
                    sells.addAll(listOf(10.0, 20.0, 25.0, 30.0, 50.0, 75.0, 90.0, 100.0))
                }
                settings = AppSettings(
                    solBalance = o.optDouble("solBalance", 10.0),
                    solUsdPrice = o.optDouble("solUsdPrice", 185.0),
                    platformFeePct = o.optDouble("platformFeePct", 1.0),
                    priorityFeeSol = o.optDouble("priorityFeeSol", 0.005),
                    slippagePct = o.optDouble("slippagePct", 1.5),
                    buyPresets = buys,
                    sellPresets = sells,
                    activeCa = o.optString("activeCa", "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr")
                )
            }

            val posRaw = p.getString(KEY_POSITIONS, null)
            positionsMap.clear()
            if (!posRaw.isNullOrEmpty()) {
                val arr = JSONArray(posRaw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val pos = OpenPosition(
                        ca = o.optString("ca"),
                        name = o.optString("name", "Token"),
                        symbol = o.optString("symbol", "TOK"),
                        imageUrl = o.optString("imageUrl", ""),
                        entryMc = o.optDouble("entryMc", 10000.0),
                        entryPriceUsd = o.optDouble("entryPriceUsd", 0.0001),
                        solInvested = o.optDouble("solInvested", 1.0),
                        initialSolInvested = o.optDouble("initialSolInvested", 1.0),
                        tokensHeld = o.optDouble("tokensHeld", 1000.0),
                        remainingPct = o.optDouble("remainingPct", 100.0),
                        realizedPnlSol = o.optDouble("realizedPnlSol", 0.0),
                        openedAtMs = o.optLong("openedAtMs", System.currentTimeMillis()),
                        lastMc = o.optDouble("lastMc", 10000.0),
                        lastPriceUsd = o.optDouble("lastPriceUsd", 0.0001),
                        source = o.optString("source", "mobile")
                    )
                    pos.peakMc = o.optDouble("peakMc", pos.lastMc).coerceAtLeast(pos.lastMc)
                    pos.maeMc = o.optDouble("maeMc", pos.lastMc).let { if (it > 0.0) it else pos.lastMc }
                    pos.stopLossMc = o.optDouble("stopLossMc", 0.0)
                    pos.realizedSolOut = if (o.has("realizedSolOut")) {
                        o.optDouble("realizedSolOut", 0.0)
                    } else {
                        max(0.0, (pos.initialSolInvested - pos.solInvested) + pos.realizedPnlSol)
                    }
                    pos.fills.addAll(fillsFromJson(o.optJSONArray("fills")))
                    if (pos.fills.isEmpty()) {
                        pos.fills.add(
                            Fill("BUY", pos.openedAtMs, pos.entryMc, pos.entryPriceUsd, pos.initialSolInvested)
                        )
                    }
                    if (pos.ca.isNotEmpty()) positionsMap[pos.ca] = pos
                }
            }

            val jRaw = p.getString(KEY_JOURNAL, null)
            journalList.clear()
            if (!jRaw.isNullOrEmpty()) {
                val arr = JSONArray(jRaw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    journalList.add(
                        ClosedTradeLog(
                            id = o.optString("id"),
                            ca = o.optString("ca"),
                            name = o.optString("name"),
                            symbol = o.optString("symbol"),
                            imageUrl = o.optString("imageUrl"),
                            entryMc = o.optDouble("entryMc", 0.0),
                            avgExitMc = o.optDouble("avgExitMc", 0.0),
                            peakMc = o.optDouble("peakMc", 0.0),
                            solIn = o.optDouble("solIn", 0.0),
                            solOut = o.optDouble("solOut", 0.0),
                            pnlSol = o.optDouble("pnlSol", 0.0),
                            multipleX = o.optDouble("multipleX", 1.0),
                            holdDurationMs = o.optLong("holdDurationMs", 1000L),
                            openedAtMs = o.optLong("openedAtMs", 0L),
                            closedAtMs = o.optLong("closedAtMs", System.currentTimeMillis()),
                            fills = fillsFromJson(o.optJSONArray("fills")),
                            emotion = o.optString("emotion", ""),
                            rating = o.optInt("rating", 0),
                            setup = o.optString("setup", ""),
                            note = o.optString("note", ""),
                            mfePct = o.optDouble("mfePct", 0.0),
                            maePct = o.optDouble("maePct", 0.0),
                            rMultiple = if (o.has("rMultiple")) o.optDouble("rMultiple") else null,
                            stopLossMc = o.optDouble("stopLossMc", 0.0)
                        )
                    )
                }
            }

            ordersMap.clear()
            val ordersRaw = p.getString(KEY_ORDERS, null)
            if (!ordersRaw.isNullOrEmpty()) {
                val arr = JSONArray(ordersRaw)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val order = PaperOrder(
                        id = o.optString("id", ""), ca = o.optString("ca", ""),
                        symbol = o.optString("symbol", "TOK"), type = o.optString("type", ""),
                        triggerMc = o.optDouble("triggerMc", 0.0), amountSol = o.optDouble("amountSol", 0.0),
                        sellPct = o.optDouble("sellPct", 100.0), totalOrders = o.optInt("totalOrders", 1),
                        intervalSeconds = o.optLong("intervalSeconds", 0L), minMc = o.optDouble("minMc", 0.0),
                        maxMc = o.optDouble("maxMc", 0.0), createdAtMs = o.optLong("createdAtMs", 0L),
                        nextExecutionAtMs = o.optLong("nextExecutionAtMs", 0L),
                        completedOrders = o.optInt("completedOrders", 0), status = o.optString("status", "ACTIVE"),
                        lastMessage = o.optString("lastMessage", ""),
                        sellTokensPerOrder = o.optDouble("sellTokensPerOrder", 0.0)
                    )
                    if (order.id.isNotBlank() && order.ca.isNotBlank()) ordersMap[order.id] = order
                }
            }

            tokenTaxMap.clear()
            val taxesRaw = p.getString(KEY_TOKEN_TAXES, null)
            if (!taxesRaw.isNullOrEmpty()) {
                val obj = JSONObject(taxesRaw)
                val it = obj.keys()
                while (it.hasNext()) {
                    val ca = it.next()
                    val tax = obj.optJSONObject(ca) ?: continue
                    tokenTaxMap[ca] = tax.optDouble("buy", 0.0).coerceIn(0.0, 99.0) to
                        tax.optDouble("sell", 0.0).coerceIn(0.0, 99.0)
                }
            }
        } catch (_: Throwable) {}
    }
}
