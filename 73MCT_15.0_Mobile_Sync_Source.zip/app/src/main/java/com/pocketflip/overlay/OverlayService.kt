package com.pocketflip.overlay

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        @Volatile
        var isRunning: Boolean = false

        @Volatile
        private var instance: OverlayService? = null

        fun onInstantScreenMcDetected(screenMc: Double) {
            val svc = instance ?: return
            svc.applyInstantScreenMc(screenMc)
        }
    }

    private lateinit var windowManager: WindowManager
    private lateinit var rootContainer: FrameLayout
    private lateinit var params: WindowManager.LayoutParams
    private val mainHandler = Handler(Looper.getMainLooper())
    private var poller: ScheduledExecutorService? = null

    // Minimized pill
    private lateinit var pillCard: LinearLayout
    private lateinit var pillIcon: ImageView
    private lateinit var pillTickerText: TextView
    private lateinit var pillPnlText: TextView
    private lateinit var pillMultBadge: TextView
    private lateinit var pillSubText: TextView

    // Expanded trading panel
    private lateinit var hudCard: LinearLayout
    private lateinit var hudTokenIcon: ImageView
    private lateinit var hudTickerText: TextView
    private lateinit var hudNameText: TextView
    private lateinit var hudBanner: TextView
    private lateinit var hudLinksRow: LinearLayout
    private lateinit var dexChip: TextView
    private lateinit var xChip: TextView
    private var linksCa: String = ""
    private var xUrl: String = ""
    private lateinit var hudLiveMcValue: TextView
    private lateinit var hudLivePnlValue: TextView
    private lateinit var hudMultipleValue: TextView
    private lateinit var hudBoughtMcValue: TextView
    private lateinit var hudRealizedValue: TextView
    private lateinit var hudBagLeftValue: TextView
    private lateinit var hudSolBalanceText: TextView
    private lateinit var hudFeeInfoText: TextView
    private lateinit var quoteStatusText: TextView
    private lateinit var ordersButton: TextView
    private lateinit var hudTradeBody: LinearLayout
    private var hudWidthPx: Int = 0
    private lateinit var hudInfoScroll: ScrollView
    private lateinit var hudTradeTab: TextView
    private lateinit var hudInfoTab: TextView
    private lateinit var infoStatusText: TextView
    private lateinit var infoTop10Text: TextView
    private lateinit var infoDevText: TextView
    private lateinit var infoInsiderText: TextView
    private lateinit var infoSniperText: TextView
    private lateinit var infoBundleText: TextView
    private lateinit var infoMigrationText: TextView
    private lateinit var infoDevWalletText: TextView
    private lateinit var infoDevHistoryText: TextView
    private lateinit var infoHoldersBox: LinearLayout
    private var showingInfoPane: Boolean = false
    private var tokenIntelCache: TokenIntel? = null
    private var tokenIntelLoadingFor: String = ""
    private var tokenIntelLastRequestedAt: Long = 0L
    private lateinit var buyButtonsRow: LinearLayout
    private lateinit var sellButtonsRow: LinearLayout
    private lateinit var customSellPctInput: EditText
    private lateinit var thesisInput: EditText
    private val selectedTags = LinkedHashSet<String>()
    @Volatile private var tradeActionPending: Boolean = false
    private val thesisChips = ArrayList<Pair<String, TextView>>()

    private val blankToken = TokenInfo(
        ca = "",
        name = "No coin selected",
        symbol = "-",
        priceUsd = 0.0,
        solUsdPrice = 185.0,
        marketCap = 0.0,
        liquidityUsd = 0.0,
        volume24h = 0.0,
        imageUrl = ""
    )

    @Volatile private var currentToken: TokenInfo = TokenInfo(
        ca = "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr",
        name = "Popcat",
        symbol = "POPCAT",
        priceUsd = 0.0452,
        solUsdPrice = 185.0,
        marketCap = 41890000.0,
        liquidityUsd = 2830000.0,
        volume24h = 10050000.0,
        imageUrl = ""
    )

    // True after the Reset button: ignore late price ticks of the old coin until a new CA is pasted
    @Volatile
    private var panelCleared: Boolean = false

    private var builtThemeVersion: Int = -1
    private var loadedImageUrl: String = ""
    private var lastBitmap: Bitmap? = null
    private var hideBannerRunnable: Runnable? = null
    private var pillFlashUntil: Long = 0L
    private var pillFlashMsg: String = ""

    private val repoListener: () -> Unit = {
        mainHandler.post {
            if (builtThemeVersion != Theme.version) {
                rebuildOverlayForTheme()
            } else {
                refreshHudAndPillUI()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        TradeRepository.init(this)
        ThesisStore.init(this)
        Theme.init(this)
        CoinImages.init(this)
        PathStore.init(this)
        isRunning = true
        instance = this
        startForegroundServiceNotification()

        if (TradeRepository.settings.activeCa.isBlank()) {
            panelCleared = true
            currentToken = blankToken
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = getSharedPreferences("73mct_overlay_ui", Context.MODE_PRIVATE).getInt("x", dp(16)).coerceAtLeast(0)
            y = getSharedPreferences("73mct_overlay_ui", Context.MODE_PRIVATE).getInt("y", dp(140)).coerceAtLeast(0)
        }

        buildNativeOverlayViews()
        TradeRepository.addListener(repoListener)
        try {
            windowManager.addView(rootContainer, params)
        } catch (e: Exception) {
            Toast.makeText(this, "Permission required: Enable 'Display over other apps'", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        // Free Shrine live-price WebSocket; HTTP only seeds metadata and checks active CA.
        val wsCallback: (TokenInfo) -> Unit = { liveToken ->
            val activeCa = TradeRepository.settings.activeCa
            if (!panelCleared && liveToken.ca == activeCa) {
                // WebSocket updates must retain the user's per-mint tax settings too.
                currentToken = TradeRepository.withStoredTokenTaxes(liveToken)
                TradeRepository.syncLiveTokenData(currentToken)
                val orderMessages = TradeRepository.evaluateOrders(currentToken)
                mainHandler.post {
                    refreshHudAndPillUI()
                    if (orderMessages.isNotEmpty()) announce(orderMessages.first(), true)
                }
            }
        }

        poller = Executors.newSingleThreadScheduledExecutor()
        poller?.scheduleWithFixedDelay({
            try {
                val activeCa = TradeRepository.settings.activeCa
                if (activeCa.isBlank() || panelCleared) return@scheduleWithFixedDelay
                // This was previously calling fetchInitialTokenMetadata() every 2 seconds. That
                // method intentionally returns its cached snapshot once subscribed, so coins
                // without Shrine socket events stayed frozen. Poll on-chain pools first, then
                // DexScreener is used as a rate-limited fallback for unsupported pool layouts.
                val token = DexScreenerClient.pollLiveOnChainPrice(activeCa, wsCallback)
                if (token != null && !panelCleared && TradeRepository.settings.activeCa == activeCa && token.ca == activeCa) {
                    currentToken = TradeRepository.withStoredTokenTaxes(token)
                    TradeRepository.syncLiveTokenData(currentToken)
                    val orderMessages = TradeRepository.evaluateOrders(currentToken)
                    mainHandler.post {
                        refreshHudAndPillUI()
                        if (orderMessages.isNotEmpty()) announce(orderMessages.first(), true)
                    }
                    val imgKey = token.ca + "|" + token.imageUrl
                    if (loadedImageUrl != imgKey) {
                        loadedImageUrl = imgKey
                        loadPanelImage(token)
                    }
                } else {
                    // A null/failed read must still advance the visible quote age.
                    mainHandler.post { refreshHudAndPillUI() }
                }
            } catch (_: Throwable) {
                // Force the UI to age the last quote even when the network request fails.
                mainHandler.post { refreshHudAndPillUI() }
            }
        }, 0, 2, TimeUnit.SECONDS)
    }

    // =====================================================================
    // UI BUILDING
    // =====================================================================

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams {
        return if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildNativeOverlayViews() {
        builtThemeVersion = Theme.version
        rootContainer = FrameLayout(this)

        val cText = Theme.text
        val cMuted = Theme.muted
        val cBorder = Theme.border
        val cCard = Theme.card
        val cBg = Theme.bg

        // ------------------------------------------------------------------
        // MINIMIZED PILL
        // ------------------------------------------------------------------
        pillCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(14), dp(7))
            background = Theme.surface(dp(22), cText, dp(1), 0xF2)
            visibility = View.GONE
        }

        pillIcon = Theme.avatar(this, dp(30), dp(1)).apply {
            (layoutParams as LinearLayout.LayoutParams).rightMargin = dp(8)
        }

        val pillTextCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pillTopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        pillTickerText = tv("\$POPCAT", 12f, cText, bold = true).apply { setPadding(0, 0, dp(6), 0) }
        pillPnlText = tv("+0.000 SOL", 12f, cText, bold = true, mono = true).apply { setPadding(0, 0, dp(6), 0) }
        pillMultBadge = tv("1.00x", 11f, cText, bold = true, mono = true).apply {
            setPadding(dp(6), dp(1), dp(6), dp(1))
            background = Theme.box(Theme.alpha(cText, 0x1F), cBorder, dp(6), dp(1))
        }
        pillTopRow.addView(pillTickerText)
        pillTopRow.addView(pillPnlText)
        pillTopRow.addView(pillMultBadge)

        pillSubText = tv("Tap to trade", 10f, cMuted, mono = true)
        pillTextCol.addView(pillTopRow)
        pillTextCol.addView(pillSubText)

        pillCard.addView(pillIcon)
        pillCard.addView(pillTextCol)

        // ------------------------------------------------------------------
        // EXPANDED TRADING PANEL
        // ------------------------------------------------------------------
        val widthPrefs = getSharedPreferences("73mct_overlay_ui", Context.MODE_PRIVATE)
        val maxWidthDp = ((resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt() - 24).coerceAtLeast(280)
        val savedWidthDp = widthPrefs.getInt("widthDp", 320).coerceIn(280, minOf(460, maxWidthDp))
        hudWidthPx = dp(savedWidthDp)
        hudCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Theme.surface(dp(22), cBorder, dp(1), 0xF5)
            layoutParams = FrameLayout.LayoutParams(hudWidthPx, FrameLayout.LayoutParams.WRAP_CONTENT)
        }

        // Header (drag handle)
        val hudHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(10), dp(8))
        }

        hudTokenIcon = Theme.avatar(this, dp(34), dp(1)).apply {
            (layoutParams as LinearLayout.LayoutParams).rightMargin = dp(10)
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hudTickerText = tv("No coin", 15f, cText, bold = true).apply {
            maxLines = 1
        }
        hudNameText = tv("Tap Paste to load a CA", 10f, cMuted).apply {
            maxLines = 1
        }
        titleCol.addView(hudTickerText)
        titleCol.addView(hudNameText)

        fun headerBtn(label: String, onClick: () -> Unit): TextView {
            return tv(label, 11f, cText, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = Theme.box(Theme.alpha(cText, 0x14), cBorder, dp(10), dp(1))
                layoutParams = lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    leftMargin = dp(5)
                }
                setOnClickListener {
                    pressFx(this)
                    onClick()
                }
            }
        }

        val pasteBtn = headerBtn("Paste CA") { pasteCaFromClipboard() }
        val resetBtn = headerBtn("Reset") { resetPanel() }
        val minimizeBtn = headerBtn("—") { switchToMinimizedPill() }

        hudHeader.addView(hudTokenIcon)
        hudHeader.addView(titleCol)
        hudHeader.addView(pasteBtn)
        hudHeader.addView(resetBtn)
        hudHeader.addView(minimizeBtn)

        // Dex + X link buttons (shown once a coin is loaded)
        fun linkChip(label: String, onClick: () -> Unit): TextView {
            return tv(label, 11f, cText, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(7), dp(14), dp(7))
                background = Theme.box(Theme.alpha(cText, 0x14), cBorder, dp(10), dp(1))
                layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
                setOnClickListener {
                    pressFx(this)
                    onClick()
                }
            }
        }
        dexChip = linkChip("Dex chart") {
            if (currentToken.ca.isNotBlank()) openLink(CoinLinkFinder.dexUrl(currentToken.ca))
        }
        xChip = linkChip("X search") { onXTapped() }
        val fomoChip = linkChip("Fomo") { openFomo() }
        hudLinksRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(12)
                rightMargin = dp(6)
                bottomMargin = dp(6)
            }
            addView(dexChip)
            addView(xChip)
            addView(fomoChip)
        }

        // Action banner (shows "SOLD 25%" etc.)
        hudBanner = tv("", 12f, cBg, bold = true, mono = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(8))
            visibility = View.GONE
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(12)
                rightMargin = dp(12)
                bottomMargin = dp(6)
            }
        }

        hudTradeBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(2), dp(12), dp(12))
        }

        // Stats box
        val statsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.box(cBg, cBorder, dp(14), dp(1))
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }

        val statsTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
        }

        val colMc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f)
        }
        colMc.addView(tv("Market cap", 10f, cMuted))
        hudLiveMcValue = tv("—", 17f, cText, bold = true, mono = true)
        colMc.addView(hudLiveMcValue)

        val colPnl = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
        }
        colPnl.addView(tv("PnL", 10f, cMuted))
        hudLivePnlValue = tv("0.000 SOL", 13f, cMuted, bold = true, mono = true)
        colPnl.addView(hudLivePnlValue)

        val colMult = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
        }
        colMult.addView(tv("Multiple", 10f, cMuted))
        hudMultipleValue = tv("1.00x", 15f, cText, bold = true, mono = true)
        colMult.addView(hudMultipleValue)

        statsTop.addView(colMc)
        statsTop.addView(colPnl)
        statsTop.addView(colMult)

        val divider = View(this).apply {
            setBackgroundColor(cBorder)
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
                topMargin = dp(8)
                bottomMargin = dp(8)
            }
        }

        val statsSub = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
        }
        hudBoughtMcValue = tv("Bought —", 10f, cMuted, mono = true).apply {
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hudRealizedValue = tv("Realized —", 10f, cMuted, mono = true).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f)
        }
        hudBagLeftValue = tv("Bag 0%", 10f, cMuted, mono = true).apply {
            gravity = Gravity.END
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.9f)
        }
        statsSub.addView(hudBoughtMcValue)
        statsSub.addView(hudRealizedValue)
        statsSub.addView(hudBagLeftValue)

        statsBox.addView(statsTop)
        statsBox.addView(divider)
        statsBox.addView(statsSub)

        quoteStatusText = tv("WAITING FOR A VERIFIED PRICE", 9f, cMuted, mono = true).apply {
            setPadding(dp(2), dp(1), dp(2), dp(7))
        }

        // Buy section
        val buyHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
        }
        buyHeaderRow.addView(tv("BUY (SOL)", 11f, cText, bold = true).apply {
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        hudSolBalanceText = tv("Bal 10.00 SOL", 11f, cMuted, mono = true)
        buyHeaderRow.addView(hudSolBalanceText)

        buyButtonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }

        // Sell section
        val sellHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
        }
        sellHeaderRow.addView(tv("SELL (% of bag)", 11f, cText, bold = true).apply {
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        hudFeeInfoText = tv("Fee 1% + 0.005 SOL", 10f, cMuted, mono = true)
        sellHeaderRow.addView(hudFeeInfoText)

        sellButtonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(10)
            }
        }

        // Custom sell row
        val customSellRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        customSellPctInput = EditText(this).apply {
            hint = "Custom %"
            setText("30")
            setHintTextColor(cMuted)
            setTextColor(cText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.MONOSPACE
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = Theme.box(cBg, cBorder, dp(10), dp(1))
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            setOnClickListener { enableKeyboardFocus(true) }
        }

        val customSellBtn = tv("Sell %", 12f, Theme.onColor(Theme.sell), bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = Theme.box(Theme.sell, Theme.sell, dp(10), 0)
            layoutParams = lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                rightMargin = dp(6)
            }
            setOnClickListener {
                val pct = customSellPctInput.text.toString().toDoubleOrNull() ?: 30.0
                enableKeyboardFocus(false)
                pressFx(this)
                handleSellClick(pct, this)
            }
        }

        val hideBtn = tv("Hide", 12f, cText, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = Theme.box(Theme.alpha(cText, 0x14), cBorder, dp(10), dp(1))
            setOnClickListener {
                pressFx(this)
                switchToMinimizedPill()
            }
        }

        customSellRow.addView(customSellPctInput)
        customSellRow.addView(customSellBtn)
        customSellRow.addView(hideBtn)

        val executionToolsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(7)
                bottomMargin = dp(8)
            }
        }
        fun toolButton(label: String, color: Int = cText, action: () -> Unit): TextView = tv(label, 10.5f, color, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(9), dp(7), dp(9))
            background = Theme.box(Theme.card, Theme.border, dp(10), dp(1))
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(5) }
            setOnClickListener { pressFx(this); action() }
        }
        executionToolsRow.addView(toolButton("SELL INITIAL", Theme.buy) { handleSellInitial() })
        ordersButton = toolButton("ORDERS") { showOrdersDialog() }
        executionToolsRow.addView(ordersButton)
        executionToolsRow.addView(toolButton("TAX") { showTokenTaxDialog() })

        // Thesis (optional): why this buy? Saved with the trade when you press a buy button.
        thesisChips.clear()
        val thesisBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        thesisInput = EditText(this).apply {
            hint = "Thesis: why this buy? (optional)"
            setHintTextColor(cMuted)
            setTextColor(cText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSingleLine(true)
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(120))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = Theme.box(cBg, cBorder, dp(10), dp(1))
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
            setOnClickListener { enableKeyboardFocus(true) }
        }
        thesisBox.addView(thesisInput)
        val tagRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = ThesisStore.tags.size.toFloat()
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        for ((i, tag) in ThesisStore.tags.withIndex()) {
            val chip = tv(tag, 10f, cText, bold = true).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(dp(2), dp(7), dp(2), dp(7))
                layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (i < ThesisStore.tags.size - 1) rightMargin = dp(5)
                }
                setOnClickListener {
                    if (selectedTags.contains(tag)) selectedTags.remove(tag) else selectedTags.add(tag)
                    paintThesisChips()
                }
            }
            thesisChips.add(tag to chip)
            tagRow.addView(chip)
        }
        thesisBox.addView(tagRow)
        paintThesisChips()

        hudTradeBody.addView(statsBox)
        hudTradeBody.addView(quoteStatusText)
        hudTradeBody.addView(buyHeaderRow)
        hudTradeBody.addView(thesisBox)
        hudTradeBody.addView(buyButtonsRow)
        hudTradeBody.addView(sellHeaderRow)
        hudTradeBody.addView(sellButtonsRow)
        hudTradeBody.addView(customSellRow)
        hudTradeBody.addView(executionToolsRow)

        // Trade / Info switch keeps the floating panel useful without opening the main app.
        val modeSwitch = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(3), dp(4), dp(3))
            background = Theme.box(cBg, cBorder, dp(12), dp(1))
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(12); rightMargin = dp(12); bottomMargin = dp(8)
            }
        }
        fun modeTab(label: String, onClick: () -> Unit): TextView {
            return tv(label, 11f, cMuted, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(8), dp(10), dp(8))
                layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { pressFx(this); onClick() }
            }
        }
        hudTradeTab = modeTab("TRADE") { showOverlayPane(false) }
        hudInfoTab = modeTab("INFO  ·  HOLDERS") { showOverlayPane(true) }
        modeSwitch.addView(hudTradeTab)
        modeSwitch.addView(hudInfoTab)

        hudInfoScroll = ScrollView(this).apply {
            isFillViewport = false
            visibility = View.GONE
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(430)).apply {
                leftMargin = dp(12); rightMargin = dp(12); bottomMargin = dp(12)
            }
            isVerticalScrollBarEnabled = false
        }
        val infoContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(1), dp(1), dp(1), dp(8))
        }
        val infoHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(7) }
        }
        infoHeader.addView(tv("TOKEN INTEL", 10f, cMuted, bold = true).apply {
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        val infoRefresh = tv("Refresh ↻", 10f, cText, bold = true).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = Theme.box(Theme.alpha(cText, 0x14), cBorder, dp(9), dp(1))
            setOnClickListener { pressFx(this); requestTokenIntel(force = true) }
        }
        infoHeader.addView(infoRefresh)
        infoContent.addView(infoHeader)

        infoStatusText = tv("Switch to Info to load holder data", 10f, cMuted).apply {
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = Theme.box(cBg, cBorder, dp(10), dp(1))
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
        }
        infoContent.addView(infoStatusText)

        fun infoMetric(label: String): LinearLayout {
            return LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(8), dp(6), dp(8))
                background = Theme.box(cBg, cBorder, dp(10), dp(1))
                layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(5) }
                addView(tv(label, 9f, cMuted, bold = true))
            }
        }
        fun metricValue(value: String): TextView = tv(value, 15f, cText, bold = true, mono = true)
        val metricsRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(5) } }
        val top10Card = infoMetric("TOP 10")
        infoTop10Text = metricValue("—"); top10Card.addView(infoTop10Text)
        val devCard = infoMetric("DEV HOLD")
        infoDevText = metricValue("—"); devCard.addView(infoDevText)
        val insiderCard = infoMetric("INSIDERS")
        infoInsiderText = metricValue("—"); insiderCard.addView(infoInsiderText)
        metricsRow1.addView(top10Card); metricsRow1.addView(devCard); metricsRow1.addView(insiderCard)
        infoContent.addView(metricsRow1)

        val metricsRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) } }
        val sniperCard = infoMetric("SNIPERS")
        infoSniperText = metricValue("—"); sniperCard.addView(infoSniperText)
        val bundleCard = infoMetric("BUNDLERS")
        infoBundleText = metricValue("—"); bundleCard.addView(infoBundleText)
        val migrationCard = infoMetric("MIGRATION")
        infoMigrationText = metricValue("—").apply { setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f) }
        migrationCard.addView(infoMigrationText)
        metricsRow2.addView(sniperCard); metricsRow2.addView(bundleCard); metricsRow2.addView(migrationCard)
        infoContent.addView(metricsRow2)

        infoContent.addView(tv("DEVELOPER / CREATOR", 9f, cMuted, bold = true).apply { setPadding(dp(1), dp(2), 0, dp(4)) })
        infoDevWalletText = tv("Not available", 10f, cText, mono = true).apply {
            setPadding(dp(9), dp(8), dp(9), dp(8))
            background = Theme.box(cBg, cBorder, dp(9), dp(1))
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            setOnClickListener {
                val intel = tokenIntelCache
                if (intel != null && intel.devAddress.isNotBlank()) {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Developer wallet", intel.devAddress))
                    announce("Developer address copied", true)
                }
            }
        }
        infoContent.addView(infoDevWalletText)
        infoDevHistoryText = tv("Dev migrations: unavailable", 9f, cMuted).apply {
            setPadding(dp(2), 0, dp(2), dp(8))
        }
        infoContent.addView(infoDevHistoryText)

        infoContent.addView(tv("TOP HOLDERS", 9f, cMuted, bold = true).apply { setPadding(dp(1), dp(4), 0, dp(5)) })
        infoHoldersBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9), dp(4), dp(9), dp(4))
            background = Theme.box(cBg, cBorder, dp(10), dp(1))
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
        }
        infoContent.addView(infoHoldersBox)

        val infoLinks = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun intelLink(label: String, urlForCa: (String) -> String): TextView = tv(label, 10f, cText, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(9), dp(8), dp(9))
            background = Theme.box(Theme.alpha(cText, 0x14), cBorder, dp(9), dp(1))
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(5) }
            setOnClickListener { val ca = currentToken.ca; if (ca.isNotBlank()) openLink(urlForCa(ca)) }
        }
        infoLinks.addView(intelLink("Open Solscan") { "https://solscan.io/token/$it" })
        infoContent.addView(infoLinks)
        infoContent.addView(tv("Vybe provides the ranked holder list and supply shares. Top 10 is calculated from the returned rows. Developer, insider, sniper and bundler tags are left unverified until transaction-level evidence is available; holder size alone is not proof.", 9f, cMuted).apply {
            setPadding(dp(2), dp(7), dp(2), 0)
        })
        hudInfoScroll.addView(infoContent)

        hudCard.addView(hudHeader)
        hudCard.addView(hudLinksRow)
        hudCard.addView(hudBanner)
        hudCard.addView(modeSwitch)
        hudCard.addView(hudTradeBody)
        hudCard.addView(hudInfoScroll)

        val resizeHandle = tv("↔  DRAG TO RESIZE", 8.5f, cMuted, bold = true, mono = true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(7))
            contentDescription = "Drag left or right to resize the trading panel"
        }
        hudCard.addView(resizeHandle)
        resizeHandle.setOnTouchListener(object : View.OnTouchListener {
            private var startRawX = 0f
            private var startWidth = 0
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startRawX = event.rawX
                        startWidth = hudCard.width.takeIf { it > 0 } ?: hudWidthPx
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val maxPx = (resources.displayMetrics.widthPixels - params.x - dp(12)).coerceAtLeast(dp(280))
                        val minPx = dp(280)
                        val nextWidth = (startWidth + (event.rawX - startRawX).toInt()).coerceIn(minPx, minOf(dp(460), maxPx))
                        hudWidthPx = nextWidth
                        hudCard.layoutParams = (hudCard.layoutParams as FrameLayout.LayoutParams).apply { width = nextWidth }
                        hudCard.requestLayout()
                        rootContainer.requestLayout()
                        try { windowManager.updateViewLayout(rootContainer, params) } catch (_: Throwable) {}
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val widthDp = (hudWidthPx / resources.displayMetrics.density).toInt().coerceIn(280, 460)
                        getSharedPreferences("73mct_overlay_ui", Context.MODE_PRIVATE).edit()
                            .putInt("widthDp", widthDp).apply()
                        return true
                    }
                }
                return false
            }
        })

        rootContainer.addView(
            pillCard,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        )
        rootContainer.addView(hudCard)

        // Touch dragging for pill + header
        val dragTouchListener = object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        params.x = startX + dx
                        params.y = startY + dy
                        windowManager.updateViewLayout(rootContainer, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            getSharedPreferences("73mct_overlay_ui", Context.MODE_PRIVATE).edit()
                                .putInt("x", params.x).putInt("y", params.y).apply()
                        }
                        if (!moved && v == pillCard) {
                            switchToExpandedHud()
                        }
                        return true
                    }
                }
                return false
            }
        }

        pillCard.setOnTouchListener(dragTouchListener)
        hudHeader.setOnTouchListener(dragTouchListener)

        lastBitmap?.let { setTokenBitmap(it) }
        rebuildPresetButtons()
        refreshHudAndPillUI()
        showOverlayPane(showingInfoPane, loadData = false)
    }

    private fun rebuildOverlayForTheme() {
        val wasPill = ::pillCard.isInitialized && pillCard.visibility == View.VISIBLE
        try {
            windowManager.removeView(rootContainer)
        } catch (_: Throwable) {
        }
        buildNativeOverlayViews()
        try {
            windowManager.addView(rootContainer, params)
        } catch (_: Throwable) {
        }
        if (wasPill) {
            hudCard.visibility = View.GONE
            pillCard.visibility = View.VISIBLE
        }
    }

    private fun rebuildPresetButtons() {
        fun buildRows(container: LinearLayout, values: List<Double>, isBuy: Boolean) {
            container.removeAllViews()
            val accent = if (isBuy) Theme.buy else Theme.sell
            val textColor = if (isBuy) Theme.onColor(accent) else accent
            values.take(8).chunked(4).forEachIndexed { rowIndex, chunk ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    weightSum = 4f
                    layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        if (rowIndex > 0) topMargin = dp(6)
                    }
                }
                chunk.forEachIndexed { index, value ->
                    val label = if (isBuy) Formatters.amount(value) else "${value.toInt()}%"
                    val button = tv(label, 12.5f, textColor, bold = true, mono = true).apply {
                        gravity = Gravity.CENTER
                        minHeight = dp(38)
                        setPadding(dp(4), dp(9), dp(4), dp(9))
                        background = if (isBuy) Theme.box(accent, accent, dp(11), 0)
                            else Theme.box(Theme.bg, accent, dp(11), dp(2))
                        layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                            if (index < chunk.size - 1) rightMargin = dp(6)
                        }
                        setOnClickListener {
                            pressFx(this)
                            if (isBuy) handleBuyClick(value) else handleSellClick(value, this)
                        }
                    }
                    row.addView(button)
                }
                while (chunk.size < 4 && row.childCount < 4) {
                    row.addView(View(this).apply { layoutParams = lp(0, dp(38), 1f) })
                    // The rows are normally 4-wide; this keeps a custom 5–7 preset set aligned.
                }
                container.addView(row)
            }
        }
        buildRows(buyButtonsRow, TradeRepository.settings.buyPresets, true)
        buildRows(sellButtonsRow, TradeRepository.settings.sellPresets, false)
    }

    // =====================================================================
    // ANIMATIONS / FEEDBACK
    // =====================================================================

    private fun pressFx(v: View) {
        try {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        } catch (_: Throwable) {
        }
        v.animate().cancel()
        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
    }

    /** Fills a sell button solid for a moment so you can see the tap registered. */
    private fun flashSellButton(btn: TextView) {
        val sellColor = Theme.sell
        btn.background = Theme.box(sellColor, sellColor, dp(12), dp(2))
        btn.setTextColor(Theme.onColor(sellColor))
        mainHandler.postDelayed({
            btn.background = Theme.box(Theme.bg, sellColor, dp(12), dp(2))
            btn.setTextColor(sellColor)
        }, 380)
    }

    private fun showBanner(msg: String, ok: Boolean) {
        hideBannerRunnable?.let { mainHandler.removeCallbacks(it) }
        hudBanner.animate().cancel()
        hudBanner.text = msg
        if (ok) {
            hudBanner.background = Theme.box(Theme.text, Theme.text, dp(12), 0)
            hudBanner.setTextColor(Theme.onColor(Theme.text))
        } else {
            hudBanner.background = Theme.box(Theme.bg, Theme.loss, dp(12), dp(1))
            hudBanner.setTextColor(Theme.text)
        }
        hudBanner.visibility = View.VISIBLE
        hudBanner.alpha = 0f
        hudBanner.translationY = -dp(10).toFloat()
        hudBanner.animate().alpha(1f).translationY(0f).setDuration(170).start()

        val r = Runnable {
            hudBanner.animate().alpha(0f).setDuration(260).withEndAction {
                if (hudBanner.alpha < 0.05f) hudBanner.visibility = View.GONE
            }.start()
        }
        hideBannerRunnable = r
        mainHandler.postDelayed(r, 2400)
    }

    private fun flashPill(msg: String) {
        pillFlashMsg = msg
        pillFlashUntil = System.currentTimeMillis() + 2400
        pillSubText.text = msg
        pillCard.animate().cancel()
        pillCard.animate().scaleX(1.08f).scaleY(1.08f).setDuration(110).withEndAction {
            pillCard.animate().scaleX(1f).scaleY(1f).setDuration(170).start()
        }.start()
        mainHandler.postDelayed({ refreshHudAndPillUI() }, 2450)
    }

    private fun pulseBag() {
        hudBagLeftValue.animate().cancel()
        hudBagLeftValue.alpha = 0.15f
        hudBagLeftValue.animate().alpha(1f).setDuration(500).start()
        hudRealizedValue.animate().cancel()
        hudRealizedValue.alpha = 0.15f
        hudRealizedValue.animate().alpha(1f).setDuration(500).start()
    }

    private fun announce(msg: String, ok: Boolean) {
        if (hudCard.visibility == View.VISIBLE) {
            showBanner(msg, ok)
        } else {
            flashPill(msg)
        }
    }

    // =====================================================================
    // ACTIONS
    // =====================================================================

    private fun isQuoteFresh(token: TokenInfo = currentToken): Boolean {
        val age = System.currentTimeMillis() - token.marketDataUpdatedAtMs
        return token.ca.isNotBlank() && token.marketCap > 0.0 && token.priceUsd > 0.0 &&
            token.marketDataUpdatedAtMs > 0L && age in 0L..10_000L
    }

    private fun requireFreshQuote(): Boolean {
        if (isQuoteFresh()) return true
        announce("PAPER TRADING PAUSED · PRICE FEED STALE", false)
        return false
    }

    private fun handleBuyClick(solAmount: Double) {
        if (currentToken.ca.isBlank()) {
            announce("Paste a CA first", false)
            return
        }
        if (!requireFreshQuote()) return
        if (tradeActionPending) {
            announce("Execution already pending", false)
            return
        }
        val expectedCa = currentToken.ca
        tradeActionPending = true
        announce("BUY QUEUED · VERIFYING QUOTE", true)
        mainHandler.postDelayed({
            tradeActionPending = false
            val latest = currentToken
            if (latest.ca != expectedCa) {
                announce("Token changed · buy cancelled", false)
                return@postDelayed
            }
            if (!isQuoteFresh(latest)) {
                announce("BUY CANCELLED · PRICE FEED STALE", false)
                return@postDelayed
            }
            val freshToken = TradeRepository.withStoredTokenTaxes(latest)
            val res = TradeRepository.executeBuy(freshToken, solAmount)
            res.onSuccess { pos ->
                saveThesisFromPanel(pos)
                announce("BOUGHT ${Formatters.amount(solAmount)} SOL  @ ${Formatters.compactUsd(latest.marketCap)}", true)
                pulseBag()
                refreshHudAndPillUI()
            }.onFailure { err -> announce(err.message ?: "Buy failed", false) }
        }, 300L)
    }

    private fun paintThesisChips() {
        for ((tag, chip) in thesisChips) {
            val on = selectedTags.contains(tag)
            chip.setTextColor(if (on) Theme.onColor(Theme.text) else Theme.text)
            chip.background = if (on) Theme.box(Theme.text, Theme.text, dp(10), 0)
            else Theme.box(Theme.bg, Theme.border, dp(10), dp(1))
        }
    }

    /** Saves the thesis the user typed / tagged (if any) with the position that was just bought. */
    private fun saveThesisFromPanel(pos: OpenPosition) {
        try {
            val txt = thesisInput.text.toString().trim()
            if (txt.isNotEmpty() || selectedTags.isNotEmpty()) {
                ThesisStore.save(pos.ca, pos.openedAtMs, txt, selectedTags.toList())
                thesisInput.setText("")
                selectedTags.clear()
                paintThesisChips()
            }
            if (thesisInput.hasFocus()) {
                thesisInput.clearFocus()
                enableKeyboardFocus(false)
            }
        } catch (_: Throwable) {
        }
    }

    private fun handleSellClick(pct: Double, button: TextView?) {
        if (currentToken.ca.isBlank()) {
            announce("Paste a CA first", false)
            return
        }
        if (!requireFreshQuote()) return
        if (tradeActionPending) {
            announce("Execution already pending", false)
            return
        }
        val expectedCa = currentToken.ca
        tradeActionPending = true
        announce("SELL QUEUED · VERIFYING QUOTE", true)
        mainHandler.postDelayed({
            tradeActionPending = false
            val latest = currentToken
            if (latest.ca != expectedCa || !isQuoteFresh(latest)) {
                announce("SELL CANCELLED · TOKEN OR PRICE CHANGED", false)
                return@postDelayed
            }
            val res = TradeRepository.executeSell(TradeRepository.withStoredTokenTaxes(latest), pct)
            res.onSuccess { r ->
                if (button != null) flashSellButton(button)
                val msg = if (r.closed) "SOLD 100%  •  CLOSED  ${Formatters.solSigned(r.tradePnlSol)}"
                    else "SOLD ${r.soldPct.toInt()}%  ${Formatters.solSigned(r.slicePnlSol)}  •  ${r.remainingPct.toInt()}% left"
                announce(msg, true)
                pulseBag()
                refreshHudAndPillUI()
            }.onFailure { err -> announce(err.message ?: "No position to sell", false) }
        }, 300L)
    }

    private fun handleSellInitial() {
        if (currentToken.ca.isBlank()) { announce("Paste a CA first", false); return }
        if (!requireFreshQuote()) return
        if (tradeActionPending) { announce("Execution already pending", false); return }
        tradeActionPending = true
        val expectedCa = currentToken.ca
        mainHandler.postDelayed({
            tradeActionPending = false
            val latest = currentToken
            if (latest.ca != expectedCa || !isQuoteFresh(latest)) {
                announce("SELL INITIAL CANCELLED · STALE QUOTE", false)
                return@postDelayed
            }
            TradeRepository.sellInitial(TradeRepository.withStoredTokenTaxes(latest)).onSuccess { result ->
                val msg = if (result.closed) "SELL INITIAL · POSITION CLOSED ${Formatters.solSigned(result.tradePnlSol)}"
                    else "SELL INITIAL · ${result.soldPct.toInt()}% SOLD · ${result.remainingPct.toInt()}% LEFT"
                announce(msg, true)
                pulseBag()
                refreshHudAndPillUI()
            }.onFailure { err -> announce(err.message ?: "Sell Initial failed", false) }
        }, 300L)
    }

    private fun showServiceDialog(dialog: AlertDialog) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
            }
            dialog.show()
        } catch (_: Throwable) {
            announce("Open the app to manage this setting", false)
        }
    }

    private fun showTokenTaxDialog() {
        val token = currentToken
        if (token.ca.isBlank()) { announce("Load a token first", false); return }
        val current = TradeRepository.withStoredTokenTaxes(token)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        fun taxInput(hintText: String, value: Double): EditText = EditText(this).apply {
            hint = hintText
            setText(value.toString())
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
        }
        val buyInput = taxInput("Buy tax %", current.buyTaxPct)
        val sellInput = taxInput("Sell tax %", current.sellTaxPct)
        content.addView(tv("Enter verified token taxes. Zero means no tax is modeled, not that the token is tax-free.", 11f, Theme.muted))
        content.addView(buyInput)
        content.addView(sellInput)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Token taxes · ${token.symbol}")
            .setView(content)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save taxes", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val buy = buyInput.text.toString().toDoubleOrNull()
                val sell = sellInput.text.toString().toDoubleOrNull()
                if (buy == null || sell == null || buy !in 0.0..99.0 || sell !in 0.0..99.0) {
                    Toast.makeText(this, "Enter tax values from 0 to 99", Toast.LENGTH_SHORT).show()
                } else {
                    TradeRepository.setTokenTaxes(token.ca, buy, sell)
                    currentToken = TradeRepository.withStoredTokenTaxes(currentToken)
                    announce("TOKEN TAXES SAVED · BUY ${buy}% / SELL ${sell}%", true)
                    refreshHudAndPillUI()
                    dialog.dismiss()
                }
            }
        }
        showServiceDialog(dialog)
    }

    private fun showOrdersDialog() {
        val ca = currentToken.ca
        if (ca.isBlank()) { announce("Load a token first", false); return }
        val orders = TradeRepository.getOrders(ca)
        val active = orders.filter { it.isActive }
        val labels = if (orders.isEmpty()) arrayOf("No paper orders saved yet") else
            orders.take(12).map { order ->
                val trigger = if (order.triggerMc > 0.0) " · ${Formatters.compactUsd(order.triggerMc)}" else ""
                "${order.type.replace('_', ' ')}$trigger · ${order.status} · ${order.completedOrders}/${order.totalOrders}"
            }.toTypedArray()
        val builder = AlertDialog.Builder(this)
            .setTitle("Paper orders · ${currentToken.symbol}")
            .setItems(labels) { _, which ->
                if (orders.isEmpty()) {
                    showOrderTypePicker()
                } else {
                    val selected = orders.getOrNull(which) ?: return@setItems
                    if (selected.isActive) {
                        val cancelDialog = AlertDialog.Builder(this)
                            .setTitle("Cancel ${selected.type.replace('_', ' ')}?")
                            .setMessage("${selected.lastMessage}\n\nCancel this local paper order?")
                            .setNegativeButton("Keep", null)
                            .setPositiveButton("Cancel order") { _, _ ->
                                TradeRepository.cancelOrder(selected.id)
                                refreshHudAndPillUI()
                                announce("PAPER ORDER CANCELLED", true)
                            }.create()
                        showServiceDialog(cancelDialog)
                    } else {
                        announce(selected.lastMessage.ifBlank { selected.status }, true)
                    }
                }
            }
            .setPositiveButton("New order") { _, _ -> showOrderTypePicker() }
            .setNeutralButton("Done", null)
        val dialog = builder.create()
        showServiceDialog(dialog)
        if (active.isEmpty() && orders.isNotEmpty()) announce("No active orders for this token", true)
    }

    private fun showOrderTypePicker() {
        val types = arrayOf("Take profit", "Stop loss", "Limit buy", "DCA buy", "DCA sell")
        val keys = arrayOf("TAKE_PROFIT", "STOP_LOSS", "LIMIT_BUY", "DCA_BUY", "DCA_SELL")
        val dialog = AlertDialog.Builder(this)
            .setTitle("Create paper order")
            .setItems(types) { _, which -> showOrderForm(keys[which]) }
            .setNegativeButton("Cancel", null)
            .create()
        showServiceDialog(dialog)
    }

    private fun showOrderForm(type: String) {
        if (!requireFreshQuote()) return
        val token = currentToken
        val isDca = type.startsWith("DCA_")
        val isSell = type in setOf("TAKE_PROFIT", "STOP_LOSS", "DCA_SELL")
        val isBuy = type in setOf("LIMIT_BUY", "DCA_BUY")
        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(6), dp(18), dp(2))
        }
        fun numberField(hintText: String, value: String = ""): EditText = EditText(this).apply {
            hint = hintText
            if (value.isNotEmpty()) setText(value)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
        }
        val trigger = if (!isDca) numberField("Trigger market cap (USD)") else null
        val amount = if (isBuy) numberField(if (isDca) "Total SOL across all buys" else "Buy amount SOL", "0.5") else null
        val defaultSellPct = if (type == "DCA_SELL") "100" else if (type == "TAKE_PROFIT") "25" else "100"
        val sellPct = if (isSell) numberField(if (type == "DCA_SELL") "Total bag % to sell across the ladder" else "Percent of current bag to sell", defaultSellPct) else null
        val count = if (isDca) numberField("Number of orders (2–20)", "4") else null
        val interval = if (isDca) numberField("Interval seconds", "30") else null
        val min = if (isDca) numberField("Optional minimum market cap", "0") else null
        val max = if (isDca) numberField("Optional maximum market cap", "0") else null
        fields.addView(tv("${type.replace('_', ' ')} · triggers only while this token is loaded and receiving fresh quotes.", 11f, Theme.muted))
        listOfNotNull(trigger, amount, sellPct, count, interval, min, max).forEach { fields.addView(it) }
        val dialog = AlertDialog.Builder(this)
            .setTitle("${type.replace('_', ' ')} · ${token.symbol}")
            .setView(fields)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val result = TradeRepository.createOrder(
                    token = TradeRepository.withStoredTokenTaxes(currentToken),
                    type = type,
                    triggerMc = trigger?.text?.toString()?.toDoubleOrNull() ?: 0.0,
                    amountSol = amount?.text?.toString()?.toDoubleOrNull() ?: 0.0,
                    sellPct = sellPct?.text?.toString()?.toDoubleOrNull() ?: 100.0,
                    totalOrders = count?.text?.toString()?.toIntOrNull() ?: 1,
                    intervalSeconds = interval?.text?.toString()?.toLongOrNull() ?: 0L,
                    minMc = min?.text?.toString()?.toDoubleOrNull() ?: 0.0,
                    maxMc = max?.text?.toString()?.toDoubleOrNull() ?: 0.0
                )
                result.onSuccess {
                    announce("PAPER ORDER CREATED · ${type.replace('_', ' ')}", true)
                    refreshHudAndPillUI()
                    dialog.dismiss()
                }.onFailure { err ->
                    Toast.makeText(this, err.message ?: "Could not create order", Toast.LENGTH_LONG).show()
                }
            }
        }
        showServiceDialog(dialog)
    }

    /** Coin picture for the panel + bubble: letter circle first, then the real picture (with backup sources). */
    private fun loadPanelImage(token: TokenInfo) {
        val ca = token.ca
        val key = ca + "|" + token.imageUrl
        mainHandler.post {
            if (currentToken.ca == ca && !panelCleared) setTokenBitmap(CoinImages.letterBitmap(token.symbol))
        }
        CoinImages.load(ca, token.imageUrl) { bmp ->
            mainHandler.post {
                if (bmp != null && currentToken.ca == ca && !panelCleared) setTokenBitmap(bmp)
            }
            if (bmp == null) {
                // nothing found yet: allow another try in a while
                mainHandler.postDelayed({ if (loadedImageUrl == key) loadedImageUrl = "" }, 45000L)
            }
        }
    }

    private fun setTokenBitmap(bmp: Bitmap?) {
        lastBitmap = bmp
        if (::hudTokenIcon.isInitialized) hudTokenIcon.setImageBitmap(bmp)
        if (::pillIcon.isInitialized) pillIcon.setImageBitmap(bmp)
    }

    private fun openLink(url: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Throwable) {
            announce("Couldn't open the link", false)
        }
    }

    /** Tap on the X chip: open the coin's listed X link. If none is known yet, look again right now first. */
    private fun onXTapped() {
        val ca = currentToken.ca
        if (ca.isBlank()) return
        if (xUrl.isNotEmpty()) { openLink(xUrl); return }
        announce("Looking for the X link...", true)
        CoinLinkFinder.find(ca, true) { links ->
            mainHandler.post {
                if (links.x.isNotEmpty()) {
                    if (currentToken.ca == ca && !panelCleared) applyLinks(links)
                    openLink(links.x)
                } else {
                    announce("No X link listed yet, opening X search", false)
                    openLink(CoinLinkFinder.xSearchUrl(ca))
                }
            }
        }
    }

    /** Opens the Fomo app (found by its name among your installed apps). The coin's CA is copied so you can paste it in Fomo's search. */
    private fun openFomo() {
        val ca = currentToken.ca
        var copied = false
        if (ca.isNotBlank()) {
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("CA", ca))
                copied = true
            } catch (_: Throwable) {
            }
        }
        var pkg: String? = null
        try {
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(main, 0)) {
                val p = ri.activityInfo.packageName
                if (p == packageName) continue
                val label = ri.loadLabel(pm).toString().lowercase()
                if (label.contains("fomo") || p.lowercase().contains("fomo")) { pkg = p; break }
            }
            if (pkg != null) {
                val launch = pm.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                    announce(if (copied) "Opening Fomo, CA copied" else "Opening Fomo", true)
                    return
                }
            }
        } catch (_: Throwable) {
        }
        announce("Fomo app not found, opening its website", false)
        openLink("https://fomo.family")
    }

    private fun applyLinks(links: CoinLinks) {
        xUrl = links.x
        xChip.text = if (xUrl.isNotEmpty()) "X" else "X search"
    }

    /** Looks up the coin's X link once per coin. */
    private fun ensureLinks(ca: String) {
        if (linksCa == ca) return
        linksCa = ca
        xUrl = ""
        xChip.text = "X search"
        val cached = CoinLinkFinder.cached(ca)
        if (cached != null) { applyLinks(cached); return }
        CoinLinkFinder.find(ca) { links ->
            mainHandler.post {
                if (currentToken.ca == ca && !panelCleared) applyLinks(links)
                // a coin with no X link yet: allow another look later
                else if (links.x.isEmpty()) linksCa = ""
            }
            if (links.x.isEmpty()) mainHandler.postDelayed({ if (linksCa == ca && xUrl.isEmpty()) linksCa = "" }, 15000L)
        }
    }

    private fun resetPanel() {
        linksCa = ""
        panelCleared = true
        currentToken = blankToken
        loadedImageUrl = ""
        tokenIntelCache = null
        tokenIntelLoadingFor = ""
        tokenIntelLastRequestedAt = 0L
        setTokenBitmap(null)
        enableKeyboardFocus(false)
        TradeRepository.setActiveCa("")
        val hasOpen = TradeRepository.getAllPositions().isNotEmpty()
        announce(if (hasOpen) "Panel cleared • open trades kept" else "Panel cleared • paste a new CA", true)
        refreshHudAndPillUI()
    }

    private fun pasteCaFromClipboard() {
        // Temporarily make window focusable to read Android 10+ clipboard reliably
        enableKeyboardFocus(true)
        mainHandler.postDelayed({
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val raw = clip.getItemAt(0).coerceToText(this).toString()
                    val ca = DexScreenerClient.extractSolanaCa(raw)
                    if (ca.length >= 20) {
                        panelCleared = false
                        loadedImageUrl = ""
                        tokenIntelCache = null
                        tokenIntelLoadingFor = ""
                        tokenIntelLastRequestedAt = 0L
                        TradeRepository.setActiveCa(ca)
                        announce("Loading ${Formatters.shortCa(ca)}...", true)
                        Executors.newSingleThreadExecutor().execute {
                            val token = DexScreenerClient.fetchInitialTokenMetadata(ca) { liveTick ->
                                if (!panelCleared && TradeRepository.settings.activeCa == ca && liveTick.ca == ca) {
                                    currentToken = TradeRepository.withStoredTokenTaxes(liveTick)
                                    TradeRepository.syncLiveTokenData(currentToken)
                                    val orderMessages = TradeRepository.evaluateOrders(currentToken)
                                    mainHandler.post {
                                        refreshHudAndPillUI()
                                        if (orderMessages.isNotEmpty()) announce(orderMessages.first(), true)
                                    }
                                }
                            }
                            if (token != null && !panelCleared && TradeRepository.settings.activeCa == ca && token.ca == ca) {
                                currentToken = TradeRepository.withStoredTokenTaxes(token)
                                TradeRepository.syncLiveTokenData(currentToken)
                                val orderMessages = TradeRepository.evaluateOrders(currentToken)
                                mainHandler.post {
                                    refreshHudAndPillUI()
                                    if (orderMessages.isNotEmpty()) announce(orderMessages.first(), true)
                                    if (showingInfoPane) requestTokenIntel(force = false)
                                }
                                loadedImageUrl = token.ca + "|" + token.imageUrl
                                loadPanelImage(token)
                            }
                        }
                    } else {
                        announce("Copy a valid Solana CA first", false)
                    }
                } else {
                    announce("Clipboard is empty", false)
                }
            } catch (_: Throwable) {
            } finally {
                enableKeyboardFocus(false)
            }
        }, 120)
    }

    private fun enableKeyboardFocus(focusable: Boolean) {
        params.flags = if (focusable) {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        windowManager.updateViewLayout(rootContainer, params)
        if (!focusable) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(rootContainer.windowToken, 0)
        }
    }

    private fun switchToMinimizedPill() {
        enableKeyboardFocus(false)
        hudCard.visibility = View.GONE
        pillCard.visibility = View.VISIBLE
        windowManager.updateViewLayout(rootContainer, params)
    }

    private fun switchToExpandedHud() {
        pillCard.visibility = View.GONE
        hudCard.visibility = View.VISIBLE
        rebuildPresetButtons()
        refreshHudAndPillUI()
        windowManager.updateViewLayout(rootContainer, params)
    }

    fun applyInstantScreenMc(screenMc: Double) {
        if (screenMc <= 0.0 || panelCleared) return
        val oldMc = currentToken.marketCap.coerceAtLeast(1.0)
        val ratio = screenMc / oldMc
        val newPrice = (currentToken.priceUsd * ratio).coerceAtLeast(0.0000000001)
        currentToken = currentToken.copy(
            marketCap = screenMc,
            priceUsd = newPrice,
            marketDataUpdatedAtMs = System.currentTimeMillis(),
            marketDataSource = "Screen capture"
        )
        TradeRepository.syncLiveTokenData(currentToken)
        val orderMessages = TradeRepository.evaluateOrders(currentToken)
        if (orderMessages.isNotEmpty()) announce(orderMessages.first(), true)
        mainHandler.post { refreshHudAndPillUI() }
    }

    // =====================================================================
    // LIVE REFRESH
    // =====================================================================

    private fun refreshHudAndPillUI() {
        val blank = currentToken.ca.isBlank()
        val sym = if (currentToken.symbol.startsWith("$")) currentToken.symbol else "$${currentToken.symbol}"
        val mcStr = Formatters.compactUsd(currentToken.marketCap)

        if (!blank && !panelCleared) PathStore.record(currentToken.ca, currentToken.marketCap)
        hudLinksRow.visibility = if (blank) View.GONE else View.VISIBLE
        if (!blank && !panelCleared) ensureLinks(currentToken.ca)
        xChip.text = if (xUrl.isNotEmpty()) "X" else "X search"
        hudTickerText.text = if (blank) "No coin" else sym
        hudNameText.text = if (blank) "Tap Paste CA to load a coin" else currentToken.name
        pillTickerText.text = if (blank) "No coin" else sym
        hudLiveMcValue.text = if (blank) "—" else mcStr
        hudSolBalanceText.text = String.format("Bal %.2f SOL", TradeRepository.settings.solBalance)
        hudFeeInfoText.text = "Fee ${TradeRepository.settings.platformFeePct}% + ${TradeRepository.settings.priorityFeeSol} SOL · Tax ${currentToken.buyTaxPct}/${currentToken.sellTaxPct}"
        val quoteAgeMs = if (currentToken.marketDataUpdatedAtMs > 0L) System.currentTimeMillis() - currentToken.marketDataUpdatedAtMs else Long.MAX_VALUE
        val quoteFresh = !blank && quoteAgeMs in 0L..10_000L
        quoteStatusText.text = if (blank) "WAITING FOR A TOKEN" else if (quoteFresh)
            "LIVE · ${currentToken.marketDataSource.uppercase()} · ${(quoteAgeMs / 1000L)}s"
        else "STALE PRICE · PAPER EXECUTION PAUSED"
        quoteStatusText.setTextColor(if (quoteFresh) Theme.buy else Theme.loss)
        val activeOrderCount = if (blank) 0 else TradeRepository.getActiveOrders(currentToken.ca).size
        ordersButton.text = if (activeOrderCount > 0) "ORDERS $activeOrderCount" else "ORDERS"

        val flashing = System.currentTimeMillis() < pillFlashUntil
        val pos = if (blank) null else TradeRepository.getPosition(currentToken.ca)
        if (pos != null && pos.tokensHeld > 0.0) {
            val pnlSol = TradeRepository.computeUnrealizedPnlSol(pos, currentToken.priceUsd, currentToken.sellTaxPct)
            val pnlPct = if (pos.solInvested > 0.0) (pnlSol / pos.solInvested) * 100.0 else 0.0
            val multX = if (pos.entryMc > 0.0) (currentToken.marketCap / pos.entryMc) else 1.0
            val pnlColor = Theme.pnlColor(pnlSol)

            val pnlFormatted = "${Formatters.solSigned(pnlSol)} (${Formatters.pctSigned(pnlPct)})"
            val multFormatted = Formatters.multX(multX)
            val remPctInt = pos.remainingPct.toInt()

            hudLivePnlValue.text = pnlFormatted
            hudLivePnlValue.setTextColor(pnlColor)
            hudMultipleValue.text = multFormatted
            hudBoughtMcValue.text = "Bought ${Formatters.compactUsd(pos.entryMc)}"
            hudRealizedValue.text = "Realized ${Formatters.solSigned(pos.realizedPnlSol)}"
            hudRealizedValue.setTextColor(if (pos.fills.any { it.side == "SELL" }) Theme.pnlColor(pos.realizedPnlSol) else Theme.muted)
            hudBagLeftValue.text = "Bag $remPctInt%"

            pillPnlText.text = pnlFormatted
            pillPnlText.setTextColor(pnlColor)
            pillMultBadge.text = multFormatted
            if (!flashing) pillSubText.text = "$remPctInt% bag running • tap to sell"
        } else {
            hudLivePnlValue.text = "0.000 SOL"
            hudLivePnlValue.setTextColor(Theme.muted)
            hudMultipleValue.text = "1.00x"
            hudBoughtMcValue.text = "Bought —"
            hudRealizedValue.text = "Realized —"
            hudRealizedValue.setTextColor(Theme.muted)
            hudBagLeftValue.text = "Bag 0%"

            pillPnlText.text = "0.000 SOL"
            pillPnlText.setTextColor(Theme.muted)
            pillMultBadge.text = "1.00x"
            if (!flashing) pillSubText.text = if (blank) "Tap to open • paste a CA" else "Tap bubble to buy / sell"
        }
    }

    private fun showOverlayPane(showInfo: Boolean, loadData: Boolean = true) {
        showingInfoPane = showInfo
        if (!::hudTradeBody.isInitialized || !::hudInfoScroll.isInitialized) return
        hudTradeBody.visibility = if (showInfo) View.GONE else View.VISIBLE
        hudInfoScroll.visibility = if (showInfo) View.VISIBLE else View.GONE
        val activeBg = Theme.alpha(Theme.text, 0x20)
        hudTradeTab.background = if (!showInfo) Theme.box(activeBg, Theme.border, dp(9), dp(1)) else Theme.box(Theme.card, Theme.card, dp(9), dp(1))
        hudInfoTab.background = if (showInfo) Theme.box(activeBg, Theme.border, dp(9), dp(1)) else Theme.box(Theme.card, Theme.card, dp(9), dp(1))
        hudTradeTab.setTextColor(if (!showInfo) Theme.text else Theme.muted)
        hudInfoTab.setTextColor(if (showInfo) Theme.text else Theme.muted)
        if (showInfo && loadData) requestTokenIntel(force = false)
        else if (showInfo && tokenIntelCache?.ca == currentToken.ca) tokenIntelCache?.let { renderTokenIntel(it) }
    }

    private fun requestTokenIntel(force: Boolean) {
        val ca = currentToken.ca
        if (ca.isBlank() || panelCleared) {
            infoStatusText.text = "Paste a Solana CA to inspect holders and developer data."
            return
        }
        val now = System.currentTimeMillis()
        val cached = tokenIntelCache
        if (!force && cached != null && cached.ca == ca && now - cached.updatedAtMs < 60_000L) {
            renderTokenIntel(cached)
            return
        }
        // Avoid duplicate holder requests while a lookup for this mint is already running.
        if (tokenIntelLoadingFor == ca) return
        if (force && now - tokenIntelLastRequestedAt < 1_200L) return
        tokenIntelLoadingFor = ca
        tokenIntelLastRequestedAt = now
        infoStatusText.text = "Loading holder distribution from Vybe…"
        if (force) announce("Refreshing token intelligence…", true)
        TokenIntelClient.load(ca) { intel ->
            mainHandler.post {
                if (!panelCleared && currentToken.ca == ca && TradeRepository.settings.activeCa == ca) {
                    tokenIntelCache = intel
                    renderTokenIntel(intel)
                }
                if (tokenIntelLoadingFor == ca) tokenIntelLoadingFor = ""
            }
        }
    }

    private fun renderTokenIntel(intel: TokenIntel) {
        if (!::infoStatusText.isInitialized) return
        fun pct(value: Double?): String = if (value == null) "N/A" else String.format(java.util.Locale.US, "%.1f%%", value)
        infoTop10Text.text = pct(intel.top10Pct)
        infoDevText.text = pct(intel.devPct)
        infoInsiderText.text = pct(intel.insiderPct)
        infoSniperText.text = pct(intel.sniperPct)
        infoBundleText.text = pct(intel.bundlePct)
        infoMigrationText.text = when {
            intel.migrationStatus.startsWith("Migrated", true) -> "MIGRATED"
            intel.migrationStatus.equals("Bonding curve", true) -> "CURVE"
            intel.migrationStatus.startsWith("DEX pool", true) -> "DEX POOL"
            else -> intel.migrationStatus.uppercase().take(12)
        }
        infoDevWalletText.text = if (intel.devAddress.isBlank()) "Creator wallet not identified" else
            "${Formatters.shortCa(intel.devAddress)}  ·  tap to copy"
        infoDevHistoryText.text = intel.devMigrationRecord.ifBlank {
            "Dev wallet: not identified from current holder data"
        }
        val holderCountLabel = "top holders returned"
        val holderCountSuffix = if (intel.holderCount > 0) " · ${intel.holderCount} $holderCountLabel" else ""
        infoStatusText.text = intel.status.ifBlank { "Updated" } +
            holderCountSuffix + " · ${Formatters.dateTime(intel.updatedAtMs)}"
        infoHoldersBox.removeAllViews()
        if (intel.holders.isEmpty()) {
            infoHoldersBox.addView(tv("Holder list is not available for this token yet.", 10f, Theme.muted).apply { setPadding(0, dp(7), 0, dp(7)) })
        } else {
            intel.holders.take(25).forEachIndexed { index, holder ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(6), 0, dp(6))
                }
                row.addView(tv("${index + 1}.", 10f, Theme.muted, mono = true).apply {
                    layoutParams = lp(dp(20), LinearLayout.LayoutParams.WRAP_CONTENT)
                })
                val holderLabel = holder.ownerName.ifBlank {
                    holder.label.ifBlank { Formatters.shortCa(holder.address) }
                }
                row.addView(tv(holderLabel, 9f, Theme.text, mono = holder.ownerName.isBlank()).apply {
                    layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    maxLines = 1
                    setOnClickListener {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Holder wallet", holder.address))
                        announce("Holder address copied", true)
                    }
                })
                row.addView(tv(pct(holder.share * 100.0), 10f, Theme.text, mono = true, bold = true))
                holder.valueUsd?.let { usd ->
                    row.addView(tv("  " + Formatters.compactUsd(usd), 8f, Theme.muted, mono = true))
                }
                infoHoldersBox.addView(row)
                if (index < minOf(24, intel.holders.size - 1)) {
                    infoHoldersBox.addView(View(this).apply { setBackgroundColor(Theme.border); layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)) })
                }
            }
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "pocketflip_native_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "73MCT Floating Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the 73MCT floating bubble alive"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)

            val launchIntent = Intent(this, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = Notification.Builder(this, channelId)
                .setContentTitle("73MCT Floating Bubble Active")
                .setContentText("Hovering over fomo & Axiom • Tap to open controls")
                .setSmallIcon(android.R.drawable.sym_def_app_icon)
                .setContentIntent(pendingIntent)
                .build()

            try {
                if (Build.VERSION.SDK_INT >= 34) { // Android 14+ (UpsideDownCake)
                    startForeground(
                        101,
                        notification,
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                } else {
                    startForeground(101, notification)
                }
            } catch (err: Throwable) {
                try {
                    startForeground(101, notification)
                } catch (_: Throwable) {
                }
            }
        }
    }

    override fun onDestroy() {
        isRunning = false
        instance = null
        TradeRepository.removeListener(repoListener)
        poller?.shutdownNow()
        PathStore.flush()
        if (::rootContainer.isInitialized) {
            try {
                windowManager.removeView(rootContainer)
            } catch (_: Throwable) {
            }
        }
        super.onDestroy()
    }
}
