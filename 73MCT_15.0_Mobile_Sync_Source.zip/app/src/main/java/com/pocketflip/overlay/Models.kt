package com.pocketflip.overlay

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

data class TokenInfo(
    val ca: String,
    val name: String,
    val symbol: String,
    val priceUsd: Double,
    val solUsdPrice: Double,
    val marketCap: Double,
    val liquidityUsd: Double,
    val volume24h: Double,
    val imageUrl: String,
    /** Timestamp of the last confirmed market-data update. A cached snapshot keeps its old timestamp. */
    val marketDataUpdatedAtMs: Long = 0L,
    val marketDataSource: String = "Unknown",
    /** Token tax is per mint and stays zero until verified or entered by the user. */
    val buyTaxPct: Double = 0.0,
    val sellTaxPct: Double = 0.0
)

/** One buy or one sell inside a trade. SELL fills carry the % of the bag sold and the PnL of that slice. */
data class Fill(
    val side: String,            // "BUY" or "SELL"
    val timeMs: Long,
    val mc: Double,              // market cap at the moment of the fill
    val priceUsd: Double,
    val sol: Double,             // BUY: SOL spent (incl. priority fee) | SELL: net SOL received
    val pct: Double = 0.0,       // SELL only: % of the current bag that was sold
    val pnlSol: Double = 0.0,    // SELL only: PnL of that slice
    val remainingAfterPct: Double = 0.0,
    val executionType: String = "MANUAL",
    val orderId: String = "",
    val taxPct: Double = 0.0,
    val feeSol: Double = 0.0,
    val slippagePct: Double = 0.0,
    val impactPct: Double = 0.0
)

data class OpenPosition(
    val ca: String,
    val name: String,
    val symbol: String,
    val imageUrl: String,
    var entryMc: Double,
    var entryPriceUsd: Double,
    var solInvested: Double,
    var initialSolInvested: Double,
    var tokensHeld: Double,
    var remainingPct: Double,
    var realizedPnlSol: Double,
    val openedAtMs: Long,
    var lastMc: Double,
    var lastPriceUsd: Double,
    var peakMc: Double = 0.0,
    var realizedSolOut: Double = 0.0,
    val fills: MutableList<Fill> = mutableListOf(),
    /** mobile = created/managed on this phone; desktop = mirrored from the desktop paper account. */
    val source: String = "mobile",
    /** Lowest observed market cap since entry (used for MAE). */
    var maeMc: Double = 0.0,
    /** Stop level used to calculate R-multiple when the trade closes. */
    var stopLossMc: Double = 0.0
)

/** One finished trade (coin fully sold). All partial sells live inside [fills]. */
data class ClosedTradeLog(
    val id: String,
    val ca: String,
    val name: String,
    val symbol: String,
    val imageUrl: String,
    val entryMc: Double,
    val avgExitMc: Double,
    val peakMc: Double,
    val solIn: Double,
    val solOut: Double,
    val pnlSol: Double,
    val multipleX: Double,       // avg exit MC / entry MC
    val holdDurationMs: Long,
    val openedAtMs: Long,
    val closedAtMs: Long,
    val fills: List<Fill>,
    val emotion: String = "",
    val rating: Int = 0,
    val setup: String = "",
    val note: String = "",
    val mfePct: Double = 0.0,
    val maePct: Double = 0.0,
    val rMultiple: Double? = null,
    val stopLossMc: Double = 0.0
) {
    val returnX: Double get() = if (solIn > 0.0) solOut / solIn else 0.0
    val roiPct: Double get() = if (solIn > 0.0) (pnlSol / solIn) * 100.0 else 0.0
    val peakX: Double get() = if (entryMc > 0.0) peakMc / entryMc else 0.0
    val sellCount: Int get() = fills.count { it.side == "SELL" }
    val buyCount: Int get() = fills.count { it.side == "BUY" }
}

/** What the bubble needs to show after pressing a sell button. */
data class SellResult(
    val symbol: String,
    val soldPct: Double,
    val solOut: Double,
    val slicePnlSol: Double,
    val multipleX: Double,
    val remainingPct: Double,
    val closed: Boolean,
    val tradePnlSol: Double
)

data class AppSettings(
    var solBalance: Double = 10.0,
    var solUsdPrice: Double = 185.0,
    var platformFeePct: Double = 1.0,
    var priorityFeeSol: Double = 0.005,
    /** Slippage tolerance is applied to automated orders; manual fills use the observed quote. */
    var slippagePct: Double = 1.5,
    var buyPresets: List<Double> = listOf(0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 2.5),
    var sellPresets: List<Double> = listOf(10.0, 20.0, 25.0, 30.0, 50.0, 75.0, 90.0, 100.0),
    var activeCa: String = "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr"
)

/** A local-only pending paper order. It never interacts with a wallet or submits a real transaction. */
data class PaperOrder(
    val id: String,
    val ca: String,
    val symbol: String,
    val type: String,              // TAKE_PROFIT, STOP_LOSS, LIMIT_BUY, DCA_BUY, DCA_SELL
    val triggerMc: Double = 0.0,
    val amountSol: Double = 0.0,    // total for DCA, amount for one LIMIT_BUY
    val sellPct: Double = 100.0,    // percent of the current bag per sell fill
    val totalOrders: Int = 1,
    val intervalSeconds: Long = 0L,
    val minMc: Double = 0.0,
    val maxMc: Double = 0.0,
    val createdAtMs: Long = System.currentTimeMillis(),
    var nextExecutionAtMs: Long = 0L,
    var completedOrders: Int = 0,
    var status: String = "ACTIVE",
    var lastMessage: String = "",
    /** Fixed token quantity per DCA sell slice, captured when the ladder is created. */
    val sellTokensPerOrder: Double = 0.0
) {
    val isActive: Boolean get() = status == "ACTIVE"
}

object Formatters {
    fun compactUsd(value: Double): String {
        val v = if (value.isNaN() || value.isInfinite()) 0.0 else value
        return when {
            v >= 1_000_000_000.0 -> String.format(Locale.US, "$%.2fB", v / 1_000_000_000.0)
            v >= 1_000_000.0 -> String.format(Locale.US, "$%.2fM", v / 1_000_000.0)
            v >= 1_000.0 -> String.format(Locale.US, "$%.1fK", v / 1_000.0)
            else -> String.format(Locale.US, "$%.2f", v)
        }
    }

    fun solSigned(value: Double): String {
        val sign = if (value >= 0.0) "+" else "-"
        return String.format(Locale.US, "%s%.3f SOL", sign, abs(value))
    }

    fun pctSigned(value: Double): String {
        val sign = if (value >= 0.0) "+" else "-"
        return String.format(Locale.US, "%s%.0f%%", sign, abs(value))
    }

    fun multX(value: Double): String {
        val v = if (value.isNaN() || value.isInfinite() || value <= 0.0) 1.0 else value
        return String.format(Locale.US, "%.2fx", v)
    }

    fun duration(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(1L)
        val hrs = totalSec / 3600L
        val mins = (totalSec % 3600L) / 60L
        val secs = totalSec % 60L
        return when {
            hrs > 0L -> "${hrs}h ${mins}m ${secs}s"
            mins > 0L -> "${mins}m ${secs}s"
            else -> "${secs}s"
        }
    }

    fun shortCa(ca: String): String {
        if (ca.length <= 12) return ca
        return ca.take(6) + "..." + ca.takeLast(5)
    }

    fun solPlain(value: Double): String = String.format(Locale.US, "%.3f SOL", value)

    fun pctSigned1(value: Double): String {
        val sign = if (value >= 0.0) "+" else "-"
        return String.format(Locale.US, "%s%.1f%%", sign, abs(value))
    }

    fun amount(value: Double): String {
        return if (value == Math.floor(value)) value.toLong().toString() else value.toString()
    }

    fun dateTime(ms: Long): String =
        SimpleDateFormat("d MMM HH:mm:ss", Locale.US).format(Date(ms))
}
