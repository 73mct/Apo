# 73MCT repair pass

This source archive contains the fixes for the market-cap and entry-marker issues:

- The overlay now seeds token metadata once and polls live Solana RPC reserves instead of re-reading cached DexScreener pair data every cycle.
- WebSocket and asynchronous CA-load callbacks are scoped to the currently active mint, preventing a previous coin from overwriting the selected coin.
- Pair selection prefers the requested mint and preserves that mint as the token identity, including quote-side pairs.
- Buy events record an immediate market-cap point so fast entries cannot disappear from replay data.
- Replay charts keep a dashed vertical BUY guide visible after the animated buy marker settles.
- Disconnected Shrine sockets are closed before reconnecting to avoid duplicate/stale subscriptions.

The sandbox could not produce a final APK because its Linux environment cannot start the AAPT2 executable (the source compiles through Gradle configuration, but resource packaging fails at AAPT2 startup). Build with the repository's Android CI workflow or Android Studio.
