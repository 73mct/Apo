package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One buy or sell a tracked wallet made. [sol] is the SOL moved, [tok] the token amount moved. */
class KolFill(val ts: Long, val buy: Boolean, val sol: Double, val tok: Double)

class KolWallet(val address: String, var label: String) {
    var lastTxTs: Long = 0L      // newest swap time seen (seconds), so re-scans only fetch what is new
    var lastScanMs: Long = 0L
    var swapCount: Int = 0
    var error: String = ""
}

class KolToken(val mint: String) {
    var sym: String = ""
    var name: String = ""
    var img: String = ""
    var pair: String = ""
    var mc: Double = 0.0
    var priceUsd: Double = 0.0
    var priceNative: Double = 0.0
    var peakMc: Double = 0.0
    var peakAt: Long = 0L        // when the peak was last looked up (ms)
    var metaAt: Long = 0L        // when price/mc were last looked up (ms)
    val valid: Boolean get() = priceNative > 0.0 && mc > 0.0
}

/**
 * Everything the KOL tracker saves. Completely separate from the trading journal and balance:
 * it never reads or writes TradeRepository, DexScreenerClient or Models.
 */
object KolStore {
    const val MAX_WALLETS = 100

    private var prefs: SharedPreferences? = null
    private var dir: File? = null
    private val lock = Any()

    val wallets = ArrayList<KolWallet>()
    private val fills = HashMap<String, HashMap<String, ArrayList<KolFill>>>()   // wallet -> mint -> fills
    val tokens = HashMap<String, KolToken>()

    fun init(context: Context) {
        synchronized(lock) {
            if (prefs != null) return
            val ctx = context.applicationContext
            prefs = ctx.getSharedPreferences("kol_prefs", Context.MODE_PRIVATE)
            val d = File(ctx.filesDir, "kol")
            d.mkdirs()
            dir = d
            loadWallets()
            loadTokens()
        }
    }

    // ---------- settings ----------
    var heliusKey: String
        get() = prefs?.getString("helius_key", "") ?: ""
        set(v) { prefs?.edit()?.putString("helius_key", v.trim())?.apply() }

    var days: Int
        get() = prefs?.getInt("days", 30) ?: 30
        set(v) { prefs?.edit()?.putInt("days", v)?.apply() }

    var minPeakMc: Double
        get() = (prefs?.getString("min_peak", "1000000") ?: "1000000").toDoubleOrNull() ?: 1_000_000.0
        set(v) { prefs?.edit()?.putString("min_peak", v.toString())?.apply() }

    var earlyMc: Double
        get() = (prefs?.getString("early_mc", "150000") ?: "150000").toDoubleOrNull() ?: 150_000.0
        set(v) { prefs?.edit()?.putString("early_mc", v.toString())?.apply() }

    var minSizeSol: Double
        get() = (prefs?.getString("min_size", "0.1") ?: "0.1").toDoubleOrNull() ?: 0.1
        set(v) { prefs?.edit()?.putString("min_size", v.toString())?.apply() }

    // ---------- wallets ----------
    private fun loadWallets() {
        wallets.clear()
        try {
            val arr = JSONArray(prefs?.getString("wallets", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val w = KolWallet(o.getString("a"), o.optString("l", ""))
                w.lastTxTs = o.optLong("t", 0L)
                w.lastScanMs = o.optLong("s", 0L)
                w.swapCount = o.optInt("n", 0)
                w.error = o.optString("e", "")
                wallets.add(w)
            }
        } catch (_: Throwable) {
        }
    }

    fun saveWallets() {
        synchronized(lock) {
            val arr = JSONArray()
            for (w in wallets) {
                val o = JSONObject()
                o.put("a", w.address); o.put("l", w.label); o.put("t", w.lastTxTs)
                o.put("s", w.lastScanMs); o.put("n", w.swapCount); o.put("e", w.error)
                arr.put(o)
            }
            prefs?.edit()?.putString("wallets", arr.toString())?.apply()
        }
    }

    /** Adds wallets, skipping duplicates, up to MAX_WALLETS. Returns how many were added. */
    fun addWallets(list: List<Pair<String, String>>): Int {
        var added = 0
        synchronized(lock) {
            for ((addr, label) in list) {
                if (wallets.size >= MAX_WALLETS) break
                if (wallets.any { it.address == addr }) continue
                wallets.add(KolWallet(addr, label.ifBlank { addr.take(4) + ".." + addr.takeLast(4) }))
                added++
            }
        }
        saveWallets()
        return added
    }

    fun removeWallet(addr: String) {
        synchronized(lock) {
            wallets.removeAll { it.address == addr }
            fills.remove(addr)
            try { File(dir, "w_" + addr + ".json").delete() } catch (_: Throwable) {}
        }
        saveWallets()
    }

    // ---------- fills ----------
    fun fillsOf(addr: String): HashMap<String, ArrayList<KolFill>> {
        synchronized(lock) {
            fills[addr]?.let { return it }
            val map = HashMap<String, ArrayList<KolFill>>()
            try {
                val f = File(dir, "w_" + addr + ".json")
                if (f.exists()) {
                    val root = JSONObject(f.readText())
                    for (mint in root.keys()) {
                        val arr = root.getJSONArray(mint)
                        val list = ArrayList<KolFill>()
                        for (i in 0 until arr.length()) {
                            val r = arr.getJSONArray(i)
                            list.add(KolFill(r.getLong(0), r.getInt(1) == 1, r.getDouble(2), r.getDouble(3)))
                        }
                        map[mint] = list
                    }
                }
            } catch (_: Throwable) {
            }
            fills[addr] = map
            return map
        }
    }

    fun saveFills(addr: String) {
        synchronized(lock) {
            val map = fills[addr] ?: return
            try {
                val root = JSONObject()
                for ((mint, list) in map) {
                    val arr = JSONArray()
                    for (x in list) {
                        val r = JSONArray()
                        r.put(x.ts); r.put(if (x.buy) 1 else 0); r.put(x.sol); r.put(x.tok)
                        arr.put(r)
                    }
                    root.put(mint, arr)
                }
                File(dir, "w_" + addr + ".json").writeText(root.toString())
            } catch (_: Throwable) {
            }
        }
    }

    // ---------- tokens ----------
    private fun loadTokens() {
        tokens.clear()
        try {
            val f = File(dir, "tokens.json")
            if (!f.exists()) return
            val root = JSONObject(f.readText())
            for (mint in root.keys()) {
                val o = root.getJSONObject(mint)
                val t = KolToken(mint)
                t.sym = o.optString("s"); t.name = o.optString("n"); t.img = o.optString("i")
                t.pair = o.optString("p"); t.mc = o.optDouble("m", 0.0)
                t.priceUsd = o.optDouble("u", 0.0); t.priceNative = o.optDouble("x", 0.0)
                t.peakMc = o.optDouble("k", 0.0); t.peakAt = o.optLong("ka", 0L); t.metaAt = o.optLong("ma", 0L)
                tokens[mint] = t
            }
        } catch (_: Throwable) {
        }
    }

    fun saveTokens() {
        synchronized(lock) {
            try {
                val root = JSONObject()
                for ((mint, t) in tokens) {
                    val o = JSONObject()
                    o.put("s", t.sym); o.put("n", t.name); o.put("i", t.img); o.put("p", t.pair)
                    o.put("m", t.mc); o.put("u", t.priceUsd); o.put("x", t.priceNative)
                    o.put("k", t.peakMc); o.put("ka", t.peakAt); o.put("ma", t.metaAt)
                    root.put(mint, o)
                }
                File(dir, "tokens.json").writeText(root.toString())
            } catch (_: Throwable) {
            }
        }
    }

    fun clearAllData() {
        synchronized(lock) {
            fills.clear()
            tokens.clear()
            dir?.listFiles()?.forEach { try { it.delete() } catch (_: Throwable) {} }
            for (w in wallets) { w.lastTxTs = 0L; w.lastScanMs = 0L; w.swapCount = 0; w.error = "" }
        }
        saveWallets()
    }
}
