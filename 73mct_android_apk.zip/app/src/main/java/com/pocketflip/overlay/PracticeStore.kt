package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import org.json.JSONArray

/** Persisted user-defined training rules. These are advisory filters, never automatic trade signals. */
data class StrategyProfile(
    val name: String = "My Solana setup",
    val maxEntryMc: Double = 1_000_000.0,
    val minLiquidityUsd: Double = 20_000.0,
    val minVolume24h: Double = 25_000.0,
    val minWalletEntries: Int = 2,
    val targetMultiple: Double = 2.0,
    val invalidation: String = "Liquidity weakens, volume fades, or the original narrative is invalidated.",
    val checkNarrative: Boolean = true,
    val checkLiquidity: Boolean = true,
    val checkVolume: Boolean = true,
    val checkWalletFlow: Boolean = true,
    val checkExitPlan: Boolean = true
)

data class RiskProfile(
    val riskPct: Double = 1.0,
    val stopLossPct: Double = 25.0,
    val maxPositionPct: Double = 10.0,
    val maxConcurrent: Int = 3,
    val dailyLossLimitPct: Double = 3.0
)

data class ChallengeProfile(
    val startedAt: Long = 0L,
    val targetDays: Int = 30,
    val completed: Boolean = false
)

object PracticeStore {
    private const val PREFS = "pocketflip_practice_lab_v1"
    private const val KEY_STRATEGY = "strategy"
    private const val KEY_RISK = "risk"
    private const val KEY_CHALLENGE = "challenge"
    private const val KEY_WATCHLIST = "watchlist"
    private var prefs: SharedPreferences? = null

    @Synchronized fun init(context: Context) {
        if (prefs == null) prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    @Synchronized fun strategy(): StrategyProfile {
        val o = read(KEY_STRATEGY)
        return StrategyProfile(
            name = o.optString("name", "My Solana setup"),
            maxEntryMc = o.optDouble("maxEntryMc", 1_000_000.0),
            minLiquidityUsd = o.optDouble("minLiquidityUsd", 20_000.0),
            minVolume24h = o.optDouble("minVolume24h", 25_000.0),
            minWalletEntries = o.optInt("minWalletEntries", 2),
            targetMultiple = o.optDouble("targetMultiple", 2.0),
            invalidation = o.optString("invalidation", "Liquidity weakens, volume fades, or the original narrative is invalidated."),
            checkNarrative = o.optBoolean("checkNarrative", true),
            checkLiquidity = o.optBoolean("checkLiquidity", true),
            checkVolume = o.optBoolean("checkVolume", true),
            checkWalletFlow = o.optBoolean("checkWalletFlow", true),
            checkExitPlan = o.optBoolean("checkExitPlan", true)
        )
    }

    @Synchronized fun saveStrategy(s: StrategyProfile) {
        val o = JSONObject().apply {
            put("name", s.name.take(40)); put("maxEntryMc", s.maxEntryMc.coerceAtLeast(0.0))
            put("minLiquidityUsd", s.minLiquidityUsd.coerceAtLeast(0.0)); put("minVolume24h", s.minVolume24h.coerceAtLeast(0.0))
            put("minWalletEntries", s.minWalletEntries.coerceIn(0, 100)); put("targetMultiple", s.targetMultiple.coerceIn(1.0, 100.0))
            put("invalidation", s.invalidation.take(240)); put("checkNarrative", s.checkNarrative)
            put("checkLiquidity", s.checkLiquidity); put("checkVolume", s.checkVolume)
            put("checkWalletFlow", s.checkWalletFlow); put("checkExitPlan", s.checkExitPlan)
        }
        prefs?.edit()?.putString(KEY_STRATEGY, o.toString())?.apply()
    }

    @Synchronized fun risk(): RiskProfile {
        val o = read(KEY_RISK)
        return RiskProfile(
            riskPct = o.optDouble("riskPct", 1.0), stopLossPct = o.optDouble("stopLossPct", 25.0),
            maxPositionPct = o.optDouble("maxPositionPct", 10.0), maxConcurrent = o.optInt("maxConcurrent", 3),
            dailyLossLimitPct = o.optDouble("dailyLossLimitPct", 3.0)
        )
    }

    @Synchronized fun saveRisk(r: RiskProfile) {
        val o = JSONObject().apply {
            put("riskPct", r.riskPct.coerceIn(0.1, 10.0)); put("stopLossPct", r.stopLossPct.coerceIn(1.0, 95.0))
            put("maxPositionPct", r.maxPositionPct.coerceIn(1.0, 100.0)); put("maxConcurrent", r.maxConcurrent.coerceIn(1, 20))
            put("dailyLossLimitPct", r.dailyLossLimitPct.coerceIn(0.1, 25.0))
        }
        prefs?.edit()?.putString(KEY_RISK, o.toString())?.apply()
    }

    @Synchronized fun challenge(): ChallengeProfile {
        val o = read(KEY_CHALLENGE)
        return ChallengeProfile(o.optLong("startedAt", 0L), o.optInt("targetDays", 30), o.optBoolean("completed", false))
    }

    @Synchronized fun startChallenge(now: Long = System.currentTimeMillis()) {
        val o = JSONObject().put("startedAt", now).put("targetDays", 30).put("completed", false)
        prefs?.edit()?.putString(KEY_CHALLENGE, o.toString())?.apply()
    }

    @Synchronized fun markChallengeCompleted() {
        val c = challenge()
        if (c.startedAt <= 0L) return
        val o = JSONObject().put("startedAt", c.startedAt).put("targetDays", c.targetDays).put("completed", true)
        prefs?.edit()?.putString(KEY_CHALLENGE, o.toString())?.apply()
    }

    @Synchronized fun watchlist(): List<String> {
        return try {
            val arr = JSONArray(prefs?.getString(KEY_WATCHLIST, "[]") ?: "[]")
            val values = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val value = arr.optString(i)
                if (value.isNotBlank()) values.add(value)
            }
            values.distinct()
        } catch (_: Throwable) { emptyList() }
    }

    @Synchronized fun addWatch(mint: String): Boolean {
        val clean = mint.trim()
        if (clean.length !in 32..44 || watchlist().contains(clean)) return false
        val next = (listOf(clean) + watchlist()).take(100)
        val arr = JSONArray()
        next.forEach { arr.put(it) }
        prefs?.edit()?.putString(KEY_WATCHLIST, arr.toString())?.apply()
        return true
    }

    @Synchronized fun removeWatch(mint: String) {
        val arr = JSONArray()
        watchlist().filter { it != mint }.forEach { arr.put(it) }
        prefs?.edit()?.putString(KEY_WATCHLIST, arr.toString())?.apply()
    }

    private fun read(key: String): JSONObject = try {
        JSONObject(prefs?.getString(key, "{}") ?: "{}")
    } catch (_: Throwable) { JSONObject() }
}
