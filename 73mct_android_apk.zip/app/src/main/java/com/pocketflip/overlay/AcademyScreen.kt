package com.pocketflip.overlay

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.ln
import kotlin.math.max

/** One historical KOL-origin case. The decision point is the first tracked-wallet entry. */
private data class AcademyCase(
    val coin: KolCoin,
    val decisionTs: Long,
    val entryMc: Double,
    val walletsAtDecision: Int,
    val id: String
)

/**
 * Standalone training destination. It does not read or modify the trading journal, balance,
 * buy/sell math, or market update path. It only reads the saved KOL dataset and stores Academy
 * decisions in AcademyStore.
 */
class AcademyScreen(private val act: Activity) : LinearLayout(act) {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private lateinit var tabBar: LinearLayout
    private lateinit var holder: LinearLayout
    private val tabViews = ArrayList<TextView>()
    private var selectedTab = 0 // 0 Game, 1 Results
    @Volatile private var currentCase: AcademyCase? = null
    private var activeDecisionId: String? = null
    private var chartAll = emptyList<Pair<Long, Double>>()
    private var chartLoading = false
    private var chartMessage = ""
    private var selectedThesis = "Narrative"
    private var selectedRisk = "Medium"
    private var selectedExit = "Scale out"
    private var p2 = 60
    private var p4 = 25
    private var thesisInput: EditText? = null
    private var p2Value: TextView? = null
    private var p4Value: TextView? = null
    private var p2Seek: SeekBar? = null
    private var p4Seek: SeekBar? = null

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun tv(text: String, size: Float, color: Int = Theme.text, bold: Boolean = false): TextView =
        TextView(act).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            includeFontPadding = false
        }

    private fun vstack(): LinearLayout = LinearLayout(act).apply { orientation = VERTICAL }
    private fun hstack(): LinearLayout = LinearLayout(act).apply {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun LinearLayout.add(
        view: View, top: Int = 0, bottom: Int = 0,
        width: Int = LayoutParams.MATCH_PARENT, height: Int = LayoutParams.WRAP_CONTENT,
        weight: Float = 0f, left: Int = 0, right: Int = 0
    ) {
        val lp = if (weight > 0f) LayoutParams(width, height, weight) else LayoutParams(width, height)
        lp.topMargin = top; lp.bottomMargin = bottom; lp.leftMargin = left; lp.rightMargin = right
        addView(view, lp)
    }

    private fun card(): LinearLayout = vstack().apply {
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = Theme.box(Theme.card, Theme.border, dp(18), dp(1))
        elevation = dp(2).toFloat()
    }

    private fun button(label: String, filled: Boolean = false, onClick: () -> Unit): TextView =
        tv(label, 13f, if (filled) Theme.onColor(Theme.text) else Theme.text, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = if (filled) Theme.box(Theme.text, Theme.text, dp(14), 0)
                else Theme.box(Theme.bg, Theme.border, dp(14), dp(1))
            isClickable = true
            setOnClickListener { onClick() }
        }

    private fun chip(label: String, active: Boolean, onClick: () -> Unit): TextView =
        tv(label, 11f, if (active) Theme.onColor(Theme.text) else Theme.text, active).apply {
            gravity = Gravity.CENTER
            setPadding(dp(11), dp(9), dp(11), dp(9))
            background = if (active) Theme.box(Theme.text, Theme.text, dp(12), 0)
                else Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
            setOnClickListener { onClick() }
        }

    private fun smallLabel(label: String): TextView = tv(label.uppercase(Locale.US), 9f, Theme.muted, true)

    init {
        Theme.init(act)
        CoinImages.init(act)
        KolStore.init(act)
        AcademyStore.init(act)
        orientation = VERTICAL
        visibility = View.GONE
        setup()
    }

    private fun setup() {
        val header = hstack()
        val title = vstack()
        title.add(tv("Coin Judgment Academy", 22f, Theme.text, true))
        title.add(tv("Train your eye. Commit first. Reveal after.", 11f, Theme.muted), top = dp(4))
        header.add(title, width = 0, weight = 1f)
        add(header, bottom = dp(14))

        tabBar = hstack()
        val game = tv(AppTabLabels.label("academy_game"), 13f, Theme.text, true)
        val results = tv(AppTabLabels.label("academy_results"), 13f, Theme.text, true)
        tabViews.add(game); tabViews.add(results)
        game.setOnClickListener { selectedTab = 0; styleTabs(); render() }
        results.setOnClickListener { selectedTab = 1; styleTabs(); render() }
        tabBar.add(game, width = 0, weight = 1f, right = dp(6))
        tabBar.add(results, width = 0, weight = 1f, left = dp(6))
        add(tabBar, bottom = dp(14))

        holder = vstack()
        add(holder)
        styleTabs()
    }

    fun applyLabels() {
        if (tabViews.size >= 2) {
            tabViews[0].text = AppTabLabels.label("academy_game")
            tabViews[1].text = AppTabLabels.label("academy_results")
        }
    }

    private fun styleTabs() {
        for ((i, v) in tabViews.withIndex()) {
            val active = i == selectedTab
            v.background = if (active) Theme.box(Theme.text, Theme.text, dp(14), 0)
                else Theme.box(Theme.bg, Theme.border, dp(14), dp(1))
            v.setTextColor(if (active) Theme.onColor(Theme.text) else Theme.text)
            v.setPadding(dp(10), dp(11), dp(10), dp(11))
            v.gravity = Gravity.CENTER
        }
    }

    fun onShown() {
        try {
            KolStore.init(act)
            AcademyStore.init(act)
            if (currentCase == null && activeDecisionId == null) selectNextCase()
            render()
        } catch (t: Throwable) {
            Toast.makeText(act, "Academy could not load: ${t.message ?: t.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    fun destroy() {
        io.shutdownNow()
    }

    /** Academy has no nested detail route; false means let Android handle Back normally. */
    fun onBack(): Boolean = false

    private fun candidates(): List<AcademyCase> {
        val out = ArrayList<AcademyCase>()
        val builtCoins = try { KolEngine.buildCoins() } catch (_: Throwable) { emptyList() }
        for (coin in builtCoins) {
            val ordered = coin.positions.filter { it.firstBuyTs > 0L && it.entryMc > 0.0 }
                .sortedBy { it.firstBuyTs }
            val first = ordered.firstOrNull() ?: continue
            val atTime = ordered.count { it.firstBuyTs <= first.firstBuyTs }
            val id = coin.tok.mint + ":" + first.firstBuyTs
            if (coin.tok.sym.isBlank() && coin.tok.name.isBlank()) continue
            out.add(AcademyCase(coin, first.firstBuyTs, first.entryMc, max(1, atTime), id))
        }
        return out.distinctBy { it.id }.sortedBy { it.decisionTs }
    }

    private fun selectNextCase() {
        activeDecisionId = null
        chartAll = emptyList()
        chartLoading = false
        chartMessage = ""
        currentCase = candidates().firstOrNull { !AcademyStore.hasCase(it.id) }
        currentCase?.let { loadChart(it) }
    }

    private fun loadChart(c: AcademyCase) {
        val cached = AcademyStore.chartPoints(c.coin.tok.mint)
        if (cached.isNotEmpty()) {
            chartAll = cached
            chartMessage = "Cached hourly pool candles"
            return
        }
        val tok = c.coin.tok
        if (tok.pair.isBlank() || tok.priceUsd <= 0.0 || tok.mc <= 0.0) {
            chartMessage = "Historical chart unavailable from the saved token metadata"
            return
        }
        chartLoading = true
        chartMessage = "Loading historical pool candles…"
        val id = c.id
        io.execute {
            // Skip queued downloads when the user has already moved to another case.
            if (currentCase?.id != id) return@execute
            try { Thread.sleep(6300L) } catch (_: InterruptedException) { return@execute }
            if (currentCase?.id != id) return@execute
            // One request per unseen mint, spaced to stay below a conservative 10-requests/min rate.
            // The result is cached locally and reused by future rounds.
            val points: List<Pair<Long, Double>> = try {
                KolEngine.candles(tok, c.decisionTs - 24L * 3600L, c.decisionTs + 7L * 86400L)
            } catch (_: Throwable) { emptyList() }
            if (points.isNotEmpty()) AcademyStore.saveChartPoints(tok.mint, points)
            main.post {
                if (currentCase?.id == id) {
                    chartAll = points
                    chartLoading = false
                    chartMessage = if (points.isNotEmpty()) "Hourly pool candles cached on this device"
                        else "No usable historical candles returned; this case remains unscored for missing outcomes"
                    renderGame()
                }
            }
        }
    }

    private fun render() {
        styleTabs()
        if (selectedTab == 0) renderGame() else renderResults()
    }

    private fun dailyCount(): Int {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        return AcademyStore.all().count { it.submittedAt >= start && it.status != "SKIPPED" }
    }

    private fun statBox(label: String, value: String): LinearLayout = card().apply {
        setPadding(dp(10), dp(11), dp(10), dp(11))
        add(smallLabel(label))
        add(tv(value, 17f, Theme.text, true), top = dp(5))
    }

    private fun renderGame() {
        holder.removeAllViews()
        val history = AcademyStore.all()
        val completedToday = dailyCount()
        val remaining = candidates().count { !AcademyStore.hasCase(it.id) }
        val stats = hstack()
        stats.add(statBox("TODAY", "$completedToday / 100"), width = 0, weight = 1f, right = dp(6))
        stats.add(statBox("DECISIONS", history.count { it.status != "SKIPPED" }.toString()), width = 0, weight = 1f, left = dp(3), right = dp(3))
        stats.add(statBox("READY", remaining.toString()), width = 0, weight = 1f, left = dp(6))
        holder.add(stats, bottom = dp(12))

        val submitted = activeDecisionId?.let { AcademyStore.get(it) }
        if (submitted != null) {
            holder.add(buildSubmittedCard(submitted), bottom = dp(12))
            return
        }

        val c = currentCase
        if (c == null) {
            val empty = card()
            empty.add(tv("No unseen, sufficiently complete cases yet", 16f, Theme.text, true))
            empty.add(tv(
                "Open KOL Tracker → Wallets, add your tracked wallets and run a scan. The Academy only creates a round when a saved buy, a usable entry market-cap estimate and an identifiable token are available. It will not invent a chart or label missing evidence as a loss.",
                12f, Theme.muted
            ), top = dp(8), bottom = dp(12))
            empty.add(button("Refresh cases from KOL Tracker", true) {
                currentCase = null
                selectNextCase()
                renderGame()
            })
            holder.add(empty)
            return
        }

        val coin = c.coin
        val tok = coin.tok
        val displayName = tok.sym.takeIf { it.isNotBlank() }?.let { "\$$it" } ?: tok.name.ifBlank { "Unknown token" }
        val head = card()
        val h = hstack()
        val img = ImageView(act).apply {
            background = Theme.circle(Theme.bg, Theme.border, dp(1))
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            CoinImages.bind(this, tok.mint, tok.sym.ifBlank { "?" }, tok.img)
        }
        h.add(img, width = dp(54), height = dp(54), right = dp(12))
        val details = vstack()
        details.add(tv(displayName, 17f, Theme.text, true))
        details.add(tv(tok.name.ifBlank { shortMint(tok.mint) }, 11f, Theme.muted), top = dp(3))
        details.add(tv("Solana · historical decision point", 10f, Theme.muted), top = dp(3))
        h.add(details, width = 0, weight = 1f)
        head.add(h)
        head.add(tv("Decision point · ${dateTime(c.decisionTs)}", 10f, Theme.muted), top = dp(12))
        val metrics = hstack()
        metrics.add(metric("ENTRY MC (EST.)", KolEngine.money(c.entryMc)), width = 0, weight = 1f, right = dp(5))
        metrics.add(metric("KOL SIGNALS", c.walletsAtDecision.toString()), width = 0, weight = 1f, left = dp(5))
        head.add(metrics, top = dp(12))
        holder.add(head, bottom = dp(10))

        val chartCard = card()
        chartCard.add(tv("PRICE HISTORY BEFORE YOUR DECISION", 10f, Theme.muted, true), bottom = dp(8))
        val preDecision = chartAll.filter { it.first <= c.decisionTs }
        val chart = AcademyChart(act).apply {
            points = preDecision
            note = when {
                chartLoading -> "Loading historical candles…"
                preDecision.isEmpty() -> "Historical chart unavailable"
                else -> ""
            }
        }
        chartCard.add(chart, height = dp(210))
        chartCard.add(tv(
            when {
                chartLoading -> "Fetching one historical chart for this token."
                chartAll.isNotEmpty() -> "Estimated market-cap path from hourly pool candles · future candles are hidden."
                else -> chartMessage.ifBlank { "No verified candle series attached to this case." }
            }, 10f, Theme.muted
        ), top = dp(8))
        holder.add(chartCard, bottom = dp(10))

        val evidence = card()
        evidence.add(tv("AVAILABLE EVIDENCE", 10f, Theme.muted, true), bottom = dp(6))
        evidence.add(evidenceRow("Tracked wallet activity", "${c.walletsAtDecision} wallet signal${if (c.walletsAtDecision == 1) "" else "s"} at decision"))
        evidence.add(evidenceRow("Market-cap estimate", "Derived from the tracked wallet's swap and current token metadata"), top = dp(6))
        evidence.add(evidenceRow("X / narrative context", "Not attached to this historical case yet"), top = dp(6))
        evidence.add(tv("The coin identity and market-cap mapping may reflect current metadata. Missing social context is not inferred.",
            10f, Theme.muted), top = dp(9))
        holder.add(evidence, bottom = dp(12))

        val form = card()
        form.add(tv("MAKE YOUR CALL", 14f, Theme.text, true), bottom = dp(4))
        form.add(tv("Commit to your reasoning before seeing what happened next.", 11f, Theme.muted), bottom = dp(12))
        form.add(smallLabel("Strongest thesis"), bottom = dp(7))
        val thesisTags = listOf("Narrative", "Wallet flow", "Liquidity", "Structure", "Social", "No clear edge")
        val tagRows = vstack()
        for (rowItems in thesisTags.chunked(3)) {
            val row = hstack()
            for ((i, item) in rowItems.withIndex()) {
                row.add(chip(item, selectedThesis == item) { selectedThesis = item; renderGame() },
                    width = 0, weight = 1f, right = if (i < rowItems.size - 1) dp(5) else 0)
            }
            tagRows.add(row, bottom = dp(6))
        }
        form.add(tagRows, bottom = dp(8))

        val note = EditText(act).apply {
            setText(thesisInput?.text?.toString().orEmpty())
            hint = "Paste relevant X context if you have it, then explain why it could run and what would invalidate your thesis."
            setTextColor(Theme.text); setHintTextColor(Theme.muted)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            minLines = 2; maxLines = 4; gravity = Gravity.TOP
            setPadding(dp(11), dp(10), dp(11), dp(10))
            background = Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
        }
        thesisInput = note
        form.add(note, bottom = dp(14))

        p2 = p2.coerceIn(0, 100); p4 = p4.coerceIn(0, p2)
        form.add(probabilityControl("Probability of reaching 2x", p2, true), bottom = dp(10))
        form.add(probabilityControl("Probability of reaching 4x", p4, false), bottom = dp(14))
        form.add(smallLabel("Risk assessment"), bottom = dp(7))
        form.add(optionRow(listOf("Low", "Medium", "High"), selectedRisk) { selectedRisk = it; renderGame() }, bottom = dp(12))
        form.add(smallLabel("Exit plan"), bottom = dp(7))
        form.add(optionRow(listOf("Scale out", "All out", "Trailing", "Unsure"), selectedExit) { selectedExit = it; renderGame() }, bottom = dp(14))

        val actions = hstack()
        actions.add(button("Skip case") {
            AcademyStore.skip(c.id, tok.mint, tok.name, tok.sym, c.decisionTs, c.entryMc)
            thesisInput = null
            selectedThesis = "Narrative"; selectedRisk = "Medium"; selectedExit = "Scale out"
            selectNextCase(); renderGame()
        }, width = 0, weight = 1f, right = dp(6))
        actions.add(button("Lock decision", true) {
            val cleanP4 = p4.coerceAtMost(p2)
            val d = AcademyDecision(
                id = c.id, mint = tok.mint, coinName = tok.name, symbol = tok.sym, imageUrl = tok.img,
                decisionTs = c.decisionTs, entryMc = c.entryMc, walletsAtDecision = c.walletsAtDecision,
                totalWallets = coin.kolCount, thesisTag = selectedThesis,
                thesisText = thesisInput?.text?.toString()?.trim().orEmpty(),
                probability2x = p2, probability4x = cleanP4, risk = selectedRisk,
                exitPlan = selectedExit, submittedAt = System.currentTimeMillis()
            )
            AcademyStore.save(d)
            thesisInput = null
            activeDecisionId = d.id
            renderGame()
        }, width = 0, weight = 1f, left = dp(6))
        form.add(actions)
        holder.add(form)
    }

    private fun metric(label: String, value: String): LinearLayout = vstack().apply {
        add(smallLabel(label))
        add(tv(value, 15f, Theme.text, true), top = dp(4))
    }

    private fun evidenceRow(label: String, value: String): LinearLayout = hstack().apply {
        add(tv(label, 11f, Theme.text, true), width = 0, weight = 1f, right = dp(8))
        add(tv(value, 10f, Theme.muted).apply { gravity = Gravity.END }, width = 0, weight = 1.2f)
    }

    private fun probabilityControl(label: String, value: Int, isTwoX: Boolean): LinearLayout {
        val box = vstack()
        val head = hstack()
        head.add(tv(label, 12f, Theme.text, true), width = 0, weight = 1f)
        val valueText = tv("$value%", 14f, Theme.text, true)
        head.add(valueText)
        box.add(head, bottom = dp(3))
        val seek = SeekBar(act).apply {
            setMax(100)
            progress = value
            progressTintList = android.content.res.ColorStateList.valueOf(Theme.text)
            thumbTintList = android.content.res.ColorStateList.valueOf(Theme.text)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Theme.border)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    if (isTwoX) {
                        p2 = progress
                        if (p4 > p2) { p4 = p2; p4Seek?.progress = p4; p4Value?.text = "$p4%" }
                    } else {
                        p4 = progress.coerceAtMost(p2)
                        if (p4 != progress) bar?.progress = p4
                    }
                    valueText.text = "${if (isTwoX) p2 else p4}%"
                    if (isTwoX) p2Value = valueText else p4Value = valueText
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        }
        if (isTwoX) { p2Seek = seek; p2Value = valueText } else { p4Seek = seek; p4Value = valueText }
        box.add(seek)
        return box
    }

    private fun optionRow(options: List<String>, selected: String, onPick: (String) -> Unit): LinearLayout = hstack().apply {
        for ((i, item) in options.withIndex()) {
            val label = when (item) { "Trailing" -> "Trail"; "Unsure" -> "Unsure"; "Scale out" -> "Scale"; "All out" -> "All out"; else -> item }
            add(chip(label, selected == item) { onPick(item) }, width = 0, weight = 1f,
                right = if (i < options.size - 1) dp(5) else 0)
        }
    }

    private fun buildSubmittedCard(d: AcademyDecision): LinearLayout {
        val box = card()
        if (d.status == "REVEALED") {
            box.add(tv("Outcome revealed", 17f, Theme.text, true))
            box.add(tv("${d.symbol.ifBlank { shortMint(d.mint) }} · ${KolEngine.money(d.entryMc)} estimated entry market cap",
                11f, Theme.muted), top = dp(5), bottom = dp(12))
            if (d.outcomeVerified && d.entryMc > 0.0) {
                val multiple = d.peakMc / d.entryMc
                box.add(tv("Observed peak: ${String.format(Locale.US, "%.2fx", multiple)} · ${KolEngine.money(d.peakMc)}",
                    16f, Theme.text, true), bottom = dp(6))
                box.add(tv("2x ${if (multiple >= 2.0) "touched" else "not verified"} · 4x ${if (multiple >= 4.0) "touched" else "not verified"}",
                    11f, Theme.muted), bottom = dp(8))
            } else {
                box.add(tv("This case does not have a verified post-entry peak series. It is recorded as incomplete, not as a loss.",
                    12f, Theme.muted), bottom = dp(8))
            }
            box.add(tv(d.outcomeSource, 10f, Theme.muted), bottom = dp(12))
            box.add(tv("Your call: ${d.probability2x}% for 2x · ${d.probability4x}% for 4x · ${d.thesisTag}",
                11f, Theme.text), bottom = dp(12))
            box.add(button("Next case", true) {
                selectedThesis = "Narrative"; selectedRisk = "Medium"; selectedExit = "Scale out"
                p2 = 60; p4 = 25; thesisInput = null
                selectNextCase(); renderGame()
            })
        } else {
            box.add(tv("Decision locked", 17f, Theme.text, true))
            box.add(tv("${if (d.symbol.isNotBlank()) "${d.symbol} · " else ""}${KolEngine.money(d.entryMc)} estimated entry market cap",
                11f, Theme.muted), top = dp(5), bottom = dp(12))
            val probs = hstack()
            probs.add(metric("YOUR 2X PROBABILITY", "${d.probability2x}%"), width = 0, weight = 1f)
            probs.add(metric("YOUR 4X PROBABILITY", "${d.probability4x}%"), width = 0, weight = 1f)
            box.add(probs, bottom = dp(12))
            box.add(tv("Thesis: ${d.thesisTag}", 12f, Theme.text, true))
            if (d.thesisText.isNotBlank()) box.add(tv(d.thesisText, 11f, Theme.muted), top = dp(4))
            box.add(tv("The outcome was hidden until you committed. Reveal it now to record the result.", 11f, Theme.muted), top = dp(10), bottom = dp(12))
            box.add(button("Reveal outcome", true) { revealCurrent(d) })
        }
        return box
    }

    private fun revealCurrent(d: AcademyDecision) {
        val c = currentCase
        val tok = c?.coin?.tok
        val verified = tok != null && tok.peakAt > 0L && tok.peakMc > 0.0
        val peak = if (verified) tok!!.peakMc else 0.0
        val source = if (verified) "GeckoTerminal hourly pool OHLCV peak estimate" else
            "No verified post-entry peak series; outcome left unscored"
        AcademyStore.reveal(d.id, peak, verified, source)
        renderGame()
    }

    private fun renderResults() {
        holder.removeAllViews()
        val rows = AcademyStore.all().filter { it.status != "SKIPPED" }
        val revealed = rows.filter { it.status == "REVEALED" && it.outcomeVerified }
        val brier2 = brier(revealed, 2.0)
        val brier4 = brier(revealed, 4.0)
        val wins2 = revealed.count { it.peakMc / it.entryMc >= 2.0 }
        val wins4 = revealed.count { it.peakMc / it.entryMc >= 4.0 }

        val summary = card()
        summary.add(tv("Your training record", 17f, Theme.text, true), bottom = dp(10))
        val row1 = hstack()
        row1.add(metric("DECISIONS", rows.size.toString()), width = 0, weight = 1f)
        row1.add(metric("REVEALED", rows.count { it.status == "REVEALED" }.toString()), width = 0, weight = 1f)
        row1.add(metric("VERIFIED", revealed.size.toString()), width = 0, weight = 1f)
        summary.add(row1, bottom = dp(12))
        val row2 = hstack()
        row2.add(metric("2X HIT", if (revealed.isEmpty()) "—" else "$wins2 / ${revealed.size}"), width = 0, weight = 1f)
        row2.add(metric("4X HIT", if (revealed.isEmpty()) "—" else "$wins4 / ${revealed.size}"), width = 0, weight = 1f)
        summary.add(row2, bottom = dp(12))
        val row3 = hstack()
        row3.add(metric("2X CALIBRATION", brier2?.let { "${it.toInt()}/100" } ?: "—"), width = 0, weight = 1f)
        row3.add(metric("4X CALIBRATION", brier4?.let { "${it.toInt()}/100" } ?: "—"), width = 0, weight = 1f)
        summary.add(row3)
        summary.add(tv("Calibration is calculated only from cases with verified peak data. A higher score means your probabilities better matched the observed outcomes. These peak-based outcomes do not prove an executable exit.",
            10f, Theme.muted), top = dp(10))
        holder.add(summary, bottom = dp(12))

        if (rows.isEmpty()) {
            val empty = card()
            empty.add(tv("No decisions yet", 15f, Theme.text, true))
            empty.add(tv("Complete a Game round, lock your thesis and reveal the outcome. Your decisions and results will appear here.",
                12f, Theme.muted), top = dp(6))
            holder.add(empty)
            return
        }

        holder.add(tv("RECENT DECISIONS", 10f, Theme.muted, true), bottom = dp(7))
        for (d in rows.take(100)) {
            val item = card()
            val header = hstack()
            header.add(tv("${d.symbol.ifBlank { shortMint(d.mint) }}", 14f, Theme.text, true), width = 0, weight = 1f)
            val status = when {
                d.status == "REVEALED" && d.outcomeVerified -> "REVEALED"
                d.status == "REVEALED" -> "INCOMPLETE"
                else -> "COMMITTED"
            }
            header.add(tv(status, 9f, Theme.muted, true))
            item.add(header)
            item.add(tv(d.coinName.ifBlank { shortMint(d.mint) } + " · " + KolEngine.money(d.entryMc) + " estimated entry",
                10f, Theme.muted), top = dp(4))
            val probs = hstack()
            probs.add(tv("2x ${d.probability2x}%", 11f, Theme.text, true), width = 0, weight = 1f)
            probs.add(tv("4x ${d.probability4x}%", 11f, Theme.text, true), width = 0, weight = 1f)
            item.add(probs, top = dp(8))
            if (d.status == "REVEALED" && d.outcomeVerified) {
                val multiple = d.peakMc / d.entryMc
                item.add(tv("Observed hourly-candle peak: ${String.format(Locale.US, "%.2fx", multiple)} · ${KolEngine.money(d.peakMc)}",
                    11f, if (multiple >= 2.0) Theme.pnlColor(1.0) else Theme.muted, true), top = dp(7))
            } else if (d.status == "REVEALED") {
                item.add(tv("Outcome not scored — historical evidence incomplete", 10f, Theme.muted), top = dp(7))
            } else {
                item.add(tv("Awaiting reveal", 10f, Theme.muted), top = dp(7))
            }
            item.add(tv("${d.thesisTag} · ${d.risk} risk · ${d.exitPlan}", 10f, Theme.muted), top = dp(5))
            item.add(tv(dateTime(d.decisionTs), 9f, Theme.muted), top = dp(5))
            if (d.status == "SUBMITTED") {
                item.add(button("Reveal this result") {
                    activeDecisionId = d.id
                    currentCase = candidates().firstOrNull { it.id == d.id }
                    if (currentCase == null) renderResults() else {
                        val cached = AcademyStore.chartPoints(currentCase!!.coin.tok.mint)
                        chartAll = cached
                        renderGame()
                    }
                    selectedTab = 0; styleTabs(); render()
                }, top = dp(9))
            }
            holder.add(item, bottom = dp(8))
        }
    }

    private fun brier(ds: List<AcademyDecision>, target: Double): Double? {
        if (ds.isEmpty()) return null
        var error = 0.0
        for (d in ds) {
            val actual = if (d.peakMc / d.entryMc >= target) 1.0 else 0.0
            val probability = (if (target <= 2.0) d.probability2x else d.probability4x) / 100.0
            error += (probability - actual) * (probability - actual)
        }
        return (1.0 - error / ds.size) * 100.0
    }

    private fun shortMint(mint: String): String = if (mint.length > 12) mint.take(5) + "…" + mint.takeLast(5) else mint

    private fun dateTime(seconds: Long): String = try {
        SimpleDateFormat("dd MMM yyyy · HH:mm", Locale.getDefault()).format(Date(seconds * 1000L))
    } catch (_: Throwable) { "Unknown time" }
}

/** Compact log-market-cap chart; it deliberately receives only candles at or before decision time. */
private class AcademyChart(context: Context) : View(context) {
    var points: List<Pair<Long, Double>> = emptyList()
        set(value) { field = value; invalidate() }
    var note: String = ""
        set(value) { field = value; invalidate() }

    private val density = resources.displayMetrics.density
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = density }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * density
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9f * density }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        fill.color = Theme.bg
        canvas.drawRoundRect(RectF(0f, 0f, w, h), 14f * density, 14f * density, fill)
        grid.color = Theme.border
        val left = 48f * density; val right = w - 10f * density
        val top = 12f * density; val bottom = h - 20f * density
        for (i in 0..3) {
            val y = top + (bottom - top) * i / 3f
            canvas.drawLine(left, y, right, y, grid)
        }
        if (points.size < 2) {
            text.color = Theme.muted; text.textAlign = Paint.Align.CENTER
            canvas.drawText(note.ifBlank { "Not enough historical candles" }, w / 2f, h / 2f, text)
            return
        }
        val values = points.map { it.second }.filter { it > 0.0 }
        if (values.size < 2) return
        val minV = max(1.0, values.minOrNull() ?: 1.0)
        val maxV = max(minV * 1.01, values.maxOrNull() ?: (minV * 1.5))
        val lo = ln(minV); val hi = ln(maxV)
        val t0 = points.first().first; val t1 = max(t0 + 1L, points.last().first)
        val path = Path()
        var started = false
        for (p in points) {
            if (p.second <= 0.0) continue
            val x = left + (p.first - t0).toFloat() / (t1 - t0).toFloat() * (right - left)
            val f = ((ln(p.second) - lo) / (hi - lo)).toFloat().coerceIn(0f, 1f)
            val y = bottom - f * (bottom - top)
            if (!started) { path.moveTo(x, y); started = true } else path.lineTo(x, y)
        }
        line.color = Theme.text
        canvas.drawPath(path, line)
        text.color = Theme.muted; text.textAlign = Paint.Align.RIGHT
        canvas.drawText(KolEngine.money(maxV), left - 5f * density, top + 3f * density, text)
        canvas.drawText(KolEngine.money(minV), left - 5f * density, bottom + 3f * density, text)
        text.textAlign = Paint.Align.LEFT
        canvas.drawText("Hourly pool candles · estimated MC", left, h - 5f * density, text)
    }
}
