package com.pocketflip.overlay

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

data class TokenInfo(
    val ca: String,
    val name: String,
    val symbol: String,
    val priceUsd: Double,
    val solUsdPrice: Double,
    val marketCap: Double,
    val liquidityUsd: Double,
    val volume24h: Double,
    val imageUrl: String
)

/** One buy or one sell inside a trade. SELL fills carry the % of the bag sold and the PnL of that slice. */
data class Fill(
    val side: String,            // "BUY" or "SELL"
    val timeMs: Long,
    val mc: Double,              // market cap at the moment of the fill
    val priceUsd: Double,
    val sol: Double,             // BUY: SOL spent (incl. priority fee) | SELL: net SOL received
    val pct: Double = 0.0,       // SELL only: % of the current bag that was sold
    val pnlSol: Double = 0.0,    // SELL only: PnL of that slice
    val remainingAfterPct: Double = 0.0
)

data class OpenPosition(
    val ca: String,
    val name: String,
    val symbol: String,
    val imageUrl: String,
    var entryMc: Double,
    var entryPriceUsd: Double,
    var solInvested: Double,
    var initialSolInvested: Double,
    var tokensHeld: Double,
    var remainingPct: Double,
    var realizedPnlSol: Double,
    val openedAtMs: Long,
    var lastMc: Double,
    var lastPriceUsd: Double,
    var peakMc: Double = 0.0,
    var realizedSolOut: Double = 0.0,
    val fills: MutableList<Fill> = mutableListOf(),
    /** mobile = created/managed on this phone; desktop = mirrored from the desktop paper account. */
    val source: String = "mobile"
)

/** One finished trade (coin fully sold). All partial sells live inside [fills]. */
data class ClosedTradeLog(
    val id: String,
    val ca: String,
    val name: String,
    val symbol: String,
    val imageUrl: String,
    val entryMc: Double,
    val avgExitMc: Double,
    val peakMc: Double,
    val solIn: Double,
    val solOut: Double,
    val pnlSol: Double,
    val multipleX: Double,       // avg exit MC / entry MC
    val holdDurationMs: Long,
    val openedAtMs: Long,
    val closedAtMs: Long,
    val fills: List<Fill>
) {
    val returnX: Double get() = if (solIn > 0.0) solOut / solIn else 0.0
    val roiPct: Double get() = if (solIn > 0.0) (pnlSol / solIn) * 100.0 else 0.0
    val peakX: Double get() = if (entryMc > 0.0) peakMc / entryMc else 0.0
    val sellCount: Int get() = fills.count { it.side == "SELL" }
    val buyCount: Int get() = fills.count { it.side == "BUY" }
}

/** What the bubble needs to show after pressing a sell button. */
data class SellResult(
    val symbol: String,
    val soldPct: Double,
    val solOut: Double,
    val slicePnlSol: Double,
    val multipleX: Double,
    val remainingPct: Double,
    val closed: Boolean,
    val tradePnlSol: Double
)

data class AppSettings(
    var solBalance: Double = 10.0,
    var solUsdPrice: Double = 185.0,
    var platformFeePct: Double = 1.0,
    var priorityFeeSol: Double = 0.005,
    var slippagePct: Double = 1.5,
    var buyPresets: List<Double> = listOf(0.25, 0.5, 1.0, 2.5),
    var sellPresets: List<Double> = listOf(25.0, 30.0, 50.0, 100.0),
    var activeCa: String = "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr"
)

object Formatters {
    fun compactUsd(value: Double): String {
        val v = if (value.isNaN() || value.isInfinite()) 0.0 else value
        return when {
            v >= 1_000_000_000.0 -> String.format(Locale.US, "$%.2fB", v / 1_000_000_000.0)
            v >= 1_000_000.0 -> String.format(Locale.US, "$%.2fM", v / 1_000_000.0)
            v >= 1_000.0 -> String.format(Locale.US, "$%.1fK", v / 1_000.0)
            else -> String.format(Locale.US, "$%.2f", v)
        }
    }

    fun solSigned(value: Double): String {
        val sign = if (value >= 0.0) "+" else "-"
        return String.format(Locale.US, "%s%.3f SOL", sign, abs(value))
    }

    fun pctSigned(value: Double): String {
        val sign = if (value >= 0.0) "+" else "-"
        return String.format(Locale.US, "%s%.0f%%", sign, abs(value))
    }

    fun multX(value: Double): String {
        val v = if (value.isNaN() || value.isInfinite() || value <= 0.0) 1.0 else value
        return String.format(Locale.US, "%.2fx", v)
    }

    fun duration(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(1L)
        val hrs = totalSec / 3600L
        val mins = (totalSec % 3600L) / 60L
        val secs = totalSec % 60L
        return when {
            hrs > 0L -> "${hrs}h ${mins}m ${secs}s"
            mins > 0L -> "${mins}m ${secs}s"
            else -> "${secs}s"
        }
    }

    fun shortCa(ca: String): String {
        if (ca.length <= 12) return ca
        return ca.take(6) + "..." + ca.takeLast(5)
    }

    fun solPlain(value: Double): String = String.format(Locale.US, "%.3f SOL", value)

    fun pctSigned1(value: Double): String {
        val sign = if (value >= 0.0) "+" else "-"
        return String.format(Locale.US, "%s%.1f%%", sign, abs(value))
    }

    fun amount(value: Double): String {
        return if (value == Math.floor(value)) value.toLong().toString() else value.toString()
    }

    fun dateTime(ms: Long): String =
        SimpleDateFormat("d MMM HH:mm:ss", Locale.US).format(Date(ms))
}
