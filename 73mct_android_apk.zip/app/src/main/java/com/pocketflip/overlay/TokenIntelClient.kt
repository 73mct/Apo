package com.pocketflip.overlay

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Holder distribution data returned by Vybe. Classification fields stay empty unless evidence exists. */
data class HolderIntel(
    val address: String,
    val share: Double,
    val cluster: String = "",
    val label: String = "",
    val kind: String = "",
    val flags: List<String> = emptyList(),
    val ownerName: String = "",
    val balance: Double? = null,
    val valueUsd: Double? = null,
    val rank: Int = 0
)

data class TokenIntel(
    val ca: String,
    val top10Pct: Double? = null,
    val devPct: Double? = null,
    val insiderPct: Double? = null,
    val sniperPct: Double? = null,
    val bundlePct: Double? = null,
    val devAddress: String = "",
    val devMigrationRecord: String = "",
    val migrationStatus: String = "Unknown",
    val holderCount: Int = 0,
    val holders: List<HolderIntel> = emptyList(),
    val source: String = "",
    val status: String = "",
    val updatedAtMs: Long = System.currentTimeMillis()
)

object TokenIntelClient {
    private const val VYBE_PROXY = "https://73mct-vybe-proxycopy.73mctt.workers.dev"
    private val executor = Executors.newSingleThreadExecutor()
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    fun load(ca: String, callback: (TokenIntel) -> Unit) {
        executor.execute {
            val result = try {
                fetch(ca)
            } catch (t: Throwable) {
                TokenIntel(ca = ca, status = "Vybe request failed · ${t.javaClass.simpleName}")
            }
            callback(result)
        }
    }

    private fun fetch(ca: String): TokenIntel {
        if (!ca.matches(Regex("^[1-9A-HJ-NP-Za-km-z]{32,44}$"))) {
            return TokenIntel(ca = ca, status = "Invalid Solana mint address")
        }

        val url = "$VYBE_PROXY/tokens/$ca/top-holders?limit=100&page=0"
        val request = Request.Builder()
            .url(url)
            .get()
            .header("Accept", "application/json")
            .header("Cache-Control", "no-cache")
            .header("User-Agent", "73MCT-Android/14.5")
            .build()

        val responseData = try {
            http.newCall(request).execute().use { response ->
                Pair(response.code, response.body?.string().orEmpty())
            }
        } catch (t: Throwable) {
            return TokenIntel(ca = ca, source = "Vybe Network", status = "Cannot reach holder data · ${t.javaClass.simpleName}")
        }
        val responseCode = responseData.first
        val body = responseData.second
        if (responseCode !in 200..299) {
            val detail = try {
                val errorJson = JSONObject(body)
                errorJson.optString("error", errorJson.optString("message", ""))
            } catch (_: Throwable) { "" }
            return TokenIntel(
                ca = ca,
                source = "Vybe Network",
                status = "Vybe HTTP $responseCode" + if (detail.isNotBlank()) " · ${detail.take(90)}" else ""
            )
        }
        if (body.isBlank()) {
            return TokenIntel(ca = ca, source = "Vybe Network", status = "Vybe returned an empty response")
        }
        val root = try {
            JSONObject(body)
        } catch (_: Throwable) {
            return TokenIntel(ca = ca, source = "Vybe Network", status = "Vybe returned invalid JSON")
        }

        val rows = root.optJSONArray("data")
            ?: root.optJSONObject("data")?.optJSONArray("data")
            ?: root.optJSONArray("holders")
            ?: JSONArray()

        val holders = ArrayList<HolderIntel>()
        for (i in 0 until rows.length()) {
            val row = rows.optJSONObject(i) ?: continue
            val address = row.optString("ownerAddress", row.optString("owner_address", "")).trim()
            if (address.isBlank() || address == "null") continue
            val pct = readNumber(row, "percentageOfSupplyHeld", "percentage_of_supply_held", "percentage")
                ?: continue
            val balance = readNumber(row, "balance")
            val valueUsd = readNumber(row, "valueUsd", "value_usd")
            holders.add(
                HolderIntel(
                    address = address,
                    share = (pct / 100.0).coerceIn(0.0, 1.0),
                    label = row.optString("ownerLabel", row.optString("owner_label", "")).takeUnless { it == "null" }.orEmpty(),
                    ownerName = row.optString("ownerName", row.optString("owner_name", "")).takeUnless { it == "null" }.orEmpty(),
                    balance = balance,
                    valueUsd = valueUsd,
                    rank = row.optInt("rank", i + 1)
                )
            )
        }
        holders.sortByDescending { it.share }
        val top10 = if (holders.isNotEmpty()) holders.take(10).sumOf { it.share } * 100.0 else null
        val migration = getDexType(ca)

        val status = when {
            holders.isNotEmpty() -> "Updated from Vybe Network · ${holders.size} top holders returned"
            root.optString("error").isNotBlank() -> "Vybe: ${root.optString("error").take(100)}"
            else -> "Vybe returned no usable holder rows"
        }

        return TokenIntel(
            ca = ca,
            top10Pct = top10,
            // Holder ranking alone cannot prove developer, insider, sniper or bundler identity.
            devPct = null,
            insiderPct = null,
            sniperPct = null,
            bundlePct = null,
            devAddress = "",
            devMigrationRecord = "Not identified by the holder-ranking endpoint",
            migrationStatus = migration,
            holderCount = holders.size,
            holders = holders.take(100),
            source = "Vybe Network",
            status = status
        )
    }

    private fun readNumber(obj: JSONObject, vararg keys: String): Double? {
        for (key in keys) {
            if (!obj.has(key) || obj.isNull(key)) continue
            val raw = obj.opt(key)
            val value = when (raw) {
                is Number -> raw.toDouble()
                else -> raw.toString().toDoubleOrNull()
            }
            if (value != null && value.isFinite()) return value
        }
        return null
    }

    private fun getDexType(ca: String): String {
        return try {
            val request = Request.Builder()
                .url("https://api.dexscreener.com/token-pairs/v1/solana/$ca")
                .header("Accept", "application/json")
                .build()
            val responseData = http.newCall(request).execute().use { response ->
                Pair(response.isSuccessful, response.body?.string().orEmpty())
            }
            if (!responseData.first || responseData.second.isBlank()) return "Unknown"
            val arr = JSONArray(responseData.second)
            var best = ""
            var bestLiquidity = -1.0
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val liquidity = item.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
                if (liquidity > bestLiquidity) {
                    bestLiquidity = liquidity
                    best = item.optString("dexId", "")
                }
            }
            when {
                best.contains("pumpswap", true) -> "Migrated · PumpSwap"
                best.contains("pumpfun", true) -> "Bonding curve"
                best.isNotBlank() -> "DEX pool · $best"
                else -> "Unknown"
            }
        } catch (_: Throwable) { "Unknown" }
    }
}
