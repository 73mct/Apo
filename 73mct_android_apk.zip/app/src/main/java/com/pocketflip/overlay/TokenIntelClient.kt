package com.pocketflip.overlay

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.pow

/** Public, read-only token distribution data used by the floating Info pane. */
data class HolderIntel(
    val address: String,
    val share: Double,
    val cluster: String = "",
    val label: String = "",
    val kind: String = "",
    val flags: List<String> = emptyList()
)

data class HolderEdge(val from: String, val to: String)

data class TokenIntel(
    val ca: String,
    val top10Pct: Double? = null,
    val devPct: Double? = null,
    val insiderPct: Double? = null,
    val sniperPct: Double? = null,
    val bundlePct: Double? = null,
    val devAddress: String = "",
    val devMigrationRecord: String = "",
    val migrationStatus: String = "Unknown",
    val holderCount: Int = 0,
    val holders: List<HolderIntel> = emptyList(),
    val edges: List<HolderEdge> = emptyList(),
    val hasBubbleMap: Boolean = false,
    val source: String = "",
    val status: String = "",
    val updatedAtMs: Long = System.currentTimeMillis()
)

object TokenIntelClient {
    private val executor = Executors.newSingleThreadExecutor()
    private val devHistoryExecutor = Executors.newSingleThreadExecutor()
    private val rpcIndex = AtomicInteger(0)
    private val mapThrottleLock = Any()
    private var nextMapRequestAtMs = 0L
    private val devHistoryThrottleLock = Any()
    private var nextDevHistoryRequestAtMs = 0L
    private val devHistoryRequestTimes = ArrayDeque<Long>()
    private val devHistoryCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private val http = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
    private val rpcUrls = arrayOf(
        "https://solana-rpc.publicnode.com",
        "https://api.mainnet-beta.solana.com"
    )

    fun load(ca: String, callback: (TokenIntel) -> Unit) {
        executor.execute {
            val result = try {
                fetch(ca)
            } catch (t: Throwable) {
                TokenIntel(ca = ca, status = "Token data is temporarily unavailable")
            }
            // Render holders/launch-risk data immediately. The slower creator-history lookup
            // updates only the dev-history row when it arrives.
            val initial = if (result.devAddress.isNotBlank()) result.copy(devMigrationRecord = "Checking creator history…") else result
            callback(initial)
            if (result.devAddress.isNotBlank()) {
                devHistoryExecutor.execute {
                    val history = fetchDevMigrationRecord(result.devAddress)
                    if (history.isNotBlank()) callback(result.copy(devMigrationRecord = history))
                }
            }
        }
    }

    private fun fetch(ca: String): TokenIntel {
        var creator = ""
        var migration = "Unknown"

        var map: JSONObject? = null
        var legacySummary: JSONObject? = null
        var legacyGrade: JSONObject? = null
        var mapPending = false
        try {
            // The public map endpoint rate-limits newly requested maps to roughly one per second.
            val now = System.currentTimeMillis()
            val delay = synchronized(mapThrottleLock) {
                val wait = (nextMapRequestAtMs - now).coerceAtLeast(0L)
                nextMapRequestAtMs = now + wait + 1_100L
                wait
            }
            if (delay > 0L) Thread.sleep(delay)
            val response = getJsonResponse("https://bubblemaps.dev/api/map/$ca")
            if (response != null) {
                map = response.second.optJSONObject("map")
                legacySummary = response.second.optJSONObject("summary")
                legacyGrade = response.second.optJSONObject("grade")
                val job = response.second.optJSONObject("job")
                val jobState = job?.optString("state", "") ?: ""
                // map=null is not synonymous with a pending job: the service can finish
                // indexing but return only its summary/grade for locked or partial maps.
                mapPending = response.first == 202 || jobState == "queued" || jobState == "running"
            }
        } catch (_: Throwable) {}

        // The legacy endpoint can return HTTP 202 while its graph is queued, and may
        // return a completed job with map=null. Do not treat that as the only source:
        // Bubbles' documented v0 holder endpoint serves balances independently, while
        // the v0 map endpoint returns top holders, clusters and relationships directly.
        val v0Holders = try {
            getJson("https://bubblemaps.dev/v0/tokens/holders/solana/$ca?limit=80&return_metadata=true") as? JSONArray
        } catch (_: Throwable) { null }
        val v0Map = if (map == null || (map.optJSONArray("nodes")?.length() ?: 0) == 0) {
            try {
                getJson("https://bubblemaps.dev/v0/tokens/map/solana/$ca?return_nodes=true&return_relationships=true&return_clusters=true") as? JSONObject
            } catch (_: Throwable) { null }
        } else null

        val holders = ArrayList<HolderIntel>()
        val edges = ArrayList<HolderEdge>()
        var top10: Double? = null
        var devPct: Double? = null
        var insiderPct: Double? = null
        var sniperPct: Double? = null
        var bundlePct: Double? = null
        var providerCreator = ""
        var source = "Solana RPC"
        var hasBubbleMap = false

        // Even when Bubbles cannot expose a graph, its response can contain a useful
        // summary and risk-factor breakdown. Keep those metrics instead of showing a
        // misleading endless "preparing" state.
        if (legacySummary != null) {
            source = "Bubbles summary"
            top10 = fractionToPct(legacySummary!!, "top10Share")
        }
        val gradeFactors = legacyGrade?.optJSONArray("factors")
        if (gradeFactors != null) {
            for (i in 0 until gradeFactors.length()) {
                val factor = gradeFactors.optJSONObject(i) ?: continue
                val value = factor.optDouble("value", Double.NaN)
                if (value.isNaN() || value.isInfinite()) continue
                when (factor.optString("key", "")) {
                    "top10" -> if (top10 == null) top10 = numberToPct(value)
                    "bundlersNow", "bundlersLaunch" -> if (bundlePct == null) bundlePct = numberToPct(value)
                    "dev" -> if (devPct == null) devPct = numberToPct(value)
                }
            }
        }

        if (map != null) {
            source = "Bubbles holder map"
            val launch = map.optJSONObject("launch")
            if (launch != null) {
                top10 = fractionToPct(launch, "top10Share")
                insiderPct = fractionToPct(launch, "devClusterShare")
                sniperPct = fractionToPct(launch, "sniperShare")
                bundlePct = fractionToPct(launch, "bundleShare")
                providerCreator = launch.optString("creator", "")
            }
            val nodes = map.optJSONArray("nodes") ?: JSONArray()
            hasBubbleMap = nodes.length() > 0
            val nodeAddresses = ArrayList<String>()
            for (i in 0 until nodes.length()) {
                val node = nodes.optJSONObject(i) ?: continue
                val address = node.optString("address", "")
                if (address.isBlank()) continue
                nodeAddresses.add(address)
                val flagsObj = node.optJSONObject("flags")
                val flags = ArrayList<String>()
                if (flagsObj != null) {
                    if (flagsObj.optBoolean("dev")) flags.add("DEV")
                    if (flagsObj.optBoolean("dev-funded")) flags.add("DEV FUNDED")
                    if (flagsObj.optBoolean("dev-cluster")) flags.add("DEV CLUSTER")
                    if (flagsObj.optBoolean("sniper")) flags.add("SNIPER")
                    if (flagsObj.optBoolean("bundle")) flags.add("BUNDLE")
                    if (flagsObj.optBoolean("launch-slot")) flags.add("EARLY")
                }
                val share = node.optDouble("share", 0.0).coerceIn(0.0, 1.0)
                val item = HolderIntel(
                    address = address,
                    share = share,
                    cluster = node.optString("cluster", ""),
                    label = node.optString("label", ""),
                    kind = node.optString("kind", ""),
                    flags = flags
                )
                holders.add(item)
                if (flags.contains("DEV") || address == creator || address == providerCreator) {
                    devPct = ((devPct ?: 0.0) + share * 100.0)
                }
            }
            holders.sortByDescending { it.share }
            if (top10 == null && holders.isNotEmpty()) top10 = holders.take(10).sumOf { it.share } * 100.0
            if (devPct == null && holders.any { it.address == creator || it.address == providerCreator }) {
                devPct = holders.filter { it.address == creator || it.address == providerCreator }.sumOf { it.share } * 100.0
            }

            addEdges(map.optJSONArray("links"), edges, nodeAddresses)
            addEdges(map.optJSONArray("funderLinks"), edges, nodeAddresses)
        }

        // Parse the documented v0 response shape. It is deliberately separate from
        // the legacy /api/map schema: v0 uses nodes.top_holders, relationships and clusters.
        if (holders.isEmpty() && v0Holders != null) {
            for (i in 0 until v0Holders.length()) {
                val row = v0Holders.optJSONObject(i) ?: continue
                val address = row.optString("address", "")
                val holderData = row.optJSONObject("holder_data")
                if (address.isBlank() || holderData == null) continue
                val share = holderData.optDouble("share", 0.0).coerceIn(0.0, 1.0)
                val details = row.optJSONObject("address_details")
                val label = details?.optString("label", "") ?: ""
                val flags = ArrayList<String>()
                if (label.contains("dev", true) || label.contains("creator", true)) flags.add("DEV")
                if (label.contains("sniper", true)) flags.add("SNIPER")
                if (label.contains("bundle", true)) flags.add("BUNDLE")
                holders.add(HolderIntel(address = address, share = share, label = label, flags = flags))
            }
            holders.sortByDescending { it.share }
            if (holders.isNotEmpty()) source = "Bubbles holder index"
        }

        if (v0Map != null) {
            val nodesObj = v0Map.optJSONObject("nodes")
            val topHolders = nodesObj?.optJSONArray("top_holders")
            val clusterByAddress = HashMap<String, String>()
            val clusters = v0Map.optJSONArray("clusters")
            if (clusters != null) {
                for (i in 0 until clusters.length()) {
                    val cluster = clusters.optJSONObject(i) ?: continue
                    val members = cluster.optJSONArray("holders") ?: continue
                    for (j in 0 until members.length()) {
                        val address = members.optString(j, "")
                        if (address.isNotBlank()) clusterByAddress[address] = "cluster-${i + 1}"
                    }
                }
            }
            if (holders.isEmpty() && topHolders != null) {
                for (i in 0 until topHolders.length()) {
                    val row = topHolders.optJSONObject(i) ?: continue
                    val address = row.optString("address", "")
                    val share = row.optJSONObject("holder_data")?.optDouble("share", 0.0) ?: 0.0
                    val label = row.optJSONObject("address_details")?.optString("label", "") ?: ""
                    if (address.isNotBlank()) {
                        val flags = if (label.contains("dev", true) || label.contains("creator", true)) listOf("DEV") else emptyList()
                        holders.add(HolderIntel(address, share.coerceIn(0.0, 1.0), clusterByAddress[address] ?: "", label, flags = flags))
                    }
                }
                holders.sortByDescending { it.share }
                if (holders.isNotEmpty()) source = "Bubbles v0 map"
            } else if (topHolders != null && topHolders.length() > 0) {
                // Attach cluster IDs to the holder rows already returned by the holders API.
                for (i in holders.indices) {
                    val holder = holders[i]
                    val cluster = clusterByAddress[holder.address]
                    if (cluster != null) holders[i] = holder.copy(cluster = cluster)
                }
            }

            val relationships = v0Map.optJSONArray("relationships")
            if (relationships != null) {
                for (i in 0 until relationships.length()) {
                    val relation = relationships.optJSONObject(i) ?: continue
                    val from = relation.optString("from_address", "")
                    val to = relation.optString("to_address", "")
                    if (from.isNotBlank() && to.isNotBlank() && from != to) edges.add(HolderEdge(from, to))
                }
            }
            // A v0 top-holder node set is enough to draw the holder bubbles; links are
            // drawn only when the provider actually returned relationships.
            hasBubbleMap = holders.isNotEmpty() && (topHolders != null && topHolders.length() > 0 ||
                clusters != null && clusters.length() > 0 || edges.isNotEmpty())

            val supplyStats = v0Map.optJSONObject("metrics")?.optJSONObject("supply_stats")
            if (top10 == null && supplyStats != null && supplyStats.has("top_10_adjusted")) {
                top10 = numberToPct(supplyStats.optDouble("top_10_adjusted", Double.NaN))
            }
            if (bundlePct == null && supplyStats != null && supplyStats.has("bundles")) {
                bundlePct = numberToPct(supplyStats.optDouble("bundles", Double.NaN))
            }
            if (source == "Solana RPC") source = "Bubbles v0 map"
        }

        // Derive transparent holder-based estimates when the provider supplied labels
        // but not an aggregate launch metric. These are lower bounds over returned holders,
        // not estimates for wallets outside the returned top-holder set.
        if (top10 == null && holders.isNotEmpty()) top10 = holders.take(10).sumOf { it.share } * 100.0
        if (devPct == null) {
            val devShare = holders.filter { it.flags.contains("DEV") }.sumOf { it.share }
            if (devShare > 0.0) devPct = devShare * 100.0
        }
        if (insiderPct == null) {
            val clusterShare = holders.filter { it.flags.contains("DEV CLUSTER") }.sumOf { it.share }
            if (clusterShare > 0.0) insiderPct = clusterShare * 100.0
        }
        if (sniperPct == null) {
            val flagged = holders.filter { it.flags.contains("SNIPER") }.sumOf { it.share }
            if (flagged > 0.0) sniperPct = flagged * 100.0
        }
        if (bundlePct == null) {
            val flagged = holders.filter { it.flags.contains("BUNDLE") }.sumOf { it.share }
            if (flagged > 0.0) bundlePct = flagged * 100.0
        }

        if (creator.isBlank()) creator = providerCreator
        if (creator.isBlank()) creator = holders.firstOrNull { it.flags.contains("DEV") }?.address ?: ""
        if (creator.isNotBlank() && devPct == null) {
            val creatorNode = holders.firstOrNull { it.address == creator || it.flags.contains("DEV") }
            if (creatorNode != null) devPct = creatorNode.share * 100.0
        }

        // Direct chain fallback gives reliable top token accounts even if the holder-map service
        // has not indexed this mint yet. These percentages do not imply wallet relationships.
        if (holders.isEmpty() || top10 == null) {
            val hadMapTop10 = top10 != null
            val rpcHolders = fetchRpcHolders(ca)
            if (rpcHolders.isNotEmpty()) {
                if (holders.isEmpty()) holders.addAll(rpcHolders)
                if (top10 == null) top10 = rpcHolders.take(10).sumOf { it.share } * 100.0
                if (creator.isNotBlank() && devPct == null) {
                    val dev = rpcHolders.firstOrNull { it.address == creator && it.label == "Wallet" }
                    if (dev != null) devPct = dev.share * 100.0
                }
                if (!hasBubbleMap) source = "Solana RPC · top token accounts"
                else if (!hadMapTop10) source = "Bubbles map + Solana RPC top-10"
            }
        }

        if (migration == "Unknown") {
            val dex = getDexType(ca)
            // A DEX listing alone does not prove that a token graduated from Pump.fun.
            // Keep it distinct from a confirmed Pump.fun migration.
            if (dex.isNotBlank()) {
                migration = when {
                    dex.contains("pumpswap", true) -> "Migrated · PumpSwap"
                    dex.contains("pumpfun", true) -> "Bonding curve"
                    else -> "DEX pool · $dex"
                }
            }
        }

        val status = when {
            holders.isNotEmpty() && hasBubbleMap -> "Updated from $source · holder relationships available"
            holders.isNotEmpty() -> "Updated from $source · relationship map not indexed for this token"
            top10 != null -> "Partial data from $source · holder list unavailable; tap Refresh to retry"
            mapPending -> "Bubbles is still indexing this token and no holder fallback responded. Tap Refresh to retry."
            else -> "No holder data returned. The public data providers did not return results; tap Refresh to retry."
        }

        return TokenIntel(
            ca = ca,
            top10Pct = top10,
            devPct = devPct,
            insiderPct = insiderPct,
            sniperPct = sniperPct,
            bundlePct = bundlePct,
            devAddress = creator,
            devMigrationRecord = "",
            migrationStatus = migration,
            holderCount = holders.size,
            holders = holders.sortedByDescending { it.share }.take(25),
            edges = edges.distinct().take(100),
            hasBubbleMap = hasBubbleMap,
            source = source,
            status = status
        )
    }

    private fun fractionToPct(obj: JSONObject, key: String): Double? {
        if (!obj.has(key) || obj.isNull(key)) return null
        val value = obj.optDouble(key, Double.NaN)
        if (value.isNaN() || value.isInfinite()) return null
        return (if (value <= 1.0) value * 100.0 else value).coerceIn(0.0, 100.0)
    }

    private fun numberToPct(value: Double): Double? {
        if (value.isNaN() || value.isInfinite()) return null
        return (if (value <= 1.0) value * 100.0 else value).coerceIn(0.0, 100.0)
    }

    private fun addEdges(arr: JSONArray?, output: MutableList<HolderEdge>, nodeAddresses: List<String>) {
        if (arr == null) return
        fun resolve(value: Any?): String {
            if (value == null || value == JSONObject.NULL) return ""
            val raw = value.toString()
            val index = raw.toIntOrNull()
            return if (index != null && index in nodeAddresses.indices) nodeAddresses[index] else raw
        }
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val from = resolve(obj.opt("from") ?: obj.opt("source") ?: obj.opt("fromAddress") ?: obj.opt("sourceAddress"))
            val to = resolve(obj.opt("to") ?: obj.opt("target") ?: obj.opt("toAddress") ?: obj.opt("targetAddress"))
            if (from.isNotBlank() && to.isNotBlank() && from != to) output.add(HolderEdge(from, to))
        }
    }

    private fun fetchRpcHolders(ca: String): List<HolderIntel> {
        val rpcUrl = rpcUrls[Math.floorMod(rpcIndex.getAndIncrement(), rpcUrls.size)]
        val largestBody = JSONObject().apply {
            put("jsonrpc", "2.0"); put("id", 1); put("method", "getTokenLargestAccounts")
            put("params", JSONArray().put(ca).put(JSONObject().put("commitment", "confirmed")))
        }
        val largestResponse = rpcCall(rpcUrl, largestBody) ?: rpcCall(rpcUrls.first { it != rpcUrl }, largestBody)
        val largest = largestResponse?.optJSONObject("result")?.optJSONArray("value") ?: return emptyList()
        val accountAddresses = ArrayList<String>()
        val accountAmounts = HashMap<String, Double>()
        for (i in 0 until largest.length()) {
            val item = largest.optJSONObject(i) ?: continue
            val address = item.optString("address", "")
            val amount = item.optString("uiAmountString", "").toDoubleOrNull()
                ?: item.optDouble("uiAmount", 0.0)
            if (address.isNotBlank() && amount > 0.0) {
                accountAddresses.add(address)
                accountAmounts[address] = amount
            }
        }
        if (accountAddresses.isEmpty()) return emptyList()

        val ownerBody = JSONObject().apply {
            put("jsonrpc", "2.0"); put("id", 1); put("method", "getMultipleAccounts")
            put("params", JSONArray().put(JSONArray().apply { accountAddresses.forEach { put(it) } })
                .put(JSONObject().put("encoding", "jsonParsed").put("commitment", "confirmed")))
        }
        val ownerResponse = rpcCall(rpcUrl, ownerBody) ?: rpcCall(rpcUrls.first { it != rpcUrl }, ownerBody)
        val accounts = ownerResponse?.optJSONObject("result")?.optJSONArray("value")
        val totals = LinkedHashMap<String, Double>()
        val labels = HashMap<String, String>()
        for (i in accountAddresses.indices) {
            val account = accounts?.optJSONObject(i)
            val info = account?.optJSONObject("data")?.optJSONObject("parsed")?.optJSONObject("info")
            val parsedOwner = info?.optString("owner", "")?.takeIf { it.isNotBlank() }
            val owner = parsedOwner ?: accountAddresses[i]
            labels[owner] = if (parsedOwner != null) "Wallet" else "Token account"
            totals[owner] = (totals[owner] ?: 0.0) + (accountAmounts[accountAddresses[i]] ?: 0.0)
        }
        val supplyBody = JSONObject().apply {
            put("jsonrpc", "2.0"); put("id", 1); put("method", "getTokenSupply")
            put("params", JSONArray().put(ca).put(JSONObject().put("commitment", "confirmed")))
        }
        val supplyResponse = rpcCall(rpcUrl, supplyBody) ?: rpcCall(rpcUrls.first { it != rpcUrl }, supplyBody)
        val supplyObj = supplyResponse?.optJSONObject("result")?.optJSONObject("value") ?: return emptyList()
        val supply = supplyObj.optString("uiAmountString", "").toDoubleOrNull()
            ?: run {
                val raw = supplyObj.optString("amount", "").toDoubleOrNull() ?: 0.0
                raw / 10.0.pow(supplyObj.optInt("decimals", 0))
            }
        if (supply <= 0.0) return emptyList()
        return totals.entries.sortedByDescending { it.value }.take(20).map {
            HolderIntel(address = it.key, share = (it.value / supply).coerceIn(0.0, 1.0), label = labels[it.key] ?: "Token account")
        }
    }

    /** Fetches an independent on-chain-derived Pump.fun deployer history (free public tier). */
    private fun fetchDevMigrationRecord(creator: String): String {
        if (creator.isBlank()) return ""
        val now = System.currentTimeMillis()
        val cached = devHistoryCache[creator]
        if (cached != null && now - cached.first < 6L * 60L * 60L * 1000L) return cached.second

        // Public /free/deployer is limited to 30 calls / 5 minutes and 300 / day per IP.
        // Keep a little headroom under both limits; cache results by creator for six hours.
        val delay = synchronized(devHistoryThrottleLock) {
            while (devHistoryRequestTimes.isNotEmpty() && now - devHistoryRequestTimes.peekFirst() > 24L * 60L * 60L * 1000L) {
                devHistoryRequestTimes.removeFirst()
            }
            if (devHistoryRequestTimes.size >= 280) return "Not checked · daily free query limit reached"
            val wait = (nextDevHistoryRequestAtMs - now).coerceAtLeast(0L)
            nextDevHistoryRequestAtMs = now + wait + 10_500L
            wait
        }
        if (delay > 0L) Thread.sleep(delay)
        synchronized(devHistoryThrottleLock) { devHistoryRequestTimes.addLast(System.currentTimeMillis()) }

        return try {
            val root = getJson("https://pumpdata.fun/free/deployer/$creator") as? JSONObject ?: return "Unavailable · provider did not return a creator record"
            val record = root.optJSONObject("record") ?: return "Unavailable · creator record not indexed"
            val launches = record.optInt("launches", 0)
            val graduations = record.optInt("graduations", 0)
            val rateRaw = record.optDouble("graduation_rate", if (launches > 0) graduations.toDouble() / launches else 0.0)
            val ratePct = if (rateRaw <= 1.0) rateRaw * 100.0 else rateRaw
            val last90 = root.optJSONObject("last_90_days")
            val doubled = last90?.optInt("doubled", 0)
            val tenX = last90?.optInt("ten_x", 0)
            val measured = last90?.optInt("launches_measured", 0)
            val recent = if (measured != null && measured > 0 && doubled != null && tenX != null) {
                " · 90d: $doubled reached 2×, $tenX reached 10× / $measured measured"
            } else ""
            val result = "$graduations/$launches graduated (${String.format(java.util.Locale.US, "%.1f", ratePct)}%)$recent"
            devHistoryCache[creator] = Pair(System.currentTimeMillis(), result)
            result
        } catch (_: Throwable) {
            "Unavailable · creator history request failed"
        }
    }

    private fun getDexType(ca: String): String {
        return try {
            val arr = getJson("https://api.dexscreener.com/token-pairs/v1/solana/$ca") as? JSONArray ?: return ""
            var best = ""
            var bestLiq = -1.0
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val liq = item.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
                if (liq > bestLiq) { bestLiq = liq; best = item.optString("dexId", "") }
            }
            best
        } catch (_: Throwable) { "" }
    }

    private fun rpcCall(body: JSONObject): JSONObject? {
        val url = rpcUrls[Math.floorMod(rpcIndex.getAndIncrement(), rpcUrls.size)]
        return rpcCall(url, body)
    }

    private fun rpcCall(url: String, body: JSONObject): JSONObject? {
        return postJson(url, body.toString())
    }

    private fun getJson(url: String): Any? {
        val req = Request.Builder().url(url)
            .header("Cache-Control", "no-cache")
            .header("Accept", "application/json")
            .header("User-Agent", "73MCT-Android/14.3")
            .build()
        http.newCall(req).execute().use { response ->
            if (!response.isSuccessful) return null
            val body = response.body?.string() ?: return null
            return if (body.trimStart().startsWith("[")) JSONArray(body) else JSONObject(body)
        }
    }

    private fun getJsonResponse(url: String): Pair<Int, JSONObject>? {
        val req = Request.Builder().url(url)
            .header("Cache-Control", "no-cache")
            .header("Accept", "application/json")
            .header("User-Agent", "73MCT-Android/14.3")
            .build()
        http.newCall(req).execute().use { response ->
            val body = response.body?.string() ?: return null
            if (response.code !in 200..299) return null
            return Pair(response.code, JSONObject(body))
        }
    }

    private fun postJson(url: String, body: String): JSONObject? {
        val req = Request.Builder().url(url)
            .post(body.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .header("Cache-Control", "no-cache")
            .build()
        http.newCall(req).execute().use { response ->
            if (!response.isSuccessful) return null
            return response.body?.string()?.let { JSONObject(it) }
        }
    }

}
