package com.pocketflip.overlay

import android.animation.ValueAnimator
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Price chart of one coin with every tracked KOL's buys (filled dots) and sells (rings) on it. */
class KolChart(context: Context) : View(context) {
    class Mark(val t: Long, val mc: Double, val buy: Boolean, val letter: String, val color: Int)

    var pts: List<Pair<Long, Double>> = emptyList()
    var marks: List<Mark> = emptyList()
    var progress: Float = 1f
    var note: String = ""

    private val d = resources.displayMetrics.density
    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val gridP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txtP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }

    private fun range(): Pair<Long, Long> {
        var a = Long.MAX_VALUE
        var b = Long.MIN_VALUE
        for (p in pts) { a = min(a, p.first); b = max(b, p.first) }
        for (m in marks) { a = min(a, m.t); b = max(b, m.t) }
        if (a == Long.MAX_VALUE) return Pair(0L, 1L)
        if (b <= a) b = a + 1L
        return Pair(a, b)
    }

    fun timeAt(p: Float): Long {
        val r = range()
        return r.first + ((r.second - r.first) * p).toLong()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        bgP.shader = LinearGradient(0f, 0f, 0f, h,
            Theme.mix(Theme.card, Theme.accent, 0.08f), Theme.card, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(0f, 0f, w, h), 18f * d, 18f * d, bgP)
        bgP.shader = null
        strokeP.color = Theme.border; strokeP.strokeWidth = 1f * d
        c.drawRoundRect(RectF(0.5f, 0.5f, w - 0.5f, h - 0.5f), 18f * d, 18f * d, strokeP)

        if (pts.isEmpty() && marks.isEmpty()) {
            txtP.color = Theme.muted; txtP.textSize = 12f * d; txtP.textAlign = Paint.Align.CENTER
            c.drawText(if (note.isEmpty()) "Loading chart..." else note, w / 2f, h / 2f, txtP)
            return
        }
        val padL = 52f * d
        val padR = 12f * d
        val padT = 14f * d
        val padB = 24f * d
        val pw = w - padL - padR
        val ph = h - padT - padB
        val (t0, t1) = range()
        var lo = Double.MAX_VALUE
        var hi = 0.0
        for (p in pts) { if (p.second > 0.0) { lo = min(lo, p.second); hi = max(hi, p.second) } }
        for (m in marks) { if (m.mc > 0.0) { lo = min(lo, m.mc); hi = max(hi, m.mc) } }
        if (lo == Double.MAX_VALUE || hi <= 0.0) { lo = 1.0; hi = 10.0 }
        if (hi <= lo) hi = lo * 1.5
        var llo = ln(lo)
        var lhi = ln(hi)
        val pad = (lhi - llo) * 0.08
        llo -= pad; lhi += pad
        fun tx(t: Long): Float = padL + (t - t0).toFloat() / (t1 - t0).toFloat() * pw
        fun ty(mc: Double): Float = padT + (1f - ((ln(max(mc, 1.0)) - llo) / (lhi - llo)).toFloat()) * ph

        // grid + market cap labels (log scale)
        gridP.color = Theme.alpha(Theme.border, 160); gridP.strokeWidth = 1f * d
        txtP.color = Theme.muted; txtP.textSize = 9f * d; txtP.textAlign = Paint.Align.RIGHT
        for (i in 0..3) {
            val f = i / 3.0
            val v = exp(lhi - (lhi - llo) * f)
            val y = padT + ph * f.toFloat()
            c.drawLine(padL, y, w - padR, y, gridP)
            c.drawText(KolEngine.money(v), padL - 5f * d, y + 3f * d, txtP)
        }
        txtP.textAlign = Paint.Align.LEFT
        c.drawText(KolEngine.dur(t1 - t0) + " window", padL, h - 7f * d, txtP)
        txtP.textAlign = Paint.Align.RIGHT
        c.drawText("filled = buy   ring = sell", w - padR, h - 7f * d, txtP)

        val tNow = t0 + ((t1 - t0) * progress).toLong()

        // price line
        if (pts.size >= 2) {
            val path = Path()
            var started = false
            var lastX = 0f
            var lastY = 0f
            for (p in pts) {
                if (p.first > tNow) break
                val x = tx(p.first)
                val y = ty(p.second)
                if (!started) { path.moveTo(x, y); started = true } else path.lineTo(x, y)
                lastX = x; lastY = y
            }
            if (started) {
                linePaint.color = Theme.accent; linePaint.strokeWidth = 2.4f * d
                c.drawPath(path, linePaint)
                if (progress < 1f) {
                    dotP.color = Theme.alpha(Theme.accent, 70)
                    c.drawCircle(lastX, lastY, 9f * d, dotP)
                    dotP.color = Theme.accent
                    c.drawCircle(lastX, lastY, 4f * d, dotP)
                }
            }
        }

        // KOL buys / sells
        txtP.textAlign = Paint.Align.CENTER
        txtP.textSize = 9f * d
        txtP.isFakeBoldText = true
        for (m in marks) {
            if (m.t > tNow || m.mc <= 0.0) continue
            val age = (tNow - m.t).toFloat() / (t1 - t0).toFloat()
            val s = min(1f, 0.35f + age / 0.03f)
            val x = tx(m.t)
            val y = ty(m.mc)
            val r = 9f * d * s
            if (m.buy) {
                dotP.color = m.color
                c.drawCircle(x, y, r, dotP)
                txtP.color = Theme.onColor(m.color)
            } else {
                dotP.color = Theme.card
                c.drawCircle(x, y, r, dotP)
                strokeP.color = m.color; strokeP.strokeWidth = 2f * d
                c.drawCircle(x, y, r, strokeP)
                txtP.color = m.color
            }
            c.drawText(m.letter, x, y + 3f * d, txtP)
        }
        txtP.isFakeBoldText = false
    }
}

/**
 * The KOL Tracker as a full page inside the app (a tab in the bottom nav, like Profile and Settings).
 * MainActivity hosts it; all scrolling is done by MainActivity's body scroll.
 */
class KolScreen(private val act: Activity) : LinearLayout(act) {

    /** MainActivity sets this so opening a detail page scrolls back to the top. */
    var scrollTop: (() -> Unit)? = null


    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private val palette = intArrayOf(
        0xFFE6E6E6.toInt(), 0xFF4ADE80.toInt(), 0xFFF87171.toInt(), 0xFF60A5FA.toInt(),
        0xFFFBBF24.toInt(), 0xFFC084FC.toInt(), 0xFF2DD4BF.toInt(), 0xFFFB923C.toInt()
    )

    private lateinit var holder: LinearLayout
    private lateinit var tabBar: LinearLayout
    private val tabNames = listOf("Coins", "KOLs", "Themes", "Wallets", "Game")
    private val game: KolGame by lazy { KolGame(act) }
    private val tabViews = ArrayList<TextView>()
    private var tab = 0
    private var detailOpen = false

    private var coins: List<KolCoin> = emptyList()
    private var stats: List<KolStat> = emptyList()
    private var themes: List<KolTheme> = emptyList()

    private var coinFilter = 0           // 0 all, 1 two or more KOLs, 2 long holds
    private var kolSort = 0              // 0 early hits, 1 pnl, 2 win rate, 3 median x, 4 hold
    private var scanning = false
    private var statusText: TextView? = null
    private var lastStatus = ""
    private var anim: ValueAnimator? = null

    // ---------- tiny UI helpers ----------
    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView =
        TextView(act).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun vstack() = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private fun hstack() = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun LinearLayout.add(
        v: View, top: Int = 0, bottom: Int = 0, left: Int = 0, right: Int = 0,
        w: Int = LinearLayout.LayoutParams.MATCH_PARENT,
        h: Int = LinearLayout.LayoutParams.WRAP_CONTENT, weight: Float = 0f
    ) {
        val p = if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
        p.topMargin = top; p.bottomMargin = bottom; p.leftMargin = left; p.rightMargin = right
        addView(v, p)
    }

    private fun card(): LinearLayout = vstack().apply {
        background = Theme.surface(dp(20), Theme.border, dp(1))
        elevation = dp(4).toFloat()
        setPadding(dp(15), dp(14), dp(15), dp(14))
    }

    private fun pill(label: String, color: Int = Theme.text, onClick: () -> Unit): TextView =
        tv(label, 12f, color, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.box(Theme.surface2, Theme.border, dp(14), dp(1))
            setOnClickListener { onClick() }
        }

    private fun filledPill(label: String, onClick: () -> Unit): TextView =
        tv(label, 13f, Theme.onColor(Theme.accent), bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = Theme.button(Theme.accent, dp(14))
            setOnClickListener { onClick() }
        }

    private fun chipRow(labels: List<String>, selected: Int, onPick: (Int) -> Unit): HorizontalScrollView {
        val sv = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false }
        val row = hstack()
        for ((i, l) in labels.withIndex()) {
            val on = i == selected
            val chip = tv(l, 12f, if (on) Theme.onColor(Theme.accent) else Theme.muted, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(7), dp(12), dp(7))
                background = Theme.chip(on, dp(12))
                setOnClickListener { onPick(i) }
            }
            row.add(chip, right = dp(6), w = LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        sv.addView(row)
        return sv
    }

    private fun solFmt(v: Double) = String.format("%+.2f SOL", v)
    private fun xFmt(v: Double) = String.format("%.1fx", v)
    private fun short(a: String) = if (a.length > 10) a.take(4) + ".." + a.takeLast(4) else a
    private fun colorOf(w: KolWallet): Int {
        val i = KolStore.wallets.indexOfFirst { it.address == w.address }
        return palette[(if (i < 0) 0 else i) % palette.size]
    }

    private fun copy(text: String, what: String) {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(what, text))
        Toast.makeText(act, what + " copied", Toast.LENGTH_SHORT).show()
    }

    private fun coinImage(tok: KolToken, size: Int): ImageView {
        val iv = ImageView(act)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Theme.circle(Theme.card, Theme.border, dp(1))
        iv.outlineProvider = ViewOutlineProvider.BACKGROUND
        iv.clipToOutline = true
        iv.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        CoinImages.bind(iv, tok.mint, if (tok.sym.isEmpty()) "?" else tok.sym, tok.img)
        return iv
    }

    // ---------- lifecycle ----------
    private fun setup() {
        Theme.init(act)
        CoinImages.init(act)
        KolStore.init(act)
        orientation = VERTICAL
        visibility = View.GONE

        val title = hstack()
        val tcol = vstack()
        tcol.add(tv("KOL Tracker", 22f, Theme.text, bold = true))
        tcol.add(tv("ON-CHAIN INTELLIGENCE  /  SMART MONEY", 9f, Theme.accent2, bold = true).apply { letterSpacing = 0.12f }, top = dp(3))
        tcol.add(tv("Follow the best traders and see who gets in early", 11f, Theme.muted), top = dp(3))
        title.add(tcol, w = 0, weight = 1f)
        add(title, bottom = dp(12))

        tabBar = hstack()
        for ((i, n) in tabNames.withIndex()) {
            val t = tv(n, 12f, Theme.text, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(2), dp(10), dp(2), dp(10))
                setOnClickListener { detailOpen = false; anim?.cancel(); tab = i; styleTabs(); render() }
            }
            tabViews.add(t)
            tabBar.add(t, w = 0, weight = 1f, right = dp(6))
        }
        add(tabBar, bottom = dp(12))

        holder = vstack()
        add(holder)
        styleTabs()
    }

    private var openedOnce = false

    /** Called by MainActivity every time the KOL tab is opened. */
    fun onShown() {
        try {
            if (!scanning) recompute()
        } catch (t: Throwable) {
            Toast.makeText(act, "KOL data could not load: " + (t.message ?: t.javaClass.simpleName), Toast.LENGTH_LONG).show()
        }
        if (!openedOnce) {
            openedOnce = true
            if (KolStore.wallets.isEmpty()) tab = 3
        }
        styleTabs()
        render()
    }

    fun destroy() {
        anim?.cancel()
        if (gameStarted()) game.destroy()
    }

    private var gameUsed = false
    private fun gameStarted(): Boolean = gameUsed

    /** Returns true if it handled Back (closed a detail page). */
    fun onBack(): Boolean {
        if (detailOpen) {
            detailOpen = false
            anim?.cancel()
            render()
            scrollTop?.invoke()
            return true
        }
        return false
    }

    private fun styleTabs() {
        for ((i, t) in tabViews.withIndex()) {
            val on = i == tab
            t.setTextColor(if (on) Theme.onColor(Theme.accent) else Theme.muted)
            t.background = Theme.chip(on, dp(14))
        }
        tabBar.visibility = View.VISIBLE
    }

    private fun recompute() {
        coins = KolEngine.buildCoins()
        stats = KolEngine.stats(coins)
        themes = KolEngine.narratives(coins)
    }

    private fun show(content: View) {
        holder.removeAllViews()
        content.alpha = 0f
        content.translationY = dp(8).toFloat()
        holder.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        content.animate().alpha(1f).translationY(0f).setDuration(230).start()
        if (detailOpen) scrollTop?.invoke()
    }

    private fun render() {
        statusText = null
        when (tab) {
            0 -> show(buildCoinsTab())
            1 -> show(buildKolsTab())
            2 -> show(buildThemesTab())
            4 -> { gameUsed = true; game.open(coins); show(game.view()) }
            else -> show(buildWalletsTab())
        }
    }

    private fun emptyHint(text: String): View =
        card().apply { add(tv(text, 13f, Theme.muted)) }

    // ======================= COINS =======================
    private val peakValues = listOf(0.0, 500_000.0, 1_000_000.0, 5_000_000.0)

    private fun buildCoinsTab(): LinearLayout {
        val col = vstack()
        val sel = peakValues.indexOfFirst { it == KolStore.minPeakMc }.let { if (it < 0) 2 else it }
        col.add(tv("Peak market cap", 11f, Theme.muted), bottom = dp(4))
        col.add(chipRow(listOf("Any", "500K+", "1M+", "5M+"), sel) {
            KolStore.minPeakMc = peakValues[it]; recompute(); render()
        }, bottom = dp(8))
        col.add(chipRow(listOf("All coins", "2+ KOLs in it", "Long holds (6h+)"), coinFilter) {
            coinFilter = it; render()
        }, bottom = dp(10))

        val minPeak = KolStore.minPeakMc
        var list = coins.filter { it.peak >= minPeak }
        if (coinFilter == 1) list = list.filter { it.kolCount >= 2 }
        if (coinFilter == 2) list = list.filter { it.longestHoldSec >= 6 * 3600L }
        list = list.sortedWith(compareByDescending<KolCoin> { it.kolCount }.thenByDescending { it.peak })

        col.add(tv(list.size.toString() + " coins  |  " + KolStore.wallets.size + " KOLs tracked  |  last " +
            KolStore.days + " days", 11f, Theme.muted), bottom = dp(8))
        if (KolStore.wallets.isEmpty()) {
            col.add(emptyHint("No KOL wallets yet. Open the Wallets tab, paste your wallet list and tap Scan."))
            return col
        }
        if (list.isEmpty()) {
            col.add(emptyHint("Nothing matches yet. Scan in the Wallets tab, or lower the peak filter. " +
                "Coins only show here after the scan finished and prices were found."))
            return col
        }
        for (c in list.take(60)) col.add(coinCard(c), bottom = dp(8))
        return col
    }

    private fun coinCard(c: KolCoin): View {
        val box = card()
        val row = hstack()
        row.add(coinImage(c.tok, 46), right = dp(12), w = dp(46), h = dp(46))
        val mid = vstack()
        val l1 = hstack()
        l1.add(tv("$" + (if (c.tok.sym.isEmpty()) short(c.tok.mint) else c.tok.sym), 15f, Theme.text, bold = true),
            w = 0, weight = 1f)
        l1.add(tv("Peak " + KolEngine.money(c.peak), 12f, Theme.text, bold = true, mono = true),
            w = LinearLayout.LayoutParams.WRAP_CONTENT)
        mid.add(l1)
        mid.add(tv(c.tok.name, 11f, Theme.muted))
        val first = c.positions.first()
        val firstLine = c.kolCount.toString() + (if (c.kolCount == 1) " KOL" else " KOLs") + "  |  first in: " +
            first.wallet.label + (if (first.entryMc > 0.0) " at " + KolEngine.money(first.entryMc) else "")
        mid.add(tv(firstLine, 11f, Theme.text), top = dp(4))
        mid.add(tv("KOL PnL " + solFmt(c.totalPnl) + "  |  best hold " + KolEngine.dur(c.longestHoldSec),
            11f, Theme.pnlColor(c.totalPnl), mono = true), top = dp(2))
        row.add(mid, w = 0, weight = 1f)
        box.add(row)
        box.setOnClickListener { showCoin(c) }
        return box
    }

    // ======================= COIN DETAIL =======================
    private fun showCoin(c: KolCoin) {
        detailOpen = true
        tabBar.visibility = View.VISIBLE
        val col = vstack()
        val head = hstack()
        head.add(coinImage(c.tok, 56), right = dp(12), w = dp(56), h = dp(56))
        val hv = vstack()
        hv.add(tv("$" + (if (c.tok.sym.isEmpty()) short(c.tok.mint) else c.tok.sym), 20f, Theme.text, bold = true))
        hv.add(tv(c.tok.name, 12f, Theme.muted))
        hv.add(tv(short(c.tok.mint), 11f, Theme.muted, mono = true), top = dp(2))
        head.add(hv, w = 0, weight = 1f)
        col.add(head, bottom = dp(10))

        val btns = hstack()
        btns.add(pill("Copy CA") { copy(c.tok.mint, "CA") }, w = 0, weight = 1f, right = dp(8))
        btns.add(pill("Dex chart") {
            val u = if (c.tok.pair.isNotEmpty()) "https://dexscreener.com/solana/" + c.tok.pair
            else "https://dexscreener.com/solana/" + c.tok.mint
            try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Throwable) {}
        }, w = 0, weight = 1f)
        col.add(btns, bottom = dp(10))

        val st = card()
        val r1 = hstack()
        r1.add(stat("Market cap now", KolEngine.money(c.tok.mc)), w = 0, weight = 1f)
        r1.add(stat("Peak", KolEngine.money(c.peak)), w = 0, weight = 1f)
        r1.add(stat("KOLs", c.kolCount.toString()), w = 0, weight = 1f)
        st.add(r1)
        col.add(st, bottom = dp(10))

        // chart + replay
        val chart = KolChart(act)
        val clock = tv("Loading chart...", 11f, Theme.muted, mono = true)
        col.add(chart, h = dp(250), bottom = dp(6))
        col.add(clock, bottom = dp(6))
        val firstFill = c.positions.minOf { p -> p.fills.minOf { it.ts } }
        val lastFill = c.positions.maxOf { p -> p.fills.maxOf { it.ts } }
        val marks = ArrayList<KolChart.Mark>()
        for (p in c.positions) {
            val color = colorOf(p.wallet)
            val letter = p.wallet.label.take(1).uppercase()
            for (f in p.fills.take(40)) {
                val mc = p.mcAt(f)
                if (mc > 0.0) marks.add(KolChart.Mark(f.ts, mc, f.buy, letter, color))
            }
        }
        chart.marks = marks
        val rbtn = hstack()
        val replayBtn = pill("Replay") { playReplay(chart, clock, firstFill) }
        rbtn.add(replayBtn, w = 0, weight = 1f, right = dp(8))
        rbtn.add(pill("Show full") { anim?.cancel(); chart.progress = 1f; chart.invalidate(); clock.text = "Full window" },
            w = 0, weight = 1f)
        col.add(rbtn, bottom = dp(12))

        io.execute {
            val cs = KolEngine.candles(c.tok, firstFill, lastFill)
            main.post {
                if (!detailOpen) return@post
                if (cs.size >= 3) {
                    chart.pts = cs
                } else {
                    // no candles: connect the KOL fills so the story is still visible
                    chart.note = "No candle data for this coin"
                    chart.pts = marks.sortedBy { it.t }.map { Pair(it.t, it.mc) }
                }
                chart.progress = 0f
                chart.invalidate()
                playReplay(chart, clock, firstFill)
            }
        }

        col.add(tv("Who got in, in order", 15f, Theme.text, bold = true), bottom = dp(8))
        val firstTs = c.positions.first().firstBuyTs
        for ((i, p) in c.positions.withIndex()) {
            col.add(positionCard(i + 1, p, p.firstBuyTs - firstTs), bottom = dp(8))
        }
        show(col)
    }

    private fun playReplay(chart: KolChart, clock: TextView, firstFill: Long) {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 10_000L
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            val v = it.animatedValue as Float
            chart.progress = v
            chart.invalidate()
            val t = chart.timeAt(v) - firstFill
            clock.text = "Replay  " + (if (t < 0) "-" else "+") + KolEngine.dur(kotlin.math.abs(t)) + " from first KOL entry"
        }
        anim = a
        a.start()
    }

    private fun stat(label: String, value: String, color: Int = Theme.text): LinearLayout {
        val v = vstack()
        v.add(tv(label, 10f, Theme.muted))
        v.add(tv(value, 14f, color, bold = true, mono = true), top = dp(2))
        return v
    }

    private fun positionCard(rank: Int, p: KolPos, afterSec: Long): View {
        val box = card()
        val l1 = hstack()
        val dot = tv(p.wallet.label.take(1).uppercase(), 11f, Theme.onColor(colorOf(p.wallet)), bold = true).apply {
            gravity = Gravity.CENTER
            background = Theme.circle(colorOf(p.wallet), colorOf(p.wallet), 0)
        }
        l1.add(dot, w = dp(24), h = dp(24), right = dp(8))
        l1.add(tv("#" + rank + "  " + p.wallet.label, 14f, Theme.text, bold = true), w = 0, weight = 1f)
        l1.add(tv(if (rank == 1) "first in" else "+" + KolEngine.dur(afterSec), 11f, Theme.muted, mono = true),
            w = LinearLayout.LayoutParams.WRAP_CONTENT)
        box.add(l1)
        box.add(tv("Entry " + KolEngine.money(p.entryMc) + "  |  in " + String.format("%.2f", p.invested) +
            " SOL  |  out " + String.format("%.2f", p.returned) + " SOL", 11f, Theme.text, mono = true), top = dp(6))
        val state = if (p.stillOpen) "holding " + (p.heldTok * 100.0 / p.boughtTok).toInt() + "%" else "sold all"
        box.add(tv(solFmt(p.pnl) + "  (" + xFmt(p.multiple) + ")  |  held " + KolEngine.dur(p.holdSec) + "  |  " + state,
            11f, Theme.pnlColor(p.pnl), mono = true), top = dp(3))
        if (p.exitMc > 0.0) box.add(tv("Avg exit " + KolEngine.money(p.exitMc), 11f, Theme.muted, mono = true), top = dp(3))
        box.setOnClickListener {
            val s = stats.firstOrNull { it.wallet.address == p.wallet.address }
            if (s != null) showKol(s)
        }
        return box
    }

    // ======================= KOLS =======================
    private fun buildKolsTab(): LinearLayout {
        val col = vstack()
        col.add(tv("Sort by", 11f, Theme.muted), bottom = dp(4))
        col.add(chipRow(listOf("Early hits", "PnL", "Win rate", "Median x", "Hold time"), kolSort) {
            kolSort = it; render()
        }, bottom = dp(8))
        col.add(tv("Early hit = got in under " + KolEngine.money(KolStore.earlyMc) + " on a coin that later peaked " +
            KolEngine.money(KolStore.minPeakMc) + "+", 11f, Theme.muted), bottom = dp(10))
        if (stats.isEmpty()) {
            col.add(emptyHint("No KOL data yet. Add wallets and scan in the Wallets tab."))
            return col
        }
        val sorted = when (kolSort) {
            0 -> stats.sortedWith(compareByDescending<KolStat> { it.earlyHits }.thenByDescending { it.firstIns })
            1 -> stats.sortedByDescending { it.totalPnl }
            2 -> stats.filter { it.trades >= 3 }.sortedByDescending { it.winRate }
            3 -> stats.filter { it.trades >= 3 }.sortedByDescending { it.avgMultiple }
            else -> stats.sortedByDescending { it.medianWinHoldSec }
        }
        for ((i, s) in sorted.withIndex()) {
            val box = card()
            val l1 = hstack()
            l1.add(tv("#" + (i + 1), 12f, Theme.muted, mono = true), w = dp(30))
            l1.add(tv(s.wallet.label, 15f, Theme.text, bold = true), w = 0, weight = 1f)
            l1.add(tv(solFmt(s.totalPnl), 12f, Theme.pnlColor(s.totalPnl), bold = true, mono = true),
                w = LinearLayout.LayoutParams.WRAP_CONTENT)
            box.add(l1)
            box.add(tv(s.earlyHits.toString() + " early hits  |  " + s.firstIns + " first-ins  |  win rate " +
                s.winRate.toInt() + "%", 11f, Theme.text), top = dp(5))
            box.add(tv(s.trades.toString() + " coins  |  median " + xFmt(s.avgMultiple) + "  |  win hold " +
                KolEngine.dur(s.medianWinHoldSec), 11f, Theme.muted, mono = true), top = dp(2))
            box.setOnClickListener { showKol(s) }
            col.add(box, bottom = dp(8))
        }
        return col
    }

    private fun showKol(s: KolStat) {
        detailOpen = true
        val col = vstack()
        col.add(tv(s.wallet.label, 22f, Theme.text, bold = true))
        col.add(tv(short(s.wallet.address), 12f, Theme.muted, mono = true), top = dp(2), bottom = dp(8))
        col.add(pill("Copy wallet address") { copy(s.wallet.address, "Wallet") }, bottom = dp(10))

        val st = card()
        val r1 = hstack()
        r1.add(stat("Total PnL", solFmt(s.totalPnl), Theme.pnlColor(s.totalPnl)), w = 0, weight = 1f)
        r1.add(stat("Win rate", s.winRate.toInt().toString() + "%"), w = 0, weight = 1f)
        r1.add(stat("Median", xFmt(s.avgMultiple)), w = 0, weight = 1f)
        st.add(r1, bottom = dp(10))
        val r2 = hstack()
        r2.add(stat("Early hits", s.earlyHits.toString()), w = 0, weight = 1f)
        r2.add(stat("First-ins", s.firstIns.toString()), w = 0, weight = 1f)
        r2.add(stat("Win hold", KolEngine.dur(s.medianWinHoldSec)), w = 0, weight = 1f)
        st.add(r2)
        col.add(st, bottom = dp(10))

        val style = card()
        style.add(tv("Trading style", 13f, Theme.text, bold = true), bottom = dp(6))
        style.add(tv("Scalps (under 30m): " + s.scalps, 12f, Theme.text, mono = true))
        style.add(tv("Swings (30m to 24h): " + s.swings, 12f, Theme.text, mono = true), top = dp(2))
        style.add(tv("Holds (24h+): " + s.holds, 12f, Theme.text, mono = true), top = dp(2))
        col.add(style, bottom = dp(12))

        col.add(tv("Their coins, best first", 15f, Theme.text, bold = true), bottom = dp(8))
        val byMint = HashMap<String, KolCoin>()
        for (c in coins) byMint[c.tok.mint] = c
        for (p in s.positions.sortedByDescending { it.pnl }.take(50)) {
            val coin = byMint[p.tok.mint]
            val box = card()
            val row = hstack()
            row.add(coinImage(p.tok, 38), right = dp(10), w = dp(38), h = dp(38))
            val mid = vstack()
            mid.add(tv("$" + (if (p.tok.sym.isEmpty()) short(p.tok.mint) else p.tok.sym), 14f, Theme.text, bold = true))
            mid.add(tv("Entry " + KolEngine.money(p.entryMc) + "  |  held " + KolEngine.dur(p.holdSec), 11f, Theme.muted, mono = true))
            row.add(mid, w = 0, weight = 1f)
            val right = vstack().apply { gravity = Gravity.END }
            right.add(tv(solFmt(p.pnl), 12f, Theme.pnlColor(p.pnl), bold = true, mono = true))
            right.add(tv(xFmt(p.multiple), 11f, Theme.muted, mono = true))
            row.add(right, w = LinearLayout.LayoutParams.WRAP_CONTENT)
            box.add(row)
            if (coin != null) box.setOnClickListener { showCoin(coin) }
            col.add(box, bottom = dp(8))
        }
        show(col)
    }

    // ======================= THEMES =======================
    private fun buildThemesTab(): LinearLayout {
        val col = vstack()
        col.add(tv("Which stories the tracked KOLs made money in. Counted from coins that peaked " +
            KolEngine.money(KolStore.minPeakMc) + "+ (change it in the Coins tab). Themes come from the coin name and ticker, " +
            "so treat it as a guide.", 11f, Theme.muted), bottom = dp(10))
        if (themes.isEmpty()) {
            col.add(emptyHint("No themes yet. Scan some KOLs first."))
            return col
        }
        for (t in themes) {
            val box = card()
            val l1 = hstack()
            l1.add(tv(t.name, 15f, Theme.text, bold = true), w = 0, weight = 1f)
            l1.add(tv(t.count.toString() + " coins", 12f, Theme.text, bold = true, mono = true),
                w = LinearLayout.LayoutParams.WRAP_CONTENT)
            box.add(l1)
            box.add(tv("Avg peak " + KolEngine.money(t.avgPeak) + "  |  " + String.format("%.1f", t.avgKols) +
                " KOLs per coin  |  KOL win rate " + t.winRate.toInt() + "%", 11f, Theme.text), top = dp(5))
            box.add(tv("KOL PnL " + solFmt(t.totalPnl), 11f, Theme.pnlColor(t.totalPnl), mono = true), top = dp(2))
            box.add(tv(t.coins.take(6).joinToString("  ") { "$" + (if (it.tok.sym.isEmpty()) short(it.tok.mint) else it.tok.sym) },
                11f, Theme.muted), top = dp(4))
            col.add(box, bottom = dp(8))
        }
        return col
    }

    // ======================= WALLETS =======================
    private fun input(hint: String, multiline: Boolean, text: String = ""): EditText = EditText(act).apply {
        setText(text)
        this.hint = hint
        setTextColor(Theme.text)
        setHintTextColor(Theme.muted)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        typeface = Typeface.MONOSPACE
        background = Theme.box(Theme.surface2, Theme.border, dp(12), dp(1))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        if (multiline) {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            minLines = 5
            gravity = Gravity.TOP
        } else {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
        }
    }

    private fun buildWalletsTab(): LinearLayout {
        val col = vstack()

        // Helius key
        val keyCard = card()
        keyCard.add(tv("Helius API key (free)", 14f, Theme.text, bold = true))
        keyCard.add(tv("Make a free key at helius.dev. It reads the KOL wallets' swaps. Stored only on this phone.",
            11f, Theme.muted), top = dp(2), bottom = dp(8))
        val keyIn = input("paste key here", false, KolStore.heliusKey)
        keyCard.add(keyIn, bottom = dp(8))
        keyCard.add(pill("Save key") {
            KolStore.heliusKey = keyIn.text.toString()
            Toast.makeText(act, "Key saved", Toast.LENGTH_SHORT).show()
        })
        col.add(keyCard, bottom = dp(10))

        // batch add
        val addCard = card()
        addCard.add(tv("Add KOL wallets (batch)", 14f, Theme.text, bold = true))
        addCard.add(tv("One per line. Either just the address, or a name and the address, for example:\n" +
            "Ansem  7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU\nThe name is optional. Max " + KolStore.MAX_WALLETS + " wallets.",
            11f, Theme.muted), top = dp(2), bottom = dp(8))
        val batchIn = input("paste wallets here", true)
        addCard.add(batchIn, bottom = dp(8))
        addCard.add(filledPill("Add wallets") {
            val parsed = KolEngine.parseBatch(batchIn.text.toString())
            if (parsed.isEmpty()) {
                Toast.makeText(act, "No wallet addresses found in that text", Toast.LENGTH_SHORT).show()
            } else {
                val n = KolStore.addWallets(parsed)
                val skipped = parsed.size - n
                Toast.makeText(act, "Added " + n + (if (skipped > 0) ", skipped " + skipped + " (duplicates or over the limit)" else ""),
                    Toast.LENGTH_LONG).show()
                render()
            }
        })
        col.add(addCard, bottom = dp(10))

        // settings
        val setCard = card()
        setCard.add(tv("Settings", 14f, Theme.text, bold = true), bottom = dp(8))
        setCard.add(tv("How far back to look", 11f, Theme.muted), bottom = dp(4))
        val dayVals = listOf(7, 14, 30, 60)
        setCard.add(chipRow(dayVals.map { it.toString() + " days" }, dayVals.indexOf(KolStore.days).let { if (it < 0) 2 else it }) {
            KolStore.days = dayVals[it]; render()
        }, bottom = dp(8))
        setCard.add(tv("Count as an early entry if market cap was under", 11f, Theme.muted), bottom = dp(4))
        val earlyVals = listOf(50_000.0, 100_000.0, 150_000.0, 250_000.0, 500_000.0)
        setCard.add(chipRow(earlyVals.map { KolEngine.money(it) }, earlyVals.indexOf(KolStore.earlyMc).let { if (it < 0) 2 else it }) {
            KolStore.earlyMc = earlyVals[it]; recompute(); render()
        }, bottom = dp(8))
        setCard.add(tv("Ignore buys smaller than (SOL, filters lottery tickets)", 11f, Theme.muted), bottom = dp(4))
        val sizeVals = listOf(0.05, 0.1, 0.5, 1.0)
        setCard.add(chipRow(sizeVals.map { it.toString() + " SOL" }, sizeVals.indexOf(KolStore.minSizeSol).let { if (it < 0) 1 else it }) {
            KolStore.minSizeSol = sizeVals[it]; recompute(); render()
        })
        col.add(setCard, bottom = dp(10))

        // scan
        val scanCard = card()
        scanCard.add(tv("Scan", 14f, Theme.text, bold = true), bottom = dp(8))
        val st = tv(if (lastStatus.isEmpty()) "Ready." else lastStatus, 11f, Theme.muted, mono = true)
        statusText = st
        if (scanning) {
            scanCard.add(pill("Stop scan") { KolEngine.cancel = true; postStatus("Stopping...") }, bottom = dp(8))
        } else {
            val b = hstack()
            b.add(filledPill("Scan all KOLs") { startScan(true) }, w = 0, weight = 1f, right = dp(8))
            b.add(pill("Refresh prices") { startScan(false) }, w = 0, weight = 1f)
            scanCard.add(b, bottom = dp(8))
        }
        scanCard.add(st)
        scanCard.add(tv("Re-scans only fetch new swaps, so they use far fewer Helius credits than the first scan.",
            10f, Theme.muted), top = dp(6))
        col.add(scanCard, bottom = dp(10))

        // list
        col.add(tv(KolStore.wallets.size.toString() + " / " + KolStore.MAX_WALLETS + " wallets", 13f, Theme.text, bold = true),
            bottom = dp(6))
        for (w in KolStore.wallets.toList()) {
            val box = card()
            val l1 = hstack()
            val mid = vstack()
            mid.add(tv(w.label, 14f, Theme.text, bold = true))
            mid.add(tv(short(w.address) + "  |  " + w.swapCount + " swaps" +
                (if (w.lastScanMs > 0L) "  |  scanned " + KolEngine.dur((System.currentTimeMillis() - w.lastScanMs) / 1000L) + " ago" else "  |  not scanned"),
                10f, Theme.muted, mono = true))
            if (w.error.isNotEmpty()) mid.add(tv(w.error, 10f, Theme.loss), top = dp(2))
            l1.add(mid, w = 0, weight = 1f)
            l1.add(pill("Remove", Theme.loss) {
                KolStore.removeWallet(w.address); recompute(); render()
            }, w = LinearLayout.LayoutParams.WRAP_CONTENT)
            box.add(l1)
            col.add(box, bottom = dp(8))
        }
        return col
    }

    private fun postStatus(s: String) {
        main.post {
            lastStatus = s
            statusText?.text = s
        }
    }

    private fun startScan(walletsToo: Boolean) {
        if (scanning) return
        if (KolStore.wallets.isEmpty()) {
            Toast.makeText(act, "Add some wallets first", Toast.LENGTH_SHORT).show(); return
        }
        val key = KolStore.heliusKey
        if (walletsToo && key.isBlank()) {
            Toast.makeText(act, "Paste and save your Helius key first", Toast.LENGTH_LONG).show(); return
        }
        scanning = true
        KolEngine.cancel = false
        KolEngine.heliusCalls = 0
        KolEngine.geckoCalls = 0
        render()
        io.execute {
            var fatal = ""
            try {
                val list = KolStore.wallets.toList()
                if (walletsToo) {
                    for ((i, w) in list.withIndex()) {
                        if (KolEngine.cancel) break
                        postStatus("Wallet " + (i + 1) + "/" + list.size + "  " + w.label)
                        val err = KolEngine.scanWallet(w, key, KolStore.days) { s ->
                            postStatus("Wallet " + (i + 1) + "/" + list.size + "  " + s + "  (" + KolEngine.heliusCalls + " calls)")
                        }
                        w.error = err ?: ""
                        KolStore.saveWallets()
                        if (err != null && (err.startsWith("Helius key") || err.contains("rate limit"))) { fatal = err; break }
                    }
                }
                if (!KolEngine.cancel) {
                    val mints = HashSet<String>()
                    for (w in list) for ((m, fl) in KolStore.fillsOf(w.address)) if (fl.any { it.buy }) mints.add(m)
                    KolEngine.refreshTokens(mints.toList()) { postStatus(it) }
                }
                if (!KolEngine.cancel) {
                    val built = KolEngine.buildCoins()
                    val order = built.sortedWith(compareByDescending<KolCoin> { it.kolCount }.thenByDescending { it.totalPnl })
                    val pairs = order.map { c -> Pair(c.tok, c.positions.minOf { it.firstBuyTs }) }
                    KolEngine.refreshPeaks(pairs, 60) { postStatus(it) }
                }
            } catch (t: Throwable) {
                fatal = "Scan stopped: " + (t.message ?: t.javaClass.simpleName)
            }
            main.post {
                scanning = false
                lastStatus = if (fatal.isNotEmpty()) fatal
                else if (KolEngine.cancel) "Stopped."
                else "Done. " + KolEngine.heliusCalls + " Helius calls, " + KolEngine.geckoCalls + " chart calls."
                recompute()
                if (!detailOpen) render()
            }
        }
    }

    init {
        setup()
    }
}
