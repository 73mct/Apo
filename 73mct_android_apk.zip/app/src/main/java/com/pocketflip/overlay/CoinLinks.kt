package com.pocketflip.overlay

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** The links a coin's creator listed. Empty strings mean "not listed". */
class CoinLinks(val x: String, val web: String, val telegram: String)

/**
 * Finds a coin's X link (post, profile or community, whatever the creator listed).
 * Sources, in order: DexScreener, pump.fun, GeckoTerminal, Jupiter, then the coin's on-chain metadata.
 * Every answer is scanned for X / Twitter links, so it still works when a source renames a field.
 * Never touches the price or PnL code.
 */
object CoinLinkFinder {
    private val cache = ConcurrentHashMap<String, CoinLinks>()
    private val lastTry = ConcurrentHashMap<String, Long>()
    private val tries = ConcurrentHashMap<String, Int>()
    private val waiters = ConcurrentHashMap<String, MutableList<(CoinLinks) -> Unit>>()
    private val io = Executors.newFixedThreadPool(2)

    private const val COOLDOWN_MS = 12_000L
    private const val MAX_AUTO_TRIES = 12

    fun dexUrl(ca: String) = "https://dexscreener.com/solana/$ca"
    fun xSearchUrl(ca: String) = "https://x.com/search?q=$ca&f=live"

    fun cached(ca: String): CoinLinks? = cache[ca]

    private fun clean(u: String): String {
        val t = u.trim()
        if (t.isEmpty()) return ""
        if (t.startsWith("http://") || t.startsWith("https://")) return t
        if (t.startsWith("x.com/") || t.startsWith("twitter.com/") || t.startsWith("www.")) return "https://$t"
        return ""
    }

    private fun isX(u: String): Boolean {
        val l = u.lowercase()
        return l.contains("x.com/") || l.contains("twitter.com/")
    }

    // links that are NOT the coin's own page (search pages, share buttons, the platforms' own accounts)
    private val junkParts = listOf(
        "/search", "/intent", "/share", "/home", "/hashtag", "/i/flow", "/login",
        "/pumpfun", "/pump_fun", "/dexscreener", "/jupiterexchange", "/solana", "/geckoterminal"
    )

    private fun goodX(u: String): Boolean {
        if (!isX(u)) return false
        val l = u.lowercase()
        if (junkParts.any { l.contains(it) }) return false
        // must have something after the domain
        val after = l.substringAfter("x.com/", l.substringAfter("twitter.com/", ""))
        return after.trim('/').isNotEmpty()
    }

    private fun handleToUrl(h: String): String {
        val t = h.trim().removePrefix("@").trim('/')
        if (t.isEmpty() || t.contains(" ")) return ""
        return "https://x.com/$t"
    }

    /** Looks through a whole JSON answer for an X link. Fields that are clearly "twitter" win. */
    private fun scanX(node: Any?): String {
        var fallback = ""
        fun walk(n: Any?, keyHint: String): String {
            when (n) {
                is JSONObject -> {
                    // priority pass on likely keys
                    val keys = n.keys().asSequence().toList()
                    for (k in keys.sortedBy { if (it.lowercase().contains("twitter") || it.lowercase() == "x") 0 else 1 }) {
                        val r = walk(n.opt(k), k.lowercase())
                        if (r.isNotEmpty()) return r
                    }
                }
                is JSONArray -> for (i in 0 until n.length()) {
                    val r = walk(n.opt(i), keyHint)
                    if (r.isNotEmpty()) return r
                }
                is String -> {
                    val c = clean(n)
                    if (c.isNotEmpty() && goodX(c)) return c
                    if (keyHint.contains("twitter") && keyHint.contains("handle")) {
                        val h = handleToUrl(n)
                        if (h.isNotEmpty() && fallback.isEmpty()) fallback = h
                    }
                }
            }
            return ""
        }
        val r = walk(node, "")
        return if (r.isNotEmpty()) r else fallback
    }

    private fun getJson(url: String): Any? {
        val txt = CoinImages.fetchText(url) ?: return null
        return try {
            val t = txt.trim()
            if (t.startsWith("[")) JSONArray(t) else JSONObject(t)
        } catch (_: Throwable) { null }
    }

    private fun firstWeb(node: Any?): String {
        var out = ""
        fun walk(n: Any?, k: String) {
            if (out.isNotEmpty()) return
            when (n) {
                is JSONObject -> n.keys().forEach { walk(n.opt(it), it.lowercase()) }
                is JSONArray -> for (i in 0 until n.length()) walk(n.opt(i), k)
                is String -> if ((k.contains("website") || k == "url" || k == "site") && !isX(n)) {
                    val c = clean(n); if (c.isNotEmpty()) out = c
                }
            }
        }
        walk(node, "")
        return out
    }

    private fun firstTg(node: Any?): String {
        var out = ""
        fun walk(n: Any?, k: String) {
            if (out.isNotEmpty()) return
            when (n) {
                is JSONObject -> n.keys().forEach { walk(n.opt(it), it.lowercase()) }
                is JSONArray -> for (i in 0 until n.length()) walk(n.opt(i), k)
                is String -> {
                    val c = clean(n)
                    if (c.contains("t.me/") || (k.contains("telegram") && c.isNotEmpty())) out = c
                }
            }
        }
        walk(node, "")
        return out
    }

    /**
     * Looks up the links. [force] ignores the short wait between tries (used when you tap the X button).
     * If a lookup for this coin is already running, [cb] simply gets the same answer when it finishes.
     */
    fun find(ca: String, force: Boolean = false, cb: (CoinLinks) -> Unit) {
        val hit = cache[ca]
        if (hit != null) { cb(hit); return }
        val now = System.currentTimeMillis()
        if (!force) {
            if ((tries[ca] ?: 0) >= MAX_AUTO_TRIES) return
            if (now - (lastTry[ca] ?: 0L) < COOLDOWN_MS) return
        }
        var startNew = false
        synchronized(waiters) {
            val list = waiters[ca]
            if (list != null) {
                list.add(cb)
            } else {
                waiters[ca] = mutableListOf(cb)
                startNew = true
            }
        }
        if (!startNew) return
        lastTry[ca] = now
        tries[ca] = (tries[ca] ?: 0) + 1
        io.execute {
            var x = ""
            var web = ""
            var tg = ""
            fun take(node: Any?) {
                if (node == null) return
                if (x.isEmpty()) x = scanX(node)
                if (web.isEmpty()) web = firstWeb(node)
                if (tg.isEmpty()) tg = firstTg(node)
            }
            try {
                // 1) DexScreener (two endpoints)
                try {
                    val a = getJson("https://api.dexscreener.com/latest/dex/tokens/$ca")
                    if (a is JSONObject) {
                        val pairs = a.optJSONArray("pairs")
                        if (pairs != null) for (i in 0 until pairs.length()) {
                            take(pairs.optJSONObject(i)?.optJSONObject("info"))
                            if (x.isNotEmpty()) break
                        }
                    }
                } catch (_: Throwable) {}
                if (x.isEmpty()) try {
                    val b = getJson("https://api.dexscreener.com/tokens/v1/solana/$ca")
                    if (b is JSONArray) for (i in 0 until b.length()) {
                        take(b.optJSONObject(i)?.optJSONObject("info"))
                        if (x.isNotEmpty()) break
                    }
                } catch (_: Throwable) {}
                // 2) pump.fun
                if (x.isEmpty()) try {
                    for (base in listOf("https://frontend-api-v3.pump.fun/coins/", "https://frontend-api.pump.fun/coins/")) {
                        val o = getJson(base + ca) ?: continue
                        take(o)
                        break
                    }
                } catch (_: Throwable) {}
                // 3) GeckoTerminal
                if (x.isEmpty()) try { take(getJson("https://api.geckoterminal.com/api/v2/networks/solana/tokens/$ca/info")) } catch (_: Throwable) {}
                // 4) Jupiter
                if (x.isEmpty()) try { take(getJson("https://lite-api.jup.ag/tokens/v2/search?query=$ca")) } catch (_: Throwable) {}
                // 5) the coin's own on-chain metadata file
                if (x.isEmpty()) try {
                    val txt = CoinImages.chainMetadataText(ca)
                    if (txt != null) take(JSONObject(txt.trim()))
                } catch (_: Throwable) {}
            } catch (_: Throwable) {}

            val res = CoinLinks(x, web, tg)
            if (x.isNotEmpty()) cache[ca] = res
            val list = synchronized(waiters) { waiters.remove(ca) } ?: mutableListOf<(CoinLinks) -> Unit>()
            for (w in list) { try { w(res) } catch (_: Throwable) {} }
        }
    }
}
