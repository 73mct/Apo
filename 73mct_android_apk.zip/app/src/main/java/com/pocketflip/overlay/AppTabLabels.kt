package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences

/** User-editable labels for the main navigation and Academy's internal sections. */
object AppTabLabels {
    private const val PREFS = "pocketflip_tab_labels"
    private var prefs: SharedPreferences? = null

    val mainKeys = listOf("trade", "journal", "thesis", "profile", "settings", "kol", "academy")
    val academyKeys = listOf("academy_game", "academy_results")

    private val defaults = mapOf(
        "trade" to "Trade",
        "journal" to "Journal",
        "thesis" to "Thesis",
        "profile" to "Profile",
        "settings" to "Settings",
        "kol" to "KOLs",
        "academy" to "Academy",
        "academy_game" to "Game",
        "academy_results" to "Results"
    )

    @Synchronized
    fun init(context: Context) {
        if (prefs == null) prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    fun label(key: String): String {
        val fallback = defaults[key] ?: key.replace('_', ' ').replaceFirstChar { it.uppercase() }
        val saved = prefs?.getString(key, null)?.trim().orEmpty()
        return if (saved.isBlank()) fallback else saved.take(14)
    }

    fun save(values: Map<String, String>): Boolean {
        val p = prefs ?: return false
        val editor = p.edit()
        for ((key, raw) in values) {
            if (!defaults.containsKey(key)) continue
            val clean = raw.trim().replace(Regex("\\s+"), " ").take(14)
            if (clean.isBlank()) continue
            editor.putString(key, clean)
        }
        editor.apply()
        return true
    }
}
