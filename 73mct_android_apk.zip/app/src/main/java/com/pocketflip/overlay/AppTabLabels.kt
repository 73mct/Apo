package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences

/** User-editable labels for the main navigation and Academy's internal sections. */
object AppTabLabels {
    private const val PREFS = "pocketflip_tab_labels"
    private var prefs: SharedPreferences? = null

    val mainKeys = listOf("trade", "journal", "thesis", "profile", "settings", "kol", "academy", "lab")
    val academyKeys = listOf("academy_game", "academy_results")
    val labKeys = listOf("lab_overview", "lab_terminal", "lab_strategy", "lab_risk", "lab_coach", "lab_replay", "lab_studio", "lab_challenges", "lab_membership")

    private val defaults = mapOf(
        "trade" to "Trade",
        "journal" to "Journal",
        "thesis" to "Thesis",
        "profile" to "Profile",
        "settings" to "Settings",
        "kol" to "KOLs",
        "academy" to "Academy",
        "academy_game" to "Game",
        "academy_results" to "Results",
        "lab" to "Lab",
        "lab_overview" to "Overview", "lab_terminal" to "Terminal", "lab_strategy" to "Strategy",
        "lab_risk" to "Risk", "lab_coach" to "Coach", "lab_replay" to "Replay",
        "lab_studio" to "Studio", "lab_challenges" to "Challenges", "lab_membership" to "Membership"
    )

    @Synchronized
    fun init(context: Context) {
        if (prefs == null) prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    fun label(key: String): String {
        val fallback = defaults[key] ?: key.replace('_', ' ').replaceFirstChar { it.uppercase() }
        val saved = prefs?.getString(key, null)?.trim().orEmpty()
        return if (saved.isBlank()) fallback else saved.take(14)
    }

    fun save(values: Map<String, String>): Boolean {
        val p = prefs ?: return false
        val editor = p.edit()
        for ((key, raw) in values) {
            if (!defaults.containsKey(key)) continue
            val clean = raw.trim().replace(Regex("\\s+"), " ").take(14)
            if (clean.isBlank()) continue
            editor.putString(key, clean)
        }
        editor.apply()
        return true
    }
}
