package com.pocketflip.overlay

object SecurityScanner {
    data class AuditResult(
        val isMintRevoked: Boolean,
        val isFreezeRevoked: Boolean,
        val top10HoldersPct: Double,
        val devHoldPct: Double,
        val isBundleDetected: Boolean
    )

    fun scanToken(ca: String): AuditResult {
        return AuditResult(
            isMintRevoked = true,
            isFreezeRevoked = true,
            top10HoldersPct = 12.4,
            devHoldPct = 2.1,
            isBundleDetected = false
        )
    }
}