package com.pocketflip.overlay

import android.animation.ValueAnimator
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * PnL card studio for one finished trade.
 * Opens from the trade detail page. It only READS the trade; it never touches prices, balance or journal data.
 */
class CardActivity : Activity() {

    companion object {
        const val EXTRA_TRADE_ID = "trade_id"
        private const val REQ_PICK_IMAGE = 7301
        private const val REQ_PICK_VIDEO = 7302
        private const val PREVIEW_FPS = 8
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private lateinit var trade: ClosedTradeLog
    private lateinit var opts: CardOptions
    private lateinit var preview: ImageView
    private var coinBmp: Bitmap? = null
    private var bgBmp: Bitmap? = null
    private var emblemBmp: Bitmap? = null
    private var anim: ValueAnimator? = null
    private var progress = 1f
    private var renderPending = false
    private var lastSavedUri: Uri? = null
    private var previewTimeMs = 0L
    private var tickerOn = false
    private val clockStart = System.currentTimeMillis()

    // background video (preview frames are small + few; the exported MP4 uses the full video)
    private var previewFrames: List<Bitmap> = emptyList()
    private var videoIdx = 0
    private var videoStatus: TextView? = null
    private var videoBtn: TextView? = null
    private var exporting = false
    private var exportWidth = 720

    // ---------- helpers ----------
    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false) =
        TextView(this).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun vstack() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun hstack() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun LinearLayout.add(
        v: View, top: Int = 0, bottom: Int = 0, left: Int = 0, right: Int = 0,
        w: Int = LinearLayout.LayoutParams.MATCH_PARENT,
        h: Int = LinearLayout.LayoutParams.WRAP_CONTENT, weight: Float = 0f
    ) {
        val p = if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
        p.topMargin = top; p.bottomMargin = bottom; p.leftMargin = left; p.rightMargin = right
        addView(v, p)
    }

    private fun filledBtn(label: String, onClick: () -> Unit) =
        tv(label, 14f, Theme.onColor(Theme.accent), bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = Theme.button(Theme.accent, dp(14))
            setOnClickListener { onClick() }
        }

    private fun outlineBtn(label: String, color: Int = Theme.text, onClick: () -> Unit) =
        tv(label, 13f, color, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = Theme.box(Theme.surface2, Theme.border, dp(14), dp(1))
            setOnClickListener { onClick() }
        }

    private fun label(text: String) =
        tv(text, 11f, Theme.muted, bold = true).apply { setPadding(dp(2), dp(14), 0, dp(6)) }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TradeRepository.init(this)
        Theme.init(this)
        CoinImages.init(this)
        ThesisStore.init(this)
        ProfileStore.init(this)
        window.statusBarColor = Theme.bg
        window.navigationBarColor = Theme.bg

        val id = intent.getStringExtra(EXTRA_TRADE_ID) ?: ""
        val found = TradeRepository.getJournal().firstOrNull { it.id == id }
        if (found == null) {
            Toast.makeText(this, "Trade not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        trade = found
        opts = CardOptions.open(this)
        // First time only: start from the app theme colors so the card matches the app.
        val prefs = getSharedPreferences(CardOptions.PREFS, Context.MODE_PRIVATE)
        if (!prefs.contains("bgHex")) {
            opts.bgHex = Theme.hexOf("bg")
            opts.textHex = Theme.hexOf("text")
            opts.profitHex = Theme.hexOf("profit")
            opts.lossHex = Theme.hexOf("loss")
        }
        opts.save(prefs)   // keeps the first-time defaults so they don't reset on the next open
        emblemBmp = try { BitmapFactory.decodeResource(resources, R.drawable.emblem) } catch (_: Throwable) { null }

        val root = vstack().apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Theme.mix(Theme.bg, Theme.accent, 0.035f), Theme.bg)) }

        // top bar
        val bar = hstack().apply { setPadding(dp(14), dp(12), dp(14), dp(8)) }
        bar.add(outlineBtn("←  Back") { finish() }, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        bar.add(
            tv("Create card", 17f, Theme.text, bold = true).apply { gravity = Gravity.CENTER },
            w = 0, weight = 1f
        )
        bar.add(outlineBtn("Replay") { replay() }, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        root.addView(bar)

        // live preview (stays pinned while you scroll the controls)
        val previewBox = FrameLayout(this).apply { setPadding(dp(14), dp(4), dp(14), dp(8)) }
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        previewBox.addView(
            preview,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        root.add(previewBox, h = 0, weight = 5.8f)

        // controls: three tabs (Style / Content / Brand) + a fixed export bar
        val panel = vstack().apply {
            background = Theme.surface(dp(24), Theme.accent, dp(1))
            elevation = dp(8).toFloat()
        }
        val styleP = vstack().apply { setPadding(dp(16), dp(2), dp(16), dp(24)) }
        val contentP = vstack().apply { setPadding(dp(16), dp(2), dp(16), dp(24)) }
        val brandP = vstack().apply { setPadding(dp(16), dp(2), dp(16), dp(24)) }
        val tuneP = vstack().apply { setPadding(dp(16), dp(2), dp(16), dp(24)) }
        buildStyle(styleP)
        buildTune(tuneP)
        buildContent(contentP)
        buildBrand(brandP)
        val panes = listOf(styleP, tuneP, contentP, brandP)
        val tabChips = ArrayList<TextView>()
        var activePane = -1
        fun showTab(idx: Int) {
            for (i in panes.indices) {
                val pane = panes[i]
                if (i == idx) {
                    pane.visibility = View.VISIBLE
                    if (activePane >= 0 && activePane != idx) {
                        pane.alpha = 0f
                        pane.translationY = dp(8).toFloat()
                        pane.animate().alpha(1f).translationY(0f).setDuration(210).setInterpolator(LinearInterpolator()).start()
                    } else {
                        pane.alpha = 1f
                        pane.translationY = 0f
                    }
                } else {
                    pane.animate().cancel()
                    pane.visibility = View.GONE
                    pane.alpha = 1f
                    pane.translationY = 0f
                }
            }
            activePane = idx
            for (i in tabChips.indices) {
                val on = i == idx
                tabChips[i].setTextColor(if (on) Theme.onColor(Theme.accent) else Theme.muted)
                tabChips[i].background = Theme.chip(on, dp(18))
            }
        }
        val tabBar = hstack().apply { setPadding(dp(12), dp(12), dp(12), dp(6)) }
        val tabNames = listOf("Style", "Tune", "Content", "Brand")
        for (i in tabNames.indices) {
            val chip = tv(tabNames[i], 12f, Theme.text, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(9), dp(4), dp(9))
                setOnClickListener { showTab(i) }
            }
            tabChips.add(chip)
            tabBar.add(chip, w = 0, weight = 1f, right = if (i < tabNames.size - 1) dp(8) else 0)
        }
        panel.addView(tabBar)
        val holder = FrameLayout(this)
        for (pane in panes) holder.addView(pane)
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        scroll.addView(holder)
        panel.add(scroll, h = 0, weight = 1f)
        showTab(0)

        val exportRow = hstack().apply { setPadding(dp(12), dp(8), dp(12), dp(12)) }
        exportRow.add(filledBtn("Save PNG") { saveCard(share = false) }, w = 0, weight = 1f, right = dp(6))
        exportRow.add(outlineBtn("Share") { saveCard(share = true) }, w = 0, weight = 0.8f, right = dp(6))
        val vb = filledBtn("Export MP4") { exportVideo() }
        videoBtn = vb
        exportRow.add(vb, w = 0, weight = 1.2f)
        panel.addView(exportRow)
        root.add(panel, h = 0, weight = 4.2f)

        setContentView(root)

        CoinImages.load(trade.ca, trade.imageUrl) { bmp ->
            coinBmp = bmp
            main.post { requestRender() }
        }
        if (opts.bgStyle == "video" && opts.videoUri.isNotEmpty()) prepareVideoPreview()
        // profile picture for the card: still for the PNG, animated in the preview and the MP4
        io.execute {
            try { AvatarAnim.load(this) } catch (_: Throwable) { }
            main.post {
                requestRender()
                startTicker()
                try {
                    AvatarAnim.captureWebp(this) { main.post { requestRender() } }
                } catch (_: Throwable) { }
            }
        }
        startTicker()
        requestRender()
    }

    /** Keeps the preview alive: your picture moves and the shine passes over the number. */
    private fun startTicker() {
        if (tickerOn) return
        tickerOn = true
        val r = object : Runnable {
            override fun run() {
                if (isFinishing || isDestroyed) return
                val moving = (opts.animateAvatar && AvatarAnim.isAnimated) || opts.lightSweep
                if (moving && !exporting && anim?.isRunning != true) {
                    previewTimeMs = System.currentTimeMillis() - clockStart
                    renderPreview()
                }
                main.postDelayed(this, 120)
            }
        }
        main.postDelayed(r, 120)
    }

    override fun onDestroy() {
        anim?.cancel()
        io.shutdown()
        super.onDestroy()
    }

    // ---------- rendering ----------
    private fun requestRender() {
        if (renderPending) return
        renderPending = true
        main.postDelayed({
            renderPending = false
            renderPreview()
        }, 40)
    }

    private fun renderPreview() {
        if (!::preview.isInitialized) return
        try {
            val bg: Bitmap? = if (opts.bgStyle == "video") previewFrames.getOrNull(videoIdx) else bgBmp
            val bmp = CardRenderer.render(trade, opts, coinBmp, bg, emblemBmp, 560, progress, previewTimeMs)
            preview.setImageBitmap(bmp)
        } catch (t: Throwable) {
            Toast.makeText(this, "Preview error: ${t.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun changed() {
        opts.save(getSharedPreferences(CardOptions.PREFS, Context.MODE_PRIVATE))
        requestRender()
    }

    private fun replay() {
        anim?.cancel()
        val hasVideo = opts.bgStyle == "video" && previewFrames.isNotEmpty()
        val totalMs: Long = if (hasVideo) (previewFrames.size * 1000L / PREVIEW_FPS) else 2200L
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = totalMs
            interpolator = LinearInterpolator()
            addUpdateListener {
                val frac = it.animatedValue as Float
                val sec = frac * totalMs / 1000f
                progress = (sec / 2.2f).coerceIn(0f, 1f)
                previewTimeMs = (sec * 1000f).toLong()
                if (hasVideo) videoIdx = (frac * (previewFrames.size - 1)).toInt()
                renderPreview()
            }
            start()
        }
    }

    // ---------- controls ----------
    private fun chips(
        parent: LinearLayout, title: String, options: List<Pair<String, String>>,
        current: () -> String, onPick: (String) -> Unit
    ) {
        parent.add(label(title))
        val scroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = hstack()
        val views = ArrayList<Pair<String, TextView>>()
        fun paint() {
            for ((key, v) in views) {
                val on = key == current()
                v.setTextColor(if (on) Theme.onColor(Theme.accent) else Theme.muted)
                v.background = Theme.chip(on, dp(18))
            }
        }
        for ((key, text) in options) {
            val v = tv(text, 12f, Theme.text, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(9), dp(14), dp(9))
                setOnClickListener {
                    onPick(key)
                    paint()
                    changed()
                }
            }
            views.add(key to v)
            row.add(v, right = dp(8), w = LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        paint()
        scroller.addView(row)
        parent.add(scroller)
    }

    private fun toggle(parent: LinearLayout, title: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val row = hstack().apply { setPadding(0, dp(7), 0, dp(7)) }
        row.add(tv(title, 13f, Theme.text), w = 0, weight = 1f)
        val sw = tv("", 12f, Theme.text, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        fun paint() {
            val on = get()
            sw.text = if (on) "ON" else "OFF"
            sw.setTextColor(if (on) Theme.onColor(Theme.accent) else Theme.muted)
            sw.background = Theme.chip(on, dp(14))
        }
        paint()
        sw.setOnClickListener {
            set(!get())
            paint()
            changed()
        }
        row.add(sw, w = dp(64))
        parent.add(row)
    }

    private fun textInput(parent: LinearLayout, title: String, initial: String, onText: (String) -> Unit) {
        parent.add(label(title))
        val et = EditText(this).apply {
            setText(initial)
            setTextColor(Theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.box(Theme.surface2, Theme.border, dp(12), dp(1))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    onText(s?.toString() ?: "")
                    changed()
                }
            })
        }
        parent.add(et)
    }

    private fun hexRow(
        parent: LinearLayout, title: String, get: () -> String, set: (String) -> Unit,
        registry: MutableMap<String, EditText>
    ) {
        val row = hstack().apply { setPadding(0, dp(4), 0, dp(4)) }
        row.add(tv(title, 13f, Theme.text), w = 0, weight = 1f)
        val swatch = View(this).apply {
            background = Theme.box(Theme.parseHex(get()) ?: Color.GRAY, Theme.muted, dp(8), dp(1))
        }
        row.add(swatch, w = dp(30), h = dp(30), right = dp(10))
        val et = EditText(this).apply {
            setText(get())
            setTextColor(Theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.MONOSPACE
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = Theme.box(Theme.surface2, Theme.border, dp(10), dp(1))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val raw = s?.toString() ?: ""
                    val parsed = Theme.parseHex(raw)
                    if (parsed != null) {
                        swatch.background = Theme.box(parsed, Theme.muted, dp(8), dp(1))
                        set(if (raw.trim().startsWith("#")) raw.trim() else "#" + raw.trim())
                        changed()
                    }
                }
            })
        }
        row.add(et, w = dp(112))
        registry[title] = et
        parent.add(row)
    }

    private fun buildStyle(p: LinearLayout) {
        chips(p, "CARD LOOK", listOf("terminal" to "Terminal", "axiom" to "Clean", "glass" to "Glass", "block" to "Block", "classic" to "Classic"),
            { opts.cardStyle }) { opts.cardStyle = it }
        chips(p, "SIZE", listOf("3:2" to "Terminal 3:2", "1:1" to "Square 1:1", "4:5" to "Post 4:5", "9:16" to "Story 9:16", "16:9" to "Wide 16:9"),
            { opts.aspect }) { opts.aspect = it }

        chips(p, "BACKGROUND",
            listOf("chrome" to "Chrome glow", "black" to "Solid", "coin" to "Coin blur", "image" to "My image", "video" to "My video"),
            { opts.bgStyle }) {
            opts.bgStyle = it
            if (it == "image" && bgBmp == null) pickImage()
            if (it == "video") {
                if (opts.videoUri.isEmpty()) pickVideo()
                else if (previewFrames.isEmpty()) prepareVideoPreview()
            }
        }
        p.add(label("BACKGROUND DARKNESS (image / video / coin)"))
        val seek = SeekBar(this).apply {
            max = 95
            progress = opts.darkness
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    if (fromUser) { opts.darkness = v; changed() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        p.add(seek)
        p.add(outlineBtn("Choose background image from gallery") { pickImage() }, top = dp(8))
        p.add(outlineBtn("Choose background VIDEO from gallery") { pickVideo() }, top = dp(8))
        val status = tv(
            if (opts.videoUri.isEmpty()) "No video picked yet" else "Video selected",
            10f, Theme.muted, mono = true
        )
        videoStatus = status
        p.add(status, top = dp(6))

        chips(p, "EXPORTED VIDEO LENGTH",
            listOf("5" to "5 sec", "8" to "8 sec", "12" to "12 sec", "15" to "15 sec"),
            { opts.videoSec.toString() }) { opts.videoSec = it.toIntOrNull() ?: 8 }
        chips(p, "EXPORTED VIDEO QUALITY",
            listOf("720" to "HD 720p", "1080" to "Full 1080p"),
            { exportWidth.toString() }) { exportWidth = if (it == "1080") 1080 else 720 }
        p.add(
            tv("The video plays behind the card with its original sound. The number counts up and the chart draws in the first 2 seconds. Exporting takes a while (about the length of the clip or more), so keep the screen on.", 10f, Theme.muted),
            top = dp(4)
        )

        chips(p, "BIG NUMBER", listOf("sol" to "SOL PnL", "pct" to "% ROI", "multiple" to "Multiple (x)"),
            { opts.heroMode }) { opts.heroMode = it }
        chips(p, "NUMBER STYLE",
            listOf("chrome" to "Chrome", "clean" to "Clean", "gold" to "Gold", "green" to "Green"),
            { opts.shader }) { opts.shader = it }

        chips(p, "CHART", listOf("real" to "My real fills", "stylized" to "Stylized path"),
            { opts.chartMode }) { opts.chartMode = it }
        p.add(
            tv("Real fills = exactly your buys and sells. Stylized = a decorative curve that starts at your entry, touches your peak and ends at your exit.", 10f, Theme.muted),
            top = dp(4)
        )
        chips(p, "BUY / SELL MARKERS", listOf("pill" to "Labels", "dot" to "Dots", "none" to "None"),
            { opts.markerStyle }) { opts.markerStyle = it }
    }


    // ---------- slider + tune tab ----------
    private fun slider(
        parent: LinearLayout, title: String, lo: Int, hi: Int, unit: String,
        get: () -> Int, set: (Int) -> Unit
    ) {
        val head = hstack()
        head.add(label(title), w = 0, weight = 1f)
        val value = tv(get().toString() + unit, 12f, Theme.muted, bold = true, mono = true)
        head.add(value, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        parent.add(head)
        val seek = SeekBar(this).apply {
            this.max = hi - lo
            progress = (get() - lo).coerceIn(0, hi - lo)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    if (fromUser) {
                        set(v + lo)
                        value.text = (v + lo).toString() + unit
                        changed()
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.add(seek)
    }

    private val statOrder = listOf("invested", "returned", "entry", "exit", "peak", "peakx", "held", "fills")

    private fun statToggle(p: LinearLayout, title: String, key: String) {
        toggle(p, title, { opts.statKeys.split(",").contains(key) }) { on ->
            val have = opts.statKeys.split(",").toMutableSet()
            if (on) have.add(key) else have.remove(key)
            opts.statKeys = statOrder.filter { have.contains(it) }.joinToString(",")
        }
    }

    private val tRowOrder = listOf("pnl", "pnlsol", "invested", "returned", "entry", "exit", "peak", "peakx", "held", "fills")

    private fun tRowToggle(p: LinearLayout, title: String, key: String) {
        toggle(p, title, { opts.tRows.split(",").contains(key) }) { on ->
            val have = opts.tRows.split(",").toMutableSet()
            if (on) have.add(key) else have.remove(key)
            opts.tRows = tRowOrder.filter { have.contains(it) }.joinToString(",")
        }
    }

    private fun buildTerminalTune(p: LinearLayout) {
        p.add(label("TERMINAL CARD"))
        chips(p, "TOP LEFT", listOf("coin" to "Coin picture", "logo" to "My logo", "none" to "Nothing"),
            { opts.tLeftMark }) { opts.tLeftMark = it }
        chips(p, "TOP RIGHT", listOf("text" to "Name text", "logo" to "My logo", "none" to "Nothing"),
            { opts.tRightMark }) { opts.tRightMark = it }
        textInput(p, "TOP RIGHT TEXT", opts.tRightText) { opts.tRightText = it }
        chips(p, "PICTURE SHAPE", listOf("square" to "Rounded square", "circle" to "Circle"),
            { opts.tAvatarShape }) { opts.tAvatarShape = it }
        slider(p, "COLOR BLOCK CORNERS", 0, 40, "", { opts.tBlockRadius }) { opts.tBlockRadius = it }
        p.add(label("BOTTOM LINE (put your Fomo code here)"))
        toggle(p, "Show the bottom line", { opts.tShowFoot }) { opts.tShowFoot = it }
        textInput(p, "LINK TEXT (next to the globe)", opts.tFootLink) { opts.tFootLink = it }
        textInput(p, "NOTE TEXT (e.g. Use code MYCODE)", opts.tFootNote) { opts.tFootNote = it }
        p.add(label("ROWS UNDER THE COLOR BLOCK"))
        tRowToggle(p, "PNL %", "pnl")
        tRowToggle(p, "Profit in SOL", "pnlsol")
        tRowToggle(p, "Invested", "invested")
        tRowToggle(p, "Sold (SOL returned)", "returned")
        tRowToggle(p, "Entry market cap", "entry")
        tRowToggle(p, "Exit market cap", "exit")
        tRowToggle(p, "Peak market cap", "peak")
        tRowToggle(p, "Peak multiple", "peakx")
        tRowToggle(p, "Time held", "held")
        tRowToggle(p, "Buys / sells count", "fills")
        p.add(
            tv("Colors of the block, the text and the number inside it are in the Brand tab. The sliders and rows below this line are for the other looks.", 10f, Theme.muted),
            top = dp(6), bottom = dp(14)
        )
    }

    private fun buildTune(p: LinearLayout) {
        buildTerminalTune(p)
        chips(p, "NUMBER POSITION", listOf("left" to "Left", "center" to "Centered"),
            { opts.align }) { opts.align = it }
        chips(p, "FONT", listOf("sans" to "Clean", "cond" to "Condensed", "mono" to "Mono", "serif" to "Serif"),
            { opts.font }) { opts.font = it }
        chips(p, "CHART LINE COLOR", listOf("result" to "Profit / loss color", "accent" to "Accent color"),
            { if (opts.lineByResult) "result" else "accent" }) { opts.lineByResult = it == "result" }

        slider(p, "BIG NUMBER SIZE", 50, 150, "%", { opts.heroScale }) { opts.heroScale = it }
        slider(p, "CHART HEIGHT", 40, 170, "%", { opts.chartScale }) { opts.chartScale = it }
        slider(p, "CHART LINE THICKNESS", 2, 12, "", { opts.lineWidth }) { opts.lineWidth = it }
        slider(p, "LIGHT BEHIND THE NUMBER", 0, 100, "", { opts.glow }) { opts.glow = it }
        slider(p, "BACKGROUND ZOOM (image / video)", 100, 180, "%", { opts.bgZoom }) { opts.bgZoom = it }

        p.add(label("EFFECTS"))
        toggle(p, "Shine passes over the number", { opts.lightSweep }) { opts.lightSweep = it }
        toggle(p, "Glowing dot on the chart line", { opts.tipGlow }) { opts.tipGlow = it }
        toggle(p, "Blur image / video background", { opts.bgBlur }) { opts.bgBlur = it }
        toggle(p, "Animated profile picture (in the video)", { opts.animateAvatar }) { opts.animateAvatar = it }

        p.add(label("ROWS UNDER THE CHART"))
        statToggle(p, "Invested", "invested")
        statToggle(p, "Returned", "returned")
        statToggle(p, "Entry market cap", "entry")
        statToggle(p, "Exit market cap", "exit")
        statToggle(p, "Peak market cap", "peak")
        statToggle(p, "Peak multiple", "peakx")
        statToggle(p, "Time held", "held")
        statToggle(p, "Buys / sells count", "fills")
        p.add(
            tv("Tip: the animated picture and the shine only move in the preview and the exported MP4. The PNG always shows the still picture.", 10f, Theme.muted),
            top = dp(8)
        )
    }

    private fun buildContent(p: LinearLayout) {
        p.add(label("SHOW"))
        toggle(p, "Coin picture + ticker", { opts.showCoin }) { opts.showCoin = it }
        toggle(p, "My profile picture", { opts.showAvatar }) { opts.showAvatar = it }
        toggle(p, "Hide SOL amounts (% only)", { opts.hideAmounts }) { opts.hideAmounts = it }
        toggle(p, "2x / 10x badge + glow", { opts.showRarity }) { opts.showRarity = it }
        toggle(p, "My thesis line", { opts.showThesis }) { opts.showThesis = it }
        toggle(p, "Chart", { opts.showChart }) { opts.showChart = it }
        toggle(p, "Stats (invested, MC, held)", { opts.showStats }) { opts.showStats = it }
        toggle(p, "Contract address", { opts.showCa }) { opts.showCa = it }
        toggle(p, "Branding (logo + name)", { opts.showBrand }) { opts.showBrand = it }
        toggle(p, "\"PAPER TRADE\" tag", { opts.showPaperTag }) { opts.showPaperTag = it }
        toggle(p, "Film grain", { opts.showGrain }) { opts.showGrain = it }
        toggle(p, "Vignette", { opts.showVignette }) { opts.showVignette = it }
        toggle(p, "Frame", { opts.showFrame }) { opts.showFrame = it }
    }

    private fun buildBrand(p: LinearLayout) {
        textInput(p, "NAME ON CARD", opts.displayName) { opts.displayName = it }
        textInput(p, "HANDLE (optional, e.g. @yourname)", opts.handle) { opts.handle = it }

        p.add(label("COLORS"))
        val reg = LinkedHashMap<String, EditText>()
        hexRow(p, "Background", { opts.bgHex }, { opts.bgHex = it }, reg)
        hexRow(p, "Text", { opts.textHex }, { opts.textHex = it }, reg)
        hexRow(p, "Accent / chart line", { opts.accentHex }, { opts.accentHex = it }, reg)
        hexRow(p, "Profit", { opts.profitHex }, { opts.profitHex = it }, reg)
        hexRow(p, "Loss", { opts.lossHex }, { opts.lossHex = it }, reg)
        hexRow(p, "Block color (profit)", { opts.tBlockWin }, { opts.tBlockWin = it }, reg)
        hexRow(p, "Block color (loss)", { opts.tBlockLoss }, { opts.tBlockLoss = it }, reg)
        hexRow(p, "Number inside block", { opts.tBlockText }, { opts.tBlockText = it }, reg)

        fun applyColors(bg: String, text: String, accent: String, profit: String, loss: String) {
            reg["Background"]?.setText(bg)
            reg["Text"]?.setText(text)
            reg["Accent / chart line"]?.setText(accent)
            reg["Profit"]?.setText(profit)
            reg["Loss"]?.setText(loss)
        }
        p.add(label("TERMINAL BLOCK PRESETS"))
        val blockRow = hstack()
        val blockScroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val blockPresets = listOf(
            "Mint / Pink" to listOf("#2EE6A6", "#F0357A", "#0B0B0B"),
            "Green / Red" to listOf("#22C55E", "#EF4444", "#0B0B0B"),
            "Silver" to listOf("#E6E8EB", "#8B8F96", "#0B0B0B"),
            "Gold" to listOf("#F7D154", "#B4533A", "#0B0B0B"),
            "Blue / Orange" to listOf("#3B82F6", "#F97316", "#FFFFFF")
        )
        for ((name, c) in blockPresets) {
            blockRow.add(
                outlineBtn(name) {
                    reg["Block color (profit)"]?.setText(c[0])
                    reg["Block color (loss)"]?.setText(c[1])
                    reg["Number inside block"]?.setText(c[2])
                },
                right = dp(8), w = LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        blockScroller.addView(blockRow)
        p.add(blockScroller)
        p.add(label("COLOR PRESETS"))
        val presetRow = hstack()
        val scroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val presets = listOf(
            "Chrome 73" to listOf("#000000", "#F1F3F6", "#C9CDD3", "#F1F3F6", "#A4A9B3"),
            "Chrome + G/R" to listOf("#000000", "#F1F3F6", "#C9CDD3", "#22C55E", "#EF4444"),
            "Pure B&W" to listOf("#000000", "#FFFFFF", "#FFFFFF", "#FFFFFF", "#9A9A9A"),
            "Gold" to listOf("#0A0804", "#F5E6B8", "#E8B923", "#F7D154", "#9A7B2F"),
            "Matrix" to listOf("#02080A", "#D6FFE9", "#22C55E", "#22C55E", "#EF4444")
        )
        for ((name, c) in presets) {
            presetRow.add(
                outlineBtn(name) { applyColors(c[0], c[1], c[2], c[3], c[4]) },
                right = dp(8), w = LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        scroller.addView(presetRow)
        p.add(scroller)
    }

    // ---------- background video ----------
    private fun pickVideo() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "video/*"
            startActivityForResult(i, REQ_PICK_VIDEO)
        } catch (_: Throwable) {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun prepareVideoPreview() {
        val u = opts.videoUri
        if (u.isEmpty()) return
        previewFrames = emptyList()
        videoStatus?.text = "Preparing video preview..."
        io.execute {
            val frames = VideoExporter.previewFrames(this, Uri.parse(u), 5, PREVIEW_FPS, 360)
            main.post {
                previewFrames = frames
                videoIdx = 0
                videoStatus?.text = if (frames.isEmpty()) {
                    "Couldn't read that video"
                } else {
                    "Video ready  •  tap Replay to preview it  •  Export MP4 makes the full video"
                }
                requestRender()
            }
        }
    }

    private fun exportVideo() {
        if (opts.videoUri.isEmpty()) {
            Toast.makeText(this, "Pick a background video first (Style tab > My video)", Toast.LENGTH_LONG).show()
            return
        }
        if (exporting) return
        exporting = true
        videoBtn?.text = "Exporting 0%"
        val uri = Uri.parse(opts.videoUri)
        val wide = opts.aspect == "16:9"
        val firstWidth = if (wide) (if (exportWidth == 1080) 1920 else 1280) else exportWidth
        val fallbackWidth = if (wide) 1280 else 720
        io.execute {
            var res = VideoExporter.export(this, trade, opts, coinBmp, emblemBmp, uri, firstWidth) { pct ->
                main.post { videoBtn?.text = "Exporting $pct%" }
            }
            if (res.uri == null && firstWidth > fallbackWidth) {
                main.post { Toast.makeText(this, "1080p failed on this phone, retrying at 720p...", Toast.LENGTH_LONG).show() }
                res = VideoExporter.export(this, trade, opts, coinBmp, emblemBmp, uri, fallbackWidth) { pct ->
                    main.post { videoBtn?.text = "Exporting $pct%" }
                }
            }
            val r = res
            main.post {
                exporting = false
                videoBtn?.text = "Export MP4"
                if (r.uri == null) {
                    Toast.makeText(this, "Video failed: ${r.message}", Toast.LENGTH_LONG).show()
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Toast.makeText(this, "Saved to Movies/73MCT", Toast.LENGTH_LONG).show()
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"
                        putExtra(Intent.EXTRA_STREAM, r.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(send, "Share video"))
                } else {
                    Toast.makeText(this, "Saved in the app's Movies folder", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ---------- background image ----------
    private fun pickImage() {
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(i, "Choose background"), REQ_PICK_IMAGE)
        } catch (_: Throwable) {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show()
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == REQ_PICK_VIDEO) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Throwable) {
            }
            opts.videoUri = uri.toString()
            opts.bgStyle = "video"
            prepareVideoPreview()
            changed()
            return
        }
        if (requestCode != REQ_PICK_IMAGE) return
        io.execute {
            val bmp = decodeScaled(uri, 1600)
            main.post {
                if (bmp == null) {
                    Toast.makeText(this, "Couldn't open that image", Toast.LENGTH_SHORT).show()
                } else {
                    bgBmp = bmp
                    opts.bgStyle = "image"
                    changed()
                }
            }
        }
    }

    private fun decodeScaled(uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) sample *= 2
            val real = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, real) }
        } catch (_: Throwable) {
            null
        }
    }

    // ---------- export ----------
    private fun saveCard(share: Boolean) {
        Toast.makeText(this, "Rendering card…", Toast.LENGTH_SHORT).show()
        io.execute {
            try {
                val full = CardRenderer.render(trade, opts, coinBmp, bgBmp, emblemBmp, if (opts.aspect == "16:9") 1920 else 1080, 1f)
                val name = "73MCT_${trade.symbol.trimStart('$')}_${System.currentTimeMillis()}.png"
                val uri = writePng(full, name)
                main.post {
                    if (uri == null) {
                        Toast.makeText(this, "Couldn't save the card", Toast.LENGTH_LONG).show()
                    } else {
                        lastSavedUri = uri
                        if (share && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "image/png"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            startActivity(Intent.createChooser(send, "Share card"))
                        } else {
                            Toast.makeText(this, "Saved to Pictures/73MCT", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            } catch (t: Throwable) {
                main.post { Toast.makeText(this, "Save failed: ${t.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun writePng(bmp: Bitmap, name: String): Uri? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/73MCT")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            return uri
        }
        // Older Android: write into the app's own pictures folder.
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return null
        val f = File(dir, name)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return Uri.fromFile(f)
    }
}
