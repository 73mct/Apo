package com.pocketflip.overlay

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.Surface
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer

/**
 * Turns the PnL card into an MP4: your background video plays behind the card,
 * the number counts up and the chart draws in the first ~2 seconds, and the original sound is kept.
 * It only READS the trade. Nothing here touches prices, balance or the journal.
 */
object VideoExporter {

    private const val FPS = 30
    private const val CARD_ANIM_SEC = 2.2f

    class ExportResult(val uri: Uri?, val message: String)

    /** Small, few frames of the background video so the editor preview can play it quickly. */
    fun previewFrames(context: Context, uri: Uri, maxSec: Int, fps: Int, maxSide: Int): List<Bitmap> {
        val out = ArrayList<Bitmap>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val totalMs = minOf(durMs, maxSec * 1000L)
            val step = 1000L / fps
            var t = 0L
            while (t < totalMs) {
                val f = r.getFrameAtTime(t * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                if (f != null) out.add(shrink(f, maxSide))
                t += step
            }
        } catch (_: Throwable) {
        } finally {
            try {
                r.release()
            } catch (_: Throwable) {
            }
        }
        return out
    }

    private fun shrink(b: Bitmap, maxSide: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= maxSide) return b
        val s = maxSide.toFloat() / m
        val nb = Bitmap.createScaledBitmap(
            b, (b.width * s).toInt().coerceAtLeast(1), (b.height * s).toInt().coerceAtLeast(1), true
        )
        if (nb !== b) b.recycle()
        return nb
    }

    fun export(
        context: Context,
        trade: ClosedTradeLog,
        opts: CardOptions,
        coin: Bitmap?,
        emblem: Bitmap?,
        videoUri: Uri,
        outW: Int,
        onProgress: (Int) -> Unit
    ): ExportResult {
        val outH = CardRenderer.heightFor(opts.aspect, outW)
        if (outW % 2 != 0 || outH % 2 != 0) return ExportResult(null, "Video size must be even")

        val retriever = MediaMetadataRetriever()
        val extractor = MediaExtractor()
        var encoder: MediaCodec? = null
        var inputSurface: Surface? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var muxerStopped = false
        val tmp = File(context.cacheDir, "73mct_export_" + System.currentTimeMillis() + ".mp4")

        try {
            retriever.setDataSource(context, videoUri)
            val durMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (durMs < 500L) return ExportResult(null, "Couldn't read that video")
            val totalMs = minOf(durMs, opts.videoSec * 1000L)
            val totalFrames = ((totalMs * FPS) / 1000L).toInt().coerceAtLeast(1)

            // Sound: copied untouched when the source is AAC (normal for phone videos)
            var audioIdx = -1
            var audioFmt: MediaFormat? = null
            try {
                extractor.setDataSource(context, videoUri, null)
                for (i in 0 until extractor.trackCount) {
                    val f = extractor.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime == "audio/mp4a-latm") {
                        audioIdx = i
                        audioFmt = f
                        break
                    }
                }
            } catch (_: Throwable) {
                audioIdx = -1
                audioFmt = null
            }
            val aFmt: MediaFormat? = audioFmt

            val enc = MediaCodec.createEncoderByType("video/avc")
            encoder = enc
            val format = MediaFormat.createVideoFormat("video/avc", outW, outH)
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            val bitrate = (outW.toLong() * outH.toLong() * 4L).coerceIn(2_000_000L, 14_000_000L).toInt()
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            format.setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = enc.createInputSurface()
            inputSurface = surface
            enc.start()

            val mux = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux

            val info = MediaCodec.BufferInfo()
            var videoTrack = -1
            var audioTrack = -1
            var outFrames = 0L

            fun drain(endOfStream: Boolean) {
                var spins = 0
                while (true) {
                    val idx = enc.dequeueOutputBuffer(info, if (endOfStream) 10_000L else 0L)
                    if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!endOfStream) return
                        spins++
                        if (spins > 800) return
                        continue
                    }
                    if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        videoTrack = mux.addTrack(enc.outputFormat)
                        if (aFmt != null) audioTrack = mux.addTrack(aFmt)
                        mux.start()
                        muxerStarted = true
                        continue
                    }
                    if (idx < 0) continue
                    val buf = enc.getOutputBuffer(idx)
                    val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                    if (buf != null && info.size > 0 && !isConfig && muxerStarted) {
                        // We draw faster than real time, so write our own clean 30 fps timestamps.
                        info.presentationTimeUs = outFrames * 1_000_000L / FPS
                        outFrames++
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        mux.writeSampleData(videoTrack, buf, info)
                    }
                    enc.releaseOutputBuffer(idx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }

            var lastFrame: Bitmap? = null
            for (i in 0 until totalFrames) {
                val tUs = i * 1_000_000L / FPS
                val f = retriever.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST)
                if (f != null) lastFrame = f
                val progress = ((i.toFloat() / FPS) / CARD_ANIM_SEC).coerceIn(0f, 1f)
                val card = CardRenderer.render(trade, opts, coin, lastFrame, emblem, outW, progress, i * 1000L / FPS)
                val canvas = surface.lockCanvas(null)
                canvas.drawBitmap(card, 0f, 0f, null)
                surface.unlockCanvasAndPost(canvas)
                card.recycle()
                drain(false)
                if (i % 4 == 0) onProgress(i * 100 / totalFrames)
            }
            enc.signalEndOfInputStream()
            drain(true)

            if (!muxerStarted) return ExportResult(null, "The phone's video encoder produced nothing")

            if (aFmt != null && audioIdx >= 0 && audioTrack >= 0) {
                try {
                    extractor.selectTrack(audioIdx)
                    val abuf = ByteBuffer.allocate(512 * 1024)
                    val ainfo = MediaCodec.BufferInfo()
                    val limitUs = totalFrames * 1_000_000L / FPS
                    while (true) {
                        val size = extractor.readSampleData(abuf, 0)
                        if (size < 0) break
                        val t = extractor.sampleTime
                        if (t > limitUs) break
                        val key = (extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                        ainfo.set(0, size, t, if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                        mux.writeSampleData(audioTrack, abuf, ainfo)
                        extractor.advance()
                    }
                } catch (_: Throwable) {
                    // sound is a bonus; the video itself is already complete
                }
            }
            mux.stop()
            muxerStopped = true
            onProgress(100)

            val name = "73MCT_" + trade.symbol.trimStart('$') + "_" + System.currentTimeMillis() + ".mp4"
            val uri = saveVideo(context, tmp, name) ?: return ExportResult(null, "Couldn't save the video")
            return ExportResult(uri, "ok")
        } catch (t: Throwable) {
            return ExportResult(null, t.message ?: t.javaClass.simpleName)
        } finally {
            try {
                encoder?.stop()
            } catch (_: Throwable) {
            }
            try {
                encoder?.release()
            } catch (_: Throwable) {
            }
            try {
                inputSurface?.release()
            } catch (_: Throwable) {
            }
            val m = muxer
            if (m != null) {
                try {
                    if (muxerStarted && !muxerStopped) m.stop()
                } catch (_: Throwable) {
                }
                try {
                    m.release()
                } catch (_: Throwable) {
                }
            }
            try {
                extractor.release()
            } catch (_: Throwable) {
            }
            try {
                retriever.release()
            } catch (_: Throwable) {
            }
            try {
                tmp.delete()
            } catch (_: Throwable) {
            }
        }
    }

    private fun saveVideo(context: Context, src: File, name: String): Uri? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues()
            values.put(MediaStore.Video.Media.DISPLAY_NAME, name)
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/73MCT")
            values.put(MediaStore.Video.Media.IS_PENDING, 1)
            val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            context.contentResolver.openOutputStream(uri)?.use { os -> src.inputStream().use { it.copyTo(os) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
            return uri
        }
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: return null
        dir.mkdirs()
        val f = File(dir, name)
        FileOutputStream(f).use { os -> src.inputStream().use { it.copyTo(os) } }
        return Uri.fromFile(f)
    }
}
