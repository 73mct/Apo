package com.pocketflip.overlay

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.min

private data class CoachInsight(val title: String, val detail: String, val positive: Boolean = false)

/** A transparent local coach. It computes from recorded trades; it does not pretend to be an LLM. */
private object PocketCoach {
    fun insights(): List<CoachInsight> {
        val journal = TradeRepository.getJournal()
        val positions = TradeRepository.getAllPositions()
        val academy = AcademyStore.all().filter { it.status == "REVEALED" && it.outcomeVerified && it.entryMc > 0.0 }
        val out = ArrayList<CoachInsight>()
        if (journal.isEmpty()) {
            out.add(CoachInsight("Your baseline starts here", "Complete and close paper trades to give the coach evidence. Until then, it won't guess at your strengths or weaknesses."))
        } else {
            val wins = journal.filter { it.pnlSol > 0.0 }
            val losses = journal.filter { it.pnlSol < 0.0 }
            val winRate = wins.size * 100.0 / journal.size
            val avgWin = if (wins.isNotEmpty()) wins.map { it.roiPct }.average() else 0.0
            val avgLoss = if (losses.isNotEmpty()) losses.map { it.roiPct }.average() else 0.0
            out.add(CoachInsight("Your recorded baseline", "${journal.size} closed trades · ${String.format(Locale.US, "%.1f", winRate)}% profitable · average winner ${String.format(Locale.US, "%+.1f%%", avgWin)} · average loser ${String.format(Locale.US, "%+.1f%%", avgLoss)}"))
            if (journal.size < 20) {
                out.add(CoachInsight("Small sample warning", "You have fewer than 20 closed trades. Treat every pattern as a hypothesis, not an established edge."))
            }
            val winningWithPeak = wins.filter { it.peakX > 1.05 && it.multipleX > 0.0 }
            if (winningWithPeak.size >= 3) {
                val captures = winningWithPeak.map { trade ->
                    ((trade.multipleX - 1.0) / (trade.peakX - 1.0)).coerceIn(0.0, 1.5)
                }
                val capture = captures.average() * 100.0
                if (capture < 45.0) {
                    out.add(CoachInsight("Review your exits", "Across ${winningWithPeak.size} winners with a recorded in-trade peak, your average captured portion of the entry-to-peak move is about ${capture.toInt()}%. Review the replays to see whether exits were planned or reactive."))
                } else {
                    out.add(CoachInsight("Exit capture", "Your winning trades captured about ${capture.toInt()}% of the recorded entry-to-peak move on average. Check the replay before changing your exit rules.", true))
                }
            } else {
                out.add(CoachInsight("Exit analysis needs more evidence", "At least three winning trades with a recorded peak are needed before estimating how much of the available move you captured."))
            }
            if (losses.size >= 3) {
                val worst = losses.minByOrNull { it.roiPct }
                out.add(CoachInsight("Study your downside", "You have ${losses.size} losing trades. Your worst recorded result was ${worst?.roiPct?.let { String.format(Locale.US, "%.1f%%", it) } ?: "unavailable"}. Replay the largest losses and compare the original thesis with the exit."))
            }
            val avgHoldHours = journal.map { it.holdDurationMs / 3_600_000.0 }.average()
            if (journal.size >= 5) out.add(CoachInsight("Holding-time context", "Your average closed-trade holding time is ${String.format(Locale.US, "%.1f", avgHoldHours)} hours. Compare this with the holding period your strategy actually intends."))
        }
        if (positions.size > PracticeStore.risk().maxConcurrent) {
            out.add(CoachInsight("Exposure exceeds your rule", "You currently have ${positions.size} open positions, above your configured limit of ${PracticeStore.risk().maxConcurrent}. This is a reminder, not an automatic block."))
        }
        if (academy.isNotEmpty()) {
            val p2Errors = academy.map { d ->
                val actual = if (d.peakMc / d.entryMc >= 2.0) 1.0 else 0.0
                val p = d.probability2x / 100.0
                (p - actual) * (p - actual)
            }
            val p4Errors = academy.map { d ->
                val actual = if (d.peakMc / d.entryMc >= 4.0) 1.0 else 0.0
                val p = d.probability4x / 100.0
                (p - actual) * (p - actual)
            }
            out.add(CoachInsight("Academy probability calibration", "${academy.size} verified chart-peak cases · Brier score 2x: ${String.format(Locale.US, "%.3f", p2Errors.average())} · 4x: ${String.format(Locale.US, "%.3f", p4Errors.average())}. Lower is better. These are chart-peak observations, not proof of executable exits."))
        }
        return out
    }

    fun answer(question: String): String {
        val q = question.lowercase(Locale.US)
        val trades = TradeRepository.getJournal()
        if (trades.isEmpty()) return "There isn't enough recorded trade history yet. Complete some paper trades first; I won't invent a personal edge from no data."
        val wins = trades.filter { it.pnlSol > 0.0 }
        val losses = trades.filter { it.pnlSol < 0.0 }
        return when {
            q.contains("win") || q.contains("accuracy") -> "Your current closed-trade win rate is ${String.format(Locale.US, "%.1f", wins.size * 100.0 / trades.size)}% (${wins.size} wins from ${trades.size} closed trades). This is not enough on its own to establish profitability; compare average wins, average losses and fees too."
            q.contains("loss") || q.contains("mistake") || q.contains("weak") -> {
                val worst = losses.minByOrNull { it.pnlSol }
                "You have ${losses.size} losing trades. ${if (worst != null) "The largest recorded SOL loss was ${Formatters.solSigned(worst.pnlSol)} on ${worst.symbol}." else "No closed losses are recorded."} Open the replay and original thesis before deciding what caused it."
            }
            q.contains("exit") || q.contains("sell") -> {
                val sample = wins.filter { it.peakX > 1.05 }
                if (sample.size < 3) "I need at least three winning trades with recorded peaks before comparing your exits to the available move." else {
                    val cap = sample.map { ((it.multipleX - 1.0) / (it.peakX - 1.0)).coerceIn(0.0, 1.5) }.average() * 100.0
                    "Your winners captured about ${cap.toInt()}% of their recorded entry-to-peak move on average. This is a retrospective metric, not an instruction to hold longer."
                }
            }
            q.contains("best") || q.contains("strong") -> {
                val best = wins.maxByOrNull { it.pnlSol }
                if (best == null) "No profitable closed trade is recorded yet." else "Your largest SOL winner is ${best.symbol}: ${Formatters.solSigned(best.pnlSol)}, ${Formatters.multX(best.multipleX)} average exit multiple. Study its thesis and replay to identify repeatable evidence, not just the outcome."
            }
            else -> "I can currently answer from your stored journal and verified Academy outcomes. Try asking about win rate, losses, mistakes, best trade or exits. Broader narrative and wallet conclusions need tagged research records and a connected AI research backend."
        }
    }
}

/** Practice and creator workspace. Live executions continue to use the existing TradeRepository. */
class LabScreen(
    private val act: Activity,
    private val navigateTrade: () -> Unit,
    private val navigateJournal: () -> Unit,
    private val openReplay: (String) -> Unit,
    private val openCard: (String) -> Unit
) : LinearLayout(act) {
    private val main = Handler(Looper.getMainLooper())
    private val tabKeys = listOf("lab_overview", "lab_terminal", "lab_strategy", "lab_risk", "lab_coach", "lab_replay", "lab_studio", "lab_challenges", "lab_membership")
    private val tabLabels = ArrayList<TextView>()
    private lateinit var holder: LinearLayout
    private lateinit var tabs: LinearLayout
    private var selected = 0
    private var visible = false

    private val repoListener: () -> Unit = {
        main.post { if (visible && selected == 0) render() }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()
    private fun tv(s: String, size: Float, color: Int = Theme.text, bold: Boolean = false, mono: Boolean = false) = TextView(act).apply {
        text = s; setTextColor(color); setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = false
    }
    private fun vstack() = LinearLayout(act).apply { orientation = VERTICAL }
    private fun hstack() = LinearLayout(act).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun LinearLayout.add(v: View, top: Int = 0, bottom: Int = 0, width: Int = LayoutParams.MATCH_PARENT, height: Int = LayoutParams.WRAP_CONTENT, weight: Float = 0f, left: Int = 0, right: Int = 0) {
        val p = if (weight > 0f) LayoutParams(width, height, weight) else LayoutParams(width, height)
        p.topMargin = top; p.bottomMargin = bottom; p.leftMargin = left; p.rightMargin = right; addView(v, p)
    }
    private fun card(): LinearLayout = vstack().apply { setPadding(dp(14), dp(14), dp(14), dp(14)); background = Theme.box(Theme.card, Theme.border, dp(18), dp(1)); elevation = dp(2).toFloat() }
    private fun button(label: String, filled: Boolean = false, onClick: () -> Unit): TextView = tv(label, 13f, if (filled) Theme.onColor(Theme.text) else Theme.text, true).apply {
        gravity = Gravity.CENTER; setPadding(dp(12), dp(12), dp(12), dp(12))
        background = if (filled) Theme.box(Theme.text, Theme.text, dp(14), 0) else Theme.box(Theme.bg, Theme.border, dp(14), dp(1))
        setOnClickListener { onClick() }
    }
    private fun label(s: String) = tv(s.uppercase(Locale.US), 9f, Theme.muted, true)
    private fun field(title: String, value: String, numeric: Boolean = false, multiline: Boolean = false): EditText {
        val box = EditText(act).apply {
            setText(value); setTextColor(Theme.text); setHintTextColor(Theme.muted)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f); setPadding(dp(11), dp(10), dp(11), dp(10))
            background = Theme.box(Theme.bg, Theme.border, dp(11), dp(1))
            inputType = when { multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; numeric -> InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED; else -> InputType.TYPE_CLASS_TEXT }
            setSingleLine(!multiline); if (multiline) minLines = 2
        }
        box.tag = title
        return box
    }
    private fun check(title: String, checked: Boolean): CheckBox = CheckBox(act).apply {
        text = title; isChecked = checked; setTextColor(Theme.text); textSize = 12f
        buttonTintList = ColorStateList.valueOf(Theme.text)
        setPadding(0, dp(3), 0, dp(3))
    }
    private fun stat(title: String, value: String, color: Int = Theme.text): LinearLayout = card().apply {
        add(label(title)); add(tv(value, 19f, color, true, true), top = dp(5))
    }
    private fun header(title: String, subtitle: String) {
        holder.add(tv(title, 19f, Theme.text, true), bottom = dp(4))
        holder.add(tv(subtitle, 11f, Theme.muted), bottom = dp(12))
    }

    init {
        Theme.init(act); PracticeStore.init(act); AcademyStore.init(act); CoinImages.init(act)
        orientation = VERTICAL; visibility = View.GONE
        buildShell()
        TradeRepository.addListener(repoListener)
    }

    private fun buildShell() {
        val top = vstack()
        top.add(tv("POCKETFLIP LAB", 21f, Theme.text, true))
        top.add(tv("Practice, analyse and build a repeatable process.", 11f, Theme.muted), top = dp(4))
        add(top, bottom = dp(14))
        val hs = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; clipToPadding = false }
        tabs = hstack()
        for (i in tabKeys.indices) {
            val t = tv(AppTabLabels.label(tabKeys[i]), 11f, Theme.text, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(13), dp(10), dp(13), dp(10))
            t.setOnClickListener {
                selected = i; styleTabs(); render()
                hs.post { hs.smoothScrollTo(t.left, 0) }
            }
            tabLabels.add(t)
            tabs.add(t, right = dp(6))
        }
        hs.addView(tabs)
        add(hs, bottom = dp(14))
        holder = vstack()
        add(holder)
        styleTabs()
    }

    fun applyLabels() {
        for (i in tabLabels.indices) tabLabels[i].text = AppTabLabels.label(tabKeys[i])
    }

    private fun styleTabs() {
        for (i in tabLabels.indices) {
            val active = selected == i
            tabLabels[i].background = if (active) Theme.box(Theme.text, Theme.text, dp(13), 0) else Theme.box(Theme.bg, Theme.border, dp(13), dp(1))
            tabLabels[i].setTextColor(if (active) Theme.onColor(Theme.text) else Theme.text)
        }
    }

    fun onShown() { visible = true; render() }
    fun onHidden() { visible = false }
    fun onBack(): Boolean = false
    fun destroy() { visible = false; TradeRepository.removeListener(repoListener); main.removeCallbacksAndMessages(null) }

    private fun render() {
        holder.removeAllViews()
        when (selected) {
            0 -> renderOverview()
            1 -> renderTerminal()
            2 -> renderStrategy()
            3 -> renderRisk()
            4 -> renderCoach()
            5 -> renderReplay()
            6 -> renderStudio()
            7 -> renderChallenges()
            else -> renderMembership()
        }
    }

    private fun renderOverview() {
        header("Your training workspace", "One connected loop: learn historically, practise live, review honestly.")
        val settings = TradeRepository.settings
        val journal = TradeRepository.getJournal()
        val open = TradeRepository.getAllPositions()
        val pnl = journal.sumOf { it.pnlSol }
        val wins = journal.count { it.pnlSol > 0.0 }
        val row = hstack()
        row.add(stat("VIRTUAL BALANCE", Formatters.solPlain(settings.solBalance)), width = 0, weight = 1f, right = dp(6))
        row.add(stat("OPEN POSITIONS", open.size.toString()), width = 0, weight = 1f, left = dp(6))
        holder.add(row, bottom = dp(8))
        val row2 = hstack()
        row2.add(stat("CLOSED TRADES", journal.size.toString()), width = 0, weight = 1f, right = dp(6))
        row2.add(stat("CLOSED PNL", Formatters.solSigned(pnl), Theme.pnlColor(pnl)), width = 0, weight = 1f, left = dp(6))
        holder.add(row2, bottom = dp(12))
        val start = card()
        start.add(tv("Your next session", 15f, Theme.text, true))
        start.add(tv("1. Complete historical cases in Academy.\n2. Watch the live market and paper trade only when your setup appears.\n3. Review every closed position and replay the decisions that matter.", 12f, Theme.muted), top = dp(8), bottom = dp(12))
        start.add(button("Open live paper terminal", true) { selected = 1; styleTabs(); render() }, bottom = dp(8))
        start.add(button("Review my performance coach") { selected = 4; styleTabs(); render() })
        holder.add(start, bottom = dp(12))
        val coach = PocketCoach.insights().firstOrNull()
        val insight = card()
        insight.add(label("CURRENT COACH NOTE"))
        insight.add(tv(coach?.title ?: "Build your baseline", 14f, Theme.text, true), top = dp(5))
        insight.add(tv(coach?.detail ?: "Your journal and Academy results will power evidence-based reviews.", 11f, Theme.muted), top = dp(5))
        holder.add(insight, bottom = dp(12))
        val trust = card()
        trust.add(tv("Simulation transparency", 13f, Theme.text, true))
        trust.add(tv("This workspace uses your existing simulated balance and trade engine. Quotes depend on the active market feed. Paper fills are not real blockchain transactions and do not guarantee an executable live fill.", 11f, Theme.muted), top = dp(5))
        holder.add(trust)
    }

    private fun renderTerminal() {
        val balance = TradeRepository.settings.solBalance
        val positions = TradeRepository.getAllPositions()
        val journal = TradeRepository.getJournal()
        val openPnl = positions.sumOf { TradeRepository.computeUnrealizedPnlSol(it, it.lastPriceUsd) + it.realizedPnlSol }
        header("Live paper terminal", "This is connected to the existing Trade screen and shared simulated account.")
        val summary = card()
        summary.add(label("AVAILABLE VIRTUAL SOL"))
        summary.add(tv(String.format(Locale.US, "%.4f SOL", balance), 30f, Theme.text, true, true), top = dp(4))
        summary.add(tv("${positions.size} open positions · ${journal.size} completed trades · ${Formatters.solSigned(openPnl)} open-position PnL", 11f, Theme.muted), top = dp(5), bottom = dp(12))
        summary.add(button("Go to Trade screen", true, navigateTrade))
        summary.add(button("Refresh portfolio snapshot", false) { renderTerminal() }, top = dp(10))
        holder.add(summary, bottom = dp(12))
        val watchCard = card()
        watchCard.add(tv("Personal token watchlist", 14f, Theme.text, true))
        watchCard.add(tv("Save Solana mint addresses from your research. Opening one sets it as the active CA for the existing Trade screen.", 10f, Theme.muted), top = dp(4), bottom = dp(8))
        val caInput = field("Solana token mint", "")
        watchCard.add(caInput, bottom = dp(8))
        watchCard.add(button("Add token to watchlist", false) {
            val mint = DexScreenerClient.extractSolanaCa(caInput.text.toString())
            if (!Regex("^[1-9A-HJ-NP-Za-km-z]{32,44}$").matches(mint)) {
                Toast.makeText(act, "Enter a valid Solana mint address", Toast.LENGTH_SHORT).show()
            } else if (!PracticeStore.addWatch(mint)) {
                Toast.makeText(act, "Already saved or watchlist is full", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(act, "Added to watchlist", Toast.LENGTH_SHORT).show()
                renderTerminal()
            }
        }, bottom = dp(8))
        val watchlist = PracticeStore.watchlist()
        if (watchlist.isEmpty()) {
            watchCard.add(tv("No saved tokens yet.", 10f, Theme.muted))
        } else {
            for (mint in watchlist.take(20)) {
                val line = hstack()
                line.add(tv(Formatters.shortCa(mint), 10f, Theme.text, mono = true), width = 0, weight = 1f)
                line.add(button("Open") {
                    TradeRepository.setActiveCa(mint)
                    navigateTrade()
                }, width = dp(62), right = dp(5))
                line.add(button("×") { PracticeStore.removeWatch(mint); renderTerminal() }, width = dp(38))
                watchCard.add(line, top = dp(4))
            }
            if (watchlist.size > 20) watchCard.add(tv("${watchlist.size - 20} more saved tokens", 9f, Theme.muted), top = dp(5))
        }
        holder.add(watchCard, bottom = dp(12))
        holder.add(label("OPEN POSITIONS"), bottom = dp(7))
        if (positions.isEmpty()) {
            holder.add(emptyCard("No open paper positions", "Paste a contract address in the Trade screen, review the live market and use the simulated buy/sell controls."), bottom = dp(12))
        } else {
            for (p in positions.sortedByDescending { it.openedAtMs }) {
                val pnl = TradeRepository.computeUnrealizedPnlSol(p, p.lastPriceUsd) + p.realizedPnlSol
                val c = card()
                val top = hstack()
                top.add(tv("${p.name.ifBlank { p.symbol }} (${p.symbol})", 14f, Theme.text, true), width = 0, weight = 1f)
                top.add(tv(Formatters.solSigned(pnl), 13f, Theme.pnlColor(pnl), true, true))
                c.add(top)
                c.add(tv("${Formatters.compactUsd(p.entryMc)} → ${Formatters.compactUsd(p.lastMc)} · ${Formatters.multX(if (p.entryMc > 0) p.lastMc / p.entryMc else 1.0)} · ${p.remainingPct.toInt()}% remaining", 10f, Theme.muted, mono = true), top = dp(4))
                c.add(tv(Formatters.shortCa(p.ca), 9f, Theme.muted, mono = true), top = dp(5))
                holder.add(c, bottom = dp(8))
            }
        }
        holder.add(label("RECENT COMPLETED TRADES"), top = dp(8), bottom = dp(7))
        for (t in journal.take(4)) holder.add(tradeRow(t, false), bottom = dp(7))
        if (journal.isEmpty()) holder.add(emptyCard("No completed trades yet", "Your closed positions will appear here."))
    }

    private fun renderStrategy() {
        header("Strategy builder", "Write down your own setup. These rules are reminders, not automatic buy signals.")
        val s = PracticeStore.strategy()
        val c = card()
        val name = field("Strategy name", s.name)
        val maxMc = field("Maximum entry market cap (USD)", s.maxEntryMc.toLong().toString(), true)
        val minLiq = field("Minimum liquidity (USD)", s.minLiquidityUsd.toLong().toString(), true)
        val minVol = field("Minimum 24h volume (USD)", s.minVolume24h.toLong().toString(), true)
        val wallets = field("Minimum tracked wallet entries", s.minWalletEntries.toString(), true)
        val target = field("Target multiple (x)", s.targetMultiple.toString(), true)
        val invalidation = field("What invalidates this thesis?", s.invalidation, multiline = true)
        c.add(label("PROFILE NAME")); c.add(name, top = dp(5), bottom = dp(10))
        c.add(label("MARKET FILTERS")); c.add(tv("These fields describe the setup you want to study. Current app data does not yet archive every historical liquidity and volume snapshot, so don't treat them as an automatic backtest.", 10f, Theme.muted), top = dp(4), bottom = dp(8))
        for ((title, input) in listOf("MAX ENTRY MC" to maxMc, "MIN LIQUIDITY" to minLiq, "MIN 24H VOLUME" to minVol, "MIN TRACKED WALLETS" to wallets, "TARGET MULTIPLE" to target)) {
            c.add(label(title), top = dp(5)); c.add(input, top = dp(4), bottom = dp(5))
        }
        c.add(label("PRE-ENTRY CHECKLIST"), top = dp(8))
        val ckNarrative = check("I can explain the narrative", s.checkNarrative)
        val ckLiquidity = check("Liquidity is sufficient for my planned size", s.checkLiquidity)
        val ckVolume = check("Volume supports the move", s.checkVolume)
        val ckWallet = check("Wallet activity is not just one isolated buyer", s.checkWalletFlow)
        val ckExit = check("I have an invalidation and exit plan", s.checkExitPlan)
        for (cb in listOf(ckNarrative, ckLiquidity, ckVolume, ckWallet, ckExit)) c.add(cb)
        c.add(label("INVALIDATION RULE"), top = dp(10)); c.add(invalidation, top = dp(4))
        c.add(button("Save my strategy", true) {
            val profile = StrategyProfile(
                name.text.toString().ifBlank { "My Solana setup" }, maxMc.text.toString().toDoubleOrNull() ?: s.maxEntryMc,
                minLiq.text.toString().toDoubleOrNull() ?: s.minLiquidityUsd,
                minVol.text.toString().toDoubleOrNull() ?: s.minVolume24h,
                wallets.text.toString().toIntOrNull() ?: s.minWalletEntries,
                target.text.toString().toDoubleOrNull() ?: s.targetMultiple,
                invalidation.text.toString(), ckNarrative.isChecked, ckLiquidity.isChecked, ckVolume.isChecked,
                ckWallet.isChecked, ckExit.isChecked
            )
            PracticeStore.saveStrategy(profile)
            Toast.makeText(act, "Strategy saved on this device", Toast.LENGTH_SHORT).show()
            renderStrategy()
        }, top = dp(12))
        holder.add(c, bottom = dp(12))
        val logs = TradeRepository.getJournal()
        val qualified = logs.filter { it.entryMc <= s.maxEntryMc }
        val targets = qualified.count { it.peakX >= s.targetMultiple }
        val proxy = card()
        proxy.add(tv("Historical journal proxy", 14f, Theme.text, true))
        proxy.add(tv("${qualified.size} closed trades entered below your current max market cap; ${targets} later recorded an in-trade peak at or above ${String.format(Locale.US, "%.1f", s.targetMultiple)}x.", 12f, Theme.muted), top = dp(5))
        proxy.add(tv("This is not a full strategy backtest: historical liquidity, volume, social context and fill quality were not consistently captured in the old journal.", 10f, Theme.muted), top = dp(6))
        holder.add(proxy)
    }

    private fun renderRisk() {
        header("Risk management", "Size positions from a defined loss budget instead of choosing an amount emotionally.")
        val r = PracticeStore.risk()
        val c = card()
        val riskPct = field("Account risk per trade (%)", r.riskPct.toString(), true)
        val stopPct = field("Assumed stop / invalidation distance (%)", r.stopLossPct.toString(), true)
        val maxPos = field("Maximum position as % of balance", r.maxPositionPct.toString(), true)
        val maxOpen = field("Maximum simultaneous positions", r.maxConcurrent.toString(), true)
        val daily = field("Daily closed-loss limit (%)", r.dailyLossLimitPct.toString(), true)
        for ((title, input) in listOf("RISK PER TRADE" to riskPct, "STOP DISTANCE" to stopPct, "MAX POSITION" to maxPos, "MAX OPEN POSITIONS" to maxOpen, "DAILY LOSS LIMIT" to daily)) {
            c.add(label(title)); c.add(input, top = dp(4), bottom = dp(9))
        }
        c.add(button("Save risk rules", true) {
            PracticeStore.saveRisk(RiskProfile(
                riskPct.text.toString().toDoubleOrNull() ?: r.riskPct,
                stopPct.text.toString().toDoubleOrNull() ?: r.stopLossPct,
                maxPos.text.toString().toDoubleOrNull() ?: r.maxPositionPct,
                maxOpen.text.toString().toIntOrNull() ?: r.maxConcurrent,
                daily.text.toString().toDoubleOrNull() ?: r.dailyLossLimitPct
            ))
            Toast.makeText(act, "Risk rules saved", Toast.LENGTH_SHORT).show()
            renderRisk()
        })
        holder.add(c, bottom = dp(12))
        val balance = TradeRepository.settings.solBalance.coerceAtLeast(0.0)
        val riskSol = balance * r.riskPct / 100.0
        val rawSize = if (r.stopLossPct > 0.0) riskSol / (r.stopLossPct / 100.0) else 0.0
        val cap = balance * r.maxPositionPct / 100.0
        val size = min(rawSize, cap).coerceAtLeast(0.0)
        val maxLoss = size * r.stopLossPct / 100.0
        val result = card()
        result.add(label("POSITION SIZE ESTIMATE"))
        result.add(tv(String.format(Locale.US, "%.4f SOL", size), 28f, Theme.text, true, true), top = dp(4))
        result.add(tv("Risk budget: ${Formatters.solPlain(riskSol)} · Estimated loss at stated stop: ${Formatters.solPlain(maxLoss)} · Position cap: ${Formatters.solPlain(cap)}", 11f, Theme.muted), top = dp(5))
        result.add(tv("Based on available virtual SOL (${Formatters.solPlain(balance)}). This calculator assumes the stop can be executed at the stated distance. Meme-coin gaps, liquidity and slippage can make actual losses much larger.", 10f, Theme.muted), top = dp(8))
        holder.add(result)
    }

    private fun renderCoach() {
        header("Personal performance coach", "Evidence-based review of your saved data. No external AI model or invented market claims.")
        val list = PocketCoach.insights()
        for (i in list) {
            val c = card()
            c.add(tv(i.title, 14f, if (i.positive) Theme.pnlColor(1.0) else Theme.text, true))
            c.add(tv(i.detail, 11f, Theme.muted), top = dp(6))
            holder.add(c, bottom = dp(8))
        }
        val ask = card()
        ask.add(tv("Ask about your own records", 14f, Theme.text, true))
        val query = field("Question", "What is my biggest weakness?")
        val answer = tv("Your answer will appear here after you submit a question.", 11f, Theme.muted)
        ask.add(query, top = dp(8), bottom = dp(8))
        ask.add(button("Analyse my records") {
            answer.text = PocketCoach.answer(query.text.toString())
        }, bottom = dp(8))
        ask.add(answer)
        holder.add(ask, bottom = dp(10))
        val future = card()
        future.add(tv("Secure AI research layer", 13f, Theme.text, true))
        future.add(tv("A true generative AI coach needs a secured backend with provider credentials, user consent, rate limits and auditable source retrieval. No private API key is embedded in this APK. This build provides local statistical coaching until that service is configured.", 10f, Theme.muted), top = dp(5))
        holder.add(future)
    }

    private fun renderReplay() {
        header("Trade replay", "Revisit your actual recorded price path and the buy/sell markers from each finished position.")
        val trades = TradeRepository.getJournal()
        if (trades.isEmpty()) {
            holder.add(emptyCard("No replays yet", "Close a simulated position and the trade will appear here."))
            return
        }
        for (t in trades) {
            val c = tradeRow(t, true)
            c.add(button("Replay this trade", false) { openReplay(t.id) }, top = dp(10))
            holder.add(c, bottom = dp(8))
        }
    }

    private fun renderStudio() {
        header("Creator studio", "Turn recorded trades into branded cards. Always label simulated results clearly when sharing.")
        val trades = TradeRepository.getJournal()
        val intro = card()
        intro.add(tv("Show the process, not just the profit", 14f, Theme.text, true))
        intro.add(tv("Your existing creator editor supports PNG cards, sharing and MP4 exports with animated numbers, charts and custom backgrounds. Include trade context and clearly disclose that these are paper results.", 11f, Theme.muted), top = dp(5))
        holder.add(intro, bottom = dp(10))
        if (trades.isEmpty()) {
            holder.add(emptyCard("Nothing to design yet", "Your completed paper trades will appear here as card projects."))
        } else {
            for (t in trades) {
                val row = tradeRow(t, false)
                row.add(button("Create share card", true) { openCard(t.id) }, top = dp(10))
                holder.add(row, bottom = dp(8))
            }
        }
    }

    private fun renderChallenges() {
        header("30-day survival challenge", "Build consistency and risk discipline. This is a personal challenge, not a public leaderboard.")
        val c = PracticeStore.challenge()
        val journal = TradeRepository.getJournal().filter { it.closedAtMs >= c.startedAt && c.startedAt > 0L }
        val academy = AcademyStore.all().filter { it.submittedAt >= c.startedAt && c.startedAt > 0L && it.status != "SKIPPED" }
        val elapsed = if (c.startedAt > 0L) ((System.currentTimeMillis() - c.startedAt) / 86_400_000L).toInt().coerceAtLeast(0) else 0
        val progress = (elapsed.toFloat() / 30f).coerceIn(0f, 1f)
        if (c.startedAt <= 0L) {
            val start = card()
            start.add(tv("Start your 30-day challenge", 15f, Theme.text, true))
            start.add(tv("Track Academy decisions and closed paper trades from a fixed starting date. The app will not claim that you followed a risk rule unless it has the data to verify it.", 11f, Theme.muted), top = dp(6), bottom = dp(12))
            start.add(button("Start challenge", true) { PracticeStore.startChallenge(); render() })
            holder.add(start)
            return
        }
        val summary = card()
        summary.add(label("CHALLENGE PROGRESS"))
        summary.add(tv("Day ${min(30, elapsed + 1)} of 30", 25f, Theme.text, true, true), top = dp(4))
        val bar = View(act).apply { background = Theme.box(Theme.text, Theme.text, dp(4), 0) }
        val track = android.widget.FrameLayout(act).apply {
            background = Theme.box(Theme.bg, Theme.border, dp(5), dp(1))
            addView(bar, android.widget.FrameLayout.LayoutParams(((resources.displayMetrics.widthPixels - dp(90)).toInt().coerceAtLeast(dp(20)) * progress).toInt(), dp(7)))
        }
        summary.add(track, top = dp(10), bottom = dp(8))
        summary.add(tv("${journal.size} closed paper trades · ${academy.size} Academy decisions · ${Formatters.solSigned(journal.sumOf { it.pnlSol })} closed-trade PnL", 11f, Theme.muted))
        if (c.completed || elapsed >= 30) summary.add(tv("30-day period completed. Review your journal and export your results.", 11f, Theme.pnlColor(1.0), true), top = dp(8))
        holder.add(summary, bottom = dp(10))
        if (!c.completed && elapsed >= 30) PracticeStore.markChallengeCompleted()
        val rule = card()
        rule.add(tv("Challenge rules to follow", 14f, Theme.text, true))
        val r = PracticeStore.risk()
        rule.add(tv("• Maximum ${r.riskPct}% account risk per planned trade\n• Maximum ${r.maxPositionPct}% position size\n• Maximum ${r.maxConcurrent} simultaneous positions\n• Daily loss threshold: ${r.dailyLossLimitPct}%\n• Record a thesis before each paper trade", 11f, Theme.muted), top = dp(7))
        rule.add(tv("These are your saved targets. The current app does not capture every intraday account-equity snapshot, so it cannot yet certify every daily-rule violation.", 10f, Theme.muted), top = dp(7))
        rule.add(button("Restart 30-day challenge", false) { PracticeStore.startChallenge(); render() }, top = dp(10))
        holder.add(rule)
    }

    private fun renderMembership() {
        header("PocketFlip membership", "A transparent product structure for a future paid release. No subscription is being charged in this build.")
        val free = card()
        free.add(tv("FREE", 11f, Theme.muted, true))
        free.add(tv("Build the habit", 18f, Theme.text, true), top = dp(4))
        free.add(tv("• Introductory Academy access\n• Basic simulated trading\n• Core journal and trade history\n• Basic wallet research\n• Personal progress overview", 11f, Theme.muted), top = dp(8))
        holder.add(free, bottom = dp(10))
        val pro = card()
        pro.add(tv("PRO · PLANNED", 11f, Theme.pnlColor(1.0), true))
        pro.add(tv("Full learning workflow", 18f, Theme.text, true), top = dp(4))
        pro.add(tv("• Expanded historical Academy and replay\n• Advanced KOL intelligence\n• Strategy and risk analytics\n• Personal performance coaching\n• Creator Studio exports\n• Larger research and data allowances", 11f, Theme.muted), top = dp(8))
        holder.add(pro, bottom = dp(10))
        val elite = card()
        elite.add(tv("ELITE · FUTURE TIER", 11f, Theme.muted, true))
        elite.add(tv("For intensive research", 18f, Theme.text, true), top = dp(4))
        elite.add(tv("Potential advanced wallet research, larger AI/data allowances, custom training sets and extended analytics. These will only be offered when the underlying services are reliable and their costs are understood.", 11f, Theme.muted), top = dp(8))
        holder.add(elite, bottom = dp(10))
        val notice = card()
        notice.add(tv("Payments are not activated", 14f, Theme.text, true))
        notice.add(tv("A real paid release requires Google Play Billing product IDs, a Play Console account, server-side purchase verification, cancellation/refund handling, privacy disclosures and a tested entitlement service. This screen is a feature plan only; it does not take payments or unlock paid entitlements.", 10f, Theme.muted), top = dp(5))
        holder.add(notice)
    }

    private fun tradeRow(t: ClosedTradeLog, compact: Boolean): LinearLayout {
        val c = card()
        val top = hstack()
        top.add(tv("${t.name.ifBlank { t.symbol }} (${t.symbol})", 13f, Theme.text, true), width = 0, weight = 1f)
        top.add(tv(Formatters.solSigned(t.pnlSol), 12f, Theme.pnlColor(t.pnlSol), true, true))
        c.add(top)
        c.add(tv("${Formatters.multX(t.multipleX)} average exit · ${Formatters.pctSigned1(t.roiPct)} · ${Formatters.dateTime(t.closedAtMs)}", 10f, Theme.muted, mono = true), top = dp(4))
        if (!compact) c.add(tv("${Formatters.compactUsd(t.entryMc)} entry MC · ${Formatters.compactUsd(t.peakMc)} recorded peak", 10f, Theme.muted), top = dp(4))
        return c
    }

    private fun emptyCard(title: String, detail: String): LinearLayout = card().apply {
        add(tv(title, 14f, Theme.text, true))
        add(tv(detail, 11f, Theme.muted), top = dp(5))
    }
}
