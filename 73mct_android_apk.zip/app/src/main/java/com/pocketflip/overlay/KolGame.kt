package com.pocketflip.overlay

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/*
 * Training game ("Game" tab inside the KOL Tracker page).
 * Shows a coin from the KOL history at YOUR entry level, hides how it ended, and asks you to commit
 * (thesis, chance of 2x, where it peaks, enter or pass). Then it replays the real price path against
 * your own exit rules (initials out at 2x, moon bag with a trailing stop) and keeps score.
 * It only READS the KOL data. It never touches TradeRepository, DexScreenerClient or Models.
 */

/** One candle, already converted to market cap (USD). */
class GCandle(val ts: Long, val o: Double, val h: Double, val l: Double, val c: Double, val v: Double)

/** One finished round, saved so the stats can be built later. */
class GameRound(
    val ts: Long, val mint: String, val sym: String, val name: String, val theme: String,
    val entryMc: Double, val enter: Boolean, val prob: Int, val bucket: Int, val thesis: String,
    val outcome: String,          // "hit" (reached the initials target), "stop", "open"
    val peakMult: Double, val simMult: Double, val timeToHit: Long,
    val lowConf: Boolean = false   // built from the KOLs' own trades only (no chart candles)
) {
    // 14.7 additions (old saved rounds simply load with these empty)
    var cat: String = ""        // story type you picked
    var sell: String = ""       // what would make you sell
    var checks: String = ""     // one digit per quick check: 1 yes, 0 no, 2 unsure
    var mistakes: String = ""   // tags picked after the reveal, joined with |
    var lesson: String = ""     // your one-line lesson
}

class SimCfg(val stopPct: Double, val initX: Double, val trailPct: Double, val slipPct: Double)

object GameSim {
    class Result(
        val outcome: String, val entryFill: Double,
        val hitIdx: Int, val hitMc: Double,
        val exitIdx: Int, val exitMc: Double, val moonOpen: Boolean,
        val peakMc: Double, val peakIdx: Int, val drawdown: Double,
        val simMult: Double, val gapped: Boolean, val timeToHit: Long
    )

    val bucketLabels = listOf("<2x", "2-3x", "3-5x", "5-10x", "10x+")

    fun bucketOf(m: Double): Int = when {
        m < 2.0 -> 0
        m < 3.0 -> 1
        m < 5.0 -> 2
        m < 10.0 -> 3
        else -> 4
    }

    /** Replays the candles after [idx] against the exit rules. Within one candle the stop is checked first. */
    fun run(cs: List<GCandle>, idx: Int, cfg: SimCfg): Result {
        val s = cfg.slipPct / 100.0
        val entry = cs[idx].c * (1.0 + s)
        val stop = entry * (1.0 - cfg.stopPct / 100.0)
        val target = entry * cfg.initX

        var peakMc = entry
        var peakIdx = idx
        for (j in idx + 1 until cs.size) {
            if (cs[j].h > peakMc) { peakMc = cs[j].h; peakIdx = j }
        }

        var minLow = entry
        var hit = -1
        var stopIdx = -1
        var gapped = false
        var j = idx + 1
        while (j < cs.size) {
            val k = cs[j]
            if (k.o <= stop) { stopIdx = j; gapped = true; break }
            if (k.l <= stop) { stopIdx = j; break }
            if (k.l < minLow) minLow = k.l
            if (k.h >= target) { hit = j; break }
            j++
        }

        if (stopIdx >= 0) {
            val raw = if (gapped) cs[stopIdx].o else stop
            val exitMc = raw * (1.0 - s)
            return Result("stop", entry, -1, 0.0, stopIdx, exitMc, false, peakMc, peakIdx,
                cfg.stopPct / 100.0, exitMc / entry, gapped, 0L)
        }
        val dd = max(0.0, 1.0 - minLow / entry)
        if (hit < 0) {
            val last = cs[cs.size - 1].c
            return Result("open", entry, -1, 0.0, cs.size - 1, last, true, peakMc, peakIdx,
                dd, last * (1.0 - s) / entry, false, 0L)
        }

        // initials are out at the target; the rest is the moon bag with a trailing stop
        val remaining = 1.0 - 1.0 / cfg.initX
        var runningHigh = cs[hit].h
        var exitIdx = -1
        var exitMc = 0.0
        var k2 = hit + 1
        while (k2 < cs.size) {
            val k = cs[k2]
            val level = runningHigh * (1.0 - cfg.trailPct / 100.0)
            if (k.o <= level) { exitIdx = k2; exitMc = k.o; break }
            if (k.l <= level) { exitIdx = k2; exitMc = level; break }
            if (k.h > runningHigh) runningHigh = k.h
            k2++
        }
        var moonOpen = false
        if (exitIdx < 0) {
            exitIdx = cs.size - 1
            exitMc = cs[cs.size - 1].c
            moonOpen = true
        }
        val moonMult = exitMc * (1.0 - s) / entry
        val total = (1.0 - s) + remaining * moonMult
        return Result("hit", entry, hit, target, exitIdx, exitMc, moonOpen, peakMc, peakIdx,
            dd, total, false, cs[hit].ts - cs[idx].ts)
    }
}

/** Settings and saved rounds of the game. Separate from the trading journal. */
object GameStore {
    private var prefs: SharedPreferences? = null
    private var file: File? = null
    private val lock = Any()
    val rounds = ArrayList<GameRound>()

    fun init(context: Context) {
        synchronized(lock) {
            if (prefs != null) return
            val ctx = context.applicationContext
            prefs = ctx.getSharedPreferences("game_prefs", Context.MODE_PRIVATE)
            file = File(ctx.filesDir, "game_rounds.json")
            load()
        }
    }

    private fun d(key: String, def: Double): Double =
        (prefs?.getString(key, def.toString()) ?: def.toString()).toDoubleOrNull() ?: def

    private fun put(key: String, v: Double) {
        prefs?.edit()?.putString(key, v.toString())?.apply()
    }

    var entryLow: Double
        get() = d("entry_low", 20000.0)
        set(v) { put("entry_low", v) }
    var entryHigh: Double
        get() = d("entry_high", 40000.0)
        set(v) { put("entry_high", v) }
    var lateMax: Double
        get() = d("late_max2", 500000.0)
        set(v) { put("late_max2", v) }
    var solUsd: Double
        get() = d("sol_usd", 150.0)
        set(v) { put("sol_usd", v) }
    var stopPct: Double
        get() = d("stop_pct", 50.0)
        set(v) { put("stop_pct", v) }
    var initX: Double
        get() = d("init_x", 2.0)
        set(v) { put("init_x", v) }
    var trailPct: Double
        get() = d("trail_pct", 50.0)
        set(v) { put("trail_pct", v) }
    var slipPct: Double
        get() = d("slip_pct", 3.0)
        set(v) { put("slip_pct", v) }
    var replaySec: Double
        get() = d("replay_sec", 10.0)
        set(v) { put("replay_sec", v) }
    var needX: Boolean
        get() = prefs?.getBoolean("need_x", true) ?: true
        set(v) { prefs?.edit()?.putBoolean("need_x", v)?.apply() }

    fun cfg(): SimCfg = SimCfg(stopPct, initX, trailPct, slipPct)

    fun playedMints(): Set<String> {
        synchronized(lock) { return rounds.map { it.mint }.toSet() }
    }

    private fun load() {
        rounds.clear()
        try {
            val f = file ?: return
            if (!f.exists()) return
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val gr = GameRound(
                    o.optLong("ts"), o.optString("mint"), o.optString("sym"), o.optString("name"),
                    o.optString("theme"), o.optDouble("entry", 0.0), o.optBoolean("enter", true),
                    o.optInt("prob", 50), o.optInt("bucket", 0), o.optString("thesis"),
                    o.optString("outcome", "open"), o.optDouble("peak", 0.0), o.optDouble("sim", 0.0),
                    o.optLong("t2x", 0L), o.optBoolean("low", false)
                )
                gr.cat = o.optString("cat")
                gr.sell = o.optString("sell")
                gr.checks = o.optString("checks")
                gr.mistakes = o.optString("mist")
                gr.lesson = o.optString("lesson")
                rounds.add(gr)
            }
        } catch (_: Throwable) {
        }
    }

    private fun save() {
        try {
            val arr = JSONArray()
            for (r in rounds) {
                val o = JSONObject()
                o.put("ts", r.ts); o.put("mint", r.mint); o.put("sym", r.sym); o.put("name", r.name)
                o.put("theme", r.theme); o.put("entry", r.entryMc); o.put("enter", r.enter)
                o.put("prob", r.prob); o.put("bucket", r.bucket); o.put("thesis", r.thesis)
                o.put("outcome", r.outcome); o.put("peak", r.peakMult); o.put("sim", r.simMult)
                o.put("t2x", r.timeToHit); o.put("low", r.lowConf)
                o.put("cat", r.cat); o.put("sell", r.sell); o.put("checks", r.checks)
                o.put("mist", r.mistakes); o.put("lesson", r.lesson)
                arr.put(o)
            }
            file?.writeText(arr.toString())
        } catch (_: Throwable) {
        }
    }

    fun add(r: GameRound) {
        synchronized(lock) { rounds.add(r); save() }
    }

    fun clear() {
        synchronized(lock) { rounds.clear(); save() }
    }

    /** Writes the list again after a finished round was edited (mistake tags, lesson). */
    fun saveAll() {
        synchronized(lock) { save() }
    }
}

/** Candle download for the game (GeckoTerminal, free). Minute candles around the first KOL buy, then hourly after. */
object GameData {
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun get(url: String): Pair<Int, String> {
        return try {
            val req = Request.Builder().url(url).header("Accept", "application/json").build()
            http.newCall(req).execute().use { r -> Pair(r.code, r.body?.string() ?: "") }
        } catch (_: Throwable) {
            Pair(-1, "")
        }
    }

    private fun getRetry(url: String): Pair<Int, String> {
        var r = get(url)
        if (r.first == 429) {
            try { Thread.sleep(6000L) } catch (_: InterruptedException) {}
            r = get(url)
        }
        return r
    }

    private fun parse(body: String, k: Double): List<GCandle> {
        val out = ArrayList<GCandle>()
        try {
            val list = JSONObject(body).getJSONObject("data").getJSONObject("attributes").getJSONArray("ohlcv_list")
            for (i in 0 until list.length()) {
                val c = list.getJSONArray(i)
                val close = c.getDouble(4) * k
                if (close <= 0.0) continue
                out.add(GCandle(c.getLong(0), c.getDouble(1) * k, c.getDouble(2) * k,
                    c.getDouble(3) * k, close, c.optDouble(5, 0.0)))
            }
        } catch (_: Throwable) {
        }
        out.sortBy { it.ts }
        return out
    }

    @Volatile private var solCache = 0.0
    @Volatile private var solCacheAt = 0L

    /** Current SOL price in USD (DexScreener, free). Falls back to the value in Game settings. */
    fun solUsd(fallback: Double): Double {
        val now = System.currentTimeMillis()
        if (solCache > 0.0 && now - solCacheAt < 3600_000L) return solCache
        val wsol = "So11111111111111111111111111111111111111112"
        val r = get("https://api.dexscreener.com/tokens/v1/solana/" + wsol)
        if (r.first == 200) {
            try {
                val arr = JSONArray(r.second)
                for (i in 0 until arr.length()) {
                    val p = arr.getJSONObject(i)
                    val base = p.optJSONObject("baseToken")?.optString("address") ?: ""
                    val q = p.optJSONObject("quoteToken")?.optString("symbol") ?: ""
                    val px = p.optString("priceUsd", "0").toDoubleOrNull() ?: 0.0
                    if (base == wsol && (q == "USDC" || q == "USDT") && px > 1.0) {
                        solCache = px; solCacheAt = now
                        return px
                    }
                }
            } catch (_: Throwable) {
            }
        }
        return if (solCache > 0.0) solCache else fallback
    }

    /**
     * For coins with no chart data: a rough price path made only from what the tracked KOLs paid and received.
     * Market cap = price in SOL x 1 billion supply (pump.fun coins) x SOL price. It is sparse and a lower bound.
     */
    fun fromFills(coin: KolCoin, solUsd: Double): List<GCandle> {
        val fl = ArrayList<KolFill>()
        for (p in coin.positions) for (f in p.fills) if (f.sol > 0.0 && f.tok > 0.0) fl.add(f)
        fl.sortBy { it.ts }
        val out = ArrayList<GCandle>()
        for (f in fl) {
            val mc = f.sol / f.tok * 1e9 * solUsd
            if (mc <= 0.0) continue
            out.add(GCandle(f.ts, mc, mc, mc, mc, f.sol * solUsd))
        }
        return out
    }

    fun fetch(tok: KolToken, firstFillSec: Long): List<GCandle> {
        if (tok.pair.isEmpty() || tok.priceUsd <= 0.0 || tok.mc <= 0.0) return emptyList()
        val k = tok.mc / tok.priceUsd
        val nowSec = System.currentTimeMillis() / 1000L
        val before = min(nowSec, firstFillSec + 600L * 60L) + 1L
        val r = getRetry("https://api.geckoterminal.com/api/v2/networks/solana/pools/" + tok.pair +
            "/ohlcv/minute?aggregate=1&before_timestamp=" + before + "&limit=1000&currency=usd")
        if (r.first != 200) return emptyList()
        val a = parse(r.second, k)
        if (a.isEmpty()) return a
        val out = ArrayList<GCandle>(a)
        val lastTs = a[a.size - 1].ts
        if (nowSec - lastTs > 2 * 3600L) {
            try { Thread.sleep(2200L) } catch (_: InterruptedException) {}
            val end = min(nowSec, lastTs + 14L * 86400L) + 1L
            val r2 = getRetry("https://api.geckoterminal.com/api/v2/networks/solana/pools/" + tok.pair +
                "/ohlcv/hour?aggregate=1&before_timestamp=" + end + "&limit=336&currency=usd")
            if (r2.first == 200) {
                for (c in parse(r2.second, k)) if (c.ts > lastTs) out.add(c)
            }
        }
        return out
    }
}

class KolGame(private val act: Activity) {

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }

    private class Cur(val coin: KolCoin, val cs: List<GCandle>, val idx: Int, val xUrl: String, val earliest: Boolean, val lowConf: Boolean)

    // 0 home, 1 loading, 2 round, 3 reveal, 4 stats, 5 settings
    private var state = 0
    private var pool: List<KolCoin> = emptyList()
    private var cur: Cur? = null
    private var thesisText = ""
    private var thesisField: EditText? = null
    private var sellText = ""
    private var sellField: EditText? = null
    private var lessonField: EditText? = null
    private var catIdx = -1
    private var checks = IntArray(7) { 2 }          // 1 yes, 0 no, 2 unsure
    private val checkVals = intArrayOf(1, 0, 2)     // chip order is Yes, No, Unsure
    private var mistakeSel = BooleanArray(7)
    private val saver = Runnable { GameStore.saveAll() }
    private val cats = listOf("Animal / viral moment", "Celebrity / person", "Community takeover", "Legacy meme",
        "Tech / utility", "News inside crypto", "Other")
    private val mistakeTags = listOf("Wrong coin (vamped)", "Too late", "Dev / account", "No legs",
        "Cold market", "Exit or sizing", "My read was right")
    private fun checkLabels(): List<String> = listOf(
        "I can say why it exists in one sentence",
        "Real attention behind it, not just bots",
        "Looks like the right coin (no copy fighting for it)",
        "Credible humans posted early, not just shillers",
        "People would still buy at " + num(GameStore.initX) + "x",
        "Dev or account looks legit",
        "Early enough: few people are ahead of me"
    )
    private var probIdx = 2
    private var peakIdx = 1
    private val probs = listOf(10, 30, 50, 70, 90)
    private var lastSim: GameSim.Result? = null
    private var lastRound: GameRound? = null
    private var message = ""
    private var loadingText: TextView? = null
    private val skipReasons = LinkedHashMap<String, Int>()
    private var anim: ValueAnimator? = null
    private var clearArmed = false
    private var token = 0

    init {
        GameStore.init(act)
    }

    fun view(): View = root

    /** Called by KolScreen every time the Game tab is shown. */
    fun open(coins: List<KolCoin>) {
        pool = coins
        thesisField?.let { thesisText = it.text.toString() }
        sellField?.let { sellText = it.text.toString() }
        if (state == 1) { render(); return }
        if (state != 2 && state != 3) state = 0
        render()
    }

    fun destroy() {
        anim?.cancel()
        token++
        try { flush() } catch (_: Throwable) {}
    }

    // ---------- tiny UI helpers ----------
    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), act.resources.displayMetrics
    ).toInt()

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView =
        TextView(act).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun vstack() = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private fun hstack() = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun LinearLayout.add(
        v: View, top: Int = 0, bottom: Int = 0, left: Int = 0, right: Int = 0,
        w: Int = LinearLayout.LayoutParams.MATCH_PARENT,
        h: Int = LinearLayout.LayoutParams.WRAP_CONTENT, weight: Float = 0f
    ) {
        val p = if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
        p.topMargin = top; p.bottomMargin = bottom; p.leftMargin = left; p.rightMargin = right
        addView(v, p)
    }

    private fun card(): LinearLayout = vstack().apply {
        background = Theme.box(Theme.card, Theme.border, dp(18), dp(1))
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    /** Small spaced-out label that starts a block. */
    private fun section(text: String): TextView =
        tv(text.uppercase(), 11f, Theme.muted, bold = true).apply { letterSpacing = 0.08f }

    private fun divider(): View = View(act).apply { setBackgroundColor(Theme.border) }

    private fun pill(label: String, color: Int = Theme.text, onClick: () -> Unit): TextView =
        tv(label, 13f, color, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = Theme.box(Theme.bg, Theme.border, dp(14), dp(1))
            setOnClickListener { onClick() }
        }

    private fun filledPill(label: String, onClick: () -> Unit): TextView =
        tv(label, 14f, Theme.onColor(Theme.text), bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = Theme.box(Theme.text, Theme.text, dp(14), 0)
            setOnClickListener { onClick() }
        }

    /** Chip row that restyles itself when tapped, so typed text elsewhere on the page is never lost. */
    private fun chips(labels: List<String>, start: Int, onPick: (Int) -> Unit): View {
        val sv = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false }
        val row = hstack()
        val views = ArrayList<TextView>()
        fun style(sel: Int) {
            for ((i, t) in views.withIndex()) {
                val on = i == sel
                t.setTextColor(if (on) Theme.onColor(Theme.text) else Theme.text)
                t.background = if (on) Theme.box(Theme.text, Theme.text, dp(12), 0)
                else Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
            }
        }
        for ((i, l) in labels.withIndex()) {
            val chip = tv(l, 13f, Theme.text, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(9), dp(14), dp(9))
                setOnClickListener { style(i); onPick(i) }
            }
            views.add(chip)
            row.add(chip, right = dp(8), w = LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        style(start)
        sv.addView(row)
        return sv
    }

    /** Chips laid out in a grid (all options visible at once). Single choice; start = -1 means none picked yet. */
    private fun gridChips(labels: List<String>, start: Int, cols: Int, rowGap: Int = dp(8), onPick: (Int) -> Unit): View {
        val wrap = vstack()
        val views = ArrayList<TextView>()
        fun style(sel: Int) {
            for ((i, t) in views.withIndex()) {
                val on = i == sel
                t.setTextColor(if (on) Theme.onColor(Theme.text) else Theme.text)
                t.background = if (on) Theme.box(Theme.text, Theme.text, dp(12), 0)
                else Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
            }
        }
        var i = 0
        while (i < labels.size) {
            val row = hstack()
            for (k in 0 until cols) {
                val idx = i + k
                if (idx < labels.size) {
                    val chip = tv(labels[idx], 12f, Theme.text, bold = true).apply {
                        gravity = Gravity.CENTER
                        setPadding(dp(8), dp(11), dp(8), dp(11))
                        setOnClickListener { style(idx); onPick(idx) }
                    }
                    views.add(chip)
                    row.add(chip, w = 0, weight = 1f, right = if (k < cols - 1) dp(8) else 0)
                } else {
                    row.add(View(act), w = 0, weight = 1f)
                }
            }
            wrap.add(row, bottom = rowGap)
            i += cols
        }
        style(start)
        return wrap
    }

    /** Same grid, but several can be on at once. */
    private fun multiChips(labels: List<String>, on: BooleanArray, cols: Int, onChange: () -> Unit): View {
        val wrap = vstack()
        val views = ArrayList<TextView>()
        fun style() {
            for ((i, t) in views.withIndex()) {
                val sel = on[i]
                t.setTextColor(if (sel) Theme.onColor(Theme.text) else Theme.text)
                t.background = if (sel) Theme.box(Theme.text, Theme.text, dp(12), 0)
                else Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
            }
        }
        var i = 0
        while (i < labels.size) {
            val row = hstack()
            for (k in 0 until cols) {
                val idx = i + k
                if (idx < labels.size) {
                    val chip = tv(labels[idx], 12f, Theme.text, bold = true).apply {
                        gravity = Gravity.CENTER
                        setPadding(dp(8), dp(11), dp(8), dp(11))
                        setOnClickListener { on[idx] = !on[idx]; style(); onChange() }
                    }
                    views.add(chip)
                    row.add(chip, w = 0, weight = 1f, right = if (k < cols - 1) dp(8) else 0)
                } else {
                    row.add(View(act), w = 0, weight = 1f)
                }
            }
            wrap.add(row, bottom = dp(8))
            i += cols
        }
        style()
        return wrap
    }

    private fun textBox(hint: String, text: String, minLines: Int): EditText = EditText(act).apply {
        this.hint = hint
        setHintTextColor(Theme.muted)
        setTextColor(Theme.text)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        this.minLines = minLines
        gravity = Gravity.TOP or Gravity.START
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        background = Theme.box(Theme.bg, Theme.border, dp(14), dp(1))
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setText(text)
    }

    private fun stat(label: String, value: String, color: Int = Theme.text): LinearLayout {
        val v = vstack()
        v.add(tv(label, 11f, Theme.muted))
        v.add(tv(value, 15f, color, bold = true, mono = true), top = dp(3))
        return v
    }

    private fun coinImage(tok: KolToken, size: Int): ImageView {
        val iv = ImageView(act)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Theme.circle(Theme.card, Theme.border, dp(1))
        iv.outlineProvider = ViewOutlineProvider.BACKGROUND
        iv.clipToOutline = true
        iv.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        CoinImages.bind(iv, tok.mint, if (tok.sym.isEmpty()) "?" else tok.sym, tok.img)
        return iv
    }

    private fun xFmt(v: Double) = String.format("%.1fx", v)
    private fun mFmt(v: Double) = String.format("%.2fx", v)
    private fun pctFmt(a: Int, b: Int) = if (b <= 0) "-" else String.format("%d%%", Math.round(a * 100.0 / b).toInt())
    private fun num(v: Double): String = if (v == Math.floor(v) && Math.abs(v) < 1e12) v.toLong().toString() else v.toString()
    private fun empty(text: String): View = card().apply { add(tv(text, 13f, Theme.muted)) }
    private fun symOf(t: KolToken) = "$" + (if (t.sym.isEmpty()) "?" else t.sym)

    private fun openUrl(u: String) {
        try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Throwable) {}
    }

    // ---------- rendering ----------
    private fun render() {
        anim?.cancel()
        thesisField = null
        sellField = null
        lessonField = null
        loadingText = null
        root.removeAllViews()
        val v: View = when (state) {
            1 -> buildLoading()
            2 -> { val c = cur; if (c == null) buildHome() else buildRound(c) }
            3 -> { val c = cur; val s = lastSim; val r = lastRound
                if (c == null || s == null || r == null) buildHome() else buildReveal(c, s, r) }
            4 -> buildStats()
            5 -> buildSettings()
            else -> buildHome()
        }
        root.addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun poolOk(c: KolCoin): Boolean = c.tok.pair.isNotEmpty() && c.tok.priceUsd > 0.0 && c.tok.mc > 0.0

    /** Dead pump.fun coins can still be played from the KOLs' own trades, if there are enough of them. */
    private fun fallbackOk(c: KolCoin): Boolean {
        if (!c.tok.mint.endsWith("pump")) return false
        var n = 0
        for (p in c.positions) n += p.fills.size
        return n >= 6
    }

    private fun usableCount(): Int = pool.count { poolOk(it) || fallbackOk(it) }

    // ======================= HOME =======================
    private fun buildHome(): View {
        val col = vstack()
        val intro = card()
        intro.add(tv("Training game", 20f, Theme.text, bold = true))
        intro.add(tv("You see a real coin at your entry level. The app does not tell you if it ran or died. " +
            "Name the story, run the quick checks, say how likely a " + num(GameStore.initX) + "x is, guess where it peaks, " +
            "then choose Enter or Pass. After that it replays what really happened against your own exit rules.",
            13f, Theme.muted), top = dp(8))
        col.add(intro, bottom = dp(14))

        val rs = GameStore.rounds
        val st = card()
        val r1 = hstack()
        r1.add(stat("Rounds", rs.size.toString()), w = 0, weight = 1f)
        r1.add(stat(num(GameStore.initX) + "x rate", pctFmt(rs.count { it.outcome == "hit" }, rs.size)), w = 0, weight = 1f)
        r1.add(stat("Coins ready", usableCount().toString()), w = 0, weight = 1f)
        st.add(r1)
        val withChart = pool.count { poolOk(it) }
        st.add(tv("In your KOL data: " + pool.size + " coins. With a live pool and chart: " + withChart +
            ". Trades-only (dead pump.fun coins): " + pool.count { !poolOk(it) && fallbackOk(it) } + ".", 12f, Theme.muted), top = dp(12))
        col.add(st, bottom = dp(14))

        if (usableCount() == 0) {
            col.add(empty("No usable coins yet. Open the Wallets tab, add KOL wallets and scan them. " +
                "A coin needs a live pool, or at least 6 KOL trades on a pump.fun coin."), bottom = dp(14))
        }
        if (message.isNotEmpty()) {
            col.add(empty(message), bottom = dp(14))
        }
        col.add(filledPill("Start a round") { nextRound() }, bottom = dp(12))
        val row = hstack()
        row.add(pill("My stats") { state = 4; render() }, w = 0, weight = 1f, right = dp(10))
        row.add(pill("Game settings") { state = 5; render() }, w = 0, weight = 1f)
        col.add(row, bottom = dp(16))
        col.add(tv("Entry level " + KolEngine.money(GameStore.entryLow) + " to " + KolEngine.money(GameStore.entryHigh) +
            "  \u00B7  stop -" + num(GameStore.stopPct) + "%  \u00B7  initials at " + num(GameStore.initX) + "x  \u00B7  moon bag trail " +
            num(GameStore.trailPct) + "%", 11f, Theme.muted, mono = true), left = dp(4))
        return col
    }

    // ======================= LOADING / PICKING =======================
    private fun buildLoading(): View {
        val c = card()
        c.add(tv("Finding a coin at your entry level...", 16f, Theme.text, bold = true))
        val t = tv(skipSummary(), 12f, Theme.muted)
        loadingText = t
        c.add(t, top = dp(10))
        c.add(tv("Each round downloads real candles, so it can take 10 to 40 seconds.", 12f, Theme.muted), top = dp(8))
        return c
    }

    private fun skipSummary(): String {
        if (skipReasons.isEmpty()) return "Starting..."
        return "Skipped so far: " + skipReasons.entries.joinToString(", ") { it.value.toString() + " " + it.key }
    }

    private fun pickCoin(exclude: Set<String>): KolCoin? {
        val played = GameStore.playedMints()
        val usable = pool.filter { (poolOk(it) || fallbackOk(it)) && !exclude.contains(it.tok.mint) }
        if (usable.isEmpty()) return null
        val fresh = usable.filter { !played.contains(it.tok.mint) }
        val src = if (fresh.isNotEmpty()) fresh else usable
        // mix runners, middle coins and flops so the answer cannot be guessed from the group
        val hi = src.filter { it.peak >= 1_000_000.0 }
        val mid = src.filter { it.peak >= 200_000.0 && it.peak < 1_000_000.0 }
        val lo = src.filter { it.peak < 200_000.0 }
        val groups = listOf(hi, mid, lo).filter { it.isNotEmpty() }
        return groups.random().random()
    }

    private fun noteSkip(reason: String) {
        skipReasons[reason] = (skipReasons[reason] ?: 0) + 1
        val t = skipSummary()
        main.post { loadingText?.text = t }
    }

    private fun pickIndex(cs: List<GCandle>): Int {
        val lo = GameStore.entryLow
        val hi = GameStore.entryHigh
        for (i in cs.indices) {
            if (cs[i].c >= lo && cs[i].c <= hi) return i
        }
        if (cs[0].c <= GameStore.lateMax) return 0
        return -1
    }

    private fun awaitX(mint: String): String {
        val latch = CountDownLatch(1)
        val box = arrayOf("")
        CoinLinkFinder.find(mint, true) { l -> box[0] = l.x; latch.countDown() }
        try { latch.await(10, TimeUnit.SECONDS) } catch (_: InterruptedException) {}
        return box[0]
    }

    private fun nextRound() {
        if (usableCount() == 0) { message = "No usable coins yet. Scan some KOL wallets first."; state = 0; render(); return }
        message = ""
        state = 1
        skipReasons.clear()
        token++
        val my = token
        render()
        io.execute {
            val exclude = HashSet<String>()
            var tries = 0
            while (tries < 14 && my == token) {
                val c = pickCoin(exclude) ?: break
                tries++
                exclude.add(c.tok.mint)
                val first = c.positions.minOf { p -> p.fills.minOf { f -> f.ts } }
                var cs: List<GCandle> = emptyList()
                var idx = -1
                var low = false
                if (poolOk(c)) {
                    val got = GameData.fetch(c.tok, first)
                    if (got.size < 40) noteSkip("no chart data")
                    else {
                        val i = pickIndex(got)
                        if (i < 0) noteSkip("started too high")
                        else if (got.size - i < 30) noteSkip("too little history")
                        else { cs = got; idx = i }
                    }
                }
                if (idx < 0 && fallbackOk(c)) {
                    val fc = GameData.fromFills(c, GameData.solUsd(GameStore.solUsd))
                    val i = if (fc.isEmpty()) -1 else pickIndex(fc)
                    if (fc.size >= 6 && i >= 0 && fc.size - i >= 4) { cs = fc; idx = i; low = true }
                    else noteSkip("trades too thin")
                }
                if (idx < 0) continue
                var x = ""
                if (GameStore.needX) {
                    x = awaitX(c.tok.mint)
                    if (x.isEmpty()) { noteSkip("no X link"); continue }
                }
                val earliest = !(cs[idx].c >= GameStore.entryLow && cs[idx].c <= GameStore.entryHigh)
                val found = Cur(c, cs, idx, x, earliest, low)
                main.post {
                    if (my != token) return@post
                    cur = found
                    thesisText = ""
                    sellText = ""
                    catIdx = -1
                    checks = IntArray(7) { 2 }
                    probIdx = 2
                    peakIdx = 1
                    state = 2
                    render()
                }
                return@execute
            }
            main.post {
                if (my != token) return@post
                message = "Could not find a usable coin this time. " + skipSummary() + ". Try again, or widen the entry level in Game settings."
                state = 0
                render()
            }
        }
    }

    // ======================= ROUND =======================
    private fun fmtTime(ts: Long): String =
        java.text.SimpleDateFormat("d MMM yyyy, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ts * 1000L))

    private fun checkIdx(v: Int): Int = when (v) { 1 -> 0; 0 -> 1; else -> 2 }

    private fun buildRound(c: Cur): View {
        val col = vstack()
        val tok = c.coin.tok
        val now = c.cs[c.idx]

        val head = hstack()
        head.add(coinImage(tok, 56), right = dp(14), w = dp(56), h = dp(56))
        val hv = vstack()
        hv.add(tv(symOf(tok), 22f, Theme.text, bold = true))
        hv.add(tv(tok.name, 13f, Theme.muted), top = dp(2))
        head.add(hv, w = 0, weight = 1f)
        head.add(tv("Round " + (GameStore.rounds.size + 1), 12f, Theme.muted, mono = true))
        col.add(head, bottom = dp(14))

        var vol = 0.0
        if (c.lowConf) {
            for (i in 0..c.idx) if (c.cs[i].ts >= now.ts - 900L) vol += c.cs[i].v
        } else {
            for (i in max(0, c.idx - 14)..c.idx) vol += c.cs[i].v
        }
        val st = card()
        val r1 = hstack()
        r1.add(stat("Market cap now", KolEngine.money(now.c)), w = 0, weight = 1f)
        r1.add(stat("Volume 15m", KolEngine.money(vol)), w = 0, weight = 1f)
        if (c.lowConf) r1.add(stat("KOL trades so far", (c.idx + 1).toString()), w = 0, weight = 1f)
        else r1.add(stat("Chart history", KolEngine.dur(now.ts - c.cs[0].ts)), w = 0, weight = 1f)
        st.add(r1, bottom = dp(12))
        st.add(divider(), h = dp(1), bottom = dp(12))
        st.add(tv("Entry point  " + fmtTime(now.ts), 13f, Theme.text, bold = true, mono = true))
        st.add(tv("When you look at the X posts, ignore anything after this time. Later posts give away the ending.",
            12f, Theme.muted), top = dp(4))
        col.add(st, bottom = dp(14))

        val chart = KolChart(act)
        val from = max(0, c.idx - 120)
        val pts = ArrayList<Pair<Long, Double>>()
        for (i in from..c.idx) pts.add(Pair(c.cs[i].ts, c.cs[i].c))
        chart.pts = pts
        chart.marks = listOf(KolChart.Mark(now.ts, now.c, true, "E", Theme.text))
        chart.progress = 1f
        col.add(chart, h = dp(220), bottom = dp(8))
        if (c.lowConf) {
            col.add(tv("No chart data for this coin (it is dead or its pool is gone). This chart is built only from what the KOLs paid, so it is sparse and the real path had more ups and downs.",
                12f, Theme.muted), bottom = dp(8), left = dp(4))
        }
        if (c.earliest) {
            col.add(tv("Earliest data available for this coin. Its first minutes are not on this chart, so it already looks older than it was.",
                12f, Theme.muted), bottom = dp(8), left = dp(4))
        }

        val links = hstack()
        if (c.xUrl.isNotEmpty()) {
            links.add(pill("Open X") { openUrl(c.xUrl) }, w = 0, weight = 1f, right = dp(10))
        }
        links.add(pill("Copy CA") {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("CA", tok.mint))
            Toast.makeText(act, "CA copied", Toast.LENGTH_SHORT).show()
        }, w = 0, weight = 1f)
        col.add(links, bottom = dp(24))

        col.add(section("Your read"), bottom = dp(10), left = dp(4))

        // 1. the story
        val c1 = card()
        c1.add(tv("1  What kind of story is it?", 15f, Theme.text, bold = true), bottom = dp(12))
        c1.add(gridChips(cats, catIdx, 2) { catIdx = it }, bottom = dp(8))
        c1.add(tv("The story in one sentence", 13f, Theme.text, bold = true), bottom = dp(8))
        val th = textBox("Why would people buy this? If you cannot say it in one sentence, that is a signal.", thesisText, 2)
        thesisField = th
        c1.add(th)
        col.add(c1, bottom = dp(14))

        // 2. quick checks
        val c2 = card()
        c2.add(tv("2  Quick checks", 15f, Theme.text, bold = true), bottom = dp(4))
        c2.add(tv("Answer from what you can see. Unsure is a fine answer.", 12f, Theme.muted), bottom = dp(14))
        val labels = checkLabels()
        for ((i, l) in labels.withIndex()) {
            c2.add(tv(l, 13f, Theme.text), bottom = dp(8))
            c2.add(gridChips(listOf("Yes", "No", "Unsure"), checkIdx(checks[i]), 3, 0) { checks[i] = checkVals[it] },
                bottom = if (i == labels.size - 1) 0 else dp(16))
        }
        col.add(c2, bottom = dp(14))

        // 3. the call
        val c3 = card()
        c3.add(tv("3  Your call", 15f, Theme.text, bold = true), bottom = dp(14))
        c3.add(tv("Chance it reaches " + num(GameStore.initX) + "x before -" + num(GameStore.stopPct) + "%", 13f, Theme.text), bottom = dp(8))
        c3.add(chips(probs.map { it.toString() + "%" }, probIdx) { probIdx = it }, bottom = dp(16))
        c3.add(tv("Where does it peak, from this entry?", 13f, Theme.text), bottom = dp(8))
        c3.add(chips(GameSim.bucketLabels, peakIdx) { peakIdx = it }, bottom = dp(16))
        c3.add(tv("What would make you sell? (optional)", 13f, Theme.text), bottom = dp(8))
        val sf = textBox("For example: dev sells, volume dies, the story gets copied.", sellText, 2)
        sellField = sf
        c3.add(sf)
        col.add(c3, bottom = dp(18))

        val row = hstack()
        row.add(filledPill("Enter (paper)") { commit(true) }, w = 0, weight = 1f, right = dp(10))
        row.add(pill("Pass") { commit(false) }, w = 0, weight = 1f)
        col.add(row, bottom = dp(12))
        val row2 = hstack()
        row2.add(pill("Skip coin (not scored)") { nextRound() }, w = 0, weight = 1f, right = dp(10))
        row2.add(pill("Back to menu") { token++; state = 0; render() }, w = 0, weight = 1f)
        col.add(row2)
        return col
    }

    private fun commit(enter: Boolean) {
        val c = cur ?: return
        thesisField?.let { thesisText = it.text.toString().trim() }
        sellField?.let { sellText = it.text.toString().trim() }
        val sim = GameSim.run(c.cs, c.idx, GameStore.cfg())
        val round = GameRound(
            System.currentTimeMillis(), c.coin.tok.mint, c.coin.tok.sym, c.coin.tok.name,
            KolEngine.themeOf(c.coin.tok), sim.entryFill, enter, probs[probIdx], peakIdx, thesisText,
            sim.outcome, sim.peakMc / sim.entryFill, sim.simMult, sim.timeToHit, c.lowConf
        )
        round.cat = if (catIdx in cats.indices) cats[catIdx] else ""
        round.sell = sellText
        round.checks = checks.joinToString("")
        GameStore.add(round)
        mistakeSel = BooleanArray(mistakeTags.size)
        lastSim = sim
        lastRound = round
        state = 3
        render()
        try { root.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) } catch (_: Throwable) {}
    }

    /** Keeps the lesson line and mistake tags on disk. */
    private fun flush() {
        lessonField?.let { lastRound?.lesson = it.text.toString().trim() }
        GameStore.saveAll()
    }

    // ======================= REVEAL =======================
    private fun buildReveal(c: Cur, s: GameSim.Result, r: GameRound): View {
        val col = vstack()
        val tok = c.coin.tok
        val cfg = GameStore.cfg()
        val head = hstack()
        head.add(coinImage(tok, 52), right = dp(14), w = dp(52), h = dp(52))
        val hv = vstack()
        hv.add(tv(symOf(tok), 20f, Theme.text, bold = true))
        hv.add(tv(tok.name, 13f, Theme.muted), top = dp(2))
        head.add(hv, w = 0, weight = 1f)
        col.add(head, bottom = dp(14))

        // result
        val res = card()
        val good = s.simMult >= 1.0
        val big = tv(mFmt(s.simMult), 36f, Theme.pnlColor(if (good) 1.0 else -1.0), bold = true, mono = true)
        big.alpha = 0f; big.scaleX = 0.8f; big.scaleY = 0.8f
        big.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(380L).start()
        if (r.enter) {
            res.add(section("Your paper result (money in = 1.00x)"))
            res.add(big, top = dp(4))
        } else {
            res.add(section("You passed. If you had entered"))
            res.add(big, top = dp(4))
        }
        val line = when (s.outcome) {
            "hit" -> "Reached " + num(cfg.initX) + "x in " + KolEngine.dur(s.timeToHit) + " (initials out). Moon bag " +
                (if (s.moonOpen) "still open at the end of the data, " else "stopped out at ") +
                KolEngine.money(s.exitMc) + " = " + xFmt(s.exitMc / s.entryFill) + " from entry."
            "stop" -> "Fell to your -" + num(cfg.stopPct) + "% stop before reaching " + num(cfg.initX) + "x." +
                (if (s.gapped) " Price gapped through the stop, so the exit was worse than the stop." else "")
            else -> "Neither " + num(cfg.initX) + "x nor your stop happened in the data window. Marked at the last price."
        }
        res.add(tv(line, 13f, Theme.text), top = dp(8))
        col.add(res, bottom = dp(14))

        // chart + replay
        val chart = KolChart(act)
        val from = max(0, c.idx - 60)
        val raw = ArrayList<Pair<Long, Double>>()
        for (i in from until c.cs.size) raw.add(Pair(c.cs[i].ts, c.cs[i].c))
        val step = max(1, raw.size / 900)
        val pts = ArrayList<Pair<Long, Double>>()
        for (i in raw.indices) if (i % step == 0 || i == raw.size - 1) pts.add(raw[i])
        chart.pts = pts
        val marks = ArrayList<KolChart.Mark>()
        marks.add(KolChart.Mark(c.cs[c.idx].ts, s.entryFill, true, "E", Theme.text))
        if (s.hitIdx >= 0) marks.add(KolChart.Mark(c.cs[s.hitIdx].ts, s.hitMc, false, num(cfg.initX) + "x", Theme.profit))
        if (s.outcome == "stop") marks.add(KolChart.Mark(c.cs[s.exitIdx].ts, s.exitMc, false, "S", Theme.loss))
        if (s.outcome == "hit" && !s.moonOpen) marks.add(KolChart.Mark(c.cs[s.exitIdx].ts, s.exitMc, false, "M", Theme.profit))
        chart.marks = marks
        chart.progress = 0f
        col.add(chart, h = dp(250), bottom = dp(8))
        val clock = tv("Replay", 12f, Theme.muted, mono = true)
        col.add(clock, bottom = dp(10), left = dp(4))
        val rb = hstack()
        rb.add(pill("Replay") { playReplay(chart, clock, c.cs[c.idx].ts) }, w = 0, weight = 1f, right = dp(10))
        rb.add(pill("Show full") { anim?.cancel(); chart.progress = 1f; chart.invalidate(); clock.text = "Full path" }, w = 0, weight = 1f)
        col.add(rb, bottom = dp(14))
        main.post { playReplay(chart, clock, c.cs[c.idx].ts) }

        // what happened
        val wh = card()
        wh.add(section("What really happened"), bottom = dp(12))
        val a = hstack()
        a.add(stat("Entry", KolEngine.money(s.entryFill)), w = 0, weight = 1f)
        a.add(stat("Peak after", KolEngine.money(s.peakMc)), w = 0, weight = 1f)
        a.add(stat("Peak x", xFmt(s.peakMc / s.entryFill)), w = 0, weight = 1f)
        wh.add(a, bottom = dp(14))
        val b = hstack()
        b.add(stat("Time to peak", KolEngine.dur(c.cs[s.peakIdx].ts - c.cs[c.idx].ts)), w = 0, weight = 1f)
        b.add(stat("Worst dip", String.format("-%d%%", Math.round(s.drawdown * 100.0).toInt()), Theme.loss), w = 0, weight = 1f)
        b.add(stat("Fills", "-" + num(cfg.slipPct) + "% each side"), w = 0, weight = 1f)
        wh.add(b)
        col.add(wh, bottom = dp(14))

        // your read
        val yc = card()
        yc.add(section("Your read"), bottom = dp(12))
        val hitIt = s.outcome == "hit"
        yc.add(tv("You said " + r.prob + "% for " + num(cfg.initX) + "x before the stop. It " + (if (hitIt) "did." else "did not."), 13f, Theme.text))
        val actualB = GameSim.bucketOf(s.peakMc / s.entryFill)
        val verdict = if (r.bucket == actualB) "Exact." else if (r.bucket < actualB) "You guessed too low." else "You guessed too high."
        yc.add(tv("Peak guess " + GameSim.bucketLabels[r.bucket] + ", actual " + GameSim.bucketLabels[actualB] + ". " + verdict, 13f, Theme.text), top = dp(6))
        if (r.cat.isNotEmpty() || r.thesis.isNotEmpty()) {
            yc.add(divider(), h = dp(1), top = dp(14), bottom = dp(14))
            if (r.cat.isNotEmpty()) yc.add(tv("Story type: " + r.cat, 13f, Theme.text, bold = true))
            if (r.thesis.isNotEmpty()) yc.add(tv(r.thesis, 13f, Theme.text), top = dp(4))
        }
        if (r.checks.length == checkLabels().size) {
            val labels = checkLabels()
            var anyAnswered = false
            for (i in labels.indices) if (r.checks[i] != '2') anyAnswered = true
            if (anyAnswered) {
                yc.add(divider(), h = dp(1), top = dp(14), bottom = dp(14))
                yc.add(tv("Your checks", 13f, Theme.text, bold = true), bottom = dp(8))
                var unsure = 0
                for (i in labels.indices) {
                    val ch = r.checks[i]
                    if (ch == '2') { unsure++; continue }
                    val row = hstack()
                    row.add(tv(if (ch == '1') "YES" else "NO", 11f, if (ch == '1') Theme.profit else Theme.loss, bold = true, mono = true), w = dp(34))
                    row.add(tv(labels[i], 12f, Theme.text), w = 0, weight = 1f)
                    yc.add(row, bottom = dp(6))
                }
                if (unsure > 0) yc.add(tv(unsure.toString() + " unsure", 12f, Theme.muted), top = dp(2))
            }
        }
        if (r.sell.isNotEmpty()) {
            yc.add(divider(), h = dp(1), top = dp(14), bottom = dp(14))
            yc.add(tv("You would sell if", 12f, Theme.muted))
            yc.add(tv(r.sell, 13f, Theme.text), top = dp(2))
            yc.add(tv("Look at the replay: did that happen before the price turned?", 12f, Theme.muted), top = dp(4))
        }
        col.add(yc, bottom = dp(14))

        // why
        val wy = card()
        wy.add(tv("What explains the result?", 15f, Theme.text, bold = true), bottom = dp(4))
        wy.add(tv("Tap everything that applies. The stats page counts these so you can see your most common mistake.", 12f, Theme.muted), bottom = dp(12))
        mistakeSel = BooleanArray(mistakeTags.size)
        for ((i, t) in mistakeTags.withIndex()) if (r.mistakes.split("|").contains(t)) mistakeSel[i] = true
        wy.add(multiChips(mistakeTags, mistakeSel, 2) {
            r.mistakes = mistakeTags.filterIndexed { i, _ -> mistakeSel[i] }.joinToString("|")
            GameStore.saveAll()
        }, bottom = dp(8))
        wy.add(tv("One-line lesson for next time", 13f, Theme.text, bold = true), bottom = dp(8))
        val lf = textBox("For example: a copy launched an hour later and took the volume.", r.lesson, 2)
        lf.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun afterTextChanged(p0: android.text.Editable?) {
                r.lesson = (p0?.toString() ?: "").trim()
                main.removeCallbacks(saver)
                main.postDelayed(saver, 1000L)
            }
        })
        lessonField = lf
        wy.add(lf)
        col.add(wy, bottom = dp(14))

        // the KOLs (kept hidden until now)
        val kc = card()
        kc.add(section("The KOLs on this coin"), bottom = dp(10))
        val first = c.coin.positions.first()
        kc.add(tv(c.coin.kolCount.toString() + " tracked KOL(s). First in: " + first.wallet.label + " at " +
            KolEngine.money(first.entryMc) + ", result " + xFmt(first.multiple) + ".", 13f, Theme.text))
        kc.add(tv("Coin now: " + KolEngine.money(tok.mc) + ", peak seen " + KolEngine.money(c.coin.peak) + ".", 12f, Theme.muted), top = dp(6))
        col.add(kc, bottom = dp(14))

        if (c.lowConf) {
            col.add(tv("Low-confidence round: built from the KOLs' own trades only. The real peak was probably higher and dips between trades are not shown, so treat this result as a rough lower bound.",
                12f, Theme.muted), bottom = dp(10), left = dp(4))
        }
        val note = "Notes: stops are checked before targets inside one candle. After the first hours the data is hourly, " +
            "so fast moves inside an hour are approximated. Real fills would be worse on some coins."
        col.add(tv(note, 12f, Theme.muted), bottom = dp(16), left = dp(4))

        col.add(filledPill("Next round") { flush(); nextRound() }, bottom = dp(12))
        val rw = hstack()
        rw.add(pill("Dex chart") {
            openUrl(if (tok.pair.isNotEmpty()) "https://dexscreener.com/solana/" + tok.pair else "https://dexscreener.com/solana/" + tok.mint)
        }, w = 0, weight = 1f, right = dp(10))
        rw.add(pill("My stats") { flush(); state = 4; render() }, w = 0, weight = 1f, right = dp(10))
        rw.add(pill("Menu") { flush(); state = 0; render() }, w = 0, weight = 1f)
        col.add(rw)
        return col
    }

    private fun playReplay(chart: KolChart, clock: TextView, entryTs: Long) {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = (GameStore.replaySec * 1000.0).toLong().coerceIn(3000L, 60000L)
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            val v = it.animatedValue as Float
            chart.progress = v
            chart.invalidate()
            val t = chart.timeAt(v) - entryTs
            clock.text = "Replay  " + (if (t < 0) "-" else "+") + KolEngine.dur(Math.abs(t)) + " from your entry"
        }
        anim = a
        a.start()
    }

    // ======================= STATS =======================
    private fun buildStats(): View {
        val col = vstack()
        col.add(tv("Your training stats", 22f, Theme.text, bold = true), bottom = dp(14))
        val rs = GameStore.rounds
        if (rs.isEmpty()) {
            col.add(empty("No rounds yet. Play a few and this page fills up."), bottom = dp(14))
            col.add(pill("Back") { state = 0; render() })
            return col
        }
        val n = rs.size
        val hits = rs.count { it.outcome == "hit" }
        val entered = rs.filter { it.enter }
        val passed = rs.filter { !it.enter }
        val net = entered.sumOf { it.simMult - 1.0 }
        val avg = if (entered.isEmpty()) 0.0 else entered.sumOf { it.simMult } / entered.size

        val ov = card()
        ov.add(section("Overview"), bottom = dp(12))
        val a = hstack()
        a.add(stat("Rounds", n.toString()), w = 0, weight = 1f)
        a.add(stat(num(GameStore.initX) + "x base rate", pctFmt(hits, n)), w = 0, weight = 1f)
        a.add(stat("Entered", entered.size.toString()), w = 0, weight = 1f)
        ov.add(a, bottom = dp(14))
        val b = hstack()
        b.add(stat("Avg result", if (entered.isEmpty()) "-" else mFmt(avg), if (avg >= 1.0) Theme.profit else Theme.loss), w = 0, weight = 1f)
        b.add(stat("Net (1 unit each)", if (entered.isEmpty()) "-" else String.format("%+.1f", net), Theme.pnlColor(net)), w = 0, weight = 1f)
        b.add(stat("Passed", passed.size.toString()), w = 0, weight = 1f)
        ov.add(b, bottom = dp(12))
        val missed = passed.count { it.outcome == "hit" }
        val dodged = passed.count { it.outcome == "stop" }
        ov.add(tv("Passes: " + missed + " would have hit " + num(GameStore.initX) + "x (missed), " + dodged + " would have stopped out (dodged).", 12f, Theme.muted))
        val lowN = rs.count { it.lowConf }
        if (lowN > 0) {
            ov.add(tv(lowN.toString() + " of these rounds were low-confidence (trades-only, no candles).", 12f, Theme.muted), top = dp(6))
        }
        if (n < 100) {
            ov.add(tv("Only " + n + " of about 100 rounds. Under that, these percentages are mostly noise.", 12f, Theme.muted), top = dp(6))
        }
        col.add(ov, bottom = dp(14))

        // by story type (the one you pick)
        val withCat = rs.filter { it.cat.isNotEmpty() }
        if (withCat.isNotEmpty()) {
            val cc = card()
            cc.add(section("By story type"), bottom = dp(4))
            cc.add(tv("Where your reads are strong or weak. Needs a few rounds per type to mean anything.", 12f, Theme.muted), bottom = dp(12))
            val groups = cats.map { name -> Pair(name, withCat.filter { it.cat == name }) }.filter { it.second.isNotEmpty() }
            for ((gi, g) in groups.withIndex()) {
                val h = g.second.count { it.outcome == "hit" }
                val ent = g.second.filter { it.enter }
                val av = if (ent.isEmpty()) "-" else mFmt(ent.sumOf { it.simMult } / ent.size)
                cc.add(tv(g.first, 14f, Theme.text, bold = true))
                cc.add(tv(g.second.size.toString() + " rounds  \u00B7  " + num(GameStore.initX) + "x in " + pctFmt(h, g.second.size) +
                    "  \u00B7  avg entered " + av, 12f, Theme.muted, mono = true), top = dp(3), bottom = if (gi == groups.size - 1) 0 else dp(12))
            }
            col.add(cc, bottom = dp(14))
        }

        // which checks lined up with coins that ran
        val withChecks = rs.filter { it.checks.length == checkLabels().size }
        if (withChecks.size >= 3) {
            val kc = card()
            kc.add(section("Which checks mattered"), bottom = dp(4))
            kc.add(tv("When you answered Yes or No, how often did the coin reach " + num(GameStore.initX) + "x? Small samples, so read it as a hint.", 12f, Theme.muted), bottom = dp(12))
            val labels = checkLabels()
            for ((i, l) in labels.withIndex()) {
                val yes = withChecks.filter { it.checks[i] == '1' }
                val no = withChecks.filter { it.checks[i] == '0' }
                if (yes.isEmpty() && no.isEmpty()) continue
                kc.add(tv(l, 13f, Theme.text), bottom = dp(3))
                kc.add(tv("Yes: " + yes.count { it.outcome == "hit" } + "/" + yes.size + " ran  \u00B7  No: " +
                    no.count { it.outcome == "hit" } + "/" + no.size + " ran", 12f, Theme.muted, mono = true),
                    bottom = if (i == labels.size - 1) 0 else dp(12))
            }
            col.add(kc, bottom = dp(14))
        }

        // mistakes
        val mc = rs.flatMap { r -> r.mistakes.split("|").filter { it.isNotEmpty() } }.groupingBy { it }.eachCount()
        if (mc.isNotEmpty()) {
            val mcard = card()
            mcard.add(section("Your most common reasons"), bottom = dp(12))
            val sorted = mc.entries.sortedByDescending { it.value }
            for ((i, e) in sorted.withIndex()) {
                val row = hstack()
                row.add(tv(e.key, 13f, Theme.text), w = 0, weight = 1f)
                row.add(tv(e.value.toString() + "x", 13f, Theme.text, bold = true, mono = true), w = LinearLayout.LayoutParams.WRAP_CONTENT)
                mcard.add(row, bottom = if (i == sorted.size - 1) 0 else dp(8))
            }
            col.add(mcard, bottom = dp(14))
        }

        val cal = card()
        cal.add(section("Calibration: what you said vs what happened"), bottom = dp(12))
        for (p in probs) {
            val g = rs.filter { it.prob == p }
            if (g.isEmpty()) continue
            val h = g.count { it.outcome == "hit" }
            cal.add(tv("Said " + p + "%:  happened " + h + "/" + g.size + " (" + pctFmt(h, g.size) + ")", 13f, Theme.text, mono = true), bottom = dp(4))
        }
        cal.add(tv("If you say 70%, it should happen about 70% of the time. Gaps show where your gut is off.", 12f, Theme.muted), top = dp(6))
        col.add(cal, bottom = dp(14))

        val exact = rs.count { it.bucket == GameSim.bucketOf(it.peakMult) }
        val low = rs.count { it.bucket < GameSim.bucketOf(it.peakMult) }
        val highG = rs.count { it.bucket > GameSim.bucketOf(it.peakMult) }
        val pk = card()
        pk.add(section("Peak guesses"), bottom = dp(10))
        pk.add(tv("Exact " + exact + "  \u00B7  too low " + low + "  \u00B7  too high " + highG, 13f, Theme.text, mono = true))
        col.add(pk, bottom = dp(14))

        val byTheme = rs.groupBy { it.theme }.entries.sortedByDescending { it.value.size }.take(6)
        val th = card()
        th.add(section("By name theme (auto-detected)"), bottom = dp(12))
        for ((i, e) in byTheme.withIndex()) {
            val h = e.value.count { it.outcome == "hit" }
            th.add(tv(e.key + ":  " + e.value.size + " rounds, " + num(GameStore.initX) + "x in " + pctFmt(h, e.value.size), 13f, Theme.text, mono = true),
                bottom = if (i == byTheme.size - 1) 0 else dp(6))
        }
        col.add(th, bottom = dp(14))

        val lessons = rs.filter { it.lesson.isNotEmpty() }.takeLast(5).reversed()
        if (lessons.isNotEmpty()) {
            val lc = card()
            lc.add(section("Your latest lessons"), bottom = dp(12))
            for ((i, r) in lessons.withIndex()) {
                lc.add(tv("$" + (if (r.sym.isEmpty()) "?" else r.sym), 12f, Theme.muted, bold = true, mono = true))
                lc.add(tv(r.lesson, 13f, Theme.text), top = dp(2), bottom = if (i == lessons.size - 1) 0 else dp(12))
            }
            col.add(lc, bottom = dp(14))
        }

        col.add(section("Recent rounds"), bottom = dp(10), top = dp(6), left = dp(4))
        for (r in rs.takeLast(20).reversed()) {
            val c = card()
            val l1 = hstack()
            l1.add(tv("$" + (if (r.sym.isEmpty()) "?" else r.sym), 15f, Theme.text, bold = true), w = 0, weight = 1f)
            l1.add(tv((if (r.enter) "Entered" else "Passed") + "  " + mFmt(r.simMult), 13f,
                if (r.simMult >= 1.0) Theme.profit else Theme.loss, bold = true, mono = true))
            c.add(l1)
            if (r.cat.isNotEmpty()) c.add(tv(r.cat, 12f, Theme.text), top = dp(4))
            c.add(tv("said " + r.prob + "%, guessed " + GameSim.bucketLabels[r.bucket] + ", peaked " + xFmt(r.peakMult) +
                ", " + r.outcome, 12f, Theme.muted, mono = true), top = dp(4))
            if (r.thesis.isNotEmpty()) c.add(tv(r.thesis, 13f, Theme.text), top = dp(6))
            if (r.lesson.isNotEmpty()) c.add(tv("Lesson: " + r.lesson, 12f, Theme.muted), top = dp(4))
            col.add(c, bottom = dp(12))
        }

        val clr = pill(if (clearArmed) "Tap again to delete all rounds" else "Delete all rounds", Theme.loss) {
            if (clearArmed) { GameStore.clear(); clearArmed = false; state = 0; render() }
            else { clearArmed = true; render() }
        }
        col.add(clr, top = dp(8), bottom = dp(12))
        col.add(pill("Back") { clearArmed = false; state = 0; render() })
        return col
    }

    // ======================= SETTINGS =======================
    private fun buildSettings(): View {
        val col = vstack()
        col.add(tv("Game settings", 22f, Theme.text, bold = true), bottom = dp(6))
        col.add(tv("These are your rules. Change them and the replay scores against them.", 13f, Theme.muted), bottom = dp(16))

        val fields = ArrayList<Pair<String, EditText>>()
        fun field(into: LinearLayout, key: String, label: String, value: Double, last: Boolean = false) {
            into.add(tv(label, 12f, Theme.muted), bottom = dp(6))
            val e = EditText(act).apply {
                setText(num(value))
                setTextColor(Theme.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                background = Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            fields.add(Pair(key, e))
            into.add(e, bottom = if (last) 0 else dp(14))
        }
        val g1 = card()
        g1.add(section("Entry level"), bottom = dp(12))
        field(g1, "low", "Lowest market cap ($)", GameStore.entryLow)
        field(g1, "high", "Highest market cap ($)", GameStore.entryHigh)
        field(g1, "late", "If a coin has no data in that range, accept a first point up to ($)", GameStore.lateMax, true)
        col.add(g1, bottom = dp(14))

        val g2 = card()
        g2.add(section("Exit rules"), bottom = dp(12))
        field(g2, "stop", "Stop loss (% down from entry)", GameStore.stopPct)
        field(g2, "initx", "Take initials out at (x)", GameStore.initX)
        field(g2, "trail", "Moon bag trailing stop (% down from its high)", GameStore.trailPct)
        field(g2, "slip", "Fill penalty on entry and exits (%)", GameStore.slipPct, true)
        col.add(g2, bottom = dp(14))

        val g3 = card()
        g3.add(section("Other"), bottom = dp(12))
        field(g3, "replay", "Replay length (seconds)", GameStore.replaySec)
        field(g3, "sol", "SOL price in USD (used only if it cannot be fetched)", GameStore.solUsd)
        var needX = GameStore.needX
        g3.add(tv("Hide coins with no X link", 12f, Theme.muted), bottom = dp(8))
        g3.add(chips(listOf("Yes", "No"), if (needX) 0 else 1) { needX = (it == 0) })
        col.add(g3, bottom = dp(18))

        col.add(filledPill("Save settings") {
            fun read(key: String, def: Double): Double {
                for (f in fields) if (f.first == key) return f.second.text.toString().trim().toDoubleOrNull() ?: def
                return def
            }
            val low = read("low", GameStore.entryLow)
            val high = read("high", GameStore.entryHigh)
            if (low <= 0.0 || high <= low) {
                Toast.makeText(act, "Entry level: the high must be above the low", Toast.LENGTH_LONG).show()
            } else {
                GameStore.entryLow = low
                GameStore.entryHigh = high
                GameStore.lateMax = max(high, read("late", GameStore.lateMax))
                GameStore.stopPct = read("stop", GameStore.stopPct).coerceIn(5.0, 95.0)
                GameStore.initX = max(1.2, read("initx", GameStore.initX))
                GameStore.trailPct = read("trail", GameStore.trailPct).coerceIn(5.0, 95.0)
                GameStore.slipPct = read("slip", GameStore.slipPct).coerceIn(0.0, 30.0)
                GameStore.replaySec = read("replay", GameStore.replaySec).coerceIn(3.0, 60.0)
                GameStore.solUsd = read("sol", GameStore.solUsd).coerceIn(10.0, 5000.0)
                GameStore.needX = needX
                Toast.makeText(act, "Saved", Toast.LENGTH_SHORT).show()
                state = 0
                render()
            }
        }, bottom = dp(12))
        col.add(pill("Back") { state = 0; render() })
        return col
    }
}
