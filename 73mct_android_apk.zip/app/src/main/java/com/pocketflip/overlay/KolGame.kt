package com.pocketflip.overlay

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/*
 * Training game ("Game" tab inside the KOL Tracker page).
 * Shows a coin from the KOL history at YOUR entry level, hides how it ended, and asks you to commit
 * (thesis, chance of 2x, where it peaks, enter or pass). Then it replays the real price path against
 * your own exit rules (initials out at 2x, moon bag with a trailing stop) and keeps score.
 * It only READS the KOL data. It never touches TradeRepository, DexScreenerClient or Models.
 */

/** One candle, already converted to market cap (USD). */
class GCandle(val ts: Long, val o: Double, val h: Double, val l: Double, val c: Double, val v: Double)

/** One finished round, saved so the stats can be built later. */
class GameRound(
    val ts: Long, val mint: String, val sym: String, val name: String, val theme: String,
    val entryMc: Double, val enter: Boolean, val prob: Int, val bucket: Int, val thesis: String,
    val outcome: String,          // "hit" (reached the initials target), "stop", "open"
    val peakMult: Double, val simMult: Double, val timeToHit: Long,
    val lowConf: Boolean = false   // built from the KOLs' own trades only (no chart candles)
)

class SimCfg(val stopPct: Double, val initX: Double, val trailPct: Double, val slipPct: Double)

object GameSim {
    class Result(
        val outcome: String, val entryFill: Double,
        val hitIdx: Int, val hitMc: Double,
        val exitIdx: Int, val exitMc: Double, val moonOpen: Boolean,
        val peakMc: Double, val peakIdx: Int, val drawdown: Double,
        val simMult: Double, val gapped: Boolean, val timeToHit: Long
    )

    val bucketLabels = listOf("<2x", "2-3x", "3-5x", "5-10x", "10x+")

    fun bucketOf(m: Double): Int = when {
        m < 2.0 -> 0
        m < 3.0 -> 1
        m < 5.0 -> 2
        m < 10.0 -> 3
        else -> 4
    }

    /** Replays the candles after [idx] against the exit rules. Within one candle the stop is checked first. */
    fun run(cs: List<GCandle>, idx: Int, cfg: SimCfg): Result {
        val s = cfg.slipPct / 100.0
        val entry = cs[idx].c * (1.0 + s)
        val stop = entry * (1.0 - cfg.stopPct / 100.0)
        val target = entry * cfg.initX

        var peakMc = entry
        var peakIdx = idx
        for (j in idx + 1 until cs.size) {
            if (cs[j].h > peakMc) { peakMc = cs[j].h; peakIdx = j }
        }

        var minLow = entry
        var hit = -1
        var stopIdx = -1
        var gapped = false
        var j = idx + 1
        while (j < cs.size) {
            val k = cs[j]
            if (k.o <= stop) { stopIdx = j; gapped = true; break }
            if (k.l <= stop) { stopIdx = j; break }
            if (k.l < minLow) minLow = k.l
            if (k.h >= target) { hit = j; break }
            j++
        }

        if (stopIdx >= 0) {
            val raw = if (gapped) cs[stopIdx].o else stop
            val exitMc = raw * (1.0 - s)
            return Result("stop", entry, -1, 0.0, stopIdx, exitMc, false, peakMc, peakIdx,
                cfg.stopPct / 100.0, exitMc / entry, gapped, 0L)
        }
        val dd = max(0.0, 1.0 - minLow / entry)
        if (hit < 0) {
            val last = cs[cs.size - 1].c
            return Result("open", entry, -1, 0.0, cs.size - 1, last, true, peakMc, peakIdx,
                dd, last * (1.0 - s) / entry, false, 0L)
        }

        // initials are out at the target; the rest is the moon bag with a trailing stop
        val remaining = 1.0 - 1.0 / cfg.initX
        var runningHigh = cs[hit].h
        var exitIdx = -1
        var exitMc = 0.0
        var k2 = hit + 1
        while (k2 < cs.size) {
            val k = cs[k2]
            val level = runningHigh * (1.0 - cfg.trailPct / 100.0)
            if (k.o <= level) { exitIdx = k2; exitMc = k.o; break }
            if (k.l <= level) { exitIdx = k2; exitMc = level; break }
            if (k.h > runningHigh) runningHigh = k.h
            k2++
        }
        var moonOpen = false
        if (exitIdx < 0) {
            exitIdx = cs.size - 1
            exitMc = cs[cs.size - 1].c
            moonOpen = true
        }
        val moonMult = exitMc * (1.0 - s) / entry
        val total = (1.0 - s) + remaining * moonMult
        return Result("hit", entry, hit, target, exitIdx, exitMc, moonOpen, peakMc, peakIdx,
            dd, total, false, cs[hit].ts - cs[idx].ts)
    }
}

/** Settings and saved rounds of the game. Separate from the trading journal. */
object GameStore {
    private var prefs: SharedPreferences? = null
    private var file: File? = null
    private val lock = Any()
    val rounds = ArrayList<GameRound>()

    fun init(context: Context) {
        synchronized(lock) {
            if (prefs != null) return
            val ctx = context.applicationContext
            prefs = ctx.getSharedPreferences("game_prefs", Context.MODE_PRIVATE)
            file = File(ctx.filesDir, "game_rounds.json")
            load()
        }
    }

    private fun d(key: String, def: Double): Double =
        (prefs?.getString(key, def.toString()) ?: def.toString()).toDoubleOrNull() ?: def

    private fun put(key: String, v: Double) {
        prefs?.edit()?.putString(key, v.toString())?.apply()
    }

    var entryLow: Double
        get() = d("entry_low", 20000.0)
        set(v) { put("entry_low", v) }
    var entryHigh: Double
        get() = d("entry_high", 40000.0)
        set(v) { put("entry_high", v) }
    var lateMax: Double
        get() = d("late_max2", 500000.0)
        set(v) { put("late_max2", v) }
    var solUsd: Double
        get() = d("sol_usd", 150.0)
        set(v) { put("sol_usd", v) }
    var stopPct: Double
        get() = d("stop_pct", 50.0)
        set(v) { put("stop_pct", v) }
    var initX: Double
        get() = d("init_x", 2.0)
        set(v) { put("init_x", v) }
    var trailPct: Double
        get() = d("trail_pct", 50.0)
        set(v) { put("trail_pct", v) }
    var slipPct: Double
        get() = d("slip_pct", 3.0)
        set(v) { put("slip_pct", v) }
    var replaySec: Double
        get() = d("replay_sec", 10.0)
        set(v) { put("replay_sec", v) }
    var needX: Boolean
        get() = prefs?.getBoolean("need_x", true) ?: true
        set(v) { prefs?.edit()?.putBoolean("need_x", v)?.apply() }

    fun cfg(): SimCfg = SimCfg(stopPct, initX, trailPct, slipPct)

    fun playedMints(): Set<String> {
        synchronized(lock) { return rounds.map { it.mint }.toSet() }
    }

    private fun load() {
        rounds.clear()
        try {
            val f = file ?: return
            if (!f.exists()) return
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                rounds.add(GameRound(
                    o.optLong("ts"), o.optString("mint"), o.optString("sym"), o.optString("name"),
                    o.optString("theme"), o.optDouble("entry", 0.0), o.optBoolean("enter", true),
                    o.optInt("prob", 50), o.optInt("bucket", 0), o.optString("thesis"),
                    o.optString("outcome", "open"), o.optDouble("peak", 0.0), o.optDouble("sim", 0.0),
                    o.optLong("t2x", 0L), o.optBoolean("low", false)
                ))
            }
        } catch (_: Throwable) {
        }
    }

    private fun save() {
        try {
            val arr = JSONArray()
            for (r in rounds) {
                val o = JSONObject()
                o.put("ts", r.ts); o.put("mint", r.mint); o.put("sym", r.sym); o.put("name", r.name)
                o.put("theme", r.theme); o.put("entry", r.entryMc); o.put("enter", r.enter)
                o.put("prob", r.prob); o.put("bucket", r.bucket); o.put("thesis", r.thesis)
                o.put("outcome", r.outcome); o.put("peak", r.peakMult); o.put("sim", r.simMult)
                o.put("t2x", r.timeToHit); o.put("low", r.lowConf)
                arr.put(o)
            }
            file?.writeText(arr.toString())
        } catch (_: Throwable) {
        }
    }

    fun add(r: GameRound) {
        synchronized(lock) { rounds.add(r); save() }
    }

    fun clear() {
        synchronized(lock) { rounds.clear(); save() }
    }
}

/** Candle download for the game (GeckoTerminal, free). Minute candles around the first KOL buy, then hourly after. */
object GameData {
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun get(url: String): Pair<Int, String> {
        return try {
            val req = Request.Builder().url(url).header("Accept", "application/json").build()
            http.newCall(req).execute().use { r -> Pair(r.code, r.body?.string() ?: "") }
        } catch (_: Throwable) {
            Pair(-1, "")
        }
    }

    private fun getRetry(url: String): Pair<Int, String> {
        var r = get(url)
        if (r.first == 429) {
            try { Thread.sleep(6000L) } catch (_: InterruptedException) {}
            r = get(url)
        }
        return r
    }

    private fun parse(body: String, k: Double): List<GCandle> {
        val out = ArrayList<GCandle>()
        try {
            val list = JSONObject(body).getJSONObject("data").getJSONObject("attributes").getJSONArray("ohlcv_list")
            for (i in 0 until list.length()) {
                val c = list.getJSONArray(i)
                val close = c.getDouble(4) * k
                if (close <= 0.0) continue
                out.add(GCandle(c.getLong(0), c.getDouble(1) * k, c.getDouble(2) * k,
                    c.getDouble(3) * k, close, c.optDouble(5, 0.0)))
            }
        } catch (_: Throwable) {
        }
        out.sortBy { it.ts }
        return out
    }

    @Volatile private var solCache = 0.0
    @Volatile private var solCacheAt = 0L

    /** Current SOL price in USD (DexScreener, free). Falls back to the value in Game settings. */
    fun solUsd(fallback: Double): Double {
        val now = System.currentTimeMillis()
        if (solCache > 0.0 && now - solCacheAt < 3600_000L) return solCache
        val wsol = "So11111111111111111111111111111111111111112"
        val r = get("https://api.dexscreener.com/tokens/v1/solana/" + wsol)
        if (r.first == 200) {
            try {
                val arr = JSONArray(r.second)
                for (i in 0 until arr.length()) {
                    val p = arr.getJSONObject(i)
                    val base = p.optJSONObject("baseToken")?.optString("address") ?: ""
                    val q = p.optJSONObject("quoteToken")?.optString("symbol") ?: ""
                    val px = p.optString("priceUsd", "0").toDoubleOrNull() ?: 0.0
                    if (base == wsol && (q == "USDC" || q == "USDT") && px > 1.0) {
                        solCache = px; solCacheAt = now
                        return px
                    }
                }
            } catch (_: Throwable) {
            }
        }
        return if (solCache > 0.0) solCache else fallback
    }

    /**
     * For coins with no chart data: a rough price path made only from what the tracked KOLs paid and received.
     * Market cap = price in SOL x 1 billion supply (pump.fun coins) x SOL price. It is sparse and a lower bound.
     */
    fun fromFills(coin: KolCoin, solUsd: Double): List<GCandle> {
        val fl = ArrayList<KolFill>()
        for (p in coin.positions) for (f in p.fills) if (f.sol > 0.0 && f.tok > 0.0) fl.add(f)
        fl.sortBy { it.ts }
        val out = ArrayList<GCandle>()
        for (f in fl) {
            val mc = f.sol / f.tok * 1e9 * solUsd
            if (mc <= 0.0) continue
            out.add(GCandle(f.ts, mc, mc, mc, mc, f.sol * solUsd))
        }
        return out
    }

    fun fetch(tok: KolToken, firstFillSec: Long): List<GCandle> {
        if (tok.pair.isEmpty() || tok.priceUsd <= 0.0 || tok.mc <= 0.0) return emptyList()
        val k = tok.mc / tok.priceUsd
        val nowSec = System.currentTimeMillis() / 1000L
        val before = min(nowSec, firstFillSec + 600L * 60L) + 1L
        val r = getRetry("https://api.geckoterminal.com/api/v2/networks/solana/pools/" + tok.pair +
            "/ohlcv/minute?aggregate=1&before_timestamp=" + before + "&limit=1000&currency=usd")
        if (r.first != 200) return emptyList()
        val a = parse(r.second, k)
        if (a.isEmpty()) return a
        val out = ArrayList<GCandle>(a)
        val lastTs = a[a.size - 1].ts
        if (nowSec - lastTs > 2 * 3600L) {
            try { Thread.sleep(2200L) } catch (_: InterruptedException) {}
            val end = min(nowSec, lastTs + 14L * 86400L) + 1L
            val r2 = getRetry("https://api.geckoterminal.com/api/v2/networks/solana/pools/" + tok.pair +
                "/ohlcv/hour?aggregate=1&before_timestamp=" + end + "&limit=336&currency=usd")
            if (r2.first == 200) {
                for (c in parse(r2.second, k)) if (c.ts > lastTs) out.add(c)
            }
        }
        return out
    }
}

class KolGame(private val act: Activity) {

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }

    private class Cur(val coin: KolCoin, val cs: List<GCandle>, val idx: Int, val xUrl: String, val earliest: Boolean, val lowConf: Boolean)

    // 0 home, 1 loading, 2 round, 3 reveal, 4 stats, 5 settings
    private var state = 0
    private var pool: List<KolCoin> = emptyList()
    private var cur: Cur? = null
    private var thesisText = ""
    private var thesisField: EditText? = null
    private var probIdx = 2
    private var peakIdx = 1
    private val probs = listOf(10, 30, 50, 70, 90)
    private var lastSim: GameSim.Result? = null
    private var lastRound: GameRound? = null
    private var message = ""
    private var loadingText: TextView? = null
    private val skipReasons = LinkedHashMap<String, Int>()
    private var anim: ValueAnimator? = null
    private var clearArmed = false
    private var token = 0

    init {
        GameStore.init(act)
    }

    fun view(): View = root

    /** Called by KolScreen every time the Game tab is shown. */
    fun open(coins: List<KolCoin>) {
        pool = coins
        thesisField?.let { thesisText = it.text.toString() }
        if (state == 1) { render(); return }
        if (state != 2 && state != 3) state = 0
        render()
    }

    fun destroy() {
        anim?.cancel()
        token++
    }

    // ---------- tiny UI helpers ----------
    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), act.resources.displayMetrics
    ).toInt()

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView =
        TextView(act).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun vstack() = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private fun hstack() = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun LinearLayout.add(
        v: View, top: Int = 0, bottom: Int = 0, left: Int = 0, right: Int = 0,
        w: Int = LinearLayout.LayoutParams.MATCH_PARENT,
        h: Int = LinearLayout.LayoutParams.WRAP_CONTENT, weight: Float = 0f
    ) {
        val p = if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
        p.topMargin = top; p.bottomMargin = bottom; p.leftMargin = left; p.rightMargin = right
        addView(v, p)
    }

    private fun card(): LinearLayout = vstack().apply {
        background = Theme.box(Theme.card, Theme.border, dp(18), dp(1))
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun pill(label: String, color: Int = Theme.text, onClick: () -> Unit): TextView =
        tv(label, 12f, color, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.box(Theme.bg, Theme.border, dp(14), dp(1))
            setOnClickListener { onClick() }
        }

    private fun filledPill(label: String, onClick: () -> Unit): TextView =
        tv(label, 13f, Theme.onColor(Theme.text), bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = Theme.box(Theme.text, Theme.text, dp(14), 0)
            setOnClickListener { onClick() }
        }

    /** Chip row that restyles itself when tapped, so typed text elsewhere on the page is never lost. */
    private fun chips(labels: List<String>, start: Int, onPick: (Int) -> Unit): View {
        val sv = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false }
        val row = hstack()
        val views = ArrayList<TextView>()
        fun style(sel: Int) {
            for ((i, t) in views.withIndex()) {
                val on = i == sel
                t.setTextColor(if (on) Theme.onColor(Theme.text) else Theme.text)
                t.background = if (on) Theme.box(Theme.text, Theme.text, dp(12), 0)
                else Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
            }
        }
        for ((i, l) in labels.withIndex()) {
            val chip = tv(l, 12f, Theme.text, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { style(i); onPick(i) }
            }
            views.add(chip)
            row.add(chip, right = dp(6), w = LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        style(start)
        sv.addView(row)
        return sv
    }

    private fun stat(label: String, value: String, color: Int = Theme.text): LinearLayout {
        val v = vstack()
        v.add(tv(label, 10f, Theme.muted))
        v.add(tv(value, 14f, color, bold = true, mono = true), top = dp(2))
        return v
    }

    private fun coinImage(tok: KolToken, size: Int): ImageView {
        val iv = ImageView(act)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Theme.circle(Theme.card, Theme.border, dp(1))
        iv.outlineProvider = ViewOutlineProvider.BACKGROUND
        iv.clipToOutline = true
        iv.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        CoinImages.bind(iv, tok.mint, if (tok.sym.isEmpty()) "?" else tok.sym, tok.img)
        return iv
    }

    private fun xFmt(v: Double) = String.format("%.1fx", v)
    private fun mFmt(v: Double) = String.format("%.2fx", v)
    private fun pctFmt(a: Int, b: Int) = if (b <= 0) "-" else String.format("%d%%", Math.round(a * 100.0 / b).toInt())
    private fun num(v: Double): String = if (v == Math.floor(v) && Math.abs(v) < 1e12) v.toLong().toString() else v.toString()
    private fun empty(text: String): View = card().apply { add(tv(text, 13f, Theme.muted)) }
    private fun symOf(t: KolToken) = "$" + (if (t.sym.isEmpty()) "?" else t.sym)

    private fun openUrl(u: String) {
        try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Throwable) {}
    }

    // ---------- rendering ----------
    private fun render() {
        anim?.cancel()
        thesisField = null
        loadingText = null
        root.removeAllViews()
        val v: View = when (state) {
            1 -> buildLoading()
            2 -> { val c = cur; if (c == null) buildHome() else buildRound(c) }
            3 -> { val c = cur; val s = lastSim; val r = lastRound
                if (c == null || s == null || r == null) buildHome() else buildReveal(c, s, r) }
            4 -> buildStats()
            5 -> buildSettings()
            else -> buildHome()
        }
        root.addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun poolOk(c: KolCoin): Boolean = c.tok.pair.isNotEmpty() && c.tok.priceUsd > 0.0 && c.tok.mc > 0.0

    /** Dead pump.fun coins can still be played from the KOLs' own trades, if there are enough of them. */
    private fun fallbackOk(c: KolCoin): Boolean {
        if (!c.tok.mint.endsWith("pump")) return false
        var n = 0
        for (p in c.positions) n += p.fills.size
        return n >= 6
    }

    private fun usableCount(): Int = pool.count { poolOk(it) || fallbackOk(it) }

    // ======================= HOME =======================
    private fun buildHome(): View {
        val col = vstack()
        val intro = card()
        intro.add(tv("Training game", 18f, Theme.text, bold = true))
        intro.add(tv("You see a real coin at your entry level. The app does not tell you if it ran or died. " +
            "Write your thesis, say how likely a " + num(GameStore.initX) + "x is, guess where it peaks, then choose Enter or Pass. " +
            "After that it replays what really happened against your own exit rules.", 12f, Theme.muted), top = dp(6))
        col.add(intro, bottom = dp(10))

        val rs = GameStore.rounds
        val st = card()
        val r1 = hstack()
        r1.add(stat("Rounds", rs.size.toString()), w = 0, weight = 1f)
        r1.add(stat(num(GameStore.initX) + "x rate", pctFmt(rs.count { it.outcome == "hit" }, rs.size)), w = 0, weight = 1f)
        r1.add(stat("Coins ready", usableCount().toString()), w = 0, weight = 1f)
        st.add(r1)
        val withChart = pool.count { poolOk(it) }
        st.add(tv("In your KOL data: " + pool.size + " coins. With a live pool and chart: " + withChart +
            ". Trades-only (dead pump.fun coins): " + pool.count { !poolOk(it) && fallbackOk(it) } + ".", 10f, Theme.muted), top = dp(8))
        col.add(st, bottom = dp(10))

        if (usableCount() == 0) {
            col.add(empty("No usable coins yet. Open the Wallets tab, add KOL wallets and scan them. " +
                "A coin needs a live pool, or at least 6 KOL trades on a pump.fun coin."), bottom = dp(10))
        }
        if (message.isNotEmpty()) {
            col.add(empty(message), bottom = dp(10))
        }
        col.add(filledPill("Start a round") { nextRound() }, bottom = dp(8))
        val row = hstack()
        row.add(pill("My stats") { state = 4; render() }, w = 0, weight = 1f, right = dp(8))
        row.add(pill("Game settings") { state = 5; render() }, w = 0, weight = 1f)
        col.add(row, bottom = dp(8))
        col.add(tv("Entry level: " + KolEngine.money(GameStore.entryLow) + " to " + KolEngine.money(GameStore.entryHigh) +
            "  |  stop -" + num(GameStore.stopPct) + "%  |  initials at " + num(GameStore.initX) + "x  |  moon bag trail " +
            num(GameStore.trailPct) + "%", 10f, Theme.muted, mono = true))
        return col
    }

    // ======================= LOADING / PICKING =======================
    private fun buildLoading(): View {
        val c = card()
        c.add(tv("Finding a coin at your entry level...", 15f, Theme.text, bold = true))
        val t = tv(skipSummary(), 11f, Theme.muted)
        loadingText = t
        c.add(t, top = dp(8))
        c.add(tv("Each round downloads real candles, so it can take 10 to 40 seconds.", 11f, Theme.muted), top = dp(6))
        return c
    }

    private fun skipSummary(): String {
        if (skipReasons.isEmpty()) return "Starting..."
        return "Skipped so far: " + skipReasons.entries.joinToString(", ") { it.value.toString() + " " + it.key }
    }

    private fun pickCoin(exclude: Set<String>): KolCoin? {
        val played = GameStore.playedMints()
        val usable = pool.filter { (poolOk(it) || fallbackOk(it)) && !exclude.contains(it.tok.mint) }
        if (usable.isEmpty()) return null
        val fresh = usable.filter { !played.contains(it.tok.mint) }
        val src = if (fresh.isNotEmpty()) fresh else usable
        // mix runners, middle coins and flops so the answer cannot be guessed from the group
        val hi = src.filter { it.peak >= 1_000_000.0 }
        val mid = src.filter { it.peak >= 200_000.0 && it.peak < 1_000_000.0 }
        val lo = src.filter { it.peak < 200_000.0 }
        val groups = listOf(hi, mid, lo).filter { it.isNotEmpty() }
        return groups.random().random()
    }

    private fun noteSkip(reason: String) {
        skipReasons[reason] = (skipReasons[reason] ?: 0) + 1
        val t = skipSummary()
        main.post { loadingText?.text = t }
    }

    private fun pickIndex(cs: List<GCandle>): Int {
        val lo = GameStore.entryLow
        val hi = GameStore.entryHigh
        for (i in cs.indices) {
            if (cs[i].c >= lo && cs[i].c <= hi) return i
        }
        if (cs[0].c <= GameStore.lateMax) return 0
        return -1
    }

    private fun awaitX(mint: String): String {
        val latch = CountDownLatch(1)
        val box = arrayOf("")
        CoinLinkFinder.find(mint, true) { l -> box[0] = l.x; latch.countDown() }
        try { latch.await(10, TimeUnit.SECONDS) } catch (_: InterruptedException) {}
        return box[0]
    }

    private fun nextRound() {
        if (usableCount() == 0) { message = "No usable coins yet. Scan some KOL wallets first."; state = 0; render(); return }
        message = ""
        state = 1
        skipReasons.clear()
        token++
        val my = token
        render()
        io.execute {
            val exclude = HashSet<String>()
            var tries = 0
            while (tries < 14 && my == token) {
                val c = pickCoin(exclude) ?: break
                tries++
                exclude.add(c.tok.mint)
                val first = c.positions.minOf { p -> p.fills.minOf { f -> f.ts } }
                var cs: List<GCandle> = emptyList()
                var idx = -1
                var low = false
                if (poolOk(c)) {
                    val got = GameData.fetch(c.tok, first)
                    if (got.size < 40) noteSkip("no chart data")
                    else {
                        val i = pickIndex(got)
                        if (i < 0) noteSkip("started too high")
                        else if (got.size - i < 30) noteSkip("too little history")
                        else { cs = got; idx = i }
                    }
                }
                if (idx < 0 && fallbackOk(c)) {
                    val fc = GameData.fromFills(c, GameData.solUsd(GameStore.solUsd))
                    val i = if (fc.isEmpty()) -1 else pickIndex(fc)
                    if (fc.size >= 6 && i >= 0 && fc.size - i >= 4) { cs = fc; idx = i; low = true }
                    else noteSkip("trades too thin")
                }
                if (idx < 0) continue
                var x = ""
                if (GameStore.needX) {
                    x = awaitX(c.tok.mint)
                    if (x.isEmpty()) { noteSkip("no X link"); continue }
                }
                val earliest = !(cs[idx].c >= GameStore.entryLow && cs[idx].c <= GameStore.entryHigh)
                val found = Cur(c, cs, idx, x, earliest, low)
                main.post {
                    if (my != token) return@post
                    cur = found
                    thesisText = ""
                    probIdx = 2
                    peakIdx = 1
                    state = 2
                    render()
                }
                return@execute
            }
            main.post {
                if (my != token) return@post
                message = "Could not find a usable coin this time. " + skipSummary() + ". Try again, or widen the entry level in Game settings."
                state = 0
                render()
            }
        }
    }

    // ======================= ROUND =======================
    private fun buildRound(c: Cur): View {
        val col = vstack()
        val tok = c.coin.tok
        val head = hstack()
        head.add(coinImage(tok, 56), right = dp(12), w = dp(56), h = dp(56))
        val hv = vstack()
        hv.add(tv(symOf(tok), 20f, Theme.text, bold = true))
        hv.add(tv(tok.name, 12f, Theme.muted))
        head.add(hv, w = 0, weight = 1f)
        head.add(tv("Round " + (GameStore.rounds.size + 1), 11f, Theme.muted, mono = true))
        col.add(head, bottom = dp(10))

        val now = c.cs[c.idx]
        var vol = 0.0
        if (c.lowConf) {
            for (i in 0..c.idx) if (c.cs[i].ts >= now.ts - 900L) vol += c.cs[i].v
        } else {
            for (i in max(0, c.idx - 14)..c.idx) vol += c.cs[i].v
        }
        val st = card()
        val r1 = hstack()
        r1.add(stat("Market cap now", KolEngine.money(now.c)), w = 0, weight = 1f)
        r1.add(stat("Volume 15m", KolEngine.money(vol)), w = 0, weight = 1f)
        if (c.lowConf) r1.add(stat("KOL trades so far", (c.idx + 1).toString()), w = 0, weight = 1f)
        else r1.add(stat("Chart history", KolEngine.dur(now.ts - c.cs[0].ts)), w = 0, weight = 1f)
        st.add(r1)
        col.add(st, bottom = dp(10))

        val chart = KolChart(act)
        val from = max(0, c.idx - 120)
        val pts = ArrayList<Pair<Long, Double>>()
        for (i in from..c.idx) pts.add(Pair(c.cs[i].ts, c.cs[i].c))
        chart.pts = pts
        chart.marks = listOf(KolChart.Mark(now.ts, now.c, true, "E", Theme.text))
        chart.progress = 1f
        col.add(chart, h = dp(220), bottom = dp(6))
        if (c.lowConf) {
            col.add(tv("No chart data for this coin (it is dead or its pool is gone). This chart is built only from what the KOLs paid, so it is sparse and the real path had more ups and downs.",
                10f, Theme.muted), bottom = dp(8))
        }
        if (c.earliest) {
            col.add(tv("Earliest data available for this coin. Its first minutes are not on this chart, so it already looks older than it was.",
                10f, Theme.muted), bottom = dp(8))
        }

        val links = hstack()
        if (c.xUrl.isNotEmpty()) {
            links.add(pill("Open X") { openUrl(c.xUrl) }, w = 0, weight = 1f, right = dp(8))
        }
        links.add(pill("Copy CA") {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("CA", tok.mint))
            Toast.makeText(act, "CA copied", Toast.LENGTH_SHORT).show()
        }, w = 0, weight = 1f)
        col.add(links, bottom = dp(12))

        val th = EditText(act).apply {
            hint = "Your thesis: why would people care about this coin?"
            setHintTextColor(Theme.muted)
            setTextColor(Theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = Theme.box(Theme.bg, Theme.border, dp(14), dp(1))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setText(thesisText)
        }
        thesisField = th
        col.add(th, bottom = dp(12))

        col.add(tv("Chance it reaches " + num(GameStore.initX) + "x before -" + num(GameStore.stopPct) + "%", 12f, Theme.text, bold = true), bottom = dp(6))
        col.add(chips(probs.map { it.toString() + "%" }, probIdx) { probIdx = it }, bottom = dp(12))
        col.add(tv("Where does it peak, from this entry?", 12f, Theme.text, bold = true), bottom = dp(6))
        col.add(chips(GameSim.bucketLabels, peakIdx) { peakIdx = it }, bottom = dp(14))

        val row = hstack()
        row.add(filledPill("Enter (paper)") { commit(true) }, w = 0, weight = 1f, right = dp(8))
        row.add(pill("Pass") { commit(false) }, w = 0, weight = 1f)
        col.add(row, bottom = dp(8))
        col.add(pill("Skip this coin (not scored)") { nextRound() }, bottom = dp(8))
        col.add(pill("Back to menu") { token++; state = 0; render() })
        return col
    }

    private fun commit(enter: Boolean) {
        val c = cur ?: return
        thesisField?.let { thesisText = it.text.toString().trim() }
        val sim = GameSim.run(c.cs, c.idx, GameStore.cfg())
        val round = GameRound(
            System.currentTimeMillis(), c.coin.tok.mint, c.coin.tok.sym, c.coin.tok.name,
            KolEngine.themeOf(c.coin.tok), sim.entryFill, enter, probs[probIdx], peakIdx, thesisText,
            sim.outcome, sim.peakMc / sim.entryFill, sim.simMult, sim.timeToHit, c.lowConf
        )
        GameStore.add(round)
        lastSim = sim
        lastRound = round
        state = 3
        render()
        try { root.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) } catch (_: Throwable) {}
    }

    // ======================= REVEAL =======================
    private fun buildReveal(c: Cur, s: GameSim.Result, r: GameRound): View {
        val col = vstack()
        val tok = c.coin.tok
        val cfg = GameStore.cfg()
        val head = hstack()
        head.add(coinImage(tok, 48), right = dp(12), w = dp(48), h = dp(48))
        val hv = vstack()
        hv.add(tv(symOf(tok), 18f, Theme.text, bold = true))
        hv.add(tv(tok.name, 12f, Theme.muted))
        head.add(hv, w = 0, weight = 1f)
        col.add(head, bottom = dp(10))

        // result
        val res = card()
        val good = s.simMult >= 1.0
        val big = tv(mFmt(s.simMult), 34f, Theme.pnlColor(if (good) 1.0 else -1.0), bold = true, mono = true)
        big.alpha = 0f; big.scaleX = 0.8f; big.scaleY = 0.8f
        big.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(380L).start()
        if (r.enter) {
            res.add(tv("Your paper result (money in = 1.00x)", 11f, Theme.muted))
            res.add(big, top = dp(2))
        } else {
            res.add(tv("You passed. If you had entered:", 11f, Theme.muted))
            res.add(big, top = dp(2))
        }
        val line = when (s.outcome) {
            "hit" -> "Reached " + num(cfg.initX) + "x in " + KolEngine.dur(s.timeToHit) + " (initials out). Moon bag " +
                (if (s.moonOpen) "still open at the end of the data, " else "stopped out at ") +
                KolEngine.money(s.exitMc) + " = " + xFmt(s.exitMc / s.entryFill) + " from entry."
            "stop" -> "Fell to your -" + num(cfg.stopPct) + "% stop before reaching " + num(cfg.initX) + "x." +
                (if (s.gapped) " Price gapped through the stop, so the exit was worse than the stop." else "")
            else -> "Neither " + num(cfg.initX) + "x nor your stop happened in the data window. Marked at the last price."
        }
        res.add(tv(line, 12f, Theme.text), top = dp(6))
        col.add(res, bottom = dp(10))

        // chart + replay
        val chart = KolChart(act)
        val from = max(0, c.idx - 60)
        val raw = ArrayList<Pair<Long, Double>>()
        for (i in from until c.cs.size) raw.add(Pair(c.cs[i].ts, c.cs[i].c))
        val step = max(1, raw.size / 900)
        val pts = ArrayList<Pair<Long, Double>>()
        for (i in raw.indices) if (i % step == 0 || i == raw.size - 1) pts.add(raw[i])
        chart.pts = pts
        val marks = ArrayList<KolChart.Mark>()
        marks.add(KolChart.Mark(c.cs[c.idx].ts, s.entryFill, true, "E", Theme.text))
        if (s.hitIdx >= 0) marks.add(KolChart.Mark(c.cs[s.hitIdx].ts, s.hitMc, false, num(cfg.initX) + "x", Theme.profit))
        if (s.outcome == "stop") marks.add(KolChart.Mark(c.cs[s.exitIdx].ts, s.exitMc, false, "S", Theme.loss))
        if (s.outcome == "hit" && !s.moonOpen) marks.add(KolChart.Mark(c.cs[s.exitIdx].ts, s.exitMc, false, "M", Theme.profit))
        chart.marks = marks
        chart.progress = 0f
        col.add(chart, h = dp(250), bottom = dp(6))
        val clock = tv("Replay", 11f, Theme.muted, mono = true)
        col.add(clock, bottom = dp(6))
        val rb = hstack()
        rb.add(pill("Replay") { playReplay(chart, clock, c.cs[c.idx].ts) }, w = 0, weight = 1f, right = dp(8))
        rb.add(pill("Show full") { anim?.cancel(); chart.progress = 1f; chart.invalidate(); clock.text = "Full path" }, w = 0, weight = 1f)
        col.add(rb, bottom = dp(10))
        main.post { playReplay(chart, clock, c.cs[c.idx].ts) }

        // what happened
        val wh = card()
        wh.add(tv("What really happened", 14f, Theme.text, bold = true), bottom = dp(8))
        val a = hstack()
        a.add(stat("Entry", KolEngine.money(s.entryFill)), w = 0, weight = 1f)
        a.add(stat("Peak after", KolEngine.money(s.peakMc)), w = 0, weight = 1f)
        a.add(stat("Peak x", xFmt(s.peakMc / s.entryFill)), w = 0, weight = 1f)
        wh.add(a, bottom = dp(8))
        val b = hstack()
        b.add(stat("Time to peak", KolEngine.dur(c.cs[s.peakIdx].ts - c.cs[c.idx].ts)), w = 0, weight = 1f)
        b.add(stat("Worst dip", String.format("-%d%%", Math.round(s.drawdown * 100.0).toInt()), Theme.loss), w = 0, weight = 1f)
        b.add(stat("Fills", "-" + num(cfg.slipPct) + "% each side"), w = 0, weight = 1f)
        wh.add(b)
        col.add(wh, bottom = dp(10))

        // your call
        val yc = card()
        yc.add(tv("Your call", 14f, Theme.text, bold = true), bottom = dp(6))
        val hitIt = s.outcome == "hit"
        yc.add(tv("You said " + r.prob + "% for " + num(cfg.initX) + "x before the stop. It " + (if (hitIt) "did." else "did not."), 12f, Theme.text))
        val actualB = GameSim.bucketOf(s.peakMc / s.entryFill)
        val verdict = if (r.bucket == actualB) "Exact." else if (r.bucket < actualB) "You guessed too low." else "You guessed too high."
        yc.add(tv("Peak guess " + GameSim.bucketLabels[r.bucket] + ", actual " + GameSim.bucketLabels[actualB] + ". " + verdict, 12f, Theme.text), top = dp(4))
        if (r.thesis.isNotEmpty()) {
            yc.add(tv("Your thesis:", 11f, Theme.muted), top = dp(8))
            yc.add(tv(r.thesis, 12f, Theme.text), top = dp(2))
        }
        col.add(yc, bottom = dp(10))

        // the KOLs (kept hidden until now)
        val kc = card()
        kc.add(tv("The KOLs on this coin", 14f, Theme.text, bold = true), bottom = dp(6))
        val first = c.coin.positions.first()
        kc.add(tv(c.coin.kolCount.toString() + " tracked KOL(s). First in: " + first.wallet.label + " at " +
            KolEngine.money(first.entryMc) + ", result " + xFmt(first.multiple) + ".", 12f, Theme.text))
        kc.add(tv("Coin now: " + KolEngine.money(tok.mc) + ", peak seen " + KolEngine.money(c.coin.peak) + ".", 11f, Theme.muted), top = dp(4))
        col.add(kc, bottom = dp(10))

        if (c.lowConf) {
            col.add(tv("Low-confidence round: built from the KOLs' own trades only. The real peak was probably higher and dips between trades are not shown, so treat this result as a rough lower bound.",
                10f, Theme.muted), bottom = dp(8))
        }
        val note = "Notes: stops are checked before targets inside one candle. After the first hours the data is hourly, " +
            "so fast moves inside an hour are approximated. Real fills would be worse on some coins."
        col.add(tv(note, 10f, Theme.muted), bottom = dp(10))

        col.add(filledPill("Next round") { nextRound() }, bottom = dp(8))
        val rw = hstack()
        rw.add(pill("Dex chart") {
            openUrl(if (tok.pair.isNotEmpty()) "https://dexscreener.com/solana/" + tok.pair else "https://dexscreener.com/solana/" + tok.mint)
        }, w = 0, weight = 1f, right = dp(8))
        rw.add(pill("My stats") { state = 4; render() }, w = 0, weight = 1f, right = dp(8))
        rw.add(pill("Menu") { state = 0; render() }, w = 0, weight = 1f)
        col.add(rw)
        return col
    }

    private fun playReplay(chart: KolChart, clock: TextView, entryTs: Long) {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = (GameStore.replaySec * 1000.0).toLong().coerceIn(3000L, 60000L)
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            val v = it.animatedValue as Float
            chart.progress = v
            chart.invalidate()
            val t = chart.timeAt(v) - entryTs
            clock.text = "Replay  " + (if (t < 0) "-" else "+") + KolEngine.dur(Math.abs(t)) + " from your entry"
        }
        anim = a
        a.start()
    }

    // ======================= STATS =======================
    private fun buildStats(): View {
        val col = vstack()
        col.add(tv("Your training stats", 18f, Theme.text, bold = true), bottom = dp(10))
        val rs = GameStore.rounds
        if (rs.isEmpty()) {
            col.add(empty("No rounds yet. Play a few and this page fills up."), bottom = dp(10))
            col.add(pill("Back") { state = 0; render() })
            return col
        }
        val n = rs.size
        val hits = rs.count { it.outcome == "hit" }
        val entered = rs.filter { it.enter }
        val passed = rs.filter { !it.enter }
        val net = entered.sumOf { it.simMult - 1.0 }
        val avg = if (entered.isEmpty()) 0.0 else entered.sumOf { it.simMult } / entered.size

        val ov = card()
        ov.add(tv("Overview", 14f, Theme.text, bold = true), bottom = dp(8))
        val a = hstack()
        a.add(stat("Rounds", n.toString()), w = 0, weight = 1f)
        a.add(stat(num(GameStore.initX) + "x base rate", pctFmt(hits, n)), w = 0, weight = 1f)
        a.add(stat("Entered", entered.size.toString()), w = 0, weight = 1f)
        ov.add(a, bottom = dp(8))
        val b = hstack()
        b.add(stat("Avg result", if (entered.isEmpty()) "-" else mFmt(avg), if (avg >= 1.0) Theme.profit else Theme.loss), w = 0, weight = 1f)
        b.add(stat("Net (1 unit each)", if (entered.isEmpty()) "-" else String.format("%+.1f", net), Theme.pnlColor(net)), w = 0, weight = 1f)
        b.add(stat("Passed", passed.size.toString()), w = 0, weight = 1f)
        ov.add(b, bottom = dp(8))
        val missed = passed.count { it.outcome == "hit" }
        val dodged = passed.count { it.outcome == "stop" }
        ov.add(tv("Passes: " + missed + " would have hit " + num(GameStore.initX) + "x (missed), " + dodged + " would have stopped out (dodged).", 11f, Theme.muted))
        val lowN = rs.count { it.lowConf }
        if (lowN > 0) {
            ov.add(tv(lowN.toString() + " of these rounds were low-confidence (trades-only, no candles).", 11f, Theme.muted), top = dp(6))
        }
        if (n < 100) {
            ov.add(tv("Only " + n + " of about 100 rounds. Under that, these percentages are mostly noise.", 11f, Theme.muted), top = dp(6))
        }
        col.add(ov, bottom = dp(10))

        val cal = card()
        cal.add(tv("Calibration: what you said vs what happened", 14f, Theme.text, bold = true), bottom = dp(8))
        for (p in probs) {
            val g = rs.filter { it.prob == p }
            if (g.isEmpty()) continue
            val h = g.count { it.outcome == "hit" }
            cal.add(tv("Said " + p + "%:  happened " + h + "/" + g.size + " (" + pctFmt(h, g.size) + ")", 12f, Theme.text, mono = true), bottom = dp(3))
        }
        cal.add(tv("If you say 70%, it should happen about 70% of the time. Gaps show where your gut is off.", 10f, Theme.muted), top = dp(4))
        col.add(cal, bottom = dp(10))

        val exact = rs.count { it.bucket == GameSim.bucketOf(it.peakMult) }
        val low = rs.count { it.bucket < GameSim.bucketOf(it.peakMult) }
        val highG = rs.count { it.bucket > GameSim.bucketOf(it.peakMult) }
        val pk = card()
        pk.add(tv("Peak guesses", 14f, Theme.text, bold = true), bottom = dp(8))
        pk.add(tv("Exact " + exact + "  |  too low " + low + "  |  too high " + highG, 12f, Theme.text, mono = true))
        col.add(pk, bottom = dp(10))

        val byTheme = rs.groupBy { it.theme }.entries.sortedByDescending { it.value.size }.take(6)
        val th = card()
        th.add(tv("By theme", 14f, Theme.text, bold = true), bottom = dp(8))
        for (e in byTheme) {
            val h = e.value.count { it.outcome == "hit" }
            th.add(tv(e.key + ":  " + e.value.size + " rounds, " + num(GameStore.initX) + "x in " + pctFmt(h, e.value.size), 12f, Theme.text, mono = true), bottom = dp(3))
        }
        col.add(th, bottom = dp(10))

        col.add(tv("Recent rounds", 15f, Theme.text, bold = true), bottom = dp(8))
        for (r in rs.takeLast(20).reversed()) {
            val c = card()
            val l1 = hstack()
            l1.add(tv("$" + (if (r.sym.isEmpty()) "?" else r.sym), 14f, Theme.text, bold = true), w = 0, weight = 1f)
            l1.add(tv((if (r.enter) "Entered" else "Passed") + "  " + mFmt(r.simMult), 12f,
                if (r.simMult >= 1.0) Theme.profit else Theme.loss, bold = true, mono = true))
            c.add(l1)
            c.add(tv("said " + r.prob + "%, guessed " + GameSim.bucketLabels[r.bucket] + ", peaked " + xFmt(r.peakMult) +
                ", " + r.outcome, 11f, Theme.muted, mono = true), top = dp(2))
            if (r.thesis.isNotEmpty()) c.add(tv(r.thesis, 12f, Theme.text), top = dp(4))
            col.add(c, bottom = dp(8))
        }

        val clr = pill(if (clearArmed) "Tap again to delete all rounds" else "Delete all rounds", Theme.loss) {
            if (clearArmed) { GameStore.clear(); clearArmed = false; state = 0; render() }
            else { clearArmed = true; render() }
        }
        col.add(clr, top = dp(6), bottom = dp(8))
        col.add(pill("Back") { clearArmed = false; state = 0; render() })
        return col
    }

    // ======================= SETTINGS =======================
    private fun buildSettings(): View {
        val col = vstack()
        col.add(tv("Game settings", 18f, Theme.text, bold = true), bottom = dp(4))
        col.add(tv("These are your rules. Change them and the replay scores against them.", 11f, Theme.muted), bottom = dp(12))

        val fields = ArrayList<Pair<String, EditText>>()
        fun field(key: String, label: String, value: Double) {
            col.add(tv(label, 11f, Theme.muted), bottom = dp(4))
            val e = EditText(act).apply {
                setText(num(value))
                setTextColor(Theme.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                background = Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            fields.add(Pair(key, e))
            col.add(e, bottom = dp(10))
        }
        field("low", "Entry level, lowest market cap ($)", GameStore.entryLow)
        field("high", "Entry level, highest market cap ($)", GameStore.entryHigh)
        field("late", "If a coin has no data in that range, accept a first point up to ($)", GameStore.lateMax)
        field("stop", "Stop loss (% down from entry)", GameStore.stopPct)
        field("initx", "Take initials out at (x)", GameStore.initX)
        field("trail", "Moon bag trailing stop (% down from its high)", GameStore.trailPct)
        field("slip", "Fill penalty on entry and exits (%)", GameStore.slipPct)
        field("replay", "Replay length (seconds)", GameStore.replaySec)
        field("sol", "SOL price in USD (used only if it cannot be fetched)", GameStore.solUsd)

        var needX = GameStore.needX
        col.add(tv("Hide coins with no X link", 11f, Theme.muted), bottom = dp(4))
        col.add(chips(listOf("Yes", "No"), if (needX) 0 else 1) { needX = (it == 0) }, bottom = dp(14))

        col.add(filledPill("Save settings") {
            fun read(key: String, def: Double): Double {
                for (f in fields) if (f.first == key) return f.second.text.toString().trim().toDoubleOrNull() ?: def
                return def
            }
            val low = read("low", GameStore.entryLow)
            val high = read("high", GameStore.entryHigh)
            if (low <= 0.0 || high <= low) {
                Toast.makeText(act, "Entry level: the high must be above the low", Toast.LENGTH_LONG).show()
            } else {
                GameStore.entryLow = low
                GameStore.entryHigh = high
                GameStore.lateMax = max(high, read("late", GameStore.lateMax))
                GameStore.stopPct = read("stop", GameStore.stopPct).coerceIn(5.0, 95.0)
                GameStore.initX = max(1.2, read("initx", GameStore.initX))
                GameStore.trailPct = read("trail", GameStore.trailPct).coerceIn(5.0, 95.0)
                GameStore.slipPct = read("slip", GameStore.slipPct).coerceIn(0.0, 30.0)
                GameStore.replaySec = read("replay", GameStore.replaySec).coerceIn(3.0, 60.0)
                GameStore.solUsd = read("sol", GameStore.solUsd).coerceIn(10.0, 5000.0)
                GameStore.needX = needX
                Toast.makeText(act, "Saved", Toast.LENGTH_SHORT).show()
                state = 0
                render()
            }
        }, bottom = dp(8))
        col.add(pill("Back") { state = 0; render() })
        return col
    }
}
