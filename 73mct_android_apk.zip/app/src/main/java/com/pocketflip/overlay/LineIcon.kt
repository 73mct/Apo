package com.pocketflip.overlay

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import kotlin.math.min

/** Thin consistent line icons drawn in code (no emojis, no image files). */
class LineIcon(private val kind: String, private var color: Int) : Drawable() {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.8f
    }

    fun setIconColor(c: Int) {
        color = c
        invalidateSelf()
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val s = min(b.width(), b.height()) / 24f
        if (s <= 0f) return
        canvas.save()
        canvas.translate(b.left + (b.width() - 24f * s) / 2f, b.top + (b.height() - 24f * s) / 2f)
        canvas.scale(s, s)
        paint.color = color
        when (kind) {
            "trade" -> {
                val p = Path()
                p.moveTo(3f, 17f)
                p.lineTo(9f, 11f)
                p.lineTo(13f, 15f)
                p.lineTo(21f, 6f)
                canvas.drawPath(p, paint)
                val a = Path()
                a.moveTo(15.5f, 6f)
                a.lineTo(21f, 6f)
                a.lineTo(21f, 11.5f)
                canvas.drawPath(a, paint)
                canvas.drawLine(3f, 21f, 21f, 21f, paint)
            }
            "journal" -> {
                canvas.drawRoundRect(RectF(5f, 3f, 19f, 21f), 2.5f, 2.5f, paint)
                canvas.drawLine(9f, 8f, 15f, 8f, paint)
                canvas.drawLine(9f, 12f, 15f, 12f, paint)
                canvas.drawLine(9f, 16f, 12.5f, 16f, paint)
            }
            "settings" -> {
                canvas.drawLine(4f, 7f, 9.8f, 7f, paint)
                canvas.drawLine(14.2f, 7f, 20f, 7f, paint)
                canvas.drawCircle(12f, 7f, 2.2f, paint)
                canvas.drawLine(4f, 12f, 5.8f, 12f, paint)
                canvas.drawLine(10.2f, 12f, 20f, 12f, paint)
                canvas.drawCircle(8f, 12f, 2.2f, paint)
                canvas.drawLine(4f, 17f, 12.8f, 17f, paint)
                canvas.drawLine(17.2f, 17f, 20f, 17f, paint)
                canvas.drawCircle(15f, 17f, 2.2f, paint)
            }
            "profile" -> {
                canvas.drawCircle(12f, 8f, 3.8f, paint)
                val body = Path()
                body.moveTo(4.5f, 20.5f)
                body.cubicTo(4.5f, 16f, 8f, 14f, 12f, 14f)
                body.cubicTo(16f, 14f, 19.5f, 16f, 19.5f, 20.5f)
                canvas.drawPath(body, paint)
            }
            "thesis" -> {
                val bubble = Path()
                bubble.moveTo(5f, 5f)
                bubble.lineTo(19f, 5f)
                bubble.quadTo(21f, 5f, 21f, 7f)
                bubble.lineTo(21f, 14f)
                bubble.quadTo(21f, 16f, 19f, 16f)
                bubble.lineTo(11f, 16f)
                bubble.lineTo(7f, 20f)
                bubble.lineTo(7f, 16f)
                bubble.lineTo(5f, 16f)
                bubble.quadTo(3f, 16f, 3f, 14f)
                bubble.lineTo(3f, 7f)
                bubble.quadTo(3f, 5f, 5f, 5f)
                canvas.drawPath(bubble, paint)
                canvas.drawLine(7f, 9f, 17f, 9f, paint)
                canvas.drawLine(7f, 12.5f, 13f, 12.5f, paint)
            }
            "kol" -> {
                canvas.drawCircle(12f, 12f, 6.5f, paint)
                canvas.drawCircle(12f, 12f, 1.6f, paint)
                canvas.drawLine(12f, 2.5f, 12f, 6f, paint)
                canvas.drawLine(12f, 18f, 12f, 21.5f, paint)
                canvas.drawLine(2.5f, 12f, 6f, 12f, paint)
                canvas.drawLine(18f, 12f, 21.5f, 12f, paint)
            }
            "academy" -> {
                // Open book + rising spark: dedicated training destination.
                val left = Path()
                left.moveTo(3.5f, 6f); left.quadTo(8f, 4f, 12f, 8f)
                left.lineTo(12f, 20f); left.quadTo(8f, 16f, 3.5f, 18f); left.close()
                val right = Path()
                right.moveTo(20.5f, 6f); right.quadTo(16f, 4f, 12f, 8f)
                right.lineTo(12f, 20f); right.quadTo(16f, 16f, 20.5f, 18f); right.close()
                canvas.drawPath(left, paint); canvas.drawPath(right, paint)
                canvas.drawLine(12f, 8f, 12f, 20f, paint)
                canvas.drawLine(7f, 10f, 9.5f, 10.5f, paint)
                canvas.drawLine(17f, 10f, 14.5f, 10.5f, paint)
            }
            "lab" -> {
                // Lab flask with a small chart spark.
                canvas.drawLine(9f, 3f, 15f, 3f, paint)
                canvas.drawLine(11f, 3f, 11f, 10f, paint)
                canvas.drawLine(13f, 3f, 13f, 10f, paint)
                val flask = Path()
                flask.moveTo(11f, 10f); flask.lineTo(5f, 19f)
                flask.quadTo(4f, 21f, 7f, 21f); flask.lineTo(17f, 21f)
                flask.quadTo(20f, 21f, 19f, 19f); flask.lineTo(13f, 10f)
                canvas.drawPath(flask, paint)
                canvas.drawLine(7.5f, 17f, 16.5f, 17f, paint)
                canvas.drawLine(9f, 15f, 11f, 13.5f, paint)
                canvas.drawLine(11f, 13.5f, 13f, 15f, paint)
            }
            "image" -> {
                canvas.drawRoundRect(RectF(3f, 4f, 21f, 20f), 3f, 3f, paint)
                canvas.drawCircle(9f, 10f, 1.8f, paint)
                val m = Path()
                m.moveTo(3.5f, 17f)
                m.lineTo(9f, 13f)
                m.lineTo(13f, 16f)
                m.lineTo(16.5f, 13f)
                m.lineTo(20.5f, 16.5f)
                canvas.drawPath(m, paint)
            }
        }
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
