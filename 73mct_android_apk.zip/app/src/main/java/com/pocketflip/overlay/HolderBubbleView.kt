package com.pocketflip.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Compact native holder relationship map for the floating overlay. */
class HolderBubbleView(context: Context) : View(context) {
    private val nodePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1.3f }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 9f * resources.displayMetrics.scaledDensity
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
    }
    private var nodes: List<HolderIntel> = emptyList()
    private var edges: List<HolderEdge> = emptyList()
    private var graphAvailable: Boolean = false
    private val palette = intArrayOf(
        0xFF77D6A1.toInt(), 0xFF78A9FF.toInt(), 0xFFE5B56D.toInt(),
        0xFFC99AFF.toInt(), 0xFF6FD1D1.toInt(), 0xFFEE8C9E.toInt()
    )

    fun setData(holders: List<HolderIntel>, relationships: List<HolderEdge>, hasMapData: Boolean) {
        nodes = holders.sortedByDescending { it.share }.take(24)
        edges = relationships
        graphAvailable = hasMapData
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val data = nodes
        if (!graphAvailable) {
            textPaint.color = 0xFF8A8F98.toInt()
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("Relationship map not indexed", width / 2f, height / 2f - 5f, textPaint)
            canvas.drawText("Top holder list is shown below", width / 2f, height / 2f + 11f, textPaint)
            return
        }
        if (data.isEmpty()) {
            textPaint.color = 0xFF8A8F98.toInt()
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("Holder map unavailable", width / 2f, height / 2f, textPaint)
            return
        }

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val usable = min(w, h) * 0.42f
        val positions = HashMap<String, Pair<Float, Float>>()
        val groups = data.groupBy { it.cluster.ifBlank { "unclustered" } }.values.toList()
        val groupCenters = HashMap<String, Pair<Float, Float>>()
        val groupRadii = HashMap<String, Float>()
        val totalGroups = groups.size.coerceAtLeast(1)

        groups.forEachIndexed { groupIndex, group ->
            val key = group.first().cluster.ifBlank { "unclustered" }
            val angle = (2.0 * Math.PI * groupIndex / totalGroups) - Math.PI / 2.0
            val orbit = if (totalGroups == 1) 0f else usable * 0.48f
            val gx = cx + cos(angle).toFloat() * orbit
            val gy = cy + sin(angle).toFloat() * orbit
            val mass = group.sumOf { it.share }.coerceAtLeast(0.002)
            val groupRadius = (10f + sqrt(mass.toFloat()) * usable * 1.15f).coerceIn(13f, usable * 0.72f)
            groupCenters[key] = Pair(gx, gy)
            groupRadii[key] = groupRadius
            group.forEachIndexed { index, holder ->
                val a = (2.0 * Math.PI * index / group.size.coerceAtLeast(1)) - Math.PI / 2.0
                val radius = if (group.size == 1) 0f else groupRadius * 0.58f
                positions[holder.address] = Pair(
                    gx + cos(a).toFloat() * radius,
                    gy + sin(a).toFloat() * radius
                )
            }
        }

        // Relationship edges are only drawn when they are present in the provider response.
        edgePaint.color = 0x557B8797
        edgePaint.strokeWidth = 1.1f * resources.displayMetrics.density
        edges.forEach { edge ->
            val a = positions[edge.from]
            val b = positions[edge.to]
            if (a != null && b != null) canvas.drawLine(a.first, a.second, b.first, b.second, edgePaint)
        }

        groups.forEach { group ->
            val key = group.first().cluster.ifBlank { "unclustered" }
            val center = groupCenters[key] ?: return@forEach
            val color = palette[(key.hashCode() and Int.MAX_VALUE) % palette.size]
            nodePaint.color = (color and 0x00FFFFFF) or 0x19000000
            canvas.drawCircle(center.first, center.second, groupRadii[key] ?: 14f, nodePaint)
        }

        data.forEach { holder ->
            val point = positions[holder.address] ?: return@forEach
            val key = holder.cluster.ifBlank { "unclustered" }
            val color = palette[(key.hashCode() and Int.MAX_VALUE) % palette.size]
            val radius = (5f + sqrt(holder.share.toFloat()) * 52f).coerceIn(5f, 13f) * resources.displayMetrics.density
            nodePaint.color = color
            canvas.drawCircle(point.first, point.second, radius, nodePaint)
        }

        textPaint.color = 0xFFB8C0CC.toInt()
        textPaint.textAlign = Paint.Align.CENTER
        val clusterCount = data.map { it.cluster }.filter { it.isNotBlank() }.distinct().size
        val label = if (edges.isEmpty() && clusterCount < 2) {
            "${data.size} holders · no wallet links returned"
        } else {
            "${data.size} holders · grouped by detected links"
        }
        canvas.drawText(label, cx, h - 7f * resources.displayMetrics.density, textPaint)
    }
}
