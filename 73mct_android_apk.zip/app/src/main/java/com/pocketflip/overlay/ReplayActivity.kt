package com.pocketflip.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.CornerPathEffect
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Trade replay for one finished trade. It plays back the market cap path that PathStore recorded
 * while you held the coin, with your buys and sells popping in at the moment you made them.
 * Trades made before this build have no recorded path, so they replay from the buys and sells only.
 * It only READS trade data; it never changes prices, balance or the journal.
 */
class ReplayActivity : Activity() {

    companion object {
        const val EXTRA_TRADE_ID = "trade_id"
        private const val LEAD_MS = 90_000L   // how much of the run-up before your first buy to show
        private const val TAIL_MS = 90_000L   // how much after your exit to show
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private lateinit var trade: ClosedTradeLog
    private lateinit var chart: ReplayChart
    private lateinit var mcText: TextView
    private lateinit var multText: TextView
    private lateinit var timeText: TextView
    private lateinit var statText: TextView
    private lateinit var noteText: TextView
    private lateinit var scrub: SeekBar
    private lateinit var playBtn: TextView
    private lateinit var resultCard: LinearLayout
    private lateinit var resultBody: LinearLayout
    private val speedChips = ArrayList<TextView>()

    // data
    private var pts: List<PathPoint> = emptyList()
    private var fills: List<Fill> = emptyList()
    private var passedAt = LongArray(0)
    private var dataReal = false
    private var tStart = 0L
    private var tEnd = 1L
    private var lo = 0.0
    private var hi = 1.0
    private var peakT = -1L
    private var peakMc = 0.0
    private var tailMax = 0.0
    private var hasTail = false

    // playback
    private var pos = 0f
    private var playing = false
    private var seconds = 12f
    private var lastNs = 0L
    private var ready = false
    private var userSeeking = false
    private var resumeAfterSeek = false

    // ---------- helpers ----------
    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false) =
        TextView(this).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun vstack() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun hstack() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun LinearLayout.add(
        v: View, top: Int = 0, bottom: Int = 0, left: Int = 0, right: Int = 0,
        w: Int = LinearLayout.LayoutParams.MATCH_PARENT,
        h: Int = LinearLayout.LayoutParams.WRAP_CONTENT, weight: Float = 0f
    ) {
        val p = if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
        p.topMargin = top; p.bottomMargin = bottom; p.leftMargin = left; p.rightMargin = right
        addView(v, p)
    }

    private fun pill(label: String, onClick: () -> Unit) =
        tv(label, 12f, Theme.text, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.box(Theme.bg, Theme.border, dp(14), dp(1))
            setOnClickListener { onClick() }
        }

    private fun mmss(ms: Long): String {
        val s = abs(ms) / 1000L
        return String.format("%02d:%02d", s / 60L, s % 60L)
    }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TradeRepository.init(this)
        Theme.init(this)
        CoinImages.init(this)
        PathStore.init(this)
        window.statusBarColor = Theme.bg
        window.navigationBarColor = Theme.bg
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val id = intent.getStringExtra(EXTRA_TRADE_ID) ?: ""
        val found = TradeRepository.getJournal().firstOrNull { it.id == id }
            ?: RadarStore.LastWhaleReplayHolder.tempTrade?.takeIf { it.id == id }
        if (found == null) {
            Toast.makeText(this, "Trade not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        trade = found
        buildUi()
        loadData()
    }

    override fun onPause() {
        super.onPause()
        pause()
    }

    override fun onDestroy() {
        pause()
        super.onDestroy()
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Theme.bg) }
        val col = vstack().apply { setPadding(dp(16), dp(14), dp(16), dp(14)) }

        // top bar: coin + close
        val top = hstack()
        val icon = Theme.avatar(this, dp(40), dp(1))
        (icon.layoutParams as LinearLayout.LayoutParams).rightMargin = dp(10)
        CoinImages.bind(icon, trade.ca, trade.symbol, trade.imageUrl)
        top.addView(icon)
        val names = vstack()
        val sym = if (trade.symbol.startsWith("$")) trade.symbol else "$${trade.symbol}"
        names.add(tv(sym, 16f, Theme.text, bold = true))
        names.add(tv("Trade replay", 11f, Theme.muted), top = dp(1))
        top.add(names, w = 0, weight = 1f)
        top.add(pill("Close") { finish() }, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        col.add(top, bottom = dp(10))

        // live numbers
        mcText = tv("--", 34f, Theme.text, bold = true, mono = true)
        col.add(mcText)
        val row2 = hstack()
        multText = tv("--", 16f, Theme.text, bold = true, mono = true)
        timeText = tv("", 12f, Theme.muted, mono = true)
        row2.add(multText, w = LinearLayout.LayoutParams.WRAP_CONTENT, right = dp(10))
        row2.add(timeText, w = 0, weight = 1f)
        col.add(row2, top = dp(2))
        statText = tv("Loading the trade...", 12f, Theme.muted, mono = true)
        col.add(statText, top = dp(4), bottom = dp(8))

        // chart
        chart = ReplayChart(this)
        val chartH = max(dp(260), (resources.displayMetrics.heightPixels * 0.36f).toInt())
        col.add(chart, h = chartH)

        noteText = tv("", 10f, Theme.muted, mono = true)
        col.add(noteText, top = dp(6))

        // scrubber
        scrub = SeekBar(this).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(Theme.text)
            thumbTintList = ColorStateList.valueOf(Theme.text)
            progressBackgroundTintList = ColorStateList.valueOf(Theme.alpha(Theme.text, 0x33))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser || !ready) return
                    pos = p / 1000f
                    applyPos(true)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {
                    userSeeking = true
                    resumeAfterSeek = playing
                    pause()
                }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    userSeeking = false
                    if (resumeAfterSeek && pos < 1f) play()
                }
            })
        }
        col.add(scrub, top = dp(4))

        // controls
        val controls = hstack()
        playBtn = pill("Pause") { onPlayTapped() }
        controls.add(playBtn, w = LinearLayout.LayoutParams.WRAP_CONTENT, right = dp(8))
        controls.add(pill("Restart") { restart() }, w = LinearLayout.LayoutParams.WRAP_CONTENT, right = dp(8))
        controls.add(View(this), w = 0, weight = 1f)
        val speeds = listOf("Slow" to 24f, "Normal" to 12f, "Fast" to 6f, "Turbo" to 3f)
        for ((label, secs) in speeds) {
            val chip = tv(label, 11f, Theme.text, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(9), dp(9), dp(9), dp(9))
                setOnClickListener { seconds = secs; styleChips() }
                tag = secs
            }
            speedChips.add(chip)
            controls.add(chip, w = LinearLayout.LayoutParams.WRAP_CONTENT, left = dp(4))
        }
        col.add(controls, top = dp(8))
        styleChips()

        // result card (shown when the replay ends)
        resultCard = vstack().apply {
            visibility = View.GONE
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = Theme.box(Theme.card, Theme.border, dp(18), dp(1))
        }
        resultBody = vstack()
        resultCard.add(resultBody)
        val btns = hstack()
        btns.add(pill("Replay again") { restart() }, w = 0, weight = 1f, right = dp(8))
        btns.add(pill("Create PnL card") {
            startActivity(Intent(this, CardActivity::class.java).putExtra(CardActivity.EXTRA_TRADE_ID, trade.id))
        }, w = 0, weight = 1f)
        resultCard.add(btns, top = dp(10))
        col.add(resultCard, top = dp(10))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        scroll.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }

    private fun styleChips() {
        for (c in speedChips) {
            val on = (c.tag as Float) == seconds
            c.setTextColor(if (on) Theme.onColor(Theme.text) else Theme.text)
            c.background = if (on) Theme.box(Theme.text, Theme.text, dp(12), 0)
            else Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
        }
    }

    // ---------- data ----------
    private fun loadData() {
        io.execute {
            val t0 = trade.openedAtMs
            val t1 = max(trade.closedAtMs, t0 + 4000L)
            val raw = PathStore.read(trade.ca, t0 - LEAD_MS, trade.closedAtMs + TAIL_MS)
            val inside = raw.count { it.t >= t0 - 5000L && it.t <= trade.closedAtMs + 5000L }
            val real = inside >= 3
            val list: List<PathPoint> = if (real) raw else buildFallback(t0, t1)
            main.post { setData(list, real) }
        }
    }

    /** No recorded path (older trade): connect the fills, and add the peak between the first and last fill. */
    private fun buildFallback(t0: Long, t1: Long): List<PathPoint> {
        val f = trade.fills.sortedBy { it.timeMs }
        val list = ArrayList<PathPoint>()
        list.add(PathPoint(t0 - 1L, trade.entryMc.coerceAtLeast(1.0)))
        for (x in f) list.add(PathPoint(x.timeMs, x.mc.coerceAtLeast(1.0)))
        val maxFill = f.maxOfOrNull { it.mc } ?: trade.entryMc
        if (f.size >= 2 && trade.peakMc > maxFill * 1.02) {
            val mid = (f.first().timeMs + f.last().timeMs) / 2L
            list.add(PathPoint(mid, trade.peakMc))
        }
        list.add(PathPoint(max(t1, (f.lastOrNull()?.timeMs ?: t1)) + 1L, (f.lastOrNull()?.mc ?: trade.avgExitMc).coerceAtLeast(1.0)))
        val sorted = list.sortedBy { it.t }
        // make time strictly increasing
        val out = ArrayList<PathPoint>()
        var last = Long.MIN_VALUE
        for (p in sorted) {
            val t = if (p.t <= last) last + 1L else p.t
            out.add(PathPoint(t, p.mc))
            last = t
        }
        return out
    }

    private fun setData(list: List<PathPoint>, real: Boolean) {
        pts = list
        dataReal = real
        fills = trade.fills.sortedBy { it.timeMs }
        passedAt = LongArray(fills.size)
        val t0 = trade.openedAtMs
        val t1 = trade.closedAtMs
        tStart = min(pts.first().t, t0)
        tEnd = max(max(pts.last().t, t1), tStart + 1000L)

        var mn = Double.MAX_VALUE
        var mx = 0.0
        for (p in pts) { mn = min(mn, p.mc); mx = max(mx, p.mc) }
        for (f in fills) { mn = min(mn, f.mc); mx = max(mx, f.mc) }
        mn = min(mn, trade.entryMc); mx = max(mx, trade.entryMc)
        if (mx - mn < mx * 0.02) { mn = mx * 0.95; mx *= 1.05 }
        val padv = (mx - mn) * 0.14
        lo = max(0.0, mn - padv)
        hi = mx + padv

        // peak inside the trade, and what happened after the exit
        peakT = -1L; peakMc = 0.0
        for (p in pts) if (p.t >= t0 && p.t <= t1 && p.mc > peakMc) { peakMc = p.mc; peakT = p.t }
        if (!real && trade.peakMc > (fills.maxOfOrNull { it.mc } ?: 0.0)) {
            // synthetic peak point
            for (p in pts) if (abs(p.mc - trade.peakMc) < 1.0) { peakT = p.t; peakMc = p.mc }
        }
        hasTail = real && pts.last().t > t1 + 10_000L
        tailMax = 0.0
        if (hasTail) for (p in pts) if (p.t > t1) tailMax = max(tailMax, p.mc)

        noteText.text = if (real) "Recorded price path" else
            "No price path was recorded for this trade, so the line connects your buys and sells (trades from this build on record it)."
        chart.softEffect = if (real) null else CornerPathEffect(dp(16).toFloat())

        ready = true
        pos = 0f
        applyPos(true)
        play()
    }

    // ---------- playback ----------
    private val ticker = object : Runnable {
        override fun run() {
            if (!playing) return
            val now = System.nanoTime()
            val dt = (now - lastNs) / 1_000_000_000f
            lastNs = now
            pos += dt / seconds
            if (pos >= 1f) {
                pos = 1f
                playing = false
                applyPos(true)
                onFinished()
                return
            }
            applyPos(false)
            chart.postOnAnimation(this)
        }
    }

    private fun play() {
        if (!ready) return
        if (pos >= 1f) pos = 0f
        resultCard.visibility = View.GONE
        playing = true
        lastNs = System.nanoTime()
        playBtn.text = "Pause"
        chart.removeCallbacks(ticker)
        chart.postOnAnimation(ticker)
    }

    private fun pause() {
        playing = false
        if (::chart.isInitialized) chart.removeCallbacks(ticker)
        if (::playBtn.isInitialized) playBtn.text = if (pos >= 1f) "Replay" else "Play"
    }

    private fun restart() {
        if (!ready) return
        pos = 0f
        for (i in passedAt.indices) passedAt[i] = 0L
        applyPos(true)
        play()
    }

    private fun onPlayTapped() {
        if (!ready) return
        if (playing) pause() else play()
    }

    private fun currentT(): Long = tStart + ((tEnd - tStart) * pos.toDouble()).toLong()

    fun mcAt(t: Long): Double {
        if (pts.isEmpty()) return 0.0
        if (t <= pts.first().t) return pts.first().mc
        if (t >= pts.last().t) return pts.last().mc
        var a = 0
        var b = pts.size - 1
        while (b - a > 1) {
            val m = (a + b) / 2
            if (pts[m].t <= t) a = m else b = m
        }
        val p = pts[a]
        val q = pts[b]
        val span = (q.t - p.t).coerceAtLeast(1L).toDouble()
        return p.mc + (q.mc - p.mc) * ((t - p.t) / span)
    }

    private fun applyPos(force: Boolean) {
        if (!ready) return
        val tp = currentT()
        val now = System.nanoTime()
        for (k in fills.indices) {
            if (fills[k].timeMs <= tp) {
                if (passedAt[k] == 0L) {
                    passedAt[k] = now
                    if (playing) chart.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                }
            } else {
                passedAt[k] = 0L
            }
        }
        val mc = mcAt(tp)
        mcText.text = Formatters.compactUsd(mc)
        val x = if (trade.entryMc > 0.0) mc / trade.entryMc else 1.0
        multText.text = Formatters.multX(x)
        multText.setTextColor(Theme.pnlColor(mc - trade.entryMc))
        val t0 = trade.openedAtMs
        val t1 = trade.closedAtMs
        timeText.text = when {
            tp < t0 -> "Entry in ${mmss(t0 - tp)}"
            tp <= t1 -> "In trade ${mmss(tp - t0)}"
            else -> "Exited ${mmss(tp - t1)} ago"
        }
        var realized = 0.0
        var bag = -1.0
        for (f in fills) {
            if (f.timeMs <= tp) {
                if (f.side == "SELL") { realized += f.pnlSol; bag = f.remainingAfterPct }
                else if (bag < 0.0) bag = 100.0
            }
        }
        statText.text = if (bag < 0.0) "Waiting for your entry" else
            String.format("Bag %.0f%%  |  Realized %s", bag, Formatters.solSigned(realized))
        if (!userSeeking) scrub.progress = (pos * 1000f).toInt()
        if (force && !playing) playBtn.text = if (pos >= 1f) "Replay" else "Play"
        if (pos < 1f && resultCard.visibility == View.VISIBLE) resultCard.visibility = View.GONE
        chart.invalidate()
    }

    private fun onFinished() {
        playBtn.text = "Replay"
        resultBody.removeAllViews()
        val pnl = trade.pnlSol
        resultBody.add(tv("Result", 11f, Theme.muted))
        resultBody.add(tv(Formatters.solSigned(pnl), 26f, Theme.pnlColor(pnl), bold = true, mono = true), top = dp(2))
        resultBody.add(
            tv(
                String.format("%s return  |  ROI %s  |  held %s", Formatters.multX(trade.returnX), Formatters.pctSigned(trade.roiPct), Formatters.duration(trade.holdDurationMs)),
                11f, Theme.muted, mono = true
            ), top = dp(2)
        )
        val lines = ArrayList<String>()
        if (trade.peakMc > 0.0 && trade.avgExitMc > 0.0) {
            val pct = trade.avgExitMc / trade.peakMc * 100.0
            lines.add(String.format("You sold at %.0f%% of the peak (%s vs %s).", pct, Formatters.compactUsd(trade.avgExitMc), Formatters.compactUsd(trade.peakMc)))
        }
        if (dataReal && peakT > 0L) {
            lines.add("The peak came ${Formatters.duration(max(1000L, peakT - trade.openedAtMs))} after your first buy.")
        }
        if (hasTail && trade.avgExitMc > 0.0) {
            if (tailMax > trade.avgExitMc * 1.1) {
                lines.add(String.format("After you sold it reached %s, %.0f%% above your exit.", Formatters.compactUsd(tailMax), (tailMax / trade.avgExitMc - 1.0) * 100.0))
            } else {
                lines.add("After you sold it did not go much higher.")
            }
        }
        for (l in lines) resultBody.add(tv(l, 12f, Theme.text), top = dp(6))
        resultCard.alpha = 0f
        resultCard.visibility = View.VISIBLE
        resultCard.animate().alpha(1f).setDuration(350).start()
    }

    // =====================================================================
    // The chart
    // =====================================================================
    inner class ReplayChart(ctx: Context) : View(ctx) {
        var softEffect: CornerPathEffect? = null

        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat() + dp(1) / 2f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat()
            pathEffect = DashPathEffect(floatArrayOf(dp(5).toFloat(), dp(5).toFloat()), 0f)
        }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.MONOSPACE
            textSize = dp(10).toFloat()
        }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
        }

        private val cardP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat()
        }
        private val box = RectF()

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat()
            val h = height.toFloat()
            // the chart's own card (so it is visible on any theme)
            box.set(1f, 1f, w - 1f, h - 1f)
            cardP.color = Theme.lighten(Theme.bg, 0.07f)
            c.drawRoundRect(box, dp(18).toFloat(), dp(18).toFloat(), cardP)
            edgeP.color = Theme.alpha(Theme.text, 0x28)
            c.drawRoundRect(box, dp(18).toFloat(), dp(18).toFloat(), edgeP)
            if (!ready || pts.size < 2) {
                txt.color = Theme.muted
                txt.textAlign = Paint.Align.CENTER
                c.drawText("Loading the replay...", w / 2f, h / 2f, txt)
                return
            }
            val padL = dp(12).toFloat()
            val padR = dp(52).toFloat()
            val padT = dp(26).toFloat()
            val padB = dp(14).toFloat()
            val cw = w - padL - padR
            val ch = h - padT - padB
            if (cw <= 0f || ch <= 0f) return
            val span = (tEnd - tStart).coerceAtLeast(1L).toDouble()
            val vr = (hi - lo).coerceAtLeast(1e-9)
            fun xOf(t: Long): Float = padL + (((t - tStart) / span).toFloat()).coerceIn(0f, 1f) * cw
            fun yOf(mc: Double): Float = padT + (1f - ((mc - lo) / vr).toFloat()) * ch

            val t0 = trade.openedAtMs
            val t1 = trade.closedAtMs
            val tp = currentT()
            val nowNs = System.nanoTime()

            // entry line + axis labels
            val yEntry = yOf(trade.entryMc)
            dash.color = Theme.alpha(Theme.muted, 0x90)
            c.drawLine(padL, yEntry, w - padR, yEntry, dash)
            txt.color = Theme.muted
            txt.textAlign = Paint.Align.LEFT
            c.drawText("Entry", w - padR + dp(4), yEntry + dp(3), txt)
            c.drawText(Formatters.compactUsd(hi), w - padR + dp(4), padT + dp(8), txt)
            c.drawText(Formatters.compactUsd(lo), w - padR + dp(4), padT + ch, txt)

            // the path so far, split into run-up / trade / after-exit
            val pLead = Path()
            val pTrade = Path()
            val pTail = Path()
            var lastCat = -1
            var lx = 0f
            var ly = 0f
            var tradeFirstX = -1f
            var tradeLastX = -1f
            fun addPt(t: Long, mc: Double) {
                val x = xOf(t)
                val y = yOf(mc)
                val cat = if (t < t0) 0 else if (t <= t1) 1 else 2
                val path = when (cat) { 0 -> pLead; 1 -> pTrade; else -> pTail }
                if (lastCat == -1) {
                    path.moveTo(x, y)
                } else if (cat != lastCat) {
                    path.moveTo(lx, ly)
                    path.lineTo(x, y)
                } else {
                    path.lineTo(x, y)
                }
                if (cat == 1) {
                    if (tradeFirstX < 0f) tradeFirstX = if (lastCat == -1) x else lx
                    tradeLastX = x
                }
                lastCat = cat
                lx = x
                ly = y
            }
            for (p in pts) {
                if (p.t > tp) break
                addPt(p.t, p.mc)
            }
            val headMc = mcAt(tp)
            addPt(tp, headMc)

            // soft area under the trade part
            if (tradeFirstX >= 0f) {
                val area = Path(pTrade)
                area.lineTo(tradeLastX, padT + ch)
                area.lineTo(tradeFirstX, padT + ch)
                area.close()
                fillP.shader = LinearGradient(0f, padT, 0f, padT + ch, Theme.alpha(Theme.text, 0x34), 0x00000000, Shader.TileMode.CLAMP)
                c.drawPath(area, fillP)
                fillP.shader = null
            }
            line.pathEffect = softEffect
            line.color = Theme.alpha(Theme.muted, 0xB0)
            c.drawPath(pLead, line)
            c.drawPath(pTail, line)
            line.color = Theme.text
            c.drawPath(pTrade, line)
            line.pathEffect = null

            // peak marker
            if (peakT > 0L && tp >= peakT) {
                val px = xOf(peakT)
                val py = yOf(peakMc)
                ring.color = Theme.text
                c.drawCircle(px, py, dp(5).toFloat(), ring)
                txt.color = Theme.text
                txt.textAlign = Paint.Align.CENTER
                c.drawText("PEAK " + Formatters.compactUsd(peakMc), px.coerceIn(dp(40).toFloat(), w - padR - dp(10)), py - dp(10), txt)
            }

            // buys and sells
            for (k in fills.indices) {
                val at = passedAt[k]
                if (at == 0L) continue
                val f = fills[k]
                val mx = xOf(f.timeMs)
                val my = yOf(f.mc)
                val ageMs = (nowNs - at) / 1_000_000f
                val s = (ageMs / 320f).coerceIn(0f, 1f)
                val sc = s + 0.4f * sin(PI.toFloat() * s)
                val isBuy = f.side == "BUY"
                val col = if (isBuy) Theme.buy else Theme.sell
                val r = dp(10).toFloat() * sc
                if (ageMs < 700f) {
                    ring.color = Theme.alpha(col, (0x80 * (1f - ageMs / 700f)).toInt().coerceIn(0, 255))
                    c.drawCircle(mx, my, dp(10).toFloat() * (1f + ageMs / 700f * 1.4f), ring)
                }
                dot.color = col
                c.drawCircle(mx, my, r, dot)
                txt.color = Theme.onColor(col)
                txt.textAlign = Paint.Align.CENTER
                txt.isFakeBoldText = true
                c.drawText(if (isBuy) "B" else "S", mx, my + dp(3).toFloat() * sc, txt)
                txt.isFakeBoldText = false
                if (ageMs < 3500f) {
                    val fade = if (ageMs < 2800f) 1f else (1f - (ageMs - 2800f) / 700f)
                    txt.color = Theme.alpha(Theme.text, (255 * fade).toInt().coerceIn(0, 255))
                    val label = if (isBuy) String.format("%.2f SOL", f.sol) else String.format("-%.0f%%  %s", f.pct, Formatters.solSigned(f.pnlSol))
                    val ly2 = if (my - dp(24) > padT) my - dp(16).toFloat() else my + dp(24).toFloat()
                    c.drawText(label, mx.coerceIn(dp(44).toFloat(), w - padR - dp(30)), ly2, txt)
                }
            }

            // glowing head
            val hx = xOf(tp)
            val hy = yOf(headMc)
            val pc = Theme.pnlColor(headMc - trade.entryMc)
            val pulse = 0.5f + 0.5f * sin(nowNs / 1_000_000_000f * 5f)
            dot.color = Theme.alpha(pc, 0x40)
            c.drawCircle(hx, hy, dp(8).toFloat() + dp(4) * pulse, dot)
            dot.color = pc
            c.drawCircle(hx, hy, dp(4).toFloat(), dot)
        }
    }
}
