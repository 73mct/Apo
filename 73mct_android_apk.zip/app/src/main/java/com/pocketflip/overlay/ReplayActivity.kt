package com.pocketflip.overlay

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ReplayActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_replay)
    }
}