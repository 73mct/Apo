package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** A decision made before revealing the historical outcome of an Academy case. */
data class AcademyDecision(
    val id: String,
    val mint: String,
    val coinName: String,
    val symbol: String,
    val imageUrl: String,
    val decisionTs: Long,
    val entryMc: Double,
    val walletsAtDecision: Int,
    val totalWallets: Int,
    val thesisTag: String,
    val thesisText: String,
    val probability2x: Int,
    val probability4x: Int,
    val risk: String,
    val exitPlan: String,
    val submittedAt: Long,
    var status: String = "SUBMITTED", // SUBMITTED | REVEALED | SKIPPED
    var peakMc: Double = 0.0,
    var outcomeVerified: Boolean = false,
    var outcomeSource: String = "",
    var revealedAt: Long = 0L
)

/** Academy data is deliberately stored separately from TradeRepository and KolStore. */
object AcademyStore {
    private const val PREFS = "pocketflip_academy"
    private const val DECISIONS_KEY = "decisions_v1"
    private var prefs: SharedPreferences? = null
    private var chartDir: File? = null
    private val lock = Any()
    private val decisions = ArrayList<AcademyDecision>()

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val app = context.applicationContext
        prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        chartDir = File(app.filesDir, "academy/charts").apply { mkdirs() }
        load()
    }

    private fun load() {
        decisions.clear()
        try {
            val arr = JSONArray(prefs?.getString(DECISIONS_KEY, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                decisions.add(
                    AcademyDecision(
                        id = o.optString("id"), mint = o.optString("mint"),
                        coinName = o.optString("name"), symbol = o.optString("symbol"),
                        imageUrl = o.optString("image"), decisionTs = o.optLong("decisionTs"),
                        entryMc = o.optDouble("entryMc"), walletsAtDecision = o.optInt("walletsAtDecision"),
                        totalWallets = o.optInt("totalWallets"), thesisTag = o.optString("thesisTag"),
                        thesisText = o.optString("thesisText"), probability2x = o.optInt("p2"),
                        probability4x = o.optInt("p4"), risk = o.optString("risk"),
                        exitPlan = o.optString("exitPlan"), submittedAt = o.optLong("submittedAt"),
                        status = o.optString("status", "SUBMITTED"), peakMc = o.optDouble("peakMc"),
                        outcomeVerified = o.optBoolean("outcomeVerified"),
                        outcomeSource = o.optString("outcomeSource"), revealedAt = o.optLong("revealedAt")
                    )
                )
            }
        } catch (_: Throwable) {
            decisions.clear()
        }
    }

    private fun persist() {
        val arr = JSONArray()
        for (d in decisions.takeLast(5000)) {
            val o = JSONObject()
            o.put("id", d.id); o.put("mint", d.mint); o.put("name", d.coinName)
            o.put("symbol", d.symbol); o.put("image", d.imageUrl); o.put("decisionTs", d.decisionTs)
            o.put("entryMc", d.entryMc); o.put("walletsAtDecision", d.walletsAtDecision)
            o.put("totalWallets", d.totalWallets); o.put("thesisTag", d.thesisTag)
            o.put("thesisText", d.thesisText); o.put("p2", d.probability2x); o.put("p4", d.probability4x)
            o.put("risk", d.risk); o.put("exitPlan", d.exitPlan); o.put("submittedAt", d.submittedAt)
            o.put("status", d.status); o.put("peakMc", d.peakMc); o.put("outcomeVerified", d.outcomeVerified)
            o.put("outcomeSource", d.outcomeSource); o.put("revealedAt", d.revealedAt)
            arr.put(o)
        }
        prefs?.edit()?.putString(DECISIONS_KEY, arr.toString())?.apply()
    }

    @Synchronized
    fun all(): List<AcademyDecision> = decisions.map { it.copy() }.sortedByDescending { it.submittedAt }

    @Synchronized
    fun get(id: String): AcademyDecision? = decisions.firstOrNull { it.id == id }?.copy()

    @Synchronized
    fun hasCase(id: String): Boolean = decisions.any { it.id == id }

    @Synchronized
    fun save(d: AcademyDecision) {
        val ix = decisions.indexOfFirst { it.id == d.id }
        if (ix >= 0) decisions[ix] = d else decisions.add(d)
        while (decisions.size > 5000) decisions.removeAt(0)
        persist()
    }

    @Synchronized
    fun skip(id: String, mint: String, name: String, symbol: String, decisionTs: Long, entryMc: Double) {
        if (hasCase(id)) return
        decisions.add(
            AcademyDecision(
                id, mint, name, symbol, "", decisionTs, entryMc, 1, 1,
                "Skipped", "", 0, 0, "", "", System.currentTimeMillis(), "SKIPPED"
            )
        )
        persist()
    }

    @Synchronized
    fun reveal(id: String, peakMc: Double, verified: Boolean, source: String) {
        val d = decisions.firstOrNull { it.id == id } ?: return
        if (d.status == "SKIPPED") return
        d.status = "REVEALED"
        d.peakMc = peakMc
        d.outcomeVerified = verified
        d.outcomeSource = source
        d.revealedAt = System.currentTimeMillis()
        persist()
    }

    fun chartPoints(mint: String): List<Pair<Long, Double>> {
        val f = chartFile(mint)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            val out = ArrayList<Pair<Long, Double>>()
            for (i in 0 until arr.length()) {
                val p = arr.getJSONArray(i)
                if (p.length() >= 2) out.add(Pair(p.getLong(0), p.getDouble(1)))
            }
            out
        } catch (_: Throwable) { emptyList() }
    }

    fun saveChartPoints(mint: String, points: List<Pair<Long, Double>>) {
        if (mint.isBlank() || points.isEmpty()) return
        try {
            val arr = JSONArray()
            for (p in points) arr.put(JSONArray().put(p.first).put(p.second))
            val f = chartFile(mint)
            f.parentFile?.mkdirs()
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(f)) {
                f.writeText(arr.toString())
                tmp.delete()
            }
        } catch (_: Throwable) { }
    }

    private fun chartFile(mint: String): File {
        val safe = mint.replace(Regex("[^A-Za-z0-9_-]"), "_")
        return File(chartDir, "$safe.json")
    }
}
