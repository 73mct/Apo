package com.pocketflip.overlay

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStartOverlay = findViewById<Button>(R.id.btnStartOverlay)
        val btnOpenRadar = findViewById<Button>(R.id.btnOpenRadar)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)

        tvStatus.text = "73MCT v2 Active | 0.3 -> 1.0 -> 10.0 SOL Challenge"

        btnStartOverlay.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(intent)
            } else {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "73MCT Floating HUD Started", Toast.LENGTH_SHORT).show()
            }
        }

        btnOpenRadar.setOnClickListener {
            val intent = Intent(this, ReplayActivity::class.java)
            startActivity(intent)
        }
    }
}