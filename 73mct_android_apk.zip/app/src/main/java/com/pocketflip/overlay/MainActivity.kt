package com.pocketflip.overlay

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextUtils
import android.text.SpannableString
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : Activity() {

    companion object {
        var lastTab: Int = 0
        private const val REQ_COIN_PICK = 7401
        private const val REQ_AVATAR = 7402
        private const val REQ_BANNER = 7403
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var tabTrade: LinearLayout
    private lateinit var tabFeed: LinearLayout
    private lateinit var feedListContainer: LinearLayout
    private lateinit var feedSummary: TextView
    private lateinit var tabSearch: KolScreen
    private lateinit var tabPortfolio: LinearLayout
    private lateinit var portfolioContent: FrameLayout
    private lateinit var portfolioSectionLabels: List<TextView>
    private var portfolioSection = 0
    private var feedFilter = "all"
    private var settingsOpen = false
    private lateinit var settingsButton: ImageView
    private lateinit var navBarView: View
    private lateinit var tabJournal: LinearLayout
    private lateinit var tabSettings: LinearLayout
    private lateinit var tabKol: KolScreen
    private lateinit var tabProfile: LinearLayout
    private lateinit var tabThesis: LinearLayout
    private lateinit var thesisListContainer: LinearLayout
    private lateinit var equityView: EquityView
    private lateinit var dayBarsView: DayBarsView
    private lateinit var eqValue: TextView
    private lateinit var eqSub: TextView
    private lateinit var eqRow1: LinearLayout
    private lateinit var eqRow2: LinearLayout
    private var eqRange = "all"           // 24h | 7d | 30d | all
    private var eqLogs: List<ClosedTradeLog> = emptyList()
    private var eqSig = ""
    private var thesisFilter = "all"      // all | win | loss | open
    private var thesisQuery = ""
    private var thesisSig = ""

    private class ThesisItem(
        val ca: String, val name: String, val symbol: String, val imageUrl: String,
        val openedAtMs: Long, val sortMs: Long, val closed: ClosedTradeLog?, val open: OpenPosition?
    )
    private data class FeedItem(
        val timeMs: Long,
        val actor: String,
        val action: String,
        val symbol: String,
        val name: String,
        val imageUrl: String,
        val ca: String,
        val amountSol: Double,
        val marketCap: Double,
        val pnlSol: Double? = null,
        val body: String = "",
        val walletActivity: Boolean = false,
        val lesson: Boolean = false,
        val trade: ClosedTradeLog? = null
    )
    private lateinit var bodyScroll: ScrollView
    private var bioAnim: ValueAnimator? = null
    private var heroAnim: ValueAnimator? = null
    private var heroShown = Double.NaN
    private var profPnlAnim: ValueAnimator? = null
    private var profPnlShown = 0.0
    private var profileSig = ""
    private var imagesVersion = -1

    private lateinit var profBannerImg: ImageView
    private lateinit var profAvatarImg: ImageView
    private lateinit var profLetter: TextView
    private lateinit var profName: TextView
    private lateinit var profBio: TextView
    private lateinit var profNetPnl: TextView
    private lateinit var profNetSub: TextView
    private lateinit var profRow1: LinearLayout
    private lateinit var profRow2: LinearLayout
    private lateinit var profRow3: LinearLayout
    private val navIcons = ArrayList<LineIcon>()
    private val navCells = ArrayList<LinearLayout>()
    private lateinit var heroBalance: TextView
    private lateinit var heroSub: TextView
    private var pickCa: String = ""
    private var pickView: ImageView? = null

    private lateinit var headerBalanceText: TextView
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var positionsContainer: LinearLayout
    private lateinit var marketRadarContainer: LinearLayout

    private lateinit var journalNetPnl: TextView
    private lateinit var journalNetSub: TextView
    private lateinit var journalStatsRow: LinearLayout
    private lateinit var journalListContainer: LinearLayout

    private lateinit var detailLayer: ScrollView
    private lateinit var detailContent: LinearLayout

    private var journalSig: String = ""
    private var journalFilter = "all"   // all | win | loss | tag:<name>
    private var journalRange = "all"    // all | 24h | 7d | 30d
    private lateinit var insightsTitle: TextView
    private lateinit var insightsRow1: LinearLayout
    private lateinit var insightsRow2: LinearLayout
    private lateinit var insightsTags: LinearLayout
    private var refreshPending = false
    private var currentTabIdx = 0
    private var motionEnabled = true

    private val repoListener: () -> Unit = {
        mainHandler.post { scheduleRefresh() }
    }

    private fun scheduleRefresh() {
        if (refreshPending) return
        refreshPending = true
        mainHandler.postDelayed({
            refreshPending = false
            refreshMainUI(false)
        }, 350)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TradeRepository.init(this)
        Theme.init(this)
        motionEnabled = getSharedPreferences("73mct_visual_settings", MODE_PRIVATE).getBoolean("motion_enabled", true)
        CoinImages.init(this)
        ProfileStore.init(this)
        ThesisStore.init(this)
        KolStore.init(this)

        // FOMO-inspired bright market strip at the very top; keep Android navigation dark.
        window.statusBarColor = Color.rgb(35, 181, 216)
        window.navigationBarColor = Theme.bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val rootFrame = FrameLayout(this).apply { setBackgroundColor(Theme.bg) }
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ---------- Top bar ----------
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(3), dp(12), dp(3))
            setBackgroundColor(Color.rgb(35, 181, 216))
        }
        val brand = hstack()
        val logo = ImageView(this).apply { setImageResource(R.drawable.emblem); alpha = 0.96f }
        brand.add(logo, w = dp(25), h = dp(25), right = dp(7))
        val brandText = vstack()
        brandText.add(tv("73MCT", 15f, Color.WHITE, bold = true).apply { letterSpacing = 0.10f })
        brandText.add(tv("PAPER TERMINAL", 6.5f, Color.WHITE, bold = true).apply { letterSpacing = 0.12f }, top = 0)
        brand.add(brandText, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        topBar.add(brand, w = 0, weight = 1f)
        headerBalanceText = tv("10.000 SOL", 11f, Color.WHITE, bold = true, mono = true).apply {
            setPadding(dp(5), dp(4), dp(8), dp(4))
        }
        topBar.addView(headerBalanceText)
        settingsButton = ImageView(this).apply {
            setImageDrawable(LineIcon("settings", Color.WHITE))
            contentDescription = "Open settings"
            setPadding(dp(5), dp(5), dp(5), dp(5))
            setOnClickListener { if (settingsOpen) closeSettingsPage() else openSettingsPage() }
        }
        topBar.addView(settingsButton, LinearLayout.LayoutParams(dp(30), dp(30)))
        column.addView(topBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(36)))

        // ---------- Scrollable body ----------
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val contentHolder = FrameLayout(this).apply {
            setPadding(dp(13), dp(3), dp(13), dp(78))
        }
        tabTrade = buildTradeTab()
        tabJournal = buildJournalTab()
        tabThesis = buildThesisTab()
        tabProfile = buildProfileTab()
        tabSettings = buildSettingsTab()
        tabFeed = buildFeedTab()
        tabSearch = KolScreen(this, initialTab = 0, pageTitle = "Discover", showTabBar = false)
        tabKol = KolScreen(this, initialTab = 1, pageTitle = "Leaderboard", showTabBar = true)
        tabSearch.scrollTop = { bodyScroll.scrollTo(0, 0) }
        tabKol.scrollTop = { bodyScroll.scrollTo(0, 0) }
        tabPortfolio = buildPortfolioTab()
        contentHolder.addView(tabTrade)
        contentHolder.addView(tabFeed)
        contentHolder.addView(tabSearch)
        contentHolder.addView(tabKol)
        contentHolder.addView(tabPortfolio)
        contentHolder.addView(tabSettings)
        bodyScroll = scroll
        scroll.addView(contentHolder)
        column.addView(scroll)


        rootFrame.addView(
            column,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        // ---------- Compact five-destination bottom navigation ----------
        val navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(4), dp(7), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(30).toFloat()
                setColor(Color.argb(238, 43, 42, 52))
                setStroke(dp(1), Color.argb(90, 120, 118, 140))
            }
            elevation = dp(12).toFloat()
        }
        val kinds = listOf("trade", "feed", "search", "kol", "profile")
        for (i in kinds.indices) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                setPadding(0, 0, 0, 0)
                background = null
                setOnClickListener { if (!settingsOpen) switchTab(i) }
            }
            val icon = LineIcon(kinds[i], Theme.muted)
            val iv = ImageView(this).apply { setImageDrawable(icon) }
            cell.addView(iv, LinearLayout.LayoutParams(dp(21), dp(21)))
            navIcons.add(icon)
            navCells.add(cell)
            navBar.addView(cell, LinearLayout.LayoutParams(0, dp(46), 1f))
        }
        navBarView = navBar
        val navLp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(54), Gravity.BOTTOM)
        navLp.leftMargin = dp(17)
        navLp.rightMargin = dp(17)
        navLp.bottomMargin = dp(11)
        rootFrame.addView(navBar, navLp)

        // ---------- Trade detail layer (opens when a journal card is tapped) ----------
        detailContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(30))
        }
        detailLayer = ScrollView(this).apply {
            setBackgroundColor(Theme.bg)
            visibility = View.GONE
            isClickable = true
            addView(detailContent)
        }
        rootFrame.addView(
            detailLayer,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        setContentView(rootFrame)
        TradeRepository.addListener(repoListener)
        switchTab(lastTab)
    }

    override fun onResume() {
        super.onResume()
        refreshMainUI(true)
    }

    override fun onPause() {
        bioAnim?.cancel()
        bioAnim = null
        profileSig = ""
        super.onPause()
    }

    // =====================================================================
    // SMALL UI HELPERS
    // =====================================================================

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    }

    private fun LinearLayout.add(
        view: View,
        top: Int = 0,
        bottom: Int = 0,
        w: Int = LinearLayout.LayoutParams.MATCH_PARENT,
        h: Int = LinearLayout.LayoutParams.WRAP_CONTENT,
        weight: Float = 0f,
        left: Int = 0,
        right: Int = 0
    ) {
        val params = if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
        params.topMargin = top
        params.bottomMargin = bottom
        params.leftMargin = left
        params.rightMargin = right
        addView(view, params)
    }

    private fun vstack(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun hstack(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun cardBox(): LinearLayout = vstack().apply {
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = Theme.box(Theme.card, Theme.border, dp(14), 0)
        elevation = 0f
    }

    private fun filledBtn(label: String, onClick: () -> Unit): TextView {
        return tv(label, 14f, Theme.onColor(Theme.buy), bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(13), dp(9), dp(13), dp(9))
            background = Theme.box(Theme.buy, Theme.buy, dp(11), 0)
            elevation = 0f
            pressFx()
            setOnClickListener { onClick() }
        }
    }

    private fun outlineBtn(label: String, color: Int = Theme.text, onClick: () -> Unit): TextView {
        return tv(label, 13f, color, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(11), dp(8), dp(11), dp(8))
            background = Theme.box(Theme.surface2, Theme.border, dp(11), 0)
            pressFx()
            setOnClickListener { onClick() }
        }
    }

    private fun statCell(label: String, value: String, valueColor: Int = Theme.text): LinearLayout {
        return vstack().apply {
            add(tv(label, 10f, Theme.muted))
            add(tv(value, 14f, valueColor, bold = true, mono = true), top = dp(2))
        }
    }

    @Suppress("ClickableViewAccessibility")
    private fun View.pressFx() {
        setOnTouchListener { v, ev ->
            if (motionEnabled) {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                }
            }
            false
        }
    }

    private fun balanceSpan(v: Double): CharSequence {
        val t = String.format(Locale.US, "%.3f", v)
        val full = "$t SOL"
        val sp = SpannableString(full)
        val dot = t.indexOf('.')
        if (dot >= 0) sp.setSpan(ForegroundColorSpan(Theme.muted), dot, t.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(ForegroundColorSpan(Theme.muted), t.length, full.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(RelativeSizeSpan(0.40f), t.length, full.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sp
    }

    private fun decodeScaled(uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) sample *= 2
            val real = BitmapFactory.Options()
            real.inSampleSize = sample
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, real) }
        } catch (_: Throwable) {
            null
        }
    }

    private fun pickCoinImage(iv: ImageView, ca: String) {
        pickCa = ca
        pickView = iv
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            startActivityForResult(Intent.createChooser(i, "Choose coin picture"), REQ_COIN_PICK)
        } catch (_: Throwable) {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show()
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_COIN_PICK -> {
                val ca = pickCa
                Thread {
                    val bmp = decodeScaled(uri, 640)
                    mainHandler.post {
                        if (bmp == null) {
                            Toast.makeText(this, "Couldn't open that image", Toast.LENGTH_SHORT).show()
                        } else {
                            CoinImages.setCustom(ca, bmp)
                            pickView?.setImageBitmap(bmp)
                            refreshMainUI(true)
                            Toast.makeText(this, "Coin picture saved", Toast.LENGTH_SHORT).show()
                        }
                    }
                }.start()
            }
            REQ_AVATAR, REQ_BANNER -> {
                val kind = if (requestCode == REQ_AVATAR) "avatar" else "banner"
                Thread {
                    val ok = ProfileStore.saveImage(this, uri, kind)
                    mainHandler.post {
                        if (ok) {
                            refreshMainUI(true)
                            Toast.makeText(this, "Picture saved", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Couldn't use that file (images only, max 15 MB)", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
        }
    }

    private fun sectionTitle(text: String): TextView {
        return tv(text.uppercase(Locale.US), 11f, Theme.accent2, bold = true).apply {
            letterSpacing = 0.13f
            setPadding(dp(4), dp(10), 0, dp(9))
        }
    }

    // =====================================================================
    // TAB 1: TRADE
    // =====================================================================

    private fun buildTradeTab(): LinearLayout {
        val tab = vstack()
        tab.add(tv("Market overview", 21f, Theme.text, bold = true), top = dp(3))
        tab.add(tv("Your simulated portfolio at a glance", 11f, Theme.muted), top = dp(2), bottom = dp(12))

        val balanceBlock = vstack().apply {
            setPadding(dp(2), dp(2), dp(2), dp(8))
        }
        val balanceMeta = hstack()
        balanceMeta.add(tv("PAPER BALANCE", 10f, Theme.muted, bold = true).apply { letterSpacing = 0.10f }, w = 0, weight = 1f)
        balanceMeta.add(tv("● SIMULATED", 9f, Theme.profit, bold = true), w = LinearLayout.LayoutParams.WRAP_CONTENT)
        balanceBlock.add(balanceMeta)
        heroBalance = tv("10.000 SOL", 37f, Theme.text, bold = true, mono = true)
        balanceBlock.add(heroBalance, top = dp(4))
        heroSub = tv("", 10f, Theme.muted, mono = true)
        balanceBlock.add(heroSub, top = dp(3))
        tab.add(balanceBlock, bottom = dp(12))

        val actions = hstack()
        actions.add(filledBtn("Launch paper trader") { startBubbleServiceWithCheck() }, w = 0, weight = 1f, right = dp(8))
        actions.add(outlineBtn("Stop") {
            stopService(Intent(this@MainActivity, OverlayService::class.java))
            mainHandler.postDelayed({ refreshMainUI(false) }, 200)
        }, w = dp(82))
        tab.add(actions, bottom = dp(12))

        val statusRow = hstack().apply {
            setPadding(dp(11), dp(9), dp(11), dp(9))
            background = Theme.box(Theme.surface2, Theme.border, dp(11), 0)
        }
        statusDot = View(this)
        statusRow.add(statusDot, w = dp(8), h = dp(8), right = dp(8))
        statusText = tv("Bubble stopped", 11f, Theme.text, bold = true)
        statusRow.add(statusText, w = 0, weight = 1f)
        statusRow.add(tv("OVERLAY STATUS", 9f, Theme.muted, bold = true), w = LinearLayout.LayoutParams.WRAP_CONTENT)
        tab.add(statusRow, bottom = dp(16))

        val setupHead = hstack()
        setupHead.add(tv("Device permissions", 12f, Theme.text, bold = true), w = 0, weight = 1f)
        val setupToggle = tv("SETUP  +", 9f, Theme.accent2, bold = true)
        setupHead.add(setupToggle, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        val setupDetails = vstack().apply { visibility = View.GONE }
        setupDetails.add(
            tv("Allow display over other apps and background pop-up windows so the trading panel can stay above your coin app.", 11f, Theme.muted),
            top = dp(8), bottom = dp(10)
        )
        setupDetails.add(outlineBtn("1. Display over other apps") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }, bottom = dp(8))
        setupDetails.add(outlineBtn("2. Pop-up windows in background") { openHyperOsPermissions() })
        val setupBlock = vstack().apply {
            setPadding(dp(11), dp(10), dp(11), dp(10))
            background = Theme.box(Theme.card, Theme.border, dp(14), 0)
        }
        setupBlock.add(setupHead)
        setupBlock.add(setupDetails, top = dp(2))
        setupHead.setOnClickListener {
            val opening = setupDetails.visibility != View.VISIBLE
            setupDetails.visibility = if (opening) View.VISIBLE else View.GONE
            setupToggle.text = if (opening) "HIDE  −" else "SETUP  +"
        }
        tab.add(setupBlock, bottom = dp(16))

        val posHeader = hstack()
        posHeader.add(tv("Open positions", 15f, Theme.text, bold = true), w = 0, weight = 1f)
        posHeader.add(tv("LIVE PAPER BAGS", 9f, Theme.muted, bold = true), w = LinearLayout.LayoutParams.WRAP_CONTENT)
        tab.add(posHeader, bottom = dp(8))
        positionsContainer = vstack()
        tab.add(positionsContainer, bottom = dp(16))

        val radarHeader = hstack()
        radarHeader.add(tv("Tracked market", 15f, Theme.text, bold = true), w = 0, weight = 1f)
        radarHeader.add(outlineBtn("Discover  →") { switchTab(2) }, w = dp(102))
        tab.add(radarHeader, bottom = dp(5))
        tab.add(tv("Coins surfaced by wallets you follow", 10f, Theme.muted), bottom = dp(4))
        marketRadarContainer = vstack()
        tab.add(marketRadarContainer, bottom = dp(12))
        tab.add(outlineBtn("View activity  →") { switchTab(1) }, bottom = dp(20))
        return tab
    }

    /** Compact discovery rows using only the tracked-token cache; no market-data logic is changed. */
    private fun refreshMarketRadar() {
        if (!::marketRadarContainer.isInitialized) return
        marketRadarContainer.removeAllViews()
        val tracked = try {
            KolStore.tokens.values.toList()
                .filter { it.valid && it.mc > 0.0 }
                .sortedByDescending { it.mc }
                .take(4)
        } catch (_: java.util.ConcurrentModificationException) {
            emptyList()
        }
        if (tracked.isEmpty()) {
            val hint = if (KolStore.wallets.isEmpty()) {
                "Track wallets in KOLs to build your own smart-money market list."
            } else {
                "Scan your tracked wallets to surface the coins they're trading."
            }
            marketRadarContainer.add(tv(hint, 11f, Theme.muted).apply { setPadding(dp(3), dp(7), dp(3), dp(9)) })
            return
        }
        for ((index, token) in tracked.withIndex()) {
            val row = hstack().apply { setPadding(dp(2), dp(8), dp(2), dp(8)); isClickable = true; isFocusable = true }
            val avatar = Theme.avatar(this, dp(34), dp(1))
            CoinImages.bind(avatar, token.mint, token.sym, token.img)
            row.add(avatar, w = dp(34), h = dp(34), right = dp(10))
            val left = vstack()
            val symbol = token.sym.ifBlank { Formatters.shortCa(token.mint) }
            left.add(tv("$$symbol", 13f, Theme.text, bold = true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            left.add(tv(token.name.ifBlank { Formatters.shortCa(token.mint) }, 10f, Theme.muted).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, top = dp(2))
            row.add(left, w = 0, weight = 1f)
            val right = vstack().apply { gravity = Gravity.END }
            right.add(tv(Formatters.compactUsd(token.mc), 12f, Theme.text, bold = true, mono = true))
            val priceText = formatTokenPrice(token.priceUsd)
            right.add(tv(priceText, 9f, Theme.muted, mono = true), top = dp(2))
            row.add(right, w = LinearLayout.LayoutParams.WRAP_CONTENT)
            row.setOnClickListener {
                val target = if (token.pair.isNotBlank()) token.pair else token.mint
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://dexscreener.com/solana/$target"))) } catch (_: Throwable) {
                    Toast.makeText(this, "Could not open chart", Toast.LENGTH_SHORT).show()
                }
            }
            row.setOnLongClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Solana CA", token.mint))
                Toast.makeText(this, "Contract address copied", Toast.LENGTH_SHORT).show()
                true
            }
            marketRadarContainer.add(row)
            if (index < tracked.lastIndex) marketRadarContainer.add(View(this).apply { setBackgroundColor(Theme.border) }, h = dp(1))
        }
    }

    private fun formatTokenPrice(price: Double): String {
        if (price <= 0.0 || price.isNaN() || price.isInfinite()) return "Price unavailable"
        val decimals = when {
            price >= 1.0 -> 3
            price >= 0.01 -> 5
            price >= 0.0001 -> 7
            else -> 9
        }
        val pattern = "%.${decimals}f"
        val rendered = String.format(Locale.US, pattern, price).trimEnd('0').trimEnd('.')
        return "$$rendered"
    }

    private fun buildFeedTab(): LinearLayout {
        val tab = vstack()
        tab.add(tv("Activity", 21f, Theme.text, bold = true), top = dp(3))
        tab.add(tv("Your paper fills and tracked-wallet moves in one timeline", 11f, Theme.muted), top = dp(2), bottom = dp(10))
        feedSummary = tv("Loading activity…", 10f, Theme.muted, mono = true)
        tab.add(feedSummary, bottom = dp(10))
        tab.add(
            chipRow(
                listOf("all" to "All", "paper" to "My trades", "wallets" to "Tracked wallets", "lessons" to "Thesis notes"),
                { feedFilter }
            ) { feedFilter = it; refreshFeed() },
            bottom = dp(8)
        )
        feedListContainer = vstack()
        tab.add(feedListContainer)
        return tab
    }

    private fun buildPortfolioTab(): LinearLayout {
        val tab = vstack()
        val header = hstack()
        header.add(tv("Portfolio", 21f, Theme.text, bold = true), w = 0, weight = 1f)
        header.add(outlineBtn("Settings") { openSettingsPage() }, w = dp(104))
        tab.add(header, top = dp(3), bottom = dp(12))

        val options = listOf("Overview", "Trades", "Thesis")
        val labels = ArrayList<TextView>()
        val row = hstack()
        for ((i, name) in options.withIndex()) {
            val label = tv(name, 11f, if (i == 0) Theme.text else Theme.muted, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = Theme.box(if (i == 0) Theme.surface2 else Theme.bg, Color.TRANSPARENT, dp(12), 0)
                setOnClickListener { showPortfolioSection(i) }
            }
            labels.add(label)
            row.add(label, w = 0, weight = 1f, right = if (i < options.lastIndex) dp(5) else 0)
        }
        portfolioSectionLabels = labels
        tab.add(row, bottom = dp(10))

        portfolioContent = FrameLayout(this)
        portfolioContent.addView(tabProfile, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        portfolioContent.addView(tabJournal, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        portfolioContent.addView(tabThesis, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        tab.add(portfolioContent)
        showPortfolioSection(0)
        return tab
    }

    private fun showPortfolioSection(section: Int) {
        portfolioSection = section.coerceIn(0, 2)
        val pages = listOf(tabProfile, tabJournal, tabThesis)
        for (i in pages.indices) pages[i].visibility = if (i == portfolioSection) View.VISIBLE else View.GONE
        for (i in portfolioSectionLabels.indices) {
            val selected = i == portfolioSection
            portfolioSectionLabels[i].setTextColor(if (selected) Theme.text else Theme.muted)
            portfolioSectionLabels[i].background = Theme.box(
                if (selected) Theme.surface2 else Theme.bg,
                if (selected) Theme.border else Color.TRANSPARENT,
                dp(12), 0
            )
        }
        if (portfolioSection == 1) refreshMainUI(true)
        if (portfolioSection == 2) refreshThesisList()
    }

    private fun refreshFeed() {
        if (!::feedListContainer.isInitialized) return
        val events = ArrayList<FeedItem>()
        for (trade in TradeRepository.getJournal()) {
            for (fill in trade.fills) {
                events.add(
                    FeedItem(
                        timeMs = fill.timeMs, actor = "You", action = fill.side, symbol = trade.symbol,
                        name = trade.name, imageUrl = trade.imageUrl, ca = trade.ca, amountSol = fill.sol,
                        marketCap = fill.mc, pnlSol = if (fill.side == "SELL") fill.pnlSol else null,
                        body = if (fill.side == "BUY") "Paper entry" else "Paper exit · ${fill.pct.toInt()}% sold",
                        trade = trade
                    )
                )
            }
            ThesisStore.get(trade.ca, trade.openedAtMs)?.let { thesis ->
                val summary = ThesisStore.summary(thesis)
                if (summary.isNotBlank()) events.add(
                    FeedItem(thesis.atMs, "You", "THESIS", trade.symbol, trade.name, trade.imageUrl, trade.ca,
                        0.0, 0.0, body = summary, lesson = true, trade = trade)
                )
            }
        }
        for (position in TradeRepository.getAllPositions()) {
            for (fill in position.fills) {
                events.add(
                    FeedItem(
                        timeMs = fill.timeMs, actor = "You", action = fill.side, symbol = position.symbol,
                        name = position.name, imageUrl = position.imageUrl, ca = position.ca, amountSol = fill.sol,
                        marketCap = fill.mc, pnlSol = if (fill.side == "SELL") fill.pnlSol else null,
                        body = if (fill.side == "BUY") "Paper entry" else "Paper partial exit"
                    )
                )
            }
            ThesisStore.get(position.ca, position.openedAtMs)?.let { thesis ->
                val summary = ThesisStore.summary(thesis)
                if (summary.isNotBlank()) events.add(
                    FeedItem(thesis.atMs, "You", "THESIS", position.symbol, position.name, position.imageUrl,
                        position.ca, 0.0, 0.0, body = summary, lesson = true)
                )
            }
        }
        for (wallet in KolStore.wallets) {
            val byMint = KolStore.fillsOf(wallet.address)
            for ((mint, fills) in byMint) {
                val token = KolStore.tokens[mint]
                for (fill in fills) {
                    events.add(
                        FeedItem(
                            timeMs = fill.ts * 1000L, actor = wallet.label,
                            action = if (fill.buy) "BUY" else "SELL",
                            symbol = token?.sym?.ifBlank { Formatters.shortCa(mint) } ?: Formatters.shortCa(mint),
                            name = token?.name ?: "Tracked token", imageUrl = token?.img ?: "", ca = mint,
                            amountSol = fill.sol, marketCap = 0.0,
                            body = "Tracked wallet activity", walletActivity = true
                        )
                    )
                }
            }
        }

        val sorted = events.sortedByDescending { it.timeMs }
        val shown = when (feedFilter) {
            "paper" -> sorted.filter { !it.walletActivity && !it.lesson }
            "wallets" -> sorted.filter { it.walletActivity }
            "lessons" -> sorted.filter { it.lesson }
            else -> sorted
        }
        val paperCount = sorted.count { !it.walletActivity && !it.lesson }
        val walletCount = sorted.count { it.walletActivity }
        feedSummary.text = "${shown.size} EVENTS  ·  $paperCount PAPER FILLS  ·  $walletCount WALLET SWAPS  ·  ${KolStore.wallets.size} TRACKED WALLETS"
        feedListContainer.removeAllViews()
        if (shown.isEmpty()) {
            val message = when (feedFilter) {
                "paper" -> "No paper fills yet. Your buys and sells will appear here as soon as you trade."
                "wallets" -> if (KolStore.wallets.isEmpty()) "Add wallets in KOLs → Wallets and scan them to build this feed." else "No tracked-wallet swaps stored yet. Scan your wallets to populate the timeline."
                "lessons" -> "No thesis notes yet. Add your reasoning from a trade detail page or the Thesis section in Portfolio."
                else -> "No activity yet. Your paper fills, tracked-wallet swaps and thesis notes will appear here."
            }
            val empty = cardBox()
            empty.add(tv(when (feedFilter) {
                "paper" -> "Your first paper fill will appear here"
                "wallets" -> "Track a wallet to see its activity"
                "lessons" -> "Save a thesis to build your review history"
                else -> "Your feed starts with a trade"
            }, 14f, Theme.text, bold = true))
            empty.add(tv(message, 11f, Theme.muted), top = dp(4), bottom = dp(10))
            val actions = hstack()
            actions.add(filledBtn("Paper trade") { switchTab(0) }, w = 0, weight = 1f, right = dp(7))
            actions.add(outlineBtn("Add wallets") {
                switchTab(3)
                tabKol.openWalletsTab()
            }, w = 0, weight = 1f)
            empty.add(actions)
            feedListContainer.add(empty)
            return
        }
        for (item in shown.take(120)) {
            val row = hstack().apply { setPadding(dp(2), dp(10), dp(2), dp(10)) }
            val avatar = Theme.avatar(this, dp(36), dp(1))
            CoinImages.bind(avatar, item.ca, item.symbol, item.imageUrl)
            row.add(avatar, w = dp(36), h = dp(36), right = dp(10))
            val mid = vstack()
            val symbol = if (item.symbol.startsWith("$")) item.symbol else "$${item.symbol}"
            val verb = when (item.action) { "BUY" -> "bought"; "SELL" -> "sold"; else -> "added a thesis for" }
            mid.add(tv("${item.actor} $verb $symbol", 12f, Theme.text, bold = true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            val detail = if (item.lesson) item.body else {
                buildString {
                    append(if (item.walletActivity) "Tracked wallet" else if (item.action == "BUY") "Paper entry" else "Paper exit")
                    if (item.amountSol > 0.0) append(" · ${Formatters.solPlain(item.amountSol)}")
                    if (item.marketCap > 0.0) append(" · ${Formatters.compactUsd(item.marketCap)} MC")
                }
            }
            mid.add(tv(detail, 10f, Theme.muted).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }, top = dp(3))
            row.add(mid, w = 0, weight = 1f)
            val right = vstack().apply { gravity = Gravity.END }
            item.pnlSol?.let { right.add(tv(Formatters.solSigned(it), 10f, Theme.pnlColor(it), bold = true, mono = true)) }
            right.add(tv(Formatters.dateTime(item.timeMs), 9f, Theme.muted, mono = true), top = dp(3))
            row.add(right, w = LinearLayout.LayoutParams.WRAP_CONTENT)
            row.setOnClickListener {
                if (item.trade != null) showTradeDetail(item.trade)
                else if (item.ca.isNotBlank()) {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Solana CA", item.ca))
                    Toast.makeText(this, "Contract address copied", Toast.LENGTH_SHORT).show()
                }
            }
            feedListContainer.add(row)
            feedListContainer.add(View(this).apply { setBackgroundColor(Theme.border) }, h = dp(1))
        }
        if (shown.size > 120) feedListContainer.add(tv("Showing the latest 120 events", 10f, Theme.muted).apply { setPadding(0, dp(10), 0, dp(10)) })
    }

    private fun openSettingsPage() {
        settingsOpen = true
        for (i in 0..4) tabViewAt(i).visibility = View.GONE
        tabSettings.visibility = View.VISIBLE
        if (::headerBalanceText.isInitialized) headerBalanceText.visibility = View.GONE
        settingsButton.setImageDrawable(LineIcon("settings", Theme.accent2))
        settingsButton.contentDescription = "Close settings"
        if (::navBarView.isInitialized) navBarView.visibility = View.GONE
        if (::bodyScroll.isInitialized) bodyScroll.scrollTo(0, 0)
    }

    private fun closeSettingsPage() {
        settingsOpen = false
        tabSettings.visibility = View.GONE
        if (::headerBalanceText.isInitialized) headerBalanceText.visibility = View.VISIBLE
        settingsButton.setImageDrawable(LineIcon("settings", Theme.muted))
        if (::navBarView.isInitialized) navBarView.visibility = View.VISIBLE
        switchTab(currentTabIdx.coerceIn(0, 4))
    }

    private fun openHyperOsPermissions() {
        var launched = false
        try {
            val miuiIntent = Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                putExtra("extra_pkgname", packageName)
            }
            startActivity(miuiIntent)
            launched = true
        } catch (_: Throwable) {
        }
        if (!launched) {
            try {
                val miuiIntent2 = Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                    setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
                    putExtra("extra_pkgname", packageName)
                }
                startActivity(miuiIntent2)
                launched = true
            } catch (_: Throwable) {
            }
        }
        if (!launched) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
    }

    private fun buildPositionCard(pos: OpenPosition): View {
        val pnlSol = TradeRepository.computeUnrealizedPnlSol(pos, pos.lastPriceUsd)
        val multX = if (pos.entryMc > 0.0) (pos.lastMc / pos.entryMc) else 1.0
        val hasSells = pos.fills.any { it.side == "SELL" }

        val card = hstack().apply {
            setPadding(dp(4), dp(9), dp(4), dp(9))
        }
        val icon = Theme.avatar(this, dp(38), dp(1))
        CoinImages.bind(icon, pos.ca, pos.symbol, pos.imageUrl)
        card.add(icon, w = dp(38), h = dp(38), right = dp(10))

        val mid = vstack()
        val sym = if (pos.symbol.startsWith("$")) pos.symbol else "$${pos.symbol}"
        mid.add(tv(sym, 14f, Theme.text, bold = true))
        mid.add(
            tv(
                "${Formatters.compactUsd(pos.entryMc)} → ${Formatters.compactUsd(pos.lastMc)}  (${Formatters.multX(multX)})",
                11f, Theme.muted, mono = true
            ),
            top = dp(2)
        )
        val sub = if (hasSells) {
            "${pos.remainingPct.roundToInt()}% left • realized ${Formatters.solSigned(pos.realizedPnlSol)}"
        } else {
            "${pos.remainingPct.roundToInt()}% bag • ${Formatters.solPlain(pos.initialSolInvested)} in"
        }
        mid.add(tv(sub, 10f, Theme.muted, mono = true), top = dp(2))
        ThesisStore.get(pos.ca, pos.openedAtMs)?.let { th ->
            val line = ThesisStore.summary(th)
            if (line.isNotEmpty()) {
                mid.add(
                    tv(line, 10f, Theme.muted).apply {
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                    },
                    top = dp(2)
                )
            }
        }
        card.add(mid, w = 0, weight = 1f)

        card.add(
            tv(Formatters.solSigned(pnlSol), 13f, Theme.pnlColor(pnlSol), bold = true, mono = true).apply {
                gravity = Gravity.END
            },
            w = LinearLayout.LayoutParams.WRAP_CONTENT
        )
        return card
    }

    // =====================================================================
    // TAB 2: JOURNAL
    // =====================================================================

    private fun buildJournalTab(): LinearLayout {
        val tab = vstack()

        tab.add(tv("Performance", 23f, Theme.text, bold = true), top = dp(4))
        tab.add(tv("Your trading history, measured without the noise.", 11f, Theme.muted), top = dp(2), bottom = dp(12))
        val statsCard = cardBox()
        statsCard.add(tv("NET REALIZED PNL", 10f, Theme.accent2, bold = true).apply { letterSpacing = 0.12f })
        journalNetPnl = tv("+0.000 SOL", 30f, Theme.text, bold = true, mono = true)
        statsCard.add(journalNetPnl, top = dp(2))
        journalNetSub = tv("Invested 0.000 SOL  •  Returned 0.000 SOL", 11f, Theme.muted, mono = true)
        statsCard.add(journalNetSub, top = dp(2), bottom = dp(14))
        journalStatsRow = hstack().apply { weightSum = 4f }
        statsCard.add(journalStatsRow, bottom = dp(14))

        val actions = hstack()
        actions.add(outlineBtn("Export CSV") { shareJournalCsv() }, w = 0, weight = 1f, right = dp(8))
        actions.add(outlineBtn("Clear journal", Theme.loss) { confirmClearJournal() }, w = 0, weight = 1f)
        statsCard.add(actions)
        tab.add(statsCard, bottom = dp(12))

        // ---- Filters ----
        tab.add(sectionTitle("FILTERS"))
        val resultOpts = ArrayList<Pair<String, String>>()
        resultOpts.add("all" to "All")
        resultOpts.add("win" to "Wins")
        resultOpts.add("loss" to "Losses")
        for (tg in ThesisStore.tags) resultOpts.add("tag:$tg" to tg)
        tab.add(chipRow(resultOpts, { journalFilter }) { journalFilter = it; refreshMainUI(true) }, bottom = dp(8))
        tab.add(
            chipRow(
                listOf("all" to "All time", "24h" to "24 hours", "7d" to "7 days", "30d" to "30 days"),
                { journalRange }
            ) { journalRange = it; refreshMainUI(true) },
            bottom = dp(12)
        )

        // ---- Stats (follow the filters) ----
        val insights = cardBox()
        insightsTitle = tv("Stats", 13f, Theme.text, bold = true)
        insights.add(insightsTitle, bottom = dp(10))
        insightsRow1 = insetRow()
        insights.add(insightsRow1, bottom = dp(8))
        insightsRow2 = insetRow()
        insights.add(insightsRow2, bottom = dp(8))
        insights.add(tv("BY THESIS TAG", 10f, Theme.muted, bold = true), top = dp(6), bottom = dp(2))
        insightsTags = vstack()
        insights.add(insightsTags)
        tab.add(insights, bottom = dp(12))

        tab.add(sectionTitle("FINISHED TRADES"))
        journalListContainer = vstack()
        tab.add(journalListContainer)
        tab.visibility = View.GONE
        return tab
    }

    private fun confirmClearJournal() {
        AlertDialog.Builder(this)
            .setTitle("Clear journal?")
            .setMessage("This deletes every finished trade. Open positions are kept.")
            .setPositiveButton("Clear") { _, _ ->
                TradeRepository.clearJournal()
                refreshMainUI(true)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun buildJournalCard(t: ClosedTradeLog): View {
        val card = vstack().apply {
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = Theme.box(Theme.card, Theme.border, dp(14), 0)
            elevation = 0f
            pressFx()
            setOnClickListener { showTradeDetail(t) }
        }

        val top = hstack()
        val icon = Theme.avatar(this, dp(46), dp(1))
        CoinImages.bind(icon, t.ca, t.symbol, t.imageUrl)
        top.add(icon, w = dp(46), h = dp(46), right = dp(12))

        val mid = vstack()
        val sym = if (t.symbol.startsWith("$")) t.symbol else "$${t.symbol}"
        mid.add(tv(t.name, 15f, Theme.text, bold = true).apply { maxLines = 1 })
        mid.add(tv("$sym  •  ${Formatters.shortCa(t.ca)}", 11f, Theme.muted, mono = true), top = dp(2))
        top.add(mid, w = 0, weight = 1f)

        val right = vstack().apply { gravity = Gravity.END }
        right.add(
            tv(Formatters.solSigned(t.pnlSol), 14f, Theme.pnlColor(t.pnlSol), bold = true, mono = true)
                .apply { gravity = Gravity.END }
        )
        right.add(
            tv(Formatters.pctSigned1(t.roiPct), 11f, Theme.pnlColor(t.pnlSol), mono = true)
                .apply { gravity = Gravity.END },
            top = dp(2)
        )
        top.add(right, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        card.add(top)

        val line = View(this).apply { setBackgroundColor(Theme.border) }
        card.add(line, top = dp(12), bottom = dp(12), h = dp(1))

        val stats = hstack().apply {
            weightSum = 3f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.inset(dp(14))
        }
        stats.add(statCell("Invested", Formatters.solPlain(t.solIn)), w = 0, weight = 1f)
        stats.add(statCell("Returned", Formatters.solPlain(t.solOut)), w = 0, weight = 1f)
        stats.add(statCell("Exit", Formatters.multX(t.multipleX), Theme.pnlColor(t.pnlSol)), w = 0, weight = 0.8f)
        card.add(stats)

        card.add(
            tv(
                "Bought ${Formatters.compactUsd(t.entryMc)}  →  Sold ${Formatters.compactUsd(t.avgExitMc)}  •  ${t.buyCount} buy / ${t.sellCount} sell",
                10f, Theme.muted, mono = true
            ),
            top = dp(10)
        )
        ThesisStore.get(t.ca, t.openedAtMs)?.let { th ->
            val line = ThesisStore.summary(th)
            if (line.isNotEmpty()) {
                card.add(
                    tv(line, 11f, Theme.muted).apply {
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                    },
                    top = dp(8)
                )
            }
        }
        return card
    }

    private fun showTradeDetail(t: ClosedTradeLog) {
        detailContent.removeAllViews()

        val bar = hstack()
        bar.add(outlineBtn("←  Back") { hideTradeDetail() }, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        bar.add(View(this), w = 0, weight = 1f)
        bar.add(outlineBtn("Delete", Theme.loss) {
            AlertDialog.Builder(this)
                .setTitle("Delete this trade?")
                .setMessage("It will be removed from the journal.")
                .setPositiveButton("Delete") { _, _ ->
                    TradeRepository.deleteTrade(t.id)
                    hideTradeDetail()
                    refreshMainUI(true)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        detailContent.add(bar, bottom = dp(14))

        // Header
        val head = hstack()
        val icon = Theme.avatar(this, dp(64), dp(1))
        val imgNote = tv("Looking for the coin picture...", 10f, Theme.muted, mono = true)
        CoinImages.bind(icon, t.ca, t.symbol, t.imageUrl) { bmp ->
            imgNote.text = if (bmp != null) {
                "Picture: ${CoinImages.sourceOf(t.ca)}  •  tap it to change"
            } else {
                "No picture found  •  tap the circle to choose one"
            }
        }
        icon.setOnClickListener { pickCoinImage(icon, t.ca) }
        head.add(icon, w = dp(64), h = dp(64), right = dp(14))
        val headText = vstack()
        val sym = if (t.symbol.startsWith("$")) t.symbol else "$${t.symbol}"
        headText.add(tv(t.name, 20f, Theme.text, bold = true))
        headText.add(tv(sym, 13f, Theme.muted, bold = true, mono = true), top = dp(2))
        headText.add(imgNote, top = dp(6))
        head.add(headText, w = 0, weight = 1f)
        detailContent.add(head, bottom = dp(14))

        // Shareable PnL card (reads this trade only; changes nothing in the journal)
        detailContent.add(filledBtn("Create PnL card") {
            startActivity(
                Intent(this@MainActivity, CardActivity::class.java)
                    .putExtra(CardActivity.EXTRA_TRADE_ID, t.id)
            )
        }, bottom = dp(12))

        // Trade replay (plays the trade back: price path, your buys and sells)
        detailContent.add(outlineBtn("Replay trade") {
            startActivity(
                Intent(this@MainActivity, ReplayActivity::class.java)
                    .putExtra(ReplayActivity.EXTRA_TRADE_ID, t.id)
            )
        }, bottom = dp(12))

        // Thesis (why you took the trade)
        detailContent.add(
            buildThesisCard(t.ca, t.openedAtMs) {
                showTradeDetail(t)
                refreshMainUI(true)
            },
            bottom = dp(12)
        )

        // Big PnL card
        val pnlCard = cardBox()
        pnlCard.add(tv("Net PnL", 11f, Theme.muted))
        pnlCard.add(
            tv(Formatters.solSigned(t.pnlSol), 30f, Theme.pnlColor(t.pnlSol), bold = true, mono = true),
            top = dp(2)
        )
        pnlCard.add(
            tv(
                "${Formatters.pctSigned1(t.roiPct)}  •  you put in ${Formatters.solPlain(t.solIn)} and took out ${Formatters.solPlain(t.solOut)}",
                11f, Theme.muted, mono = true
            ),
            top = dp(4)
        )
        detailContent.add(pnlCard, bottom = dp(12))

        // CA card
        val caCard = cardBox()
        caCard.add(tv("Contract address", 11f, Theme.muted))
        caCard.add(tv(t.ca, 12f, Theme.text, mono = true), top = dp(4), bottom = dp(10))
        caCard.add(outlineBtn("Copy CA") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Solana CA", t.ca))
            Toast.makeText(this, "CA copied", Toast.LENGTH_SHORT).show()
        })
        detailContent.add(caCard, bottom = dp(12))

        // Analysis grid
        val captured = if (t.peakMc > 0.0) (t.avgExitMc / t.peakMc) * 100.0 else 0.0
        val grid = cardBox()
        fun gridRow(l1: String, v1: String, c1: Int, l2: String, v2: String, c2: Int) {
            val row = hstack().apply { weightSum = 2f }
            row.add(statCell(l1, v1, c1), w = 0, weight = 1f)
            row.add(statCell(l2, v2, c2), w = 0, weight = 1f)
            grid.add(row, bottom = dp(14))
        }
        gridRow("Invested", Formatters.solPlain(t.solIn), Theme.text, "Returned", Formatters.solPlain(t.solOut), Theme.text)
        gridRow("Return", Formatters.multX(t.returnX), Theme.pnlColor(t.pnlSol), "ROI", Formatters.pctSigned1(t.roiPct), Theme.pnlColor(t.pnlSol))
        gridRow("Bought at (MC)", Formatters.compactUsd(t.entryMc), Theme.text, "Avg sold at (MC)", Formatters.compactUsd(t.avgExitMc), Theme.text)
        gridRow("Peak MC while holding", Formatters.compactUsd(t.peakMc), Theme.text, "Peak multiple", Formatters.multX(t.peakX), Theme.text)
        gridRow("Exit multiple", Formatters.multX(t.multipleX), Theme.text, "Exit vs peak", String.format("%.0f%%", captured), Theme.text)
        gridRow("Held for", Formatters.duration(t.holdDurationMs), Theme.text, "Buys / Sells", "${t.buyCount} / ${t.sellCount}", Theme.text)
        grid.add(tv("Opened ${Formatters.dateTime(t.openedAtMs)}", 10f, Theme.muted, mono = true))
        grid.add(tv("Closed ${Formatters.dateTime(t.closedAtMs)}", 10f, Theme.muted, mono = true), top = dp(2))
        detailContent.add(grid, bottom = dp(12))

        // Timeline of buys & sells
        detailContent.add(sectionTitle("BUYS & SELLS"))
        val timeline = cardBox()
        for ((idx, f) in t.fills.withIndex()) {
            val row = hstack().apply { setPadding(0, dp(8), 0, dp(8)) }
            val isBuy = f.side == "BUY"

            val tag = tv(if (isBuy) "BUY" else "SELL", 11f, if (isBuy) Theme.onColor(Theme.buy) else Theme.sell, bold = true, mono = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(4), dp(8), dp(4))
                background = if (isBuy) Theme.box(Theme.buy, Theme.buy, dp(8), 0)
                else Theme.box(Theme.bg, Theme.sell, dp(8), dp(1))
            }
            row.add(tag, w = dp(52), right = dp(12))

            val mid = vstack()
            mid.add(tv("MC ${Formatters.compactUsd(f.mc)}", 13f, Theme.text, bold = true, mono = true))
            val off = max(0L, f.timeMs - t.openedAtMs)
            val offText = if (off < 1000L) "T+0s" else "T+${Formatters.duration(off)}"
            mid.add(tv("$offText • ${Formatters.dateTime(f.timeMs)}", 10f, Theme.muted, mono = true), top = dp(2))
            row.add(mid, w = 0, weight = 1f)

            val right = vstack().apply { gravity = Gravity.END }
            if (isBuy) {
                right.add(tv("-${Formatters.solPlain(f.sol)}", 12f, Theme.text, bold = true, mono = true).apply { gravity = Gravity.END })
                right.add(tv("spent", 10f, Theme.muted, mono = true).apply { gravity = Gravity.END }, top = dp(2))
            } else {
                right.add(tv("+${Formatters.solPlain(f.sol)}", 12f, Theme.text, bold = true, mono = true).apply { gravity = Gravity.END })
                right.add(
                    tv(
                        "${f.pct.roundToInt()}% sold • ${Formatters.solSigned(f.pnlSol)}",
                        10f, Theme.pnlColor(f.pnlSol), mono = true
                    ).apply { gravity = Gravity.END },
                    top = dp(2)
                )
            }
            row.add(right, w = LinearLayout.LayoutParams.WRAP_CONTENT)
            timeline.add(row)

            if (idx < t.fills.size - 1) {
                timeline.add(View(this).apply { setBackgroundColor(Theme.border) }, h = dp(1))
            }
        }
        detailContent.add(timeline)

        detailLayer.visibility = View.VISIBLE
        detailLayer.scrollTo(0, 0)
    }

    private fun hideTradeDetail() {
        detailLayer.visibility = View.GONE
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (::detailLayer.isInitialized && detailLayer.visibility == View.VISIBLE) {
            hideTradeDetail()
        } else if (settingsOpen) {
            closeSettingsPage()
        } else if (currentTabIdx == 3 && ::tabKol.isInitialized && tabKol.onBack()) {
            // closed a leaderboard detail page
        } else if (currentTabIdx == 2 && ::tabSearch.isInitialized && tabSearch.onBack()) {
            // closed a coin detail page
        } else {
            super.onBackPressed()
        }
    }

    @Suppress("DEPRECATION")
    private fun applyLightBarsIfNeeded() {
        try {
            if (Theme.onColor(Theme.bg) == Color.BLACK) {
                val flags = window.decorView.systemUiVisibility or
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                window.decorView.systemUiVisibility = flags
            }
        } catch (_: Throwable) {
        }
    }

    // =====================================================================
    // TAB: PROFILE
    // =====================================================================

    private fun ovalClip(): ViewOutlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setOval(0, 0, view.width, view.height)
        }
    }

    private fun roundClip(radiusPx: Int): ViewOutlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx.toFloat())
        }
    }

    /** Balance number rolls to its new value instead of jumping. */
    private fun setHeroBalance(v: Double) {
        heroAnim?.cancel()
        val from = heroShown
        if (from.isNaN() || abs(from - v) < 1e-9) {
            heroShown = v
            heroBalance.text = balanceSpan(v)
            return
        }
        heroAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val x = from + (v - from) * (it.animatedValue as Float)
                heroShown = x
                heroBalance.text = balanceSpan(x)
            }
            start()
        }
    }

    private fun setProfilePnl(v: Double) {
        profPnlAnim?.cancel()
        val from = profPnlShown
        if (abs(from - v) < 1e-9) {
            profPnlShown = v
            profNetPnl.text = Formatters.solSigned(v)
            profNetPnl.setTextColor(Theme.pnlColor(v))
            return
        }
        profPnlAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 650
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val x = from + (v - from) * (it.animatedValue as Float)
                profPnlShown = x
                profNetPnl.text = Formatters.solSigned(x)
                profNetPnl.setTextColor(Theme.pnlColor(x))
            }
            start()
        }
    }

    private fun insetRow(): LinearLayout = hstack().apply {
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = Theme.inset(dp(14))
    }

    private fun buildProfileTab(): LinearLayout {
        val tab = vstack()
        tab.visibility = View.GONE
        tab.add(tv("Your profile", 24f, Theme.text, bold = true), top = dp(4))
        tab.add(tv("Your trading identity and performance record.", 11f, Theme.muted), top = dp(3), bottom = dp(12))

        val header = FrameLayout(this)

        // Banner (picture, GIF or animated WebP). Gradient shows until you add one.
        val bannerBox = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Theme.mix(Theme.card, Theme.accent, 0.32f), Theme.card, Theme.mix(Theme.bg, Theme.accent, 0.08f))
            )
            outlineProvider = roundClip(dp(22))
            clipToOutline = true
            elevation = dp(4).toFloat()
            pressFx()
            setOnClickListener { showProfileEditor() }
        }
        profBannerImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        bannerBox.addView(
            profBannerImg,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        header.addView(bannerBox, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(86)))

        // Profile picture with a ring that overlaps the banner.
        val ring = FrameLayout(this).apply {
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = Theme.circle(Theme.bg, Theme.border, dp(1))
            elevation = dp(8).toFloat()
            pressFx()
            setOnClickListener { showProfileEditor() }
        }
        val avatarBox = FrameLayout(this).apply {
            background = Theme.circle(Theme.mix(Theme.card, Theme.text, 0.2f), Color.TRANSPARENT, 0)
            outlineProvider = ovalClip()
            clipToOutline = true
        }
        profLetter = tv("T", 26f, Theme.text, bold = true).apply { gravity = Gravity.CENTER }
        avatarBox.addView(
            profLetter,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        profAvatarImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        avatarBox.addView(
            profAvatarImg,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        ring.addView(avatarBox, FrameLayout.LayoutParams(dp(62), dp(62)))
        val ringLp = FrameLayout.LayoutParams(dp(70), dp(70))
        ringLp.topMargin = dp(49)
        ringLp.leftMargin = dp(16)
        header.addView(ring, ringLp)

        val edit = outlineBtn("Edit profile") { showProfileEditor() }
        val editLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.END or Gravity.TOP
        )
        editLp.topMargin = dp(91)
        editLp.rightMargin = dp(2)
        header.addView(edit, editLp)
        tab.add(header)

        profName = tv(ProfileStore.name, 22f, Theme.text, bold = true)
        tab.add(profName, top = dp(8), left = dp(4))
        profBio = tv("", 13f, Theme.muted).apply { setLineSpacing(0f, 1.15f) }
        tab.add(profBio, top = dp(6), bottom = dp(16), left = dp(4), right = dp(4))

        val card = cardBox()
        card.add(tv("Net PnL", 11f, Theme.muted))
        profNetPnl = tv("+0.000 SOL", 34f, Theme.text, bold = true, mono = true)
        card.add(profNetPnl, top = dp(2))
        profNetSub = tv("", 11f, Theme.muted, mono = true)
        card.add(profNetSub, top = dp(2), bottom = dp(14))
        profRow1 = insetRow()
        card.add(profRow1, bottom = dp(8))
        profRow2 = insetRow()
        card.add(profRow2, bottom = dp(8))
        profRow3 = insetRow()
        card.add(profRow3)
        tab.add(card, bottom = dp(12))

        // ---- Equity curve ----
        val eq = cardBox()
        val eqHead = hstack()
        eqHead.add(tv("Equity curve", 13f, Theme.text, bold = true), w = 0, weight = 1f)
        eq.add(eqHead)
        eqValue = tv("+0.000 SOL", 26f, Theme.text, bold = true, mono = true)
        eq.add(eqValue, top = dp(6))
        eqSub = tv("", 11f, Theme.muted, mono = true)
        eq.add(eqSub, top = dp(2), bottom = dp(10))
        eq.add(
            chipRow(
                listOf("24h" to "24h", "7d" to "7 days", "30d" to "30 days", "all" to "All"),
                { eqRange }
            ) { eqRange = it; eqSig = ""; refreshEquity(true) },
            bottom = dp(10)
        )
        equityView = EquityView(this)
        eq.add(equityView, h = dp(190))
        eqRow1 = insetRow()
        eq.add(eqRow1, top = dp(12), bottom = dp(8))
        eqRow2 = insetRow()
        eq.add(eqRow2)
        tab.add(eq, bottom = dp(12))

        val days = cardBox()
        days.add(tv("PnL per day", 13f, Theme.text, bold = true))
        days.add(tv("Last 14 days, net SOL", 11f, Theme.muted), top = dp(2), bottom = dp(8))
        dayBarsView = DayBarsView(this)
        days.add(dayBarsView, h = dp(120))
        tab.add(days, bottom = dp(12))
        return tab
    }

    private fun refreshEquity(animate: Boolean) {
        if (!::equityView.isInitialized) return
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val minT = when (eqRange) {
            "24h" -> now - day
            "7d" -> now - 7L * day
            "30d" -> now - 30L * day
            else -> 0L
        }
        val trades = eqLogs.filter { it.closedAtMs >= minT }.sortedBy { it.closedAtMs }
        val pts = ArrayList<EquityView.Pt>()
        pts.add(EquityView.Pt(0.0, "start"))
        var cum = 0.0
        var peak = 0.0
        var maxDd = 0.0
        var gw = 0.0
        var gl = 0.0
        for ((i, t) in trades.withIndex()) {
            cum += t.pnlSol
            if (t.pnlSol >= 0) gw += t.pnlSol else gl += -t.pnlSol
            if (cum > peak) peak = cum
            if (peak - cum > maxDd) maxDd = peak - cum
            val sym = if (t.symbol.startsWith("$")) t.symbol else "$" + t.symbol
            pts.add(EquityView.Pt(cum, "#${i + 1} $sym"))
        }
        eqValue.text = Formatters.solSigned(cum)
        eqValue.setTextColor(Theme.pnlColor(cum))
        eqSub.text = "${trades.size} trades  •  net PnL in this range"
        equityView.setData(pts, animate)

        // PnL per day inside the range
        val fmt = java.text.SimpleDateFormat("yyyyMMdd", Locale.US)
        val sums = HashMap<String, Double>()
        for (t in trades) {
            val k = fmt.format(java.util.Date(t.closedAtMs))
            sums[k] = (sums[k] ?: 0.0) + t.pnlSol
        }
        var bestDay: Double? = null
        var worstDay: Double? = null
        for (v in sums.values) {
            if (bestDay == null || v > bestDay) bestDay = v
            if (worstDay == null || v < worstDay) worstDay = v
        }
        val avg = if (trades.isNotEmpty()) cum / trades.size else 0.0
        val pf = if (gl > 1e-12) String.format(Locale.US, "%.2f", gw / gl) else if (gw > 0) "∞" else "-"

        eqRow1.removeAllViews()
        eqRow1.weightSum = 3f
        eqRow1.add(
            statCell("Max drawdown", if (maxDd > 0) "-" + String.format(Locale.US, "%.3f", maxDd) else "0.000", if (maxDd > 0) Theme.loss else Theme.text),
            w = 0, weight = 1f
        )
        eqRow1.add(
            statCell("Best day", bestDay?.let { Formatters.solSigned(it) } ?: "-", bestDay?.let { Theme.pnlColor(it) } ?: Theme.text),
            w = 0, weight = 1f
        )
        eqRow1.add(
            statCell("Worst day", worstDay?.let { Formatters.solSigned(it) } ?: "-", worstDay?.let { Theme.pnlColor(it) } ?: Theme.text),
            w = 0, weight = 1f
        )
        eqRow2.removeAllViews()
        eqRow2.weightSum = 3f
        eqRow2.add(statCell("Avg / trade", Formatters.solSigned(avg), Theme.pnlColor(avg)), w = 0, weight = 1f)
        eqRow2.add(statCell("Profit factor", pf), w = 0, weight = 1f)
        eqRow2.add(statCell("Trades", "${trades.size}"), w = 0, weight = 1f)

        // last 14 days bars (always the last 14 calendar days, regardless of range chips)
        val cal = java.util.Calendar.getInstance()
        val daySums = HashMap<String, Double>()
        for (t in eqLogs) {
            val k = fmt.format(java.util.Date(t.closedAtMs))
            daySums[k] = (daySums[k] ?: 0.0) + t.pnlSol
        }
        val bars = ArrayList<DayBarsView.Bar>()
        for (back in 13 downTo 0) {
            val c2 = java.util.Calendar.getInstance()
            c2.timeInMillis = cal.timeInMillis
            c2.add(java.util.Calendar.DAY_OF_YEAR, -back)
            val k = fmt.format(c2.time)
            bars.add(DayBarsView.Bar(c2.get(java.util.Calendar.DAY_OF_MONTH).toString(), daySums[k] ?: 0.0))
        }
        dayBarsView.setData(bars)
    }

    private fun loadProfileImage(kind: String, target: ImageView, maxSide: Int, onDone: (Boolean) -> Unit) {
        if (!ProfileStore.hasImage(kind)) {
            target.setImageDrawable(null)
            onDone(false)
            return
        }
        Thread {
            val d = ProfileStore.loadDrawable(this, kind, maxSide)
            mainHandler.post {
                target.setImageDrawable(d)
                ProfileStore.startIfAnimated(d)
                onDone(d != null)
            }
        }.start()
    }

    private fun refreshProfile(
        force: Boolean, balance: Double, totalPnl: Double, totalIn: Double, totalOut: Double,
        logs: List<ClosedTradeLog>, wins: Int, bestX: Double, avgHold: Long, winRate: Int, openCount: Int
    ) {
        val bio = ProfileStore.bio
        val effect = ProfileStore.effect
        val sig = ProfileStore.name + "\u0001" + bio + "\u0001" + effect
        if (force || sig != profileSig) {
            profileSig = sig
            profName.text = ProfileStore.name
            profLetter.text = ProfileStore.name.trim().take(1).uppercase().ifEmpty { "T" }
            bioAnim?.cancel()
            if (bio.isEmpty()) {
                profBio.paint.shader = null
                profBio.setShadowLayer(0f, 0f, 0f, 0)
                profBio.setTextColor(Theme.muted)
                profBio.text = "No bio yet. Tap Edit profile to add one."
                bioAnim = null
            } else {
                bioAnim = BioEffects.apply(profBio, bio, effect)
            }
        }
        if (imagesVersion != ProfileStore.version) {
            imagesVersion = ProfileStore.version
            loadProfileImage("avatar", profAvatarImg, 512) { has ->
                profLetter.visibility = if (has) View.GONE else View.VISIBLE
            }
            loadProfileImage("banner", profBannerImg, 1080) { }
        }

        setProfilePnl(totalPnl)
        profNetSub.text = "Invested ${Formatters.solPlain(totalIn)}  •  Returned ${Formatters.solPlain(totalOut)}"
        val roi = if (totalIn > 0.0) totalPnl / totalIn * 100.0 else 0.0

        profRow1.removeAllViews()
        profRow1.weightSum = 4f
        profRow1.add(statCell("Win rate", "$winRate%"), w = 0, weight = 1f)
        profRow1.add(statCell("Trades", "${logs.size}"), w = 0, weight = 1f)
        profRow1.add(statCell("Best X", Formatters.multX(bestX)), w = 0, weight = 1f)
        profRow1.add(statCell("Avg hold", Formatters.duration(avgHold)), w = 0, weight = 1.2f)

        profRow2.removeAllViews()
        profRow2.weightSum = 3f
        profRow2.add(statCell("Wins / Losses", "${wins}W / ${logs.size - wins}L"), w = 0, weight = 1f)
        profRow2.add(statCell("ROI", Formatters.pctSigned1(roi), Theme.pnlColor(totalPnl)), w = 0, weight = 1f)
        profRow2.add(statCell("Open now", "$openCount"), w = 0, weight = 1f)

        val best = logs.maxByOrNull { it.pnlSol }
        val bestTxt = if (best == null) "-" else {
            val sym = if (best.symbol.startsWith("$")) best.symbol else "$${best.symbol}"
            "$sym ${Formatters.solSigned(best.pnlSol)}"
        }
        val bestCell = statCell("Best trade", bestTxt, if (best != null) Theme.pnlColor(best.pnlSol) else Theme.text)
        (bestCell.getChildAt(1) as TextView).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        profRow3.removeAllViews()
        profRow3.weightSum = 2.3f
        profRow3.add(statCell("Paper balance", Formatters.solPlain(balance)), w = 0, weight = 1f)
        profRow3.add(bestCell, w = 0, weight = 1.3f)

        eqLogs = logs
        val esig = "${logs.size}:${logs.firstOrNull()?.id ?: ""}:${logs.lastOrNull()?.id ?: ""}:$eqRange"
        if (force || esig != eqSig) {
            val first = eqSig.isEmpty()
            eqSig = esig
            refreshEquity(first || currentTabIdx == 4)
        }
    }

    private fun pickProfileImage(req: Int) {
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            val title = if (req == REQ_AVATAR) "Choose profile picture" else "Choose banner"
            startActivityForResult(Intent.createChooser(i, title), req)
        } catch (_: Throwable) {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showProfileEditor() {
        val box = vstack().apply { setPadding(dp(18), dp(16), dp(18), dp(14)) }
        box.add(tv("Edit profile", 17f, Theme.text, bold = true), bottom = dp(4))

        val nameIn = addLabeledInput(box, "Name", ProfileStore.name, false)
        nameIn.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(24))
        nameIn.setSingleLine(true)

        val bioIn = addLabeledInput(box, "Bio (max 160 characters)", ProfileStore.bio, false)
        bioIn.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(160))
        bioIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        bioIn.setSingleLine(false)
        bioIn.minLines = 3
        bioIn.maxLines = 6
        bioIn.gravity = Gravity.TOP or Gravity.START
        bioIn.typeface = Typeface.DEFAULT

        box.add(tv("Bio animation", 11f, Theme.muted), top = dp(14), bottom = dp(6))
        var selected = ProfileStore.effect
        var previewAnim: ValueAnimator? = null
        val previewTv = tv("", 13f, Theme.muted).apply {
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.inset(dp(12))
        }
        val chips = ArrayList<TextView>()
        fun styleChips() {
            for (i in chips.indices) {
                val on = ProfileStore.effectKeys[i] == selected
                chips[i].setTextColor(if (on) Theme.onColor(Theme.accent) else Theme.muted)
                chips[i].background = Theme.chip(on, dp(14))
            }
        }
        fun restartPreview() {
            previewAnim?.cancel()
            val t = bioIn.text.toString().trim().ifEmpty { "Your bio looks like this" }
            previewAnim = BioEffects.apply(previewTv, t, selected)
        }
        val chipRow = hstack().apply { weightSum = 4f }
        for (i in ProfileStore.effectKeys.indices) {
            val chip = tv(ProfileStore.effectLabels[i], 11f, Theme.text, bold = true).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(dp(4), dp(10), dp(4), dp(10))
                pressFx()
                setOnClickListener {
                    selected = ProfileStore.effectKeys[i]
                    styleChips()
                    restartPreview()
                }
            }
            chips.add(chip)
            chipRow.add(chip, w = 0, weight = 1f, right = if (i < 3) dp(6) else 0)
        }
        styleChips()
        box.add(chipRow)
        box.add(previewTv, top = dp(8))
        restartPreview()

        box.add(tv("Pictures (GIF and animated WebP stay animated)", 11f, Theme.muted), top = dp(14), bottom = dp(6))
        val picRow = hstack()
        picRow.add(outlineBtn("Profile picture") { pickProfileImage(REQ_AVATAR) }, w = 0, weight = 1f, right = dp(8))
        picRow.add(outlineBtn("Banner") { pickProfileImage(REQ_BANNER) }, w = 0, weight = 1f)
        box.add(picRow)
        val rmRow = hstack()
        rmRow.add(outlineBtn("Remove picture", Theme.muted) {
            ProfileStore.removeImage("avatar")
            refreshMainUI(true)
        }, w = 0, weight = 1f, right = dp(8))
        rmRow.add(outlineBtn("Remove banner", Theme.muted) {
            ProfileStore.removeImage("banner")
            refreshMainUI(true)
        }, w = 0, weight = 1f)
        box.add(rmRow, top = dp(8))

        val sv = ScrollView(this)
        sv.addView(box)
        val dialog = AlertDialog.Builder(this).setView(sv).create()
        box.add(filledBtn("Save") {
            ProfileStore.name = nameIn.text.toString().trim().ifEmpty { "Trader" }
            ProfileStore.bio = bioIn.text.toString().trim()
            ProfileStore.effect = selected
            dialog.dismiss()
            refreshMainUI(true)
        }, top = dp(16))
        dialog.setOnDismissListener { previewAnim?.cancel() }
        dialog.show()
        dialog.window?.setBackgroundDrawable(Theme.box(Theme.card, Theme.border, dp(22), dp(1)))
    }

    // =====================================================================
    // THESIS + FILTERS + STATS
    // =====================================================================

    private fun chipRow(
        options: List<Pair<String, String>>,
        current: () -> String,
        onPick: (String) -> Unit
    ): HorizontalScrollView {
        val scroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = hstack()
        val views = ArrayList<Pair<String, TextView>>()
        fun paint() {
            for ((key, v) in views) {
                val on = key == current()
                v.setTextColor(if (on) Color.WHITE else Theme.muted)
                v.background = Theme.box(if (on) Theme.accent else Theme.surface2, Theme.border, dp(13), 0)
            }
        }
        for ((key, label) in options) {
            val v = tv(label, 12f, Theme.text, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(11), dp(6), dp(11), dp(6))
                pressFx()
                setOnClickListener {
                    onPick(key)
                    paint()
                }
            }
            views.add(key to v)
            row.add(v, right = dp(8), w = LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        paint()
        scroller.addView(row)
        return scroller
    }

    private fun filterLogs(all: List<ClosedTradeLog>): List<ClosedTradeLog> {
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val minTime = when (journalRange) {
            "24h" -> now - day
            "7d" -> now - 7L * day
            "30d" -> now - 30L * day
            else -> 0L
        }
        return all.filter { t ->
            if (t.closedAtMs < minTime) return@filter false
            when {
                journalFilter == "win" -> t.pnlSol >= 0.0
                journalFilter == "loss" -> t.pnlSol < 0.0
                journalFilter.startsWith("tag:") ->
                    ThesisStore.get(t.ca, t.openedAtMs)?.tags?.contains(journalFilter.removePrefix("tag:")) == true
                else -> true
            }
        }
    }

    private fun sol3(v: Double): String = String.format(Locale.US, "%+.3f", v)

    private fun refreshInsights(v: List<ClosedTradeLog>) {
        val filtered = journalFilter != "all" || journalRange != "all"
        insightsTitle.text = if (filtered) "Stats for this filter  (${v.size} trades)" else "Stats  (all ${v.size} trades)"
        insightsRow1.removeAllViews()
        insightsRow2.removeAllViews()
        insightsTags.removeAllViews()
        if (v.isEmpty()) {
            insightsRow1.add(tv("No trades to analyse yet.", 12f, Theme.muted))
            return
        }
        val winsL = v.filter { it.pnlSol >= 0.0 }
        val lossL = v.filter { it.pnlSol < 0.0 }
        val grossWin = winsL.sumOf { it.pnlSol }
        val grossLoss = abs(lossL.sumOf { it.pnlSol })
        val avgWin = if (winsL.isEmpty()) 0.0 else grossWin / winsL.size
        val avgLoss = if (lossL.isEmpty()) 0.0 else -grossLoss / lossL.size
        val pf = when {
            grossLoss > 0.0 -> String.format(Locale.US, "%.2f", grossWin / grossLoss)
            grossWin > 0.0 -> "inf"
            else -> "-"
        }
        // newest trade is first in the list
        val firstWin = v[0].pnlSol >= 0.0
        var streak = 0
        for (t in v) {
            if ((t.pnlSol >= 0.0) == firstWin) streak++ else break
        }

        insightsRow1.weightSum = 4f
        insightsRow1.add(statCell("Avg win", if (winsL.isEmpty()) "-" else sol3(avgWin), Theme.profit), w = 0, weight = 1f)
        insightsRow1.add(statCell("Avg loss", if (lossL.isEmpty()) "-" else sol3(avgLoss), Theme.loss), w = 0, weight = 1f)
        insightsRow1.add(statCell("Profit factor", pf), w = 0, weight = 1.1f)
        insightsRow1.add(
            statCell("Streak", "$streak${if (firstWin) "W" else "L"}", if (firstWin) Theme.profit else Theme.loss),
            w = 0, weight = 0.9f
        )

        val best = v.maxByOrNull { it.pnlSol }
        val worst = v.minByOrNull { it.pnlSol }
        val avgRoi = v.sumOf { it.roiPct } / v.size
        insightsRow2.weightSum = 3f
        insightsRow2.add(statCell("Best (SOL)", if (best == null) "-" else sol3(best.pnlSol), Theme.profit), w = 0, weight = 1f)
        insightsRow2.add(statCell("Worst (SOL)", if (worst == null) "-" else sol3(worst.pnlSol), Theme.loss), w = 0, weight = 1f)
        insightsRow2.add(statCell("Avg ROI", Formatters.pctSigned1(avgRoi), Theme.pnlColor(avgRoi)), w = 0, weight = 1f)

        // Performance per thesis tag (a trade with two tags counts in both)
        val groups = LinkedHashMap<String, MutableList<ClosedTradeLog>>()
        for (tg in ThesisStore.tags) groups[tg] = ArrayList()
        groups["No tag"] = ArrayList()
        for (t in v) {
            val tags = ThesisStore.get(t.ca, t.openedAtMs)?.tags ?: emptyList()
            if (tags.isEmpty()) groups["No tag"]?.add(t)
            else for (tg in tags) groups[tg]?.add(t)
        }
        for ((name, list) in groups) {
            if (list.isEmpty()) continue
            val w = list.count { it.pnlSol >= 0.0 }
            val pnl = list.sumOf { it.pnlSol }
            val row = hstack().apply {
                weightSum = 4.2f
                setPadding(dp(2), dp(7), dp(2), dp(7))
            }
            row.add(tv(name, 12f, Theme.text, bold = true), w = 0, weight = 1.3f)
            row.add(tv("${list.size} trades", 11f, Theme.muted, mono = true), w = 0, weight = 1f)
            row.add(tv("${(w * 100) / list.size}% win", 11f, Theme.muted, mono = true), w = 0, weight = 0.9f)
            row.add(
                tv(Formatters.solSigned(pnl), 11f, Theme.pnlColor(pnl), bold = true, mono = true).apply {
                    gravity = Gravity.END
                    maxLines = 1
                },
                w = 0, weight = 1f
            )
            insightsTags.add(row)
        }
    }

    // =====================================================================
    // THESIS TAB: every trade's reasoning next to how it ended
    // =====================================================================

    private fun buildThesisTab(): LinearLayout {
        val tab = vstack()
        tab.add(tv("Thesis", 25f, Theme.text, bold = true), top = dp(4))
        tab.add(tv("YOUR THINKING, CONNECTED TO THE OUTCOME", 9f, Theme.accent2, bold = true).apply { letterSpacing = 0.12f }, top = dp(4))
        tab.add(tv("Build a searchable library of your decisions and lessons.", 12f, Theme.muted), top = dp(5), bottom = dp(14))

        val search = EditText(this).apply {
            hint = "Search coin, ticker or words"
            setHintTextColor(Theme.muted)
            setTextColor(Theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = Theme.box(Theme.card, Theme.border, dp(24), dp(1))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    thesisQuery = (s?.toString() ?: "").trim()
                    refreshThesisList()
                }
            })
        }
        tab.add(search, bottom = dp(10))
        tab.add(
            chipRow(
                listOf("all" to "All", "win" to "Wins", "loss" to "Losses", "open" to "Open"),
                { thesisFilter }
            ) { thesisFilter = it; refreshThesisList() },
            bottom = dp(14)
        )
        thesisListContainer = vstack()
        tab.add(thesisListContainer)
        tab.visibility = View.GONE
        return tab
    }

    private fun refreshThesisList() {
        if (!::thesisListContainer.isInitialized) return
        val items = ArrayList<ThesisItem>()
        for (t in TradeRepository.getJournal()) {
            items.add(ThesisItem(t.ca, t.name, t.symbol, t.imageUrl, t.openedAtMs, t.closedAtMs, t, null))
        }
        val now = System.currentTimeMillis()
        for (p in TradeRepository.getAllPositions()) {
            items.add(ThesisItem(p.ca, p.name, p.symbol, p.imageUrl, p.openedAtMs, now, null, p))
        }
        val q = thesisQuery.lowercase(Locale.US)
        val shown = ArrayList<ThesisItem>()
        for (item in items.sortedByDescending { x -> x.sortMs }) {
            val th = ThesisStore.get(item.ca, item.openedAtMs)
            val note = ThesisStore.getNote(item.ca, item.openedAtMs)
            if (th == null && note.isBlank()) continue
            val c = item.closed
            val ok = when (thesisFilter) {
                "win" -> c != null && c.pnlSol >= 0.0
                "loss" -> c != null && c.pnlSol < 0.0
                "open" -> item.open != null
                else -> true
            }
            if (!ok) continue
            if (q.isNotEmpty()) {
                val hay = (item.name + " " + item.symbol + " " + (th?.text ?: "") + " " +
                    (th?.tags?.joinToString(" ") ?: "") + " " + note).lowercase(Locale.US)
                if (!hay.contains(q)) continue
            }
            shown.add(item)
        }
        thesisListContainer.removeAllViews()
        if (shown.isEmpty()) {
            val msg = if (thesisQuery.isNotEmpty() || thesisFilter != "all")
                "Nothing matches this filter."
            else
                "No theses yet. Write one in the floating panel before you buy, or tap Add on a finished trade."
            thesisListContainer.add(tv(msg, 12f, Theme.muted).apply { setPadding(dp(4), dp(4), dp(4), dp(4)) })
            return
        }
        for (item in shown) {
            thesisListContainer.add(
                buildThesisItemCard(item, ThesisStore.get(item.ca, item.openedAtMs), ThesisStore.getNote(item.ca, item.openedAtMs)),
                bottom = dp(12)
            )
        }
    }

    private fun buildThesisItemCard(item: ThesisItem, th: ThesisStore.Thesis?, note: String): View {
        val card = vstack().apply {
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = Theme.box(Theme.card, Theme.border, dp(22), dp(1))
            elevation = dp(4).toFloat()
            pressFx()
            setOnClickListener {
                val c = item.closed
                if (c != null) showTradeDetail(c)
                else Toast.makeText(this@MainActivity, "Still open. It opens in the journal once you sell 100%.", Toast.LENGTH_SHORT).show()
            }
        }
        val top = hstack()
        val icon = Theme.avatar(this, dp(48), dp(1))
        CoinImages.bind(icon, item.ca, item.symbol, item.imageUrl)
        top.add(icon, w = dp(48), h = dp(48), right = dp(12))
        val mid = vstack()
        val sym = if (item.symbol.startsWith("$")) item.symbol else "$" + item.symbol
        mid.add(tv(item.name, 16f, Theme.text, bold = true).apply { maxLines = 1 })
        mid.add(tv(sym, 12f, Theme.muted, mono = true), top = dp(2))
        top.add(mid, w = 0, weight = 1f)

        val right = vstack().apply { gravity = Gravity.END }
        val c = item.closed
        if (c != null) {
            right.add(
                tv(Formatters.solSigned(c.pnlSol), 14f, Theme.pnlColor(c.pnlSol), bold = true, mono = true)
                    .apply { gravity = Gravity.END }
            )
            right.add(
                tv(Formatters.multX(c.returnX) + "  " + Formatters.pctSigned1(c.roiPct), 11f, Theme.muted, mono = true)
                    .apply { gravity = Gravity.END },
                top = dp(2)
            )
        } else {
            right.add(tv("OPEN", 12f, Theme.text, bold = true).apply { gravity = Gravity.END })
            val rem = item.open?.remainingPct ?: 0.0
            right.add(
                tv("${rem.roundToInt()}% bag", 11f, Theme.muted, mono = true).apply { gravity = Gravity.END },
                top = dp(2)
            )
        }
        top.add(right, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        card.add(top)

        if (th != null && th.tags.isNotEmpty()) {
            val row = hstack()
            for (tag in th.tags) {
                row.add(
                    tv(tag, 11f, Theme.text, bold = true).apply {
                        setPadding(dp(10), dp(5), dp(10), dp(5))
                        background = Theme.box(Theme.surface2, Theme.border, dp(12), dp(1))
                    },
                    w = LinearLayout.LayoutParams.WRAP_CONTENT, right = dp(6)
                )
            }
            card.add(row, top = dp(12))
        }
        if (th != null && th.text.isNotBlank()) {
            card.add(
                tv(th.text, 14f, Theme.text).apply {
                    maxLines = 8
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    background = Theme.inset(dp(14))
                },
                top = dp(12)
            )
        }
        if (note.isNotBlank()) {
            card.add(tv("AFTER THE TRADE", 10f, Theme.muted, bold = true), top = dp(12))
            card.add(tv(note, 13f, Theme.muted).apply { maxLines = 5; ellipsize = TextUtils.TruncateAt.END }, top = dp(3))
        }
        val whenMs = if (c != null) c.closedAtMs else item.openedAtMs
        card.add(tv(Formatters.dateTime(whenMs), 10f, Theme.muted, mono = true), top = dp(10))
        return card
    }

    private fun buildThesisCard(ca: String, openedAtMs: Long, onSaved: () -> Unit): LinearLayout {
        val card = cardBox()
        val th = ThesisStore.get(ca, openedAtMs)
        val head = hstack()
        head.add(tv("Thesis", 11f, Theme.muted), w = 0, weight = 1f)
        head.add(
            outlineBtn(if (th == null) "Add" else "Edit") { showThesisEditor(ca, openedAtMs, onSaved) },
            w = LinearLayout.LayoutParams.WRAP_CONTENT
        )
        card.add(head)
        if (th == null) {
            card.add(tv("No thesis saved for this trade.", 12f, Theme.muted), top = dp(6))
        } else {
            if (th.tags.isNotEmpty()) {
                card.add(tv(th.tags.joinToString("   "), 12f, Theme.text, bold = true, mono = true), top = dp(6))
            }
            if (th.text.isNotBlank()) {
                card.add(tv(th.text, 13f, Theme.text), top = dp(6))
            }
        }
        val note = ThesisStore.getNote(ca, openedAtMs)
        if (note.isNotBlank()) {
            card.add(tv("AFTER THE TRADE", 10f, Theme.muted, bold = true), top = dp(12))
            card.add(tv(note, 13f, Theme.text), top = dp(4))
        }
        return card
    }

    private fun showThesisEditor(ca: String, openedAtMs: Long, onSaved: () -> Unit) {
        val cur = ThesisStore.get(ca, openedAtMs)
        val box = vstack().apply { setPadding(dp(18), dp(16), dp(18), dp(14)) }
        box.add(tv("Thesis", 17f, Theme.text, bold = true), bottom = dp(4))
        val input = addLabeledInput(box, "Why did you take this trade?", cur?.text ?: "", false)
        input.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(200))
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.setSingleLine(false)
        input.minLines = 3
        input.maxLines = 6
        input.gravity = Gravity.TOP or Gravity.START
        input.typeface = Typeface.DEFAULT

        box.add(tv("Tags", 11f, Theme.muted), top = dp(12), bottom = dp(6))
        val sel = LinkedHashSet<String>(cur?.tags ?: emptyList())
        val chips = ArrayList<Pair<String, TextView>>()
        fun paint() {
            for ((tag, chip) in chips) {
                val on = sel.contains(tag)
                chip.setTextColor(if (on) Theme.onColor(Theme.accent) else Theme.muted)
                chip.background = Theme.chip(on, dp(14))
            }
        }
        val tagRow = hstack().apply { weightSum = ThesisStore.tags.size.toFloat() }
        for ((i, tag) in ThesisStore.tags.withIndex()) {
            val chip = tv(tag, 11f, Theme.text, bold = true).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(dp(4), dp(10), dp(4), dp(10))
                pressFx()
                setOnClickListener {
                    if (sel.contains(tag)) sel.remove(tag) else sel.add(tag)
                    paint()
                }
            }
            chips.add(tag to chip)
            tagRow.add(chip, w = 0, weight = 1f, right = if (i < ThesisStore.tags.size - 1) dp(6) else 0)
        }
        paint()
        box.add(tagRow)

        val noteIn = addLabeledInput(box, "After the trade: what would you change?", ThesisStore.getNote(ca, openedAtMs), false)
        noteIn.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(240))
        noteIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        noteIn.setSingleLine(false)
        noteIn.minLines = 2
        noteIn.maxLines = 5
        noteIn.gravity = Gravity.TOP or Gravity.START
        noteIn.typeface = Typeface.DEFAULT

        val sv = ScrollView(this)
        sv.addView(box)
        val dialog = AlertDialog.Builder(this).setView(sv).create()
        val btns = hstack()
        btns.add(outlineBtn("Clear", Theme.muted) {
            ThesisStore.clear(ca, openedAtMs)
            ThesisStore.saveNote(ca, openedAtMs, "")
            dialog.dismiss()
            onSaved()
        }, w = 0, weight = 1f, right = dp(8))
        btns.add(filledBtn("Save") {
            val txt = input.text.toString().trim()
            if (txt.isEmpty() && sel.isEmpty()) ThesisStore.clear(ca, openedAtMs)
            else ThesisStore.save(ca, openedAtMs, txt, sel.toList())
            ThesisStore.saveNote(ca, openedAtMs, noteIn.text.toString())
            dialog.dismiss()
            onSaved()
        }, w = 0, weight = 1.4f)
        box.add(btns, top = dp(16))
        dialog.show()
        dialog.window?.setBackgroundDrawable(Theme.box(Theme.card, Theme.border, dp(22), dp(1)))
    }

    // =====================================================================
    // TAB 3: SETTINGS (trading + appearance)
    // =====================================================================

    private fun addLabeledInput(parent: LinearLayout, label: String, initial: String, numeric: Boolean): EditText {
        parent.add(tv(label, 11f, Theme.muted), top = dp(8), bottom = dp(4))
        val input = EditText(this).apply {
            setText(initial)
            setTextColor(Theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.MONOSPACE
            if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.box(Theme.surface2, Theme.border, dp(12), dp(1))
        }
        parent.add(input)
        return input
    }

    private fun buildSettingsTab(): LinearLayout {
        val tab = vstack()
        tab.visibility = View.GONE
        tab.add(outlineBtn("← Back to 73MCT") { closeSettingsPage() }, top = dp(4), bottom = dp(10))
        tab.add(tv("Settings", 25f, Theme.text, bold = true), top = dp(2))
        tab.add(tv("Trading controls, appearance and app preferences.", 12f, Theme.muted), top = dp(3), bottom = dp(14))
        val s = TradeRepository.settings

        // ---- Trading ----
        val trading = cardBox()
        trading.add(tv("Trading", 15f, Theme.text, bold = true), bottom = dp(4))
        val balInput = addLabeledInput(trading, "Paper wallet SOL balance", s.solBalance.toString(), true)
        val feeInput = addLabeledInput(trading, "Platform fee %", s.platformFeePct.toString(), true)
        val prioInput = addLabeledInput(trading, "Priority / bribe fee (SOL per tx)", s.priorityFeeSol.toString(), true)
        val slipInput = addLabeledInput(trading, "Simulated slippage %", s.slippagePct.toString(), true)
        val buyInput = addLabeledInput(trading, "4 quick-buy SOL buttons (comma separated)", s.buyPresets.joinToString(", "), false)
        val sellInput = addLabeledInput(
            trading, "4 quick-sell % buttons (comma separated)",
            s.sellPresets.map { it.toInt() }.joinToString(", "), false
        )
        trading.add(filledBtn("Save trading settings") {
            val cur = TradeRepository.settings
            val newBal = balInput.text.toString().toDoubleOrNull() ?: cur.solBalance
            val newFee = feeInput.text.toString().toDoubleOrNull() ?: cur.platformFeePct
            val newPrio = prioInput.text.toString().toDoubleOrNull() ?: cur.priorityFeeSol
            val newSlip = slipInput.text.toString().toDoubleOrNull() ?: cur.slippagePct
            val parsedBuys = buyInput.text.toString().split(",").mapNotNull { it.trim().toDoubleOrNull() }
            val parsedSells = sellInput.text.toString().split(",").mapNotNull { it.trim().toDoubleOrNull() }
            TradeRepository.updateSettings(
                newBalance = newBal,
                platformFeePct = newFee,
                priorityFeeSol = newPrio,
                slippagePct = newSlip,
                buyPresets = if (parsedBuys.size == 4) parsedBuys else cur.buyPresets,
                sellPresets = if (parsedSells.size == 4) parsedSells else cur.sellPresets
            )
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }, top = dp(16))
        tab.add(trading, bottom = dp(12))

        // ---- Appearance ----
        val look = cardBox()
        look.add(tv("Appearance", 15f, Theme.text, bold = true))
        look.add(
            tv("Pick a preset or type your own hex colors. Applies to the app and the floating trading panel.", 11f, Theme.muted),
            top = dp(4), bottom = dp(10)
        )

        val preview = vstack().apply {
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = Theme.surface(dp(18), Theme.accent, dp(1))
        }
        val previewTop = hstack()
        previewTop.add(tv("73MCT  /  LIVE PREVIEW", 9f, Theme.accent2, bold = true).apply { letterSpacing = 0.12f }, w = 0, weight = 1f)
        previewTop.add(tv("● ACTIVE", 9f, Theme.profit, bold = true))
        preview.add(previewTop)
        preview.add(tv("Market mindset. Measured execution.", 15f, Theme.text, bold = true), top = dp(8))
        preview.add(tv("Personalize the terminal without changing trading behavior.", 10f, Theme.muted), top = dp(3))
        val swatches = hstack()
        for (c in listOf(Theme.accent, Theme.accent2, Theme.profit, Theme.loss)) {
            val dot = View(this).apply { background = Theme.circle(c, Theme.alpha(c, 0xA0), dp(1)) }
            swatches.add(dot, w = dp(18), h = dp(18), right = dp(7))
        }
        preview.add(swatches, top = dp(10))
        look.add(preview, bottom = dp(12))

        val motionPref = getSharedPreferences("73mct_visual_settings", MODE_PRIVATE)
        look.add(outlineBtn("Motion effects: " + if (motionEnabled) "ON" else "OFF") {
            motionEnabled = !motionEnabled
            motionPref.edit().putBoolean("motion_enabled", motionEnabled).apply()
            recreate()
        }, bottom = dp(12))

        val presetNames = Theme.presets.keys.toList()
        var i = 0
        while (i < presetNames.size) {
            val row = hstack()
            for (j in 0..1) {
                if (i + j < presetNames.size) {
                    val name = presetNames[i + j]
                    row.add(
                        outlineBtn(name) { applyThemeValues(Theme.presets[name] ?: emptyMap()) },
                        w = 0, weight = 1f, right = if (j == 0) dp(8) else 0
                    )
                } else {
                    row.add(View(this), w = 0, weight = 1f)
                }
            }
            look.add(row, bottom = dp(8))
            i += 2
        }

        look.add(tv("Custom colors", 12f, Theme.muted, bold = true), top = dp(8), bottom = dp(4))
        val hexInputs = LinkedHashMap<String, EditText>()
        for (slot in Theme.slots) {
            val row = hstack().apply { setPadding(0, dp(4), 0, dp(4)) }
            row.add(tv(slot.label, 12f, Theme.text), w = 0, weight = 1f)

            val swatch = View(this)
            swatch.background = Theme.box(Theme.c(slot.key), Theme.muted, dp(8), dp(1))
            row.add(swatch, w = dp(30), h = dp(30), right = dp(10))

            val input = EditText(this).apply {
                setText(Theme.hexOf(slot.key))
                setTextColor(Theme.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.MONOSPACE
                inputType = InputType.TYPE_CLASS_TEXT
                setSingleLine(true)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = Theme.box(Theme.surface2, Theme.border, dp(10), dp(1))
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        val parsed = Theme.parseHex(s?.toString() ?: "")
                        if (parsed != null) swatch.background = Theme.box(parsed, Theme.muted, dp(8), dp(1))
                    }
                })
            }
            row.add(input, w = dp(112))
            hexInputs[slot.key] = input
            look.add(row)
        }

        look.add(filledBtn("Apply colors") {
            val values = LinkedHashMap<String, String>()
            for (slot in Theme.slots) {
                val raw = hexInputs[slot.key]?.text?.toString() ?: ""
                if (Theme.parseHex(raw) == null) {
                    Toast.makeText(this, "Invalid color for ${slot.label} (use e.g. #FFFFFF)", Toast.LENGTH_LONG).show()
                    return@filledBtn
                }
                values[slot.key] = raw
            }
            applyThemeValues(values)
        }, top = dp(14), bottom = dp(8))
        look.add(outlineBtn("Reset to Violet Pulse default") {
            applyThemeValues(Theme.presets[Theme.DEFAULT_PRESET] ?: emptyMap())
        })
        tab.add(look)
        return tab
    }

    private fun applyThemeValues(values: Map<String, String>) {
        Theme.applyColors(values)
        TradeRepository.notifyChanged() // makes the floating panel rebuild with the new colors
        Toast.makeText(this, "Colors applied", Toast.LENGTH_SHORT).show()
        recreate()
    }

    // =====================================================================
    // REFRESH
    // =====================================================================

    private fun refreshMainUI(forceJournal: Boolean) {
        val s = TradeRepository.settings
        headerBalanceText.text = String.format("%.3f SOL", s.solBalance)

        val running = OverlayService.isRunning
        statusText.text = if (running) "Bubble active" else "Bubble stopped"
        statusDot.background = if (running) Theme.circle(Theme.profit, Theme.profit, 0)
        else Theme.circle(Theme.bg, Theme.muted, dp(2))

        // Open positions
        positionsContainer.removeAllViews()
        val openList = TradeRepository.getAllPositions()
        if (openList.isEmpty()) {
            positionsContainer.add(
                tv("No open positions yet. Launch the paper trader and make your first entry.", 12f, Theme.muted).apply {
                    setPadding(dp(4), dp(10), dp(4), dp(10))
                }
            )
        } else {
            for ((index, pos) in openList.withIndex()) {
                positionsContainer.add(buildPositionCard(pos))
                if (index < openList.lastIndex) positionsContainer.add(View(this).apply { setBackgroundColor(Theme.border) }, h = dp(1))
            }
        }

        refreshMarketRadar()

        // Journal
        val logs = TradeRepository.getJournal()
        var totalPnl = 0.0
        var totalIn = 0.0
        var totalOut = 0.0
        var wins = 0
        var bestX = 0.0
        var totalHold = 0L
        for (l in logs) {
            totalPnl += l.pnlSol
            totalIn += l.solIn
            totalOut += l.solOut
            if (l.pnlSol >= 0.0) wins++
            if (l.multipleX > bestX) bestX = l.multipleX
            totalHold += l.holdDurationMs
        }
        val winRate = if (logs.isNotEmpty()) (wins * 100) / logs.size else 0
        val avgHold = if (logs.isNotEmpty()) totalHold / logs.size else 0L

        setHeroBalance(s.solBalance)
        heroSub.text = "Journal ${Formatters.solSigned(totalPnl)}  •  ${logs.size} trades  •  ${openList.size} open"
        heroSub.setTextColor(Theme.muted)

        journalNetPnl.text = Formatters.solSigned(totalPnl)
        journalNetPnl.setTextColor(Theme.pnlColor(totalPnl))
        journalNetSub.text = "Invested ${Formatters.solPlain(totalIn)}  •  Returned ${Formatters.solPlain(totalOut)}"

        journalStatsRow.removeAllViews()
        journalStatsRow.add(statCell("Win rate", "$winRate%"), w = 0, weight = 1f)
        journalStatsRow.add(statCell("Trades", "${logs.size}"), w = 0, weight = 1f)
        journalStatsRow.add(statCell("Best X", Formatters.multX(bestX)), w = 0, weight = 1f)
        journalStatsRow.add(statCell("Avg hold", Formatters.duration(avgHold)), w = 0, weight = 1.2f)

        refreshProfile(forceJournal, s.solBalance, totalPnl, totalIn, totalOut, logs, wins, bestX, avgHold, winRate, openList.size)
        if (::headerBalanceText.isInitialized) headerBalanceText.text = String.format(Locale.US, "%.3f SOL", s.solBalance)
        if (::feedListContainer.isInitialized && currentTabIdx == 1) refreshFeed()

        val tsig = "${logs.size}:${logs.firstOrNull()?.id ?: ""}:${openList.size}"
        if (forceJournal || tsig != thesisSig) {
            thesisSig = tsig
            refreshThesisList()
        }

        val sig = "${logs.size}:${logs.firstOrNull()?.id ?: ""}:$journalFilter:$journalRange"
        if (forceJournal || sig != journalSig) {
            journalSig = sig
            val shown = filterLogs(logs)
            refreshInsights(shown)
            journalListContainer.removeAllViews()
            if (logs.isEmpty()) {
                journalListContainer.add(
                    tv(
                        "No finished trades yet. A trade shows up here once you sell 100% of a coin. Partial sells are saved inside that trade.",
                        12f, Theme.muted
                    ).apply { setPadding(dp(4), dp(4), dp(4), dp(4)) }
                )
            } else if (shown.isEmpty()) {
                journalListContainer.add(
                    tv("No trades match this filter.", 12f, Theme.muted).apply { setPadding(dp(4), dp(4), dp(4), dp(4)) }
                )
            } else {
                for (item in shown) {
                    journalListContainer.add(buildJournalCard(item), bottom = dp(10))
                }
            }
        }
    }

    // =====================================================================
    // ACTIONS
    // =====================================================================

    private fun startBubbleServiceWithCheck() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Please grant 'Display over other apps' permission for 73MCT first",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val svc = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc)
        } else {
            startService(svc)
        }
        Toast.makeText(this, "Bubble launched. Open fomo now.", Toast.LENGTH_SHORT).show()
        mainHandler.postDelayed({ refreshMainUI(false) }, 250)
    }

    private fun csv(v: String): String = "\"" + v.replace("\"", "\"\"") + "\""

    private fun shareJournalCsv() {
        val logs = TradeRepository.getJournal()
        if (logs.isEmpty()) {
            Toast.makeText(this, "No trades in journal yet", Toast.LENGTH_SHORT).show()
            return
        }
        val sb = StringBuilder(
            "TradeId,Name,Ticker,CA,Side,Time,MC,SOL,PctOfBagSold,SlicePnlSol,TradeInvestedSol,TradeReturnedSol,TradePnlSol,TradeRoiPct,EntryMC,AvgExitMC,PeakMC,HoldSeconds\n"
        )
        for (l in logs) {
            for (f in l.fills) {
                sb.append(csv(l.id)).append(',')
                    .append(csv(l.name)).append(',')
                    .append(csv(l.symbol)).append(',')
                    .append(csv(l.ca)).append(',')
                    .append(f.side).append(',')
                    .append(csv(Formatters.dateTime(f.timeMs))).append(',')
                    .append(f.mc).append(',')
                    .append(f.sol).append(',')
                    .append(f.pct).append(',')
                    .append(f.pnlSol).append(',')
                    .append(l.solIn).append(',')
                    .append(l.solOut).append(',')
                    .append(l.pnlSol).append(',')
                    .append(l.roiPct).append(',')
                    .append(l.entryMc).append(',')
                    .append(l.avgExitMc).append(',')
                    .append(l.peakMc).append(',')
                    .append(l.holdDurationMs / 1000L)
                    .append('\n')
            }
        }
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "73MCT Trade Journal CSV")
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        startActivity(Intent.createChooser(sendIntent, "Export 73MCT Trade Journal"))
    }

    private fun tabViewAt(i: Int): View = when (i) {
        0 -> tabTrade
        1 -> tabFeed
        2 -> tabSearch
        3 -> tabKol
        else -> tabPortfolio
    }

    private fun switchTab(idx: Int) {
        if (settingsOpen) {
            settingsOpen = false
            tabSettings.visibility = View.GONE
            if (::headerBalanceText.isInitialized) headerBalanceText.visibility = View.VISIBLE
            if (::navBarView.isInitialized) navBarView.visibility = View.VISIBLE
        }
        val target = idx.coerceIn(0, 4)
        val prev = currentTabIdx
        currentTabIdx = target
        lastTab = target
        for (i in 0..4) {
            val view = tabViewAt(i)
            view.animate().cancel()
            view.visibility = if (i == target) View.VISIBLE else View.GONE
            view.alpha = 1f
            view.translationX = 0f
        }
        for (i in navIcons.indices) {
            val active = i == target
            navIcons[i].setIconColor(if (active) Color.WHITE else 0xFFAAA8B6.toInt())
            val cell = navCells[i]
            cell.background = if (active) GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.argb(72, 115, 124, 255))
            } else null
        }
        settingsButton.setImageDrawable(LineIcon("settings", Theme.muted))
        if (target != prev) bodyScroll.scrollTo(0, 0)
        when (target) {
            2 -> tabSearch.onShown()
            3 -> tabKol.onShown()
        }
        refreshMainUI(true)
    }

    override fun onDestroy() {
        TradeRepository.removeListener(repoListener)
        if (::tabKol.isInitialized) tabKol.destroy()
        if (::tabSearch.isInitialized) tabSearch.destroy()
        heroAnim?.cancel()
        profPnlAnim?.cancel()
        bioAnim?.cancel()
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
