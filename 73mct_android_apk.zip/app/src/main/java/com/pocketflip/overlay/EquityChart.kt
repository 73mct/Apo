package com.pocketflip.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Equity curve: running net PnL (SOL) after each finished trade. Read-only, drawn from the journal.
 * Touch and drag to scrub through your trades.
 */
class EquityView(context: Context) : View(context) {

    class Pt(val v: Double, val label: String)

    private val d = resources.displayMetrics.density
    private var pts: List<Pt> = emptyList()
    private var reveal = 1f
    private var anim: ValueAnimator? = null
    private var touchIdx = -1

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.4f * d
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 9f * d
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val zero = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1f * d
        pathEffect = DashPathEffect(floatArrayOf(5f * d, 5f * d), 0f)
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11f * d; typeface = Typeface.MONOSPACE
    }

    fun setData(p: List<Pt>, animate: Boolean) {
        pts = p
        touchIdx = -1
        anim?.cancel()
        if (animate && p.size >= 2) {
            reveal = 0f
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 800
                interpolator = DecelerateInterpolator(1.6f)
                addUpdateListener { reveal = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            reveal = 1f
        }
        invalidate()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun area(): RectF = RectF(8f * d, 26f * d, width - 8f * d, height - 8f * d)

    override fun onDraw(c: Canvas) {
        val a = area()
        if (pts.size < 2) {
            txt.color = Theme.muted
            txt.textAlign = Paint.Align.CENTER
            c.drawText("Finish a trade to start your curve", width / 2f, height / 2f, txt)
            return
        }
        var lo = min(0.0, pts.minOf { it.v })
        var hi = max(0.0, pts.maxOf { it.v })
        if (hi - lo < 1e-9) { hi += 1.0; lo -= 1.0 }
        val padV = (hi - lo) * 0.12
        lo -= padV; hi += padV
        fun mx(i: Int) = a.left + a.width() * i / (pts.size - 1f)
        fun my(v: Double) = (a.bottom - ((v - lo) / (hi - lo)).toFloat() * a.height())

        val last = pts.last().v
        val col = Theme.pnlColor(last)

        // zero line
        zero.color = Theme.alpha(Theme.text, 60)
        val zy = my(0.0)
        c.drawLine(a.left, zy, a.right, zy, zero)

        val xs = FloatArray(pts.size) { mx(it) }
        val ys = FloatArray(pts.size) { my(pts[it].v) }
        val path = Path()
        path.moveTo(xs[0], ys[0])
        for (i in 0 until pts.size - 1) {
            val p0 = max(0, i - 1); val p3 = min(pts.size - 1, i + 2)
            var c1y = ys[i] + (ys[i + 1] - ys[p0]) / 6f
            var c2y = ys[i + 1] - (ys[p3] - ys[i]) / 6f
            val yMin = min(ys[i], ys[i + 1]); val yMax = max(ys[i], ys[i + 1])
            c1y = c1y.coerceIn(yMin, yMax)   // no overshoot past the real values
            c2y = c2y.coerceIn(yMin, yMax)
            val c1x = xs[i] + (xs[i + 1] - xs[p0]) / 6f
            val c2x = xs[i + 1] - (xs[p3] - xs[i]) / 6f
            path.cubicTo(c1x, c1y, c2x, c2y, xs[i + 1], ys[i + 1])
        }

        val drawX = a.left + (a.width() + 6f * d) * reveal
        c.save()
        c.clipRect(0f, 0f, drawX, height.toFloat())
        val fp = Path(path)
        fp.lineTo(xs.last(), a.bottom)
        fp.lineTo(xs.first(), a.bottom)
        fp.close()
        fill.shader = LinearGradient(0f, a.top, 0f, a.bottom, Theme.alpha(col, 70), Theme.alpha(col, 0), Shader.TileMode.CLAMP)
        c.drawPath(fp, fill)
        glow.color = Theme.alpha(col, 40)
        c.drawPath(path, glow)
        line.color = col
        c.drawPath(path, line)
        c.restore()

        // end dot
        if (reveal >= 0.999f && touchIdx < 0) {
            dot.color = Theme.alpha(col, 70)
            c.drawCircle(xs.last(), ys.last(), 9f * d, dot)
            dot.color = col
            c.drawCircle(xs.last(), ys.last(), 4.5f * d, dot)
        }

        // scrubber
        if (touchIdx in pts.indices) {
            val x = xs[touchIdx]; val y = ys[touchIdx]
            zero.color = Theme.alpha(Theme.text, 90)
            c.drawLine(x, a.top - 4f * d, x, a.bottom, zero)
            dot.color = Theme.alpha(col, 80)
            c.drawCircle(x, y, 10f * d, dot)
            dot.color = col
            c.drawCircle(x, y, 5f * d, dot)
            val p = pts[touchIdx]
            val s = (if (p.v >= 0) "+" else "") + String.format(java.util.Locale.US, "%.3f", p.v) + " SOL  " + p.label
            txt.color = Theme.text
            txt.textAlign = Paint.Align.LEFT
            val w = txt.measureText(s)
            val left = (x - w / 2f).coerceIn(a.left, max(a.left, a.right - w))
            c.drawText(s, left, 14f * d, txt)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (pts.size < 2) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val a = area()
                val f = ((e.x - a.left) / a.width()).coerceIn(0f, 1f)
                val idx = Math.round(f * (pts.size - 1))
                if (idx != touchIdx) { touchIdx = idx; invalidate() }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                touchIdx = -1
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Net PnL per day, one bar per day (most recent days). */
class DayBarsView(context: Context) : View(context) {

    class Bar(val label: String, val v: Double)

    private val d = resources.displayMetrics.density
    private var bars: List<Bar> = emptyList()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 9.5f * d; typeface = Typeface.MONOSPACE; textAlign = Paint.Align.CENTER
    }

    fun setData(b: List<Bar>) {
        bars = b
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        if (bars.isEmpty()) return
        val left = 4f * d
        val right = width - 4f * d
        val top = 6f * d
        val labelH = 16f * d
        val bottom = height - labelH
        val maxAbs = max(1e-9, bars.maxOf { abs(it.v) })
        val hasNeg = bars.any { it.v < 0 }
        val hasPos = bars.any { it.v > 0 }
        val baseY = when {
            hasNeg && hasPos -> top + (bottom - top) * 0.5f
            hasNeg -> top
            else -> bottom
        }
        val half = if (hasNeg && hasPos) (bottom - top) / 2f else (bottom - top)
        val slot = (right - left) / bars.size
        val bw = slot * 0.58f
        p.color = Theme.alpha(Theme.text, 50)
        p.strokeWidth = 1f * d
        c.drawLine(left, baseY, right, baseY, p)
        for ((i, b) in bars.withIndex()) {
            val cx = left + slot * i + slot / 2f
            val h = (abs(b.v) / maxAbs).toFloat() * half
            p.style = Paint.Style.FILL
            if (b.v == 0.0) {
                p.color = Theme.alpha(Theme.text, 70)
                c.drawRoundRect(RectF(cx - bw / 2f, baseY - 1.5f * d, cx + bw / 2f, baseY + 1.5f * d), 2f * d, 2f * d, p)
            } else {
                p.color = Theme.pnlColor(b.v)
                val r = if (b.v > 0) RectF(cx - bw / 2f, baseY - max(h, 3f * d), cx + bw / 2f, baseY)
                else RectF(cx - bw / 2f, baseY, cx + bw / 2f, baseY + max(h, 3f * d))
                c.drawRoundRect(r, 4f * d, 4f * d, p)
            }
            txt.color = Theme.muted
            if (bars.size <= 16 || i % 2 == 0) c.drawText(b.label, cx, height - 3f * d, txt)
        }
    }
}
