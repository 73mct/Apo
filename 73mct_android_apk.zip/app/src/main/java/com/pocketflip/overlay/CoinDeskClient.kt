package com.pocketflip.overlay

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.CompletableFuture
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * Mobile Coin Desk research client. This is deliberately separate from DexScreenerClient and
 * TradeRepository: it reads public market/on-chain data only and never changes paper-trade math.
 */
data class CoinDeskMarket(
    val ca: String,
    val name: String,
    val symbol: String,
    val imageUrl: String,
    val priceUsd: Double,
    val marketCapUsd: Double,
    val marketCapLabel: String,
    val fdvUsd: Double,
    val liquidityUsd: Double,
    val volume5mUsd: Double,
    val volume1hUsd: Double,
    val volume24hUsd: Double,
    val buys5m: Int,
    val sells5m: Int,
    val buys1h: Int,
    val sells1h: Int,
    val buys24h: Int,
    val sells24h: Int,
    val change5mPct: Double,
    val change1hPct: Double,
    val change24hPct: Double,
    val pairCreatedAtMs: Long,
    val pairAddress: String,
    val dexName: String,
    val dexUrl: String,
    val xUrl: String,
    val websiteUrl: String,
    val telegramUrl: String,
    val pumpBondingCurve: String,
    val creatorAddress: String
) {
    val ageText: String
        get() {
            if (pairCreatedAtMs <= 0L) return "Unknown"
            val elapsed = max(0L, System.currentTimeMillis() - pairCreatedAtMs)
            val mins = elapsed / 60_000L
            return when {
                mins < 60L -> "${mins}m"
                mins < 1440L -> "${mins / 60L}h ${(mins % 60L)}m"
                else -> "${mins / 1440L}d ${(mins % 1440L) / 60L}h"
            }
        }
}

data class CoinDeskHolder(
    val owner: String,
    val pct: Double,
    val tokenAmount: Double,
    val insider: Boolean
)

data class CoinDeskSecurity(
    val normalizedScore: Int,
    val topHoldersPct: Double,
    val lpLockedPct: Double,
    val mintAuthority: String,
    val freezeAuthority: String,
    val totalHolders: Int,
    val developerHoldPct: Double,
    val insiderAccounts: Int,
    val creatorPreviousTokens: Int,
    val creatorAddress: String,
    val topHolderRows: List<CoinDeskHolder>,
    val riskNames: List<String>,
    val reportUrl: String
)

data class CoinDeskLoad(
    val market: CoinDeskMarket?,
    val security: CoinDeskSecurity?,
    val marketMessage: String,
    val securityMessage: String
)

data class BundleScanResult(
    val scannedTransactions: Int,
    val candidateSlots: Int,
    val bundleSlots: Int,
    val bundledTransactions: Int,
    val bundledWallets: Int,
    val estimatedTokensBought: Double,
    val estimatedSupplyPct: Double,
    val sourceLabel: String,
    val note: String
)

object CoinDeskClient {
    private val io = Executors.newFixedThreadPool(3)
    private val http = OkHttpClient.Builder()
        .connectTimeout(7, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .callTimeout(25, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    fun load(caRaw: String, callback: (CoinDeskLoad) -> Unit) {
        val ca = DexScreenerClient.extractSolanaCa(caRaw)
        // Market and security requests are independent. Run them together so the review screen
        // does not make the user wait for one provider before contacting the next.
        val marketFuture = CompletableFuture.supplyAsync({ fetchMarket(ca) }, io)
        val securityFuture = CompletableFuture.supplyAsync({ fetchSecurity(ca) }, io)
        marketFuture.thenCombine(securityFuture) { market, security ->
            val marketMessage = if (market == null) "Market data unavailable. Check the CA or try again." else ""
            val securityMessage = if (security == null) "RugCheck report unavailable; this is unknown, not a clean result." else ""
            CoinDeskLoad(market, security, marketMessage, securityMessage)
        }.whenComplete { loaded, error ->
            if (error != null || loaded == null) {
                callback(CoinDeskLoad(null, null, "Market data unavailable. Check the CA or try again.", "RugCheck report unavailable; this is unknown, not a clean result."))
            } else callback(loaded)
        }
    }

    fun scanBundles(caRaw: String, market: CoinDeskMarket, heliusKey: String, callback: (BundleScanResult) -> Unit) {
        val ca = DexScreenerClient.extractSolanaCa(caRaw)
        io.execute {
            val pumpCurve = if (market.pumpBondingCurve.isNotBlank()) market.pumpBondingCurve else ""
            val account = if (pumpCurve.isNotBlank()) pumpCurve else market.pairAddress
            val label = if (pumpCurve.isNotBlank()) "Pump.fun bonding curve" else "Selected DEX pool"
            val result = if (account.isBlank()) {
                BundleScanResult(0, 0, 0, 0, 0, 0.0, -1.0, label, "No launch or pool account was returned by the data source.")
            } else {
                runBundleScan(ca, account, label, heliusKey)
            }
            callback(result)
        }
    }

    private fun getJson(url: String): JSONObject? {
        return try {
            val req = Request.Builder().url(url).header("Accept", "application/json").build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return null
                val body = r.body?.string() ?: return null
                JSONObject(body)
            }
        } catch (_: Throwable) { null }
    }

    private fun getArray(url: String): JSONArray? {
        return try {
            val req = Request.Builder().url(url).header("Accept", "application/json").build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return null
                JSONArray(r.body?.string() ?: return null)
            }
        } catch (_: Throwable) { null }
    }

    private fun fetchMarket(ca: String): CoinDeskMarket? {
        if (ca.length !in 32..44) return null
        var pairs = getArray("https://api.dexscreener.com/token-pairs/v1/solana/$ca")
        if (pairs == null || pairs.length() == 0) {
            pairs = getJson("https://api.dexscreener.com/latest/dex/tokens/$ca")?.optJSONArray("pairs")
        }
        pairs = pairs ?: return null
        var selected: JSONObject? = null
        var bestLiquidity = -1.0
        for (i in 0 until pairs.length()) {
            val p = pairs.optJSONObject(i) ?: continue
            if (p.optString("chainId") != "solana") continue
            val base = p.optJSONObject("baseToken")?.optString("address", "") ?: ""
            val quote = p.optJSONObject("quoteToken")?.optString("address", "") ?: ""
            if (base != ca && quote != ca) continue
            val liq = p.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
            if (liq > bestLiquidity) { bestLiquidity = liq; selected = p }
        }
        val p = selected ?: return null
        val baseObj = p.optJSONObject("baseToken")
        val quoteObj = p.optJSONObject("quoteToken")
        val isBase = baseObj?.optString("address", "") == ca
        val tokenObj = if (isBase) baseObj else quoteObj
        val info = p.optJSONObject("info")
        val socials = info?.optJSONArray("socials")
        val websites = info?.optJSONArray("websites")
        var xUrl = ""
        var telegramUrl = ""
        if (socials != null) for (i in 0 until socials.length()) {
            val s = socials.optJSONObject(i) ?: continue
            val platform = s.optString("platform", "").lowercase()
            val handle = s.optString("url", "").ifBlank { s.optString("handle", "") }
            if (platform.contains("twitter") || platform == "x") {
                xUrl = cleanSocialUrl(handle, "x")
            }
            if (platform.contains("telegram") || platform == "tg") {
                telegramUrl = cleanSocialUrl(handle, "tg")
            }
        }
        var website = ""
        if (websites != null && websites.length() > 0) {
            val first = websites.optJSONObject(0)
            website = first?.optString("url", "") ?: ""
        }
        val tx5 = p.optJSONObject("txns")?.optJSONObject("m5")
        val tx1 = p.optJSONObject("txns")?.optJSONObject("h1")
        val tx24 = p.optJSONObject("txns")?.optJSONObject("h24")
        val vol = p.optJSONObject("volume")
        val ch = p.optJSONObject("priceChange")
        val created = p.optLong("pairCreatedAt", 0L)
        val marketCap = optionalNumber(p, "marketCap")
        val fdv = optionalNumber(p, "fdv")
        val hasMarketCap = marketCap.isFinite() && marketCap > 0.0
        val hasFdv = fdv.isFinite() && fdv > 0.0
        val pump = fetchPumpData(ca)
        return CoinDeskMarket(
            ca = ca,
            name = tokenObj?.optString("name", "Solana token") ?: "Solana token",
            symbol = tokenObj?.optString("symbol", "TOKEN") ?: "TOKEN",
            imageUrl = info?.optString("imageUrl", "") ?: "",
            priceUsd = p.optString("priceUsd", "0").toDoubleOrNull() ?: 0.0,
            marketCapUsd = when { hasMarketCap -> marketCap; hasFdv -> fdv; else -> Double.NaN },
            marketCapLabel = when { hasMarketCap -> "MC"; hasFdv -> "FDV proxy"; else -> "MC N/A" },
            fdvUsd = fdv,
            liquidityUsd = optionalNumber(p.optJSONObject("liquidity"), "usd"),
            volume5mUsd = optionalNumber(vol, "m5"),
            volume1hUsd = optionalNumber(vol, "h1"),
            volume24hUsd = optionalNumber(vol, "h24"),
            buys5m = optionalInt(tx5, "buys"),
            sells5m = optionalInt(tx5, "sells"),
            buys1h = optionalInt(tx1, "buys"),
            sells1h = optionalInt(tx1, "sells"),
            buys24h = optionalInt(tx24, "buys"),
            sells24h = optionalInt(tx24, "sells"),
            change5mPct = optionalNumber(ch, "m5"),
            change1hPct = optionalNumber(ch, "h1"),
            change24hPct = optionalNumber(ch, "h24"),
            pairCreatedAtMs = created,
            pairAddress = p.optString("pairAddress", ""),
            dexName = p.optString("dexId", "DEX"),
            dexUrl = p.optString("url", "https://dexscreener.com/solana/$ca"),
            xUrl = xUrl,
            websiteUrl = website,
            telegramUrl = telegramUrl,
            pumpBondingCurve = pump.first,
            creatorAddress = pump.second
        )
    }

    private fun optionalNumber(o: JSONObject?, key: String): Double {
        if (o == null || !o.has(key) || o.isNull(key)) return Double.NaN
        return o.optDouble(key, Double.NaN)
    }

    private fun optionalInt(o: JSONObject?, key: String): Int {
        if (o == null || !o.has(key) || o.isNull(key)) return -1
        return o.optInt(key, -1)
    }

    private fun cleanSocialUrl(raw: String, kind: String): String {
        val s = raw.trim()
        if (s.isBlank()) return ""
        if (s.startsWith("http://") || s.startsWith("https://")) return s
        return when (kind) {
            "x" -> "https://x.com/" + s.removePrefix("@").trimStart('/')
            else -> "https://t.me/" + s.removePrefix("@").trimStart('/')
        }
    }

    /** Public Pump.fun coin metadata is used only to discover the launch bonding curve and creator. */
    private fun fetchPumpData(ca: String): Pair<String, String> {
        val urls = listOf("https://frontend-api-v3.pump.fun/coins/$ca", "https://frontend-api.pump.fun/coins/$ca")
        for (url in urls) {
            val o = getJson(url) ?: continue
            val curve = firstNonEmpty(o, listOf("bonding_curve", "bondingCurve", "associated_bonding_curve"))
            val creator = firstNonEmpty(o, listOf("creator", "creator_address", "creatorAddress"))
            if (curve.isNotBlank() || creator.isNotBlank()) return Pair(curve, creator)
        }
        return Pair("", "")
    }

    private fun firstNonEmpty(o: JSONObject, keys: List<String>): String {
        for (k in keys) {
            val value = o.optString(k, "").trim()
            if (value.isNotBlank() && value != "null") return value
        }
        return ""
    }

    private fun fetchSecurity(ca: String): CoinDeskSecurity? {
        // Summary is used for aggregate LP-lock percentage; the full report supplies holders,
        // authorities, creator balance and insider-network information. Either can stand alone.
        val full = getJson("https://api.rugcheck.xyz/v1/tokens/$ca/report")
        val summary = getJson("https://api.rugcheck.xyz/v1/tokens/$ca/report/summary")
        if (full == null && summary == null) return null
        val o = full ?: summary ?: return null
        val risks = ArrayList<String>()
        val arr = o.optJSONArray("risks") ?: summary?.optJSONArray("risks")
        if (arr != null) for (i in 0 until minOf(5, arr.length())) {
            val risk = arr.optJSONObject(i) ?: continue
            val name = risk.optString("name", "")
            val description = risk.optString("description", "")
            val label = if (name.isNotBlank()) name else description
            if (label.isNotBlank()) risks.add(label.take(90))
        }
        val token = o.optJSONObject("token") ?: JSONObject()
        val supply = token.optDouble("supply", 0.0)
        val creatorBalancePresent = o.has("creatorBalance") && !o.isNull("creatorBalance")
        val creatorBalance = o.optDouble("creatorBalance", -1.0)
        val creatorPct = if (supply > 0.0 && creatorBalancePresent && creatorBalance >= 0.0) creatorBalance / supply * 100.0 else -1.0
        var topTenPct = -1.0
        val holders = o.optJSONArray("topHolders")
        val holderAgg = LinkedHashMap<String, CoinDeskHolder>()
        if (holders != null && holders.length() > 0) {
            for (i in 0 until holders.length()) {
                val h = holders.optJSONObject(i) ?: continue
                val owner = h.optString("owner", "").ifBlank { h.optString("address", "") }
                if (owner.isBlank()) continue
                val pct = optionalNumber(h, "pct")
                val amount = h.optDouble("uiAmount", 0.0)
                val old = holderAgg[owner]
                val combinedPct = when {
                    old == null -> pct
                    old.pct.isFinite() && pct.isFinite() -> old.pct + pct
                    else -> Double.NaN
                }
                holderAgg[owner] = CoinDeskHolder(
                    owner = owner,
                    pct = combinedPct,
                    tokenAmount = (old?.tokenAmount ?: 0.0) + amount,
                    insider = (old?.insider ?: false) || h.optBoolean("insider", false)
                )
            }
            val sorted = holderAgg.values.sortedByDescending { if (it.pct.isFinite()) it.pct else -1.0 }
            val topRows = sorted.take(10)
            if (topRows.isNotEmpty() && topRows.all { it.pct.isFinite() }) topTenPct = topRows.sumOf { it.pct }
        }
        val previous = o.optJSONArray("creatorTokens")
        val previousCount = if (previous == null) -1 else previous.length()
        val creator = if (o.isNull("creator")) "" else o.optString("creator", "").trim().takeUnless { it == "null" }.orEmpty()
        return CoinDeskSecurity(
            normalizedScore = o.optInt("score_normalised", summary?.optInt("score_normalised", -1) ?: -1),
            topHoldersPct = topTenPct,
            lpLockedPct = summary?.optDouble("lpLockedPct", -1.0) ?: -1.0,
            mintAuthority = nullableString(token, "mintAuthority"),
            freezeAuthority = nullableString(token, "freezeAuthority"),
            totalHolders = o.optInt("totalHolders", -1),
            developerHoldPct = creatorPct,
            insiderAccounts = o.optInt("graphInsidersDetected", -1),
            creatorPreviousTokens = previousCount,
            creatorAddress = creator,
            topHolderRows = holderAgg.values.sortedByDescending { if (it.pct.isFinite()) it.pct else -1.0 }.take(10),
            riskNames = risks,
            reportUrl = "https://rugcheck.xyz/tokens/$ca"
        )
    }

    private fun nullableString(o: JSONObject, key: String): String {
        if (!o.has(key)) return "Unknown"
        if (o.isNull(key)) return "Revoked / none reported"
        val value = o.optString(key, "").trim()
        return if (value.isBlank() || value == "null") "Unknown" else value
    }

    private fun rpcUrlList(heliusKey: String): List<String> {
        val key = heliusKey.trim()
        return if (key.isNotBlank()) listOf(
            "https://mainnet.helius-rpc.com/?api-key=" + URLEncoder.encode(key, "UTF-8"),
            "https://solana-rpc.publicnode.com",
            "https://api.mainnet-beta.solana.com"
        ) else listOf("https://solana-rpc.publicnode.com", "https://api.mainnet-beta.solana.com")
    }

    private fun rpc(urls: List<String>, method: String, params: JSONArray): JSONObject? {
        val body = JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", method).put("params", params).toString()
        for (url in urls) {
            try {
                val req = Request.Builder().url(url).post(body.toRequestBody(jsonMedia)).header("Accept", "application/json").build()
                http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return@use
                    val json = JSONObject(r.body?.string() ?: return@use)
                    if (!json.isNull("result")) return json
                }
            } catch (_: Throwable) { }
        }
        return null
    }

    private fun runBundleScan(ca: String, account: String, sourceLabel: String, heliusKey: String): BundleScanResult {
        val urls = rpcUrlList(heliusKey)
        val signatureParams = JSONArray().put(account).put(JSONObject().put("limit", 1000).put("commitment", "confirmed"))
        val sigResponse = rpc(urls, "getSignaturesForAddress", signatureParams)
            ?: return BundleScanResult(0, 0, 0, 0, 0, 0.0, -1.0, sourceLabel, "RPC history unavailable. Add a Helius key in KOL settings or retry later.")
        val signatures = sigResponse.optJSONArray("result") ?: JSONArray()
        if (signatures.length() == 0) {
            return BundleScanResult(0, 0, 0, 0, 0, 0.0, -1.0, sourceLabel, "No transactions were returned for this launch account.")
        }
        val slotCounts = HashMap<Long, Int>()
        for (i in 0 until signatures.length()) {
            val slot = signatures.optJSONObject(i)?.optLong("slot", -1L) ?: -1L
            if (slot > 0L) slotCounts[slot] = (slotCounts[slot] ?: 0) + 1
        }
        // Axiom describes 4+ transactions in one block as a potential bundle. We go one step
        // further and inspect those blocks for positive token balance changes before counting buys.
        val candidateSlots = slotCounts.filterValues { it >= 4 }.keys.sorted().take(8)
        var bundledSlots = 0
        var bundledTxs = 0
        var tokenBought = 0.0
        val wallets = HashSet<String>()
        var examined = 0
        for (slot in candidateSlots) {
            val blockParams = JSONArray().put(slot).put(
                JSONObject()
                    .put("commitment", "confirmed")
                    .put("transactionDetails", "full")
                    .put("encoding", "jsonParsed")
                    .put("rewards", false)
                    .put("maxSupportedTransactionVersion", 0)
            )
            val block = rpc(urls, "getBlock", blockParams)?.optJSONObject("result") ?: continue
            val txs = block.optJSONArray("transactions") ?: continue
            var buysInSlot = 0
            var slotTokenBought = 0.0
            val slotWallets = HashSet<String>()
            for (i in 0 until txs.length()) {
                val wrapper = txs.optJSONObject(i) ?: continue
                val tx = wrapper.optJSONObject("transaction") ?: continue
                val message = tx.optJSONObject("message") ?: continue
                val meta = wrapper.optJSONObject("meta") ?: continue
                if (!meta.isNull("err")) continue
                examined++
                val accountKeys = message.optJSONArray("accountKeys") ?: JSONArray()
                var referencesTargetAccount = false
                val signers = ArrayList<Pair<Int, String>>()
                for (k in 0 until accountKeys.length()) {
                    val item = accountKeys.opt(k)
                    val pubkey = if (item is JSONObject) item.optString("pubkey", "") else item?.toString() ?: ""
                    if (pubkey == account) referencesTargetAccount = true
                    if (item is JSONObject) {
                        if (item.optBoolean("signer", false)) signers.add(Pair(k, pubkey))
                    } else if (k == 0 && item is String) signers.add(Pair(k, item))
                }
                if (!referencesTargetAccount) continue
                val pre = meta.optJSONArray("preTokenBalances") ?: JSONArray()
                val post = meta.optJSONArray("postTokenBalances") ?: JSONArray()
                val beforeByOwner = HashMap<String, Double>()
                val afterByOwner = HashMap<String, Double>()
                readMintBalances(pre, ca, beforeByOwner)
                readMintBalances(post, ca, afterByOwner)
                val owners = HashSet<String>()
                owners.addAll(beforeByOwner.keys); owners.addAll(afterByOwner.keys)
                var buyer = ""
                var amount = 0.0
                for (owner in owners) {
                    val delta = (afterByOwner[owner] ?: 0.0) - (beforeByOwner[owner] ?: 0.0)
                    if (delta > amount) { buyer = owner; amount = delta }
                }
                if (buyer.isBlank() || amount <= 0.0) continue
                val signer = signers.firstOrNull { it.second == buyer } ?: signers.firstOrNull()
                if (signer == null) continue
                val preLamports = meta.optJSONArray("preBalances")
                val postLamports = meta.optJSONArray("postBalances")
                val index = signer.first
                val spentLamports = (preLamports?.optLong(index, 0L) ?: 0L) - (postLamports?.optLong(index, 0L) ?: 0L)
                val fee = meta.optLong("fee", 0L)
                // An ATA rent deposit can exceed the network fee. Require a larger SOL outflow
                // to reduce airdrop/mint false positives; tiny genuine buys may be missed.
                if (spentLamports <= fee + 2_500_000L) continue
                buysInSlot++
                slotTokenBought += amount
                slotWallets.add(signer.second)
            }
            if (buysInSlot >= 4) {
                bundledSlots++
                bundledTxs += buysInSlot
                tokenBought += slotTokenBought
                wallets.addAll(slotWallets)
            }
        }
        val supply = fetchSupply(ca, urls)
        val pct = if (supply > 0.0 && tokenBought > 0.0) tokenBought / supply * 100.0 else -1.0
        val note = when {
            candidateSlots.isEmpty() -> "No 4+ same-slot interaction groups found in the sampled 1,000 signatures. This is not proof that no launch bundle existed."
            bundledSlots == 0 -> "No same-slot group with four or more qualifying token buys was found in the inspected blocks. The RPC sample may not cover the original launch."
            else -> "Potential same-block buy clusters detected. Same-slot activity does not prove common ownership or intent; this scan samples up to 1,000 signatures and inspects up to eight candidate blocks."
        }
        return BundleScanResult(signatures.length(), candidateSlots.size, bundledSlots, bundledTxs, wallets.size, tokenBought, pct, sourceLabel, note)
    }

    private fun readMintBalances(rows: JSONArray, mint: String, into: MutableMap<String, Double>) {
        for (i in 0 until rows.length()) {
            val row = rows.optJSONObject(i) ?: continue
            if (row.optString("mint", "") != mint) continue
            val owner = row.optString("owner", "")
            if (owner.isBlank()) continue
            val amountObj = row.optJSONObject("uiTokenAmount") ?: continue
            val amount = amountObj.optString("uiAmountString", "").toDoubleOrNull()
                ?: amountObj.optDouble("uiAmount", 0.0)
            into[owner] = (into[owner] ?: 0.0) + amount
        }
    }

    private fun fetchSupply(ca: String, urls: List<String>): Double {
        val response = rpc(urls, "getTokenSupply", JSONArray().put(ca).put(JSONObject().put("commitment", "confirmed")))
            ?: return 0.0
        val value = response.optJSONObject("result")?.optJSONObject("value") ?: return 0.0
        return value.optString("uiAmountString", "").toDoubleOrNull() ?: value.optDouble("uiAmount", 0.0)
    }
}
