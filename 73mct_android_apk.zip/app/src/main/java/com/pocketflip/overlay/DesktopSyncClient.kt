package com.pocketflip.overlay

import android.content.Context
import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Desktop -> Cloudflare KV -> Android importer. */
object DesktopSyncClient {
    data class Result(
        val ok: Boolean,
        val importedTrades: Int = 0,
        val importedPositions: Int = 0,
        val message: String = ""
    )

    private const val PREFS = "73mct_desktop_sync"
    private const val KEY_URL = "worker_url"
    private const val KEY_SECRET = "sync_secret"
    private const val KEY_LAST_PULL = "last_pull_ms"
    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(18, TimeUnit.SECONDS)
        .build()

    fun workerUrl(context: Context): String = prefs(context).getString(KEY_URL, "") ?: ""
    fun syncKey(context: Context): String = prefs(context).getString(KEY_SECRET, "") ?: ""
    fun isConfigured(context: Context): Boolean = workerUrl(context).startsWith("https://") && syncKey(context).length >= 32

    fun saveConfig(context: Context, endpoint: String, secret: String): Boolean {
        val cleanUrl = endpoint.trim().trimEnd('/')
        val cleanSecret = secret.trim()
        if (!cleanUrl.startsWith("https://") || cleanSecret.length < 32) return false
        return try {
            val uri = java.net.URI(cleanUrl)
            if (uri.host.isNullOrBlank() || uri.userInfo != null) return false
            prefs(context).edit().putString(KEY_URL, cleanUrl).putString(KEY_SECRET, cleanSecret).apply()
            true
        } catch (_: Throwable) { false }
    }

    /** Pull on app resume, but avoid repeated network requests during a single active session. */
    fun pullOnResume(context: Context, callback: (Result) -> Unit) {
        val p = prefs(context)
        val last = p.getLong(KEY_LAST_PULL, 0L)
        if (System.currentTimeMillis() - last < 45_000L) return
        pull(context, force = false, callback = callback)
    }

    fun pull(context: Context, force: Boolean = true, callback: (Result) -> Unit) {
        if (!isConfigured(context)) {
            callback(Result(false, message = "Enter the Worker URL and private sync key in Settings"))
            return
        }
        val p = prefs(context)
        if (!force && System.currentTimeMillis() - p.getLong(KEY_LAST_PULL, 0L) < 45_000L) return
        p.edit().putLong(KEY_LAST_PULL, System.currentTimeMillis()).apply()
        val endpoint = workerUrl(context)
        val secret = syncKey(context)
        Thread {
            val result = try {
                val request = Request.Builder()
                    .url("$endpoint/v1/sync")
                    .header("Authorization", "Bearer $secret")
                    .header("Accept", "application/json")
                    .get()
                    .build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IllegalStateException("Worker returned HTTP ${response.code}")
                    }
                    val raw = response.body?.string() ?: throw IllegalStateException("Empty sync response")
                    val root = JSONObject(raw)
                    val desktop = root.optJSONObject("desktop")
                    val snapshot = desktop?.optJSONObject("snapshot")
                    if (snapshot == null) {
                        Result(true, message = "Connected · no desktop snapshot yet")
                    } else {
                        val counts = TradeRepository.mergeDesktopSnapshot(snapshot)
                        Result(true, counts.first, counts.second,
                            "Synced ${counts.first} new trades and ${counts.second} open positions")
                    }
                }
            } catch (e: Throwable) {
                Result(false, message = e.message ?: "Sync failed")
            }
            main.post { callback(result) }
        }.start()
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
