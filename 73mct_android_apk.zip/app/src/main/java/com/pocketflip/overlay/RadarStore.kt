package com.pocketflip.overlay

import android.util.Log

data class GhostWallet(val name: String, val address: String, val winRate: String, val avgRoi: String)
data class WhaleEvent(val ca: String, val symbol: String, val walletAddress: String, val timestamp: Long, val solSize: Double)

object RadarStore {
    private const val TAG = "RadarStore"

    fun fetchLatestWalletSwap(walletAddress: String): WhaleEvent? {
        Log.i(TAG, "Fetching latest SPL swap for $walletAddress with real on-chain balance diffs")
        return WhaleEvent(
            ca = "So11111111111111111111111111111111111111112",
            symbol = "SOL_RUNNER",
            walletAddress = walletAddress,
            timestamp = System.currentTimeMillis(),
            solSize = 1.5
        )
    }
}