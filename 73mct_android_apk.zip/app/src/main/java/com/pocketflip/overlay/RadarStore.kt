package com.pocketflip.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

data class GhostWallet(
    val address: String,
    val label: String,
    var autoMirror: Boolean = false,
    var copySolAmount: Double = 0.25
)

data class WhaleEvent(
    val id: String,
    val walletAddress: String,
    val walletLabel: String,
    val ca: String,
    val symbol: String,
    val name: String,
    val imageUrl: String,
    val side: String,          // "BUY" or "SELL"
    val solAmount: Double,
    val sellPct: Double,       // for SELL events (0..100)
    val mcAtEvent: Double,
    val timestampMs: Long,
    var mirrored: Boolean = false
)

data class KolAlert(
    val id: String,
    val handle: String,
    val ca: String,
    val snippet: String,
    val timestampMs: Long
)

object RadarStore {
    private const val PREFS_NAME = "pocketflip_radar_store"
    private const val KEY_WALLETS = "wallets_json"
    private const val KEY_KOLS = "kols_json"
    private const val KEY_EVENTS = "events_json"
    private const val KEY_RPC_URL = "rpc_url"

    private const val DEFAULT_RPC = "https://api.mainnet-beta.solana.com"
    private const val SOL_MINT = "So11111111111111111111111111111111111111112"

    private var prefs: SharedPreferences? = null
    private lateinit var appCtx: Context
    private val mainHandler = Handler(Looper.getMainLooper())
    private var poller: ScheduledExecutorService? = null

    private val wallets = ArrayList<GhostWallet>()
    private val kolHandles = ArrayList<String>()
    private val events = ArrayList<WhaleEvent>()
    private val kolAlerts = ArrayList<KolAlert>()
    private val lastSeenSig = HashMap<String, String>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    var rpcUrl: String = DEFAULT_RPC
        private set

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        appCtx = context.applicationContext
        prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        load()
        startPolling()
    }

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    private fun notifyListeners() {
        mainHandler.post {
            for (l in listeners) {
                try { l.invoke() } catch (_: Throwable) {}
            }
        }
    }

    @Synchronized
    fun getWallets(): List<GhostWallet> = ArrayList(wallets)

    @Synchronized
    fun getKols(): List<String> = ArrayList(kolHandles)

    @Synchronized
    fun getEvents(): List<WhaleEvent> = ArrayList(events)

    @Synchronized
    fun getKolAlerts(): List<KolAlert> = ArrayList(kolAlerts)

    @Synchronized
    fun setCustomRpc(url: String) {
        rpcUrl = url.trim().ifEmpty { DEFAULT_RPC }
        prefs?.edit()?.putString(KEY_RPC_URL, rpcUrl)?.apply()
    }

    @Synchronized
    fun addWallet(address: String, label: String, copySol: Double = 0.25, autoMirror: Boolean = true) {
        val clean = address.trim()
        if (clean.length < 32 || wallets.any { it.address.equals(clean, ignoreCase = true) }) return
        wallets.add(0, GhostWallet(clean, label.trim().ifEmpty { "Whale ${wallets.size + 1}" }, autoMirror, copySol))
        save()
        notifyListeners()
        Executors.newSingleThreadExecutor().execute { pollSingleWallet(wallets.first()) }
    }

    @Synchronized
    fun toggleAutoMirror(address: String): Boolean {
        val w = wallets.firstOrNull { it.address == address } ?: return false
        w.autoMirror = !w.autoMirror
        save()
        notifyListeners()
        return w.autoMirror
    }

    @Synchronized
    fun removeWallet(address: String) {
        wallets.removeAll { it.address == address }
        save()
        notifyListeners()
    }

    @Synchronized
    fun addKol(handle: String) {
        val clean = handle.trim().removePrefix("@")
        if (clean.isEmpty() || kolHandles.any { it.equals(clean, ignoreCase = true) }) return
        kolHandles.add(0, clean)
        save()
        notifyListeners()
    }

    @Synchronized
    fun removeKol(handle: String) {
        kolHandles.removeAll { it.equals(handle, ignoreCase = true) }
        save()
        notifyListeners()
    }

    fun oneTapPaperTradeAndOpenFomo(context: Context, ca: String, buySol: Double, openFomoApp: Boolean) {
        Executors.newSingleThreadExecutor().execute {
            val token = DexScreenerClient.fetchInitialTokenMetadata(ca) {}
            if (token != null) {
                TradeRepository.setActiveCa(ca)
                TradeRepository.syncLiveTokenData(token)
                val res = TradeRepository.executeBuy(token, buySol)
                mainHandler.post {
                    res.onSuccess { pos ->
                        ThesisStore.save(pos.ca, pos.openedAtMs, "Shadow-boxed via Radar", listOf("Copy"))
                        Toast.makeText(
                            context,
                            "Paper Bought ${Formatters.amount(buySol)} SOL of $${token.symbol} @ ${Formatters.compactUsd(pos.entryMc)}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }.onFailure { err ->
                        Toast.makeText(context, err.message ?: "Paper buy failed", Toast.LENGTH_SHORT).show()
                    }
                    if (openFomoApp) launchFomoWithCa(context, ca)
                }
            } else {
                mainHandler.post {
                    Toast.makeText(context, "Could not fetch token metadata for CA", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun launchFomoWithCa(context: Context, ca: String) {
        try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("CA", ca))
        } catch (_: Throwable) {}

        try {
            val pm = context.packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            var pkg: String? = null
            for (ri in pm.queryIntentActivities(main, 0)) {
                val p = ri.activityInfo.packageName
                if (p == context.packageName) continue
                val label = ri.loadLabel(pm).toString().lowercase()
                if (label.contains("fomo") || p.lowercase().contains("fomo")) {
                    pkg = p
                    break
                }
            }
            if (pkg != null) {
                val launch = pm.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launch)
                    return
                }
            }
        } catch (_: Throwable) {}
    }

    fun openWhaleReplay(context: Context, walletAddress: String, walletLabel: String, ca: String) {
        Executors.newSingleThreadExecutor().execute {
            val wEvents = synchronized(this) {
                events.filter { it.walletAddress.equals(walletAddress, true) && it.ca.equals(ca, true) }
                    .sortedBy { it.timestampMs }
            }
            val token = DexScreenerClient.fetchInitialTokenMetadata(ca) {}
            val sym = token?.symbol ?: wEvents.firstOrNull()?.symbol ?: "MEME"
            val name = token?.name ?: wEvents.firstOrNull()?.name ?: "Whale Replay"
            val img = token?.imageUrl ?: wEvents.firstOrNull()?.imageUrl ?: ""
            val curMc = token?.marketCap?.takeIf { it > 0.0 } ?: wEvents.lastOrNull()?.mcAtEvent ?: 45000.0

            val fills = ArrayList<Fill>()
            var t0 = System.currentTimeMillis() - 360_000L
            var t1 = System.currentTimeMillis() - 10_000L
            var entryMc = curMc * 0.45
            var peakMc = curMc * 1.35
            var solIn = 0.0
            var solOut = 0.0

            if (wEvents.isNotEmpty()) {
                t0 = wEvents.first().timestampMs
                t1 = max(t0 + 30_000L, wEvents.last().timestampMs)
                entryMc = wEvents.first().mcAtEvent.coerceAtLeast(1000.0)
                peakMc = max(curMc, wEvents.maxOf { it.mcAtEvent })
                var rem = 100.0
                for (ev in wEvents) {
                    if (ev.side == "BUY") {
                        solIn += ev.solAmount
                        fills.add(Fill("BUY", ev.timestampMs, ev.mcAtEvent, 0.0001, ev.solAmount, 0.0, 0.0, rem))
                    } else {
                        val pct = ev.sellPct.coerceIn(10.0, 100.0)
                        rem = (rem * (1.0 - pct / 100.0)).coerceAtLeast(0.0)
                        val slicePnl = ev.solAmount * 0.35
                        solOut += ev.solAmount
                        fills.add(Fill("SELL", ev.timestampMs, ev.mcAtEvent, 0.0001, ev.solAmount, pct, slicePnl, rem))
                    }
                }
            } else {
                solIn = 2.0
                solOut = 4.85
                fills.add(Fill("BUY", t0, entryMc, 0.0001, 2.0, 0.0, 0.0, 100.0))
                fills.add(Fill("SELL", t0 + 110_000L, entryMc * 1.9, 0.00019, 1.35, 35.0, 0.65, 65.0))
                fills.add(Fill("SELL", t0 + 230_000L, peakMc * 0.94, 0.00028, 2.10, 50.0, 1.25, 32.5))
                fills.add(Fill("SELL", t1, curMc, 0.00024, 1.40, 100.0, 0.95, 0.0))
            }

            if (solIn <= 0.0) solIn = 1.0
            if (solOut <= 0.0) solOut = solIn * (curMc / entryMc.coerceAtLeast(1.0))
            val pnlSol = solOut - solIn
            val avgExitMc = fills.filter { it.side == "SELL" }.map { it.mc }.average().takeIf { !it.isNaN() } ?: curMc

            val tempLog = ClosedTradeLog(
                id = "whale_${System.currentTimeMillis()}",
                ca = ca,
                name = "$walletLabel • $name",
                symbol = sym,
                imageUrl = img,
                entryMc = entryMc,
                avgExitMc = avgExitMc,
                peakMc = max(peakMc, avgExitMc),
                solIn = solIn,
                solOut = solOut,
                pnlSol = pnlSol,
                multipleX = avgExitMc / entryMc.coerceAtLeast(1.0),
                holdDurationMs = max(10_000L, t1 - t0),
                openedAtMs = t0,
                closedAtMs = t1,
                fills = fills
            )

            LastWhaleReplayHolder.tempTrade = tempLog
            mainHandler.post {
                val i = Intent(context, ReplayActivity::class.java)
                    .putExtra(ReplayActivity.EXTRA_TRADE_ID, tempLog.id)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
            }
        }
    }

    object LastWhaleReplayHolder {
        @Volatile
        var tempTrade: ClosedTradeLog? = null
    }

    private fun startPolling() {
        poller?.shutdownNow()
        poller = Executors.newSingleThreadScheduledExecutor()
        poller?.scheduleWithFixedDelay({
            try {
                val list = getWallets()
                for (w in list) {
                    pollSingleWallet(w)
                    Thread.sleep(600L)
                }
                pollKolFeeds()
            } catch (_: Throwable) {}
        }, 2, 12, TimeUnit.SECONDS)
    }

    private fun pollSingleWallet(wallet: GhostWallet) {
        try {
            val req = JSONObject().apply {
                put("jsonrpc", "2.0")
                put("id", 1)
                put("method", "getSignaturesForAddress")
                put("params", JSONArray().apply {
                    put(wallet.address)
                    put(JSONObject().put("limit", 3))
                })
            }
            val resp = postJson(rpcUrl, req.toString()) ?: return
            val arr = JSONObject(resp).optJSONArray("result") ?: return
            if (arr.length() == 0) return

            val latestSig = arr.getJSONObject(0).optString("signature", "")
            if (latestSig.isEmpty()) return
            val prevSig = lastSeenSig[wallet.address]
            if (prevSig == null) {
                lastSeenSig[wallet.address] = latestSig
                return
            }
            if (prevSig == latestSig) return
            lastSeenSig[wallet.address] = latestSig

            parseTransactionAndEmit(wallet, latestSig)
        } catch (_: Throwable) {}
    }

    private fun parseTransactionAndEmit(wallet: GhostWallet, signature: String) {
        try {
            val req = JSONObject().apply {
                put("jsonrpc", "2.0")
                put("id", 2)
                put("method", "getTransaction")
                put("params", JSONArray().apply {
                    put(signature)
                    put(JSONObject().apply {
                        put("encoding", "jsonParsed")
                        put("maxSupportedTransactionVersion", 0)
                    })
                })
            }
            val resp = postJson(rpcUrl, req.toString()) ?: return
            val resObj = JSONObject(resp).optJSONObject("result") ?: return
            val meta = resObj.optJSONObject("meta") ?: return

            val preTok = meta.optJSONArray("preTokenBalances") ?: JSONArray()
            val postTok = meta.optJSONArray("postTokenBalances") ?: JSONArray()

            val preMap = HashMap<String, Double>()
            val postMap = HashMap<String, Double>()

            for (i in 0 until preTok.length()) {
                val o = preTok.getJSONObject(i)
                if (o.optString("owner") == wallet.address) {
                    val mint = o.optString("mint")
                    val amt = o.optJSONObject("uiTokenAmount")?.optDouble("uiAmount", 0.0) ?: 0.0
                    if (mint != SOL_MINT) preMap[mint] = amt
                }
            }
            for (i in 0 until postTok.length()) {
                val o = postTok.getJSONObject(i)
                if (o.optString("owner") == wallet.address) {
                    val mint = o.optString("mint")
                    val amt = o.optJSONObject("uiTokenAmount")?.optDouble("uiAmount", 0.0) ?: 0.0
                    if (mint != SOL_MINT) postMap[mint] = amt
                }
            }

            val allMints = HashSet<String>().apply { addAll(preMap.keys); addAll(postMap.keys) }
            for (mint in allMints) {
                val before = preMap[mint] ?: 0.0
                val after = postMap[mint] ?: 0.0
                val diff = after - before
                if (abs(diff) <= 0.0) continue

                val isBuy = diff > 0.0
                val sellPct = if (!isBuy && before > 0.0) ((before - after) / before * 100.0).coerceIn(1.0, 100.0) else 0.0

                val token = DexScreenerClient.fetchInitialTokenMetadata(mint) {}
                val mc = token?.marketCap ?: 25000.0
                val sym = token?.symbol ?: mint.take(4).uppercase()
                val name = token?.name ?: "Solana Token"
                val img = token?.imageUrl ?: ""

                val ev = WhaleEvent(
                    id = signature.take(16) + "_" + mint.take(6),
                    walletAddress = wallet.address,
                    walletLabel = wallet.label,
                    ca = mint,
                    symbol = sym,
                    name = name,
                    imageUrl = img,
                    side = if (isBuy) "BUY" else "SELL",
                    solAmount = wallet.copySolAmount,
                    sellPct = sellPct,
                    mcAtEvent = mc,
                    timestampMs = System.currentTimeMillis(),
                    mirrored = wallet.autoMirror
                )

                synchronized(this) {
                    events.add(0, ev)
                    if (events.size > 60) events.removeLast()
                    save()
                }

                if (wallet.autoMirror && token != null) {
                    TradeRepository.syncLiveTokenData(token)
                    if (isBuy) {
                        TradeRepository.setActiveCa(mint)
                        val r = TradeRepository.executeBuy(token, wallet.copySolAmount)
                        if (r.isSuccess) {
                            val pos = r.getOrNull()
                            if (pos != null) {
                                ThesisStore.save(pos.ca, pos.openedAtMs, "Auto-mirrored ${wallet.label}", listOf("Copy"))
                            }
                        }
                    } else {
                        val existing = TradeRepository.getPosition(mint)
                        if (existing != null && existing.tokensHeld > 0.0) {
                            TradeRepository.executeSell(token, sellPct.coerceIn(5.0, 100.0))
                        }
                    }
                }
                notifyListeners()
            }
        } catch (_: Throwable) {}
    }

    fun simulateWhaleDemoEvent(context: Context, side: String) {
        Executors.newSingleThreadExecutor().execute {
            val w = synchronized(this) {
                if (wallets.isEmpty()) {
                    wallets.add(GhostWallet("73WhaleDemo9xtyKvJ2LpQ8mN4vR6sT1wZ5cB3uH9p", "Smart Whale #1", true, 0.25))
                }
                wallets.first()
            }
            val activeCa = TradeRepository.settings.activeCa.ifBlank { "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr" }
            val token = DexScreenerClient.fetchInitialTokenMetadata(activeCa) {} ?: TokenInfo(
                ca = activeCa, name = "Popcat", symbol = "POPCAT",
                priceUsd = 0.45, solUsdPrice = 185.0, marketCap = 45000.0,
                liquidityUsd = 18000.0, volume24h = 95000.0, imageUrl = ""
            )

            val ev = WhaleEvent(
                id = "sim_${System.currentTimeMillis()}",
                walletAddress = w.address,
                walletLabel = w.label,
                ca = token.ca,
                symbol = token.symbol,
                name = token.name,
                imageUrl = token.imageUrl,
                side = side,
                solAmount = w.copySolAmount,
                sellPct = if (side == "SELL") 50.0 else 0.0,
                mcAtEvent = token.marketCap,
                timestampMs = System.currentTimeMillis(),
                mirrored = w.autoMirror
            )
            synchronized(this) {
                events.add(0, ev)
                save()
            }

            if (w.autoMirror) {
                TradeRepository.syncLiveTokenData(token)
                if (side == "BUY") {
                    TradeRepository.setActiveCa(token.ca)
                    TradeRepository.executeBuy(token, w.copySolAmount)
                } else {
                    TradeRepository.executeSell(token, 50.0)
                }
            }
            notifyListeners()
            mainHandler.post {
                Toast.makeText(
                    context,
                    "${w.label} ${side} $${token.symbol} (${if (w.autoMirror) "Auto-Mirrored!" else "Logged"})",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun pollKolFeeds() {
        val handles = getKols()
        for (h in handles.take(4)) {
            try {
                val url = "https://nitter.privacydev.net/$h/rss"
                val xml = getHttp(url) ?: continue
                val ca = DexScreenerClient.extractSolanaCa(xml)
                if (ca.length >= 32 && kolAlerts.none { it.ca == ca && it.handle.equals(h, true) }) {
                    synchronized(this) {
                        kolAlerts.add(
                            0,
                            KolAlert(
                                id = "${h}_${System.currentTimeMillis()}",
                                handle = "@$h",
                                ca = ca,
                                snippet = "Extracted CA from @$h timeline",
                                timestampMs = System.currentTimeMillis()
                            )
                        )
                        if (kolAlerts.size > 40) kolAlerts.removeLast()
                    }
                    notifyListeners()
                }
            } catch (_: Throwable) {}
        }
    }

    private fun postJson(urlStr: String, body: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 4500
                readTimeout = 4500
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            OutputStreamWriter(conn.outputStream).use { it.write(body) }
            BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
        } catch (_: Throwable) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun getHttp(urlStr: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
        } catch (_: Throwable) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun save() {
        val p = prefs ?: return
        val wArr = JSONArray()
        for (w in wallets) {
            wArr.put(JSONObject().apply {
                put("address", w.address)
                put("label", w.label)
                put("autoMirror", w.autoMirror)
                put("copySolAmount", w.copySolAmount)
            })
        }
        val kArr = JSONArray()
        for (k in kolHandles) kArr.put(k)

        val eArr = JSONArray()
        for (e in events.take(40)) {
            eArr.put(JSONObject().apply {
                put("id", e.id)
                put("walletAddress", e.walletAddress)
                put("walletLabel", e.walletLabel)
                put("ca", e.ca)
                put("symbol", e.symbol)
                put("name", e.name)
                put("imageUrl", e.imageUrl)
                put("side", e.side)
                put("solAmount", e.solAmount)
                put("sellPct", e.sellPct)
                put("mcAtEvent", e.mcAtEvent)
                put("timestampMs", e.timestampMs)
                put("mirrored", e.mirrored)
            })
        }
        p.edit()
            .putString(KEY_WALLETS, wArr.toString())
            .putString(KEY_KOLS, kArr.toString())
            .putString(KEY_EVENTS, eArr.toString())
            .apply()
    }

    private fun load() {
        val p = prefs ?: return
        rpcUrl = p.getString(KEY_RPC_URL, DEFAULT_RPC) ?: DEFAULT_RPC
        wallets.clear()
        try {
            val arr = JSONArray(p.getString(KEY_WALLETS, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                wallets.add(
                    GhostWallet(
                        address = o.optString("address"),
                        label = o.optString("label", "Whale"),
                        autoMirror = o.optBoolean("autoMirror", true),
                        copySolAmount = o.optDouble("copySolAmount", 0.25)
                    )
                )
            }
        } catch (_: Throwable) {}

        kolHandles.clear()
        try {
            val arr = JSONArray(p.getString(KEY_KOLS, "[]") ?: "[]")
            for (i in 0 until arr.length()) kolHandles.add(arr.getString(i))
        } catch (_: Throwable) {}

        events.clear()
        try {
            val arr = JSONArray(p.getString(KEY_EVENTS, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                events.add(
                    WhaleEvent(
                        id = o.optString("id"),
                        walletAddress = o.optString("walletAddress"),
                        walletLabel = o.optString("walletLabel"),
                        ca = o.optString("ca"),
                        symbol = o.optString("symbol"),
                        name = o.optString("name"),
                        imageUrl = o.optString("imageUrl"),
                        side = o.optString("side", "BUY"),
                        solAmount = o.optDouble("solAmount", 0.25),
                        sellPct = o.optDouble("sellPct", 0.0),
                        mcAtEvent = o.optDouble("mcAtEvent", 25000.0),
                        timestampMs = o.optLong("timestampMs", System.currentTimeMillis()),
                        mirrored = o.optBoolean("mirrored", false)
                    )
                )
            }
        } catch (_: Throwable) {}
    }
}
