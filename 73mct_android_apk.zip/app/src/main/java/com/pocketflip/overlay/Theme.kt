package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.ImageView
import android.widget.LinearLayout
import android.view.ViewOutlineProvider

/**
 * User-customizable color theme shared by the app screens and the floating bubble.
 * Default = readable slate with green/red PnL. Colors are saved separately from trading data.
 */
object Theme {
    private const val PREFS_NAME = "pocketflip_theme"
    private const val THEME_VERSION = 4

    data class Slot(val key: String, val label: String, val defaultHex: String)

    val slots: List<Slot> = listOf(
        Slot("bg", "Background", "#101720"),
        Slot("card", "Cards / panel", "#1B2735"),
        Slot("border", "Borders", "#36485C"),
        Slot("text", "Main text / accent", "#EFF5FB"),
        Slot("muted", "Muted text", "#A8B8C9"),
        Slot("buy", "Buy buttons", "#45D39B"),
        Slot("sell", "Sell buttons", "#F27A86"),
        Slot("profit", "Profit color", "#37D99C"),
        Slot("loss", "Loss color", "#FB707C")
    )

    private val chrome: Map<String, String> = slots.associate { it.key to it.defaultHex }
    private val oldDefaults: Map<String, String> = mapOf(
        "bg" to "#050608", "card" to "#16181D", "border" to "#30333B",
        "text" to "#F1F3F6", "muted" to "#A4A9B3", "buy" to "#E3E6EB",
        "sell" to "#E3E6EB", "profit" to "#F1F3F6", "loss" to "#A4A9B3"
    )
    private val blackWhite: Map<String, String> = mapOf(
        "bg" to "#000000", "card" to "#151515", "border" to "#2E2E2E",
        "text" to "#FFFFFF", "muted" to "#A0A0A0",
        "buy" to "#FFFFFF", "sell" to "#FFFFFF",
        "profit" to "#FFFFFF", "loss" to "#A8A8A8"
    )

    const val DEFAULT_PRESET = "Slate + Green/Red PnL"

    val presets: LinkedHashMap<String, Map<String, String>> = linkedMapOf(
        "Slate + Green/Red PnL" to chrome,
        "Chrome 73 (Legacy)" to mapOf(
            "bg" to "#050608", "card" to "#16181D", "border" to "#30333B",
            "text" to "#F1F3F6", "muted" to "#A4A9B3", "buy" to "#E3E6EB",
            "sell" to "#E3E6EB", "profit" to "#22C55E", "loss" to "#EF4444"
        ),
        "Chrome + Green/Red PnL" to chrome + mapOf("profit" to "#22C55E", "loss" to "#EF4444"),
        "Black & White" to blackWhite,
        "B&W + Green/Red PnL" to blackWhite + mapOf("profit" to "#22C55E", "loss" to "#EF4444"),
        "Paper (White)" to mapOf(
            "bg" to "#FFFFFF", "card" to "#F4F4F4", "border" to "#DADADA",
            "text" to "#000000", "muted" to "#6B6B6B",
            "buy" to "#000000", "sell" to "#000000",
            "profit" to "#000000", "loss" to "#6B6B6B"
        ),
        "Midnight" to mapOf(
            "bg" to "#05070D", "card" to "#121826", "border" to "#27324A",
            "text" to "#F8FAFC", "muted" to "#94A3B8",
            "buy" to "#38BDF8", "sell" to "#F472B6",
            "profit" to "#34D399", "loss" to "#FB7185"
        )
    )

    private var prefs: SharedPreferences? = null
    private val hexMap = LinkedHashMap<String, String>()
    private val intMap = HashMap<String, Int>()

    /** Increments every time the theme changes so the bubble knows to rebuild itself. */
    @Volatile
    var version: Int = 0
        private set

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        // Theme v4 refreshes the old near-black/gray defaults without deleting custom colors.
        // Only values exactly matching the previous built-in defaults are migrated.
        val oldTheme = (prefs?.getInt("theme_ver", 0) ?: 0) < THEME_VERSION
        val migration = if (oldTheme) prefs?.edit()?.putInt("theme_ver", THEME_VERSION) else null
        for (s in slots) {
            val saved = prefs?.getString(s.key, null)
            val shouldMigrateDefault = oldTheme && saved != null && saved.equals(oldDefaults[s.key], ignoreCase = true)
            val hex = if (saved != null && !shouldMigrateDefault && parseHex(saved) != null) saved else s.defaultHex
            if (shouldMigrateDefault) migration?.putString(s.key, s.defaultHex)
            hexMap[s.key] = hex
            intMap[s.key] = parseHex(hex) ?: Color.BLACK
        }
        migration?.apply()
    }

    fun parseHex(raw: String): Int? {
        val t = raw.trim()
        if (t.isEmpty()) return null
        val withHash = if (t.startsWith("#")) t else "#$t"
        return try {
            Color.parseColor(withHash)
        } catch (_: Throwable) {
            null
        }
    }

    @Synchronized
    fun applyColors(values: Map<String, String>) {
        val ed = prefs?.edit()
        for (s in slots) {
            val raw = values[s.key] ?: continue
            val parsed = parseHex(raw) ?: continue
            val hex = if (raw.trim().startsWith("#")) raw.trim() else "#" + raw.trim()
            hexMap[s.key] = hex
            intMap[s.key] = parsed
            ed?.putString(s.key, hex)
        }
        ed?.apply()
        version++
    }

    fun hexOf(key: String): String = hexMap[key] ?: "#000000"

    fun c(key: String): Int = intMap[key] ?: Color.MAGENTA

    val bg: Int get() = c("bg")
    val card: Int get() = c("card")
    val border: Int get() = c("border")
    val text: Int get() = c("text")
    val muted: Int get() = c("muted")
    val buy: Int get() = c("buy")
    val sell: Int get() = c("sell")
    val profit: Int get() = c("profit")
    val loss: Int get() = c("loss")

    fun pnlColor(value: Double): Int = if (value >= 0.0) profit else loss

    /** Readable text color (black or white) for something drawn on top of [background]. */
    fun onColor(background: Int): Int {
        val lum = (0.299 * Color.red(background) + 0.587 * Color.green(background) +
            0.114 * Color.blue(background)) / 255.0
        return if (lum > 0.55) Color.BLACK else Color.WHITE
    }

    fun alpha(color: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt(),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    fun lighten(c: Int, t: Float): Int = mix(c, Color.WHITE, t)
    fun darken(c: Int, t: Float): Int = mix(c, Color.BLACK, t)

    /** Raised card: lighter at the top, soft edge. [a] = overall opacity (255 = solid). */
    fun surface(radiusPx: Int, stroke: Int, strokePx: Int, a: Int = 255): GradientDrawable {
        val top = alpha(lighten(card, 0.09f), a)
        val bottom = alpha(card, a)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            if (strokePx > 0) setStroke(strokePx, stroke)
        }
    }

    /** Darker box that sits INSIDE a card (second depth level). */
    fun inset(radiusPx: Int): GradientDrawable {
        val fill = mix(bg, card, 0.35f)
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(fill)
            setStroke(1, alpha(border, 0x80))
        }
    }

    /**
     * Every card/button in the app goes through here, so depth is added in one place:
     * cards get a top-lit gradient, accent buttons get a chrome gradient. Colors still come from your theme slots.
     */
    fun box(fill: Int, stroke: Int, radiusPx: Int, strokePx: Int): GradientDrawable {
        if (fill == card && radiusPx >= 12) {
            return surface(radiusPx, stroke, strokePx)
        }
        if (strokePx == 0 && (fill == text || fill == buy || fill == sell)) {
            return GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(lighten(fill, 0.30f), fill, darken(fill, 0.22f))
            ).apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radiusPx.toFloat()
            }
        }
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(fill)
            if (strokePx > 0) setStroke(strokePx, stroke)
        }
    }

    fun circle(fill: Int, stroke: Int, strokePx: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            if (strokePx > 0) setStroke(strokePx, stroke)
        }
    }

    /** Round coin-image view (falls back to an empty circle until the picture loads). */
    fun avatar(context: Context, sizePx: Int, strokePx: Int): ImageView {
        return ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = circle(alpha(text, 0x22), alpha(text, 0x40), strokePx)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)
        }
    }
}
