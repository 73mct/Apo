package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.ImageView
import android.widget.LinearLayout
import android.view.ViewOutlineProvider

/**
 * Shared design system for 73MCT. Theme values are deliberately separate from
 * trading preferences and trade history. All additions here are presentation-only.
 */
object Theme {
    private const val PREFS_NAME = "pocketflip_theme"
    private const val THEME_VERSION = 5

    data class Slot(val key: String, val label: String, val defaultHex: String)

    // Compact midnight palette: neutral surfaces, electric-blue actions, clear PnL colours.
    private val violetDefaults = linkedMapOf(
        "bg" to "#080610",
        "card" to "#15131E",
        "border" to "#292635",
        "text" to "#F5F3FA",
        "muted" to "#9A96A8",
        "buy" to "#4F65FF",
        "sell" to "#E65D80",
        "profit" to "#21C96B",
        "loss" to "#F05252",
        "accent" to "#4F65FF",
        "accent2" to "#35B9DC",
        "surface2" to "#1D1A28",
        "glow" to "#5267FF",
        "nav" to "#2C2B35"
    )

    // Previous bundled defaults are retained only for a safe upgrade migration.
    private val previousVioletDefaults = mapOf(
        "bg" to "#080A12", "card" to "#121726", "border" to "#29324A",
        "text" to "#F4F5FB", "muted" to "#99A3B8", "buy" to "#7867FF",
        "sell" to "#D85A82", "profit" to "#43DBA0", "loss" to "#FC657B",
        "accent" to "#8D7CFF", "accent2" to "#37C5F4", "surface2" to "#1A2235",
        "glow" to "#6E5BFF", "nav" to "#101626"
    )

    val slots: List<Slot> = listOf(
        Slot("bg", "App background", violetDefaults.getValue("bg")),
        Slot("card", "Cards / panels", violetDefaults.getValue("card")),
        Slot("surface2", "Inner surfaces", violetDefaults.getValue("surface2")),
        Slot("border", "Borders", violetDefaults.getValue("border")),
        Slot("text", "Main text", violetDefaults.getValue("text")),
        Slot("muted", "Secondary text", violetDefaults.getValue("muted")),
        Slot("accent", "Primary accent", violetDefaults.getValue("accent")),
        Slot("accent2", "Secondary accent", violetDefaults.getValue("accent2")),
        Slot("glow", "Ambient glow", violetDefaults.getValue("glow")),
        Slot("nav", "Navigation surface", violetDefaults.getValue("nav")),
        Slot("buy", "Buy buttons", violetDefaults.getValue("buy")),
        Slot("sell", "Sell buttons", violetDefaults.getValue("sell")),
        Slot("profit", "Profit color", violetDefaults.getValue("profit")),
        Slot("loss", "Loss color", violetDefaults.getValue("loss"))
    )

    private val legacyChrome = mapOf(
        "bg" to "#050608", "card" to "#16181D", "border" to "#30333B",
        "text" to "#F1F3F6", "muted" to "#A4A9B3", "buy" to "#E3E6EB",
        "sell" to "#E3E6EB", "profit" to "#F1F3F6", "loss" to "#A4A9B3"
    )
    private val blackWhite = mapOf(
        "bg" to "#000000", "card" to "#151515", "border" to "#2E2E2E",
        "text" to "#FFFFFF", "muted" to "#A0A0A0", "buy" to "#FFFFFF",
        "sell" to "#FFFFFF", "profit" to "#FFFFFF", "loss" to "#A8A8A8",
        "accent" to "#D9DDE5", "accent2" to "#A5ACB8", "surface2" to "#202020",
        "glow" to "#A7B0C2", "nav" to "#111111"
    )

    const val DEFAULT_PRESET = "Market Pulse"

    val presets: LinkedHashMap<String, Map<String, String>> = linkedMapOf(
        "Market Pulse" to violetDefaults,
        "Violet Pulse" to previousVioletDefaults,
        "Chrome 73" to mapOf(
            "bg" to "#08090D", "card" to "#17191F", "surface2" to "#22252D",
            "border" to "#363A45", "text" to "#F1F3F6", "muted" to "#A4A9B3",
            "accent" to "#D6D9E0", "accent2" to "#8D96A6", "glow" to "#AAB1C0",
            "nav" to "#15171D", "buy" to "#D8DCE4", "sell" to "#9EA5B2",
            "profit" to "#F1F3F6", "loss" to "#9299A6"
        ),
        "Chrome + Green/Red PnL" to mapOf(
            "bg" to "#08090D", "card" to "#17191F", "surface2" to "#22252D",
            "border" to "#363A45", "text" to "#F1F3F6", "muted" to "#A4A9B3",
            "accent" to "#D6D9E0", "accent2" to "#8D96A6", "glow" to "#AAB1C0",
            "nav" to "#15171D", "buy" to "#D8DCE4", "sell" to "#9EA5B2",
            "profit" to "#22C55E", "loss" to "#EF4444"
        ),
        "Ocean Drive" to mapOf(
            "bg" to "#061019", "card" to "#0E1D2B", "surface2" to "#142A3B",
            "border" to "#23445A", "text" to "#F1FAFF", "muted" to "#91AFC1",
            "accent" to "#36B9F4", "accent2" to "#63E5D5", "glow" to "#168ED2",
            "nav" to "#0B1926", "buy" to "#32B9F5", "sell" to "#E06B9B",
            "profit" to "#43DBA0", "loss" to "#FC657B"
        ),
        "Emerald Terminal" to mapOf(
            "bg" to "#07110F", "card" to "#10201C", "surface2" to "#193029",
            "border" to "#29483D", "text" to "#F1FFF8", "muted" to "#9BB6A9",
            "accent" to "#36D69A", "accent2" to "#A7E36D", "glow" to "#178C68",
            "nav" to "#0C1B16", "buy" to "#35D49A", "sell" to "#D96D83",
            "profit" to "#43DBA0", "loss" to "#FC657B"
        ),
        "Black & White" to blackWhite,
        "B&W + Green/Red PnL" to blackWhite + mapOf("profit" to "#22C55E", "loss" to "#EF4444"),
        "Paper (White)" to mapOf(
            "bg" to "#F4F5F8", "card" to "#FFFFFF", "surface2" to "#EAECF1",
            "border" to "#D9DDE6", "text" to "#111827", "muted" to "#697386",
            "accent" to "#5A50D6", "accent2" to "#159CC8", "glow" to "#A6A2F2",
            "nav" to "#FFFFFF", "buy" to "#5A50D6", "sell" to "#B84D70",
            "profit" to "#159A67", "loss" to "#D94E60"
        ),
        "Midnight" to mapOf(
            "bg" to "#05070D", "card" to "#121826", "surface2" to "#1B2638",
            "border" to "#27324A", "text" to "#F8FAFC", "muted" to "#94A3B8",
            "accent" to "#6477FF", "accent2" to "#38BDF8", "glow" to "#4359C9",
            "nav" to "#0D1422", "buy" to "#6477FF", "sell" to "#F472B6",
            "profit" to "#34D399", "loss" to "#FB7185"
        )
    )

    private var prefs: SharedPreferences? = null
    private var density: Float = 1f
    private val hexMap = LinkedHashMap<String, String>()
    private val intMap = HashMap<String, Int>()

    @Volatile
    var version: Int = 0
        private set

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        density = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val currentVersion = prefs?.getInt("theme_ver", 0) ?: 0
        val isLegacyDefault = currentVersion < THEME_VERSION && legacyChrome.all { (key, value) ->
            val saved = prefs?.getString(key, null)
            saved == null || saved.equals(value, ignoreCase = true)
        }
        val isPreviousBuiltIn = currentVersion < THEME_VERSION && slots.all { slot ->
            val saved = prefs?.getString(slot.key, null)
            saved == null || saved.equals(previousVioletDefaults[slot.key], ignoreCase = true)
        }
        val editor = prefs?.edit()?.putInt("theme_ver", THEME_VERSION)
        for (slot in slots) {
            val saved = prefs?.getString(slot.key, null)
            val chosen = when {
                (isLegacyDefault || isPreviousBuiltIn) && violetDefaults.containsKey(slot.key) -> violetDefaults.getValue(slot.key)
                saved != null && parseHex(saved) != null -> saved
                else -> slot.defaultHex
            }
            val hex = if (chosen.startsWith("#")) chosen else "#$chosen"
            hexMap[slot.key] = hex
            intMap[slot.key] = parseHex(hex) ?: Color.BLACK
            if (isLegacyDefault || saved == null || parseHex(saved) == null) editor?.putString(slot.key, hex)
        }
        editor?.apply()
    }

    fun parseHex(raw: String): Int? {
        val t = raw.trim()
        if (t.isEmpty()) return null
        val withHash = if (t.startsWith("#")) t else "#$t"
        return try { Color.parseColor(withHash) } catch (_: Throwable) { null }
    }

    @Synchronized
    fun applyColors(values: Map<String, String>) {
        val ed = prefs?.edit()
        for (s in slots) {
            val raw = values[s.key] ?: continue
            val parsed = parseHex(raw) ?: continue
            val hex = if (raw.trim().startsWith("#")) raw.trim() else "#" + raw.trim()
            hexMap[s.key] = hex
            intMap[s.key] = parsed
            ed?.putString(s.key, hex)
        }
        ed?.putInt("theme_ver", THEME_VERSION)?.apply()
        version++
    }

    fun hexOf(key: String): String = hexMap[key] ?: "#000000"
    fun c(key: String): Int = intMap[key] ?: Color.MAGENTA

    val bg: Int get() = c("bg")
    val card: Int get() = c("card")
    val surface2: Int get() = c("surface2")
    val border: Int get() = c("border")
    val text: Int get() = c("text")
    val muted: Int get() = c("muted")
    val buy: Int get() = c("buy")
    val sell: Int get() = c("sell")
    val profit: Int get() = c("profit")
    val loss: Int get() = c("loss")
    val accent: Int get() = c("accent")
    val accent2: Int get() = c("accent2")
    val glow: Int get() = c("glow")
    val nav: Int get() = c("nav")

    fun pnlColor(value: Double): Int = if (value >= 0.0) profit else loss

    fun onColor(background: Int): Int {
        val lum = (0.299 * Color.red(background) + 0.587 * Color.green(background) + 0.114 * Color.blue(background)) / 255.0
        return if (lum > 0.55) Color.BLACK else Color.WHITE
    }

    fun alpha(color: Int, a: Int): Int = Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt(),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    fun lighten(c: Int, t: Float): Int = mix(c, Color.WHITE, t)
    fun darken(c: Int, t: Float): Int = mix(c, Color.BLACK, t)

    /** Flat, restrained surfaces: hierarchy comes from spacing and dividers, not glow. */
    fun surface(radiusPx: Int, stroke: Int, strokePx: Int, a: Int = 255): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx.coerceAtMost((12f * density).toInt()).toFloat()
        setColor(alpha(card, a))
        if (strokePx > 0) setStroke(strokePx, alpha(stroke, a))
    }

    fun inset(radiusPx: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx.coerceAtMost((10f * density).toInt()).toFloat()
        setColor(surface2)
        setStroke(1, alpha(border, 0xB0))
    }

    fun button(fill: Int = accent, radiusPx: Int = 16): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx.coerceAtMost((9f * density).toInt()).toFloat()
        setColor(fill)
    }

    fun chip(active: Boolean, radiusPx: Int = 18): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx.coerceAtMost((9f * density).toInt()).toFloat()
        setColor(if (active) accent else surface2)
        setStroke(1, if (active) accent else alpha(border, 0xC0))
    }

    fun box(fill: Int, stroke: Int, radiusPx: Int, strokePx: Int): GradientDrawable {
        if (fill == card && radiusPx >= 12) return surface(radiusPx, stroke, strokePx)
        if (fill == accent || fill == buy || fill == sell) return button(fill, radiusPx)
        if (strokePx == 0 && fill == text) return button(fill, radiusPx)
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.coerceAtMost((12f * density).toInt()).toFloat()
            setColor(fill)
            if (strokePx > 0) setStroke(strokePx, stroke)
        }
    }

    fun circle(fill: Int, stroke: Int, strokePx: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
        if (strokePx > 0) setStroke(strokePx, stroke)
    }

    fun avatar(context: Context, sizePx: Int, strokePx: Int): ImageView = ImageView(context).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = circle(alpha(accent, 0x24), alpha(accent, 0xB0), strokePx)
        clipToOutline = true
        outlineProvider = ViewOutlineProvider.BACKGROUND
        layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)
    }
}
