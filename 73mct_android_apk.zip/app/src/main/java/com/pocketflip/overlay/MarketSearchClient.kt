package com.pocketflip.overlay

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.LinkedHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Read-only token discovery. Deliberately separate from DexScreenerClient so searching
 * never changes the app's active live-price subscriptions or paper-trade execution path.
 */
object MarketSearchClient {
    data class PairResult(
        val chainId: String,
        val dexId: String,
        val pairAddress: String,
        val tokenAddress: String,
        val symbol: String,
        val name: String,
        val priceUsd: Double,
        val marketCap: Double,
        val fdv: Double,
        val volume24h: Double,
        val change24h: Double?,
        val liquidityUsd: Double,
        val imageUrl: String,
        val pairUrl: String,
        val createdAtMs: Long
    )

    private val executor = Executors.newSingleThreadExecutor { task ->
        Thread(task, "73mct-market-search").apply { isDaemon = true }
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .callTimeout(9, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    fun searchSolana(query: String, callback: (Result<List<PairResult>>) -> Unit) {
        val clean = query.trim().take(100)
        if (clean.length < 2) {
            callback(Result.failure(IllegalArgumentException("Enter at least 2 characters.")))
            return
        }
        executor.execute {
            val result = try {
                val encoded = URLEncoder.encode(clean, "UTF-8")
                val request = Request.Builder()
                    .url("https://api.dexscreener.com/latest/dex/search?q=$encoded")
                    .header("Accept", "application/json")
                    .get()
                    .build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        val message = when (response.code) {
                            429 -> "Search is rate-limited. Try again in a moment."
                            else -> "Market search failed (HTTP ${response.code})."
                        }
                        throw IOException(message)
                    }
                    val body = response.body?.string().orEmpty()
                    if (body.isBlank()) throw IOException("The market search returned an empty response.")
                    Result.success(parseSolanaPairs(JSONObject(body), clean))
                }
            } catch (t: Throwable) {
                Result.failure(t)
            }
            callback(result)
        }
    }

    private fun parseSolanaPairs(root: JSONObject, query: String): List<PairResult> {
        val arr = root.optJSONArray("pairs") ?: return emptyList()
        val bestByToken = LinkedHashMap<String, PairResult>()
        for (i in 0 until arr.length()) {
            val pair = arr.optJSONObject(i) ?: continue
            if (!pair.optString("chainId").equals("solana", ignoreCase = true)) continue

            val token = pair.optJSONObject("baseToken") ?: JSONObject()
            val mint = token.optString("address").trim()
            val queryLooksLikeAddress = query.length >= 28 && query.all { it.isLetterOrDigit() }
            if (mint.isBlank() || (queryLooksLikeAddress && !mint.equals(query, ignoreCase = true))) continue

            val volume = pair.optJSONObject("volume") ?: JSONObject()
            val change = pair.optJSONObject("priceChange") ?: JSONObject()
            val liquidity = pair.optJSONObject("liquidity") ?: JSONObject()
            val info = pair.optJSONObject("info") ?: JSONObject()
            val pairAddress = pair.optString("pairAddress", "")
            val pairUrl = pair.optString("url", "").ifBlank {
                if (pairAddress.isNotBlank()) "https://dexscreener.com/solana/$pairAddress"
                else "https://dexscreener.com/solana/$mint"
            }
            val marketCap = pair.optDouble("marketCap", 0.0).coerceAtLeast(0.0)
            val fdv = pair.optDouble("fdv", 0.0).coerceAtLeast(0.0)
            val result = PairResult(
                chainId = "solana",
                dexId = pair.optString("dexId", "DEX"),
                pairAddress = pairAddress,
                tokenAddress = mint,
                symbol = token.optString("symbol", "").ifBlank { Formatters.shortCa(mint) },
                name = token.optString("name", "").ifBlank { "Solana token" },
                priceUsd = pair.optString("priceUsd", "0").toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0,
                marketCap = marketCap,
                fdv = fdv,
                volume24h = volume.optDouble("h24", 0.0).coerceAtLeast(0.0),
                change24h = change.optDouble("h24", Double.NaN).takeUnless { it.isNaN() || it.isInfinite() },
                liquidityUsd = liquidity.optDouble("usd", 0.0).coerceAtLeast(0.0),
                imageUrl = info.optString("imageUrl", ""),
                pairUrl = pairUrl,
                createdAtMs = pair.optLong("pairCreatedAt", 0L)
            )
            val prior = bestByToken[mint]
            if (prior == null || result.liquidityUsd > prior.liquidityUsd) bestByToken[mint] = result
        }
        return bestByToken.values.sortedWith(
            compareByDescending<PairResult> { it.liquidityUsd }
                .thenByDescending { it.volume24h }
        ).take(25)
    }
}
