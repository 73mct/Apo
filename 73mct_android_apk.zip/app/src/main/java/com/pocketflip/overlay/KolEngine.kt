package com.pocketflip.overlay

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

/** One KOL's whole history in one coin. */
class KolPos(val wallet: KolWallet, val tok: KolToken, val fills: List<KolFill>) {
    val invested: Double = fills.filter { it.buy }.sumOf { it.sol }
    val returned: Double = fills.filter { !it.buy }.sumOf { it.sol }
    val boughtTok: Double = fills.filter { it.buy }.sumOf { it.tok }
    val soldTok: Double = fills.filter { !it.buy }.sumOf { it.tok }
    val firstBuyTs: Long = fills.filter { it.buy }.minOfOrNull { it.ts } ?: 0L
    val lastSellTs: Long = fills.filter { !it.buy }.maxOfOrNull { it.ts } ?: 0L
    val heldTok: Double = max(0.0, boughtTok - soldTok)
    val stillOpen: Boolean = boughtTok > 0.0 && heldTok / boughtTok > 0.05
    private val heldValue: Double = if (tok.priceNative > 0.0) heldTok * tok.priceNative else 0.0
    val pnl: Double = returned + heldValue - invested
    val multiple: Double = if (invested > 0.0) (returned + heldValue) / invested else 0.0
    val holdSec: Long = run {
        val end = if (stillOpen || lastSellTs == 0L) System.currentTimeMillis() / 1000L else lastSellTs
        max(0L, end - firstBuyTs)
    }

    /** Market cap (USD) a fill happened at, worked out from the price ratio to the current price. */
    fun mcAt(f: KolFill): Double {
        if (!tok.valid || f.tok <= 0.0) return 0.0
        return (f.sol / f.tok) / tok.priceNative * tok.mc
    }

    val entryMc: Double = fills.filter { it.buy }.minByOrNull { it.ts }?.let { mcAt(it) } ?: 0.0
    val maxSellMc: Double = fills.filter { !it.buy }.maxOfOrNull { mcAt(it) } ?: 0.0
    val exitMc: Double = if (soldTok > 0.0 && tok.valid) (returned / soldTok) / tok.priceNative * tok.mc else 0.0
}

/** One coin and every tracked KOL who traded it, earliest first. */
class KolCoin(val tok: KolToken, val positions: List<KolPos>) {
    val peak: Double = max(tok.peakMc, max(tok.mc, positions.maxOfOrNull { max(it.maxSellMc, it.entryMc) } ?: 0.0))
    val kolCount: Int = positions.size
    val totalPnl: Double = positions.sumOf { it.pnl }
    val longestHoldSec: Long = positions.filter { it.pnl > 0.0 }.maxOfOrNull { it.holdSec } ?: 0L
}

class KolStat(val wallet: KolWallet, val positions: List<KolPos>, val earlyHits: Int, val firstIns: Int) {
    val trades: Int = positions.size
    val wins: Int = positions.count { it.pnl > 0.0 }
    val winRate: Double = if (trades > 0) wins * 100.0 / trades else 0.0
    val totalPnl: Double = positions.sumOf { it.pnl }
    val avgMultiple: Double = if (trades > 0) positions.map { it.multiple }.sorted().let { it[it.size / 2] } else 0.0
    val medianWinHoldSec: Long = positions.filter { it.pnl > 0.0 }.map { it.holdSec }.sorted().let { if (it.isEmpty()) 0L else it[it.size / 2] }
    val scalps: Int = positions.count { it.holdSec < 30 * 60L }
    val swings: Int = positions.count { it.holdSec in (30 * 60L)..(24 * 3600L - 1L) }
    val holds: Int = positions.count { it.holdSec >= 24 * 3600L }
    val best: KolPos? = positions.maxByOrNull { it.pnl }
}

class KolTheme(val name: String, val coins: List<KolCoin>) {
    val count: Int = coins.size
    val totalPnl: Double = coins.sumOf { it.totalPnl }
    val avgPeak: Double = if (count > 0) coins.sumOf { it.peak } / count else 0.0
    val avgKols: Double = if (count > 0) coins.sumOf { it.kolCount }.toDouble() / count else 0.0
    val positions: Int = coins.sumOf { it.kolCount }
    val winRate: Double = if (positions > 0) coins.sumOf { c -> c.positions.count { it.pnl > 0.0 } } * 100.0 / positions else 0.0
}

object KolEngine {
    private const val WSOL = "So11111111111111111111111111111111111111112"
    private val STABLES = setOf(
        "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
        "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"
    )

    @Volatile var cancel = false
    @Volatile var heliusCalls = 0
    @Volatile var geckoCalls = 0

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    /** Returns (status code, body). Code -1 = network failure. */
    private fun get(url: String): Pair<Int, String> {
        return try {
            val req = Request.Builder().url(url).header("Accept", "application/json").build()
            http.newCall(req).execute().use { r -> Pair(r.code, r.body?.string() ?: "") }
        } catch (_: Throwable) {
            Pair(-1, "")
        }
    }

    private fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) {}
    }

    // ------------------------------------------------------------------
    // 1) Wallet swaps from Helius (free key). Reads the wallet's own balance changes, so it works
    //    for pump.fun, PumpSwap, Raydium, Jupiter and anything else that swaps SOL for a token.
    // ------------------------------------------------------------------
    /** Returns null if fine, otherwise a short error message. */
    fun scanWallet(w: KolWallet, key: String, days: Int, onStatus: (String) -> Unit): String? {
        val nowSec = System.currentTimeMillis() / 1000L
        val cutoffDays = nowSec - days * 86400L
        // re-scan: only go back to a bit before the newest swap we already have
        val cutoff = if (w.lastTxTs > 0L) max(cutoffDays, w.lastTxTs - 120L) else cutoffDays
        val store = KolStore.fillsOf(w.address)
        val seen = HashSet<String>()
        for (list in store.values) for (f in list) seen.add("" + f.ts + (if (f.buy) "b" else "s") + f.tok)
        var before = ""
        var pages = 0
        var newest = w.lastTxTs
        var added = 0
        while (pages < 40 && !cancel) {
            val url = "https://api.helius.xyz/v0/addresses/" + w.address + "/transactions?api-key=" + key +
                "&limit=100&type=SWAP" + (if (before.isNotEmpty()) "&before=$before" else "")
            var code = 0
            var body = ""
            var tries = 0
            while (tries < 4) {
                heliusCalls++
                val r = get(url)
                code = r.first; body = r.second
                if (code == 429) { sleep(2500L); tries++; continue }
                if (code == -1) { sleep(1500L); tries++; continue }
                break
            }
            if (code == 401 || code == 403) return "Helius key rejected"
            if (code == 429) return "Helius rate limit hit, try again in a minute"
            if (code != 200) return "Helius error " + code
            val arr = try { JSONArray(body) } catch (_: Throwable) { return "Bad answer from Helius" }
            if (arr.length() == 0) break
            var reachedOld = false
            for (i in 0 until arr.length()) {
                val tx = arr.getJSONObject(i)
                val ts = tx.optLong("timestamp", 0L)
                if (ts in 1 until cutoff) { reachedOld = true; continue }
                before = tx.optString("signature", before)
                if (!tx.isNull("transactionError")) continue
                val parsed = parseSwap(tx, w.address) ?: continue
                val key2 = "" + ts + (if (parsed.second.buy) "b" else "s") + parsed.second.tok
                if (!seen.add(key2)) continue
                store.getOrPut(parsed.first) { ArrayList() }.add(parsed.second)
                added++
                if (ts > newest) newest = ts
            }
            onStatus(w.label + ": page " + (pages + 1) + ", " + added + " swaps")
            pages++
            if (reachedOld || arr.length() < 100) break
            sleep(600L)   // free plan allows about 2 of these calls per second
        }
        for (list in store.values) list.sortBy { it.ts }
        KolStore.saveFills(w.address)
        w.lastTxTs = newest
        w.lastScanMs = System.currentTimeMillis()
        w.swapCount = store.values.sumOf { it.size }
        w.error = ""
        return null
    }

    /** One swap -> (mint, fill), or null if it is not a clean SOL <-> single token trade. */
    private fun parseSwap(tx: JSONObject, wallet: String): Pair<String, KolFill>? {
        val ts = tx.optLong("timestamp", 0L)
        if (ts <= 0L) return null
        var lam = 0L
        val ad = tx.optJSONArray("accountData")
        if (ad != null) {
            for (i in 0 until ad.length()) {
                val a = ad.getJSONObject(i)
                if (a.optString("account") == wallet) lam += a.optLong("nativeBalanceChange", 0L)
            }
        }
        val net = HashMap<String, Double>()
        val tt = tx.optJSONArray("tokenTransfers")
        if (tt != null) {
            for (i in 0 until tt.length()) {
                val t = tt.getJSONObject(i)
                val mint = t.optString("mint")
                val amt = t.optDouble("tokenAmount", 0.0)
                if (mint.isEmpty() || amt.isNaN()) continue
                if (t.optString("toUserAccount") == wallet) net[mint] = (net[mint] ?: 0.0) + amt
                if (t.optString("fromUserAccount") == wallet) net[mint] = (net[mint] ?: 0.0) - amt
            }
        }
        val wsol = net.remove(WSOL) ?: 0.0
        val lamSol = lam / 1e9
        val solDelta = if (abs(wsol) > abs(lamSol)) wsol else lamSol
        val others = net.filter { abs(it.value) > 0.0 && !STABLES.contains(it.key) }
        if (others.size != 1) return null
        val mint = others.keys.first()
        val tokDelta = others[mint] ?: return null
        if (abs(solDelta) < 0.001) return null
        if (tokDelta > 0.0 && solDelta < 0.0) return Pair(mint, KolFill(ts, true, -solDelta, tokDelta))
        if (tokDelta < 0.0 && solDelta > 0.0) return Pair(mint, KolFill(ts, false, solDelta, -tokDelta))
        return null
    }

    // ------------------------------------------------------------------
    // 2) Coin info + current price from DexScreener (free, 30 coins per call)
    // ------------------------------------------------------------------
    fun refreshTokens(mints: List<String>, onStatus: (String) -> Unit) {
        val now = System.currentTimeMillis()
        val todo = mints.filter { m -> val t = KolStore.tokens[m]; t == null || now - t.metaAt > 10 * 60_000L }
        var done = 0
        for (chunk in todo.chunked(30)) {
            if (cancel) break
            val r = get("https://api.dexscreener.com/tokens/v1/solana/" + chunk.joinToString(","))
            if (r.first == 200) {
                try {
                    val arr = JSONArray(r.second)
                    val best = HashMap<String, JSONObject>()
                    val bestLiq = HashMap<String, Double>()
                    for (i in 0 until arr.length()) {
                        val p = arr.getJSONObject(i)
                        val mint = p.optJSONObject("baseToken")?.optString("address") ?: continue
                        val quote = p.optJSONObject("quoteToken")?.optString("symbol") ?: ""
                        if (quote != "SOL" && quote != "WSOL") continue
                        val liq = p.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
                        if (liq >= (bestLiq[mint] ?: -1.0)) { best[mint] = p; bestLiq[mint] = liq }
                    }
                    for (m in chunk) {
                        val t = KolStore.tokens.getOrPut(m) { KolToken(m) }
                        t.metaAt = now
                        val p = best[m]
                        if (p == null) { t.priceNative = 0.0; t.mc = 0.0; continue }
                        val bt = p.optJSONObject("baseToken")
                        t.sym = bt?.optString("symbol") ?: t.sym
                        t.name = bt?.optString("name") ?: t.name
                        t.pair = p.optString("pairAddress", t.pair)
                        t.priceNative = p.optString("priceNative", "0").toDoubleOrNull() ?: 0.0
                        t.priceUsd = p.optString("priceUsd", "0").toDoubleOrNull() ?: 0.0
                        var mc = p.optDouble("marketCap", 0.0)
                        if (mc.isNaN() || mc <= 0.0) mc = p.optDouble("fdv", 0.0)
                        t.mc = if (mc.isNaN()) 0.0 else mc
                        val img = p.optJSONObject("info")?.optString("imageUrl") ?: ""
                        if (img.isNotEmpty()) t.img = img
                    }
                } catch (_: Throwable) {
                }
            }
            done += chunk.size
            onStatus("Coin info " + done + "/" + todo.size)
            sleep(350L)
        }
        KolStore.saveTokens()
    }

    // ------------------------------------------------------------------
    // 3) Real peak market cap from GeckoTerminal hourly candles (free, ~30 calls/min)
    // ------------------------------------------------------------------
    fun refreshPeaks(coins: List<Pair<KolToken, Long>>, maxCalls: Int, onStatus: (String) -> Unit) {
        val now = System.currentTimeMillis()
        val todo = coins.filter { it.first.pair.isNotEmpty() && it.first.priceUsd > 0.0 && now - it.first.peakAt > 6 * 3600_000L }
            .take(maxCalls)
        var i = 0
        for ((t, firstTs) in todo) {
            if (cancel) break
            i++
            onStatus("Peak market caps " + i + "/" + todo.size)
            geckoCalls++
            val r = get("https://api.geckoterminal.com/api/v2/networks/solana/pools/" + t.pair +
                "/ohlcv/hour?aggregate=1&limit=1000&currency=usd")
            if (r.first == 429) { sleep(8000L); continue }
            if (r.first == 200) {
                try {
                    val list = JSONObject(r.second).getJSONObject("data").getJSONObject("attributes").getJSONArray("ohlcv_list")
                    var hi = 0.0
                    for (k in 0 until list.length()) {
                        val c = list.getJSONArray(k)
                        if (c.getLong(0) >= firstTs - 3600L) hi = max(hi, c.getDouble(2))
                    }
                    if (hi > 0.0) t.peakMc = hi / t.priceUsd * t.mc
                    t.peakAt = now
                } catch (_: Throwable) {
                }
            }
            sleep(2200L)
        }
        KolStore.saveTokens()
    }

    /** Candles for the coin chart: list of (timeSec, marketCapUsd), oldest first. */
    fun candles(tok: KolToken, fromSec: Long, toSec: Long): List<Pair<Long, Double>> {
        if (tok.pair.isEmpty() || tok.priceUsd <= 0.0 || tok.mc <= 0.0) return emptyList()
        val now = System.currentTimeMillis() / 1000L
        val lead = max(600L, (toSec - fromSec) * 15 / 100)
        val tail = max(600L, (toSec - fromSec) * 25 / 100)
        val start = fromSec - lead
        val end = if (now - toSec < 6 * 3600L) now else minOf(now, toSec + tail)
        val total = end - start
        val unit: String
        val agg: Int
        when {
            total <= 1000L * 60L -> { unit = "minute"; agg = 1 }
            total <= 1000L * 300L -> { unit = "minute"; agg = 5 }
            total <= 1000L * 900L -> { unit = "minute"; agg = 15 }
            else -> { unit = "hour"; agg = 1 }
        }
        geckoCalls++
        val r = get("https://api.geckoterminal.com/api/v2/networks/solana/pools/" + tok.pair + "/ohlcv/" + unit +
            "?aggregate=" + agg + "&before_timestamp=" + (end + 1L) + "&limit=1000&currency=usd")
        if (r.first != 200) return emptyList()
        return try {
            val list = JSONObject(r.second).getJSONObject("data").getJSONObject("attributes").getJSONArray("ohlcv_list")
            val out = ArrayList<Pair<Long, Double>>()
            for (k in 0 until list.length()) {
                val c = list.getJSONArray(k)
                val ts = c.getLong(0)
                if (ts < start) continue
                out.add(Pair(ts, c.getDouble(4) / tok.priceUsd * tok.mc))
            }
            out.sortBy { it.first }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    // ------------------------------------------------------------------
    // 4) Analytics (pure reading of the saved fills)
    // ------------------------------------------------------------------
    fun buildCoins(): List<KolCoin> {
        val minSize = KolStore.minSizeSol
        val byMint = HashMap<String, ArrayList<KolPos>>()
        for (w in KolStore.wallets) {
            for ((mint, list) in KolStore.fillsOf(w.address)) {
                if (list.none { it.buy }) continue                 // sells only = airdrop / transfer, skip
                val tok = KolStore.tokens.getOrPut(mint) { KolToken(mint) }
                val pos = KolPos(w, tok, ArrayList(list))
                if (pos.invested < minSize) continue
                byMint.getOrPut(mint) { ArrayList() }.add(pos)
            }
        }
        val out = ArrayList<KolCoin>()
        for ((mint, list) in byMint) {
            list.sortBy { it.firstBuyTs }
            out.add(KolCoin(KolStore.tokens[mint]!!, list))
        }
        return out
    }

    fun stats(coins: List<KolCoin>): List<KolStat> {
        val minPeak = KolStore.minPeakMc
        val early = KolStore.earlyMc
        val out = ArrayList<KolStat>()
        for (w in KolStore.wallets) {
            val mine = ArrayList<KolPos>()
            var earlyHits = 0
            var firstIns = 0
            for (c in coins) {
                val p = c.positions.firstOrNull { it.wallet.address == w.address } ?: continue
                mine.add(p)
                if (c.peak >= minPeak) {
                    if (p.entryMc in 1.0..early) earlyHits++
                    if (c.kolCount >= 2 && c.positions.first().wallet.address == w.address) firstIns++
                }
            }
            if (mine.isNotEmpty()) out.add(KolStat(w, mine, earlyHits, firstIns))
        }
        return out
    }

    private val themes: LinkedHashMap<String, List<String>> = linkedMapOf(
        "Dogs" to listOf("dog", "doge", "inu", "shib", "puppy", "pup", "wif", "bonk", "hound", "woof", "cheems"),
        "Cats" to listOf("cat", "kitty", "kit", "meow", "mog", "popcat", "neko", "kitten", "purr"),
        "Frogs / Pepe" to listOf("pepe", "frog", "toad", "kek", "ribbit"),
        "AI / Agents" to listOf("ai", "agent", "gpt", "bot", "neural", "grok", "robot", "llm", "agi"),
        "Politics / Trump" to listOf("trump", "maga", "biden", "kamala", "vote", "president", "usa", "america", "elon"),
        "Other animals" to listOf("hamster", "monkey", "ape", "bear", "bull", "pig", "fish", "whale", "duck", "goat", "penguin", "bird", "panda", "fox", "rat", "cow", "horse", "rabbit", "bunny", "chicken", "squirrel", "turtle", "shark", "wolf", "tiger", "lion"),
        "Anime / Culture" to listOf("anime", "waifu", "chan", "kawaii", "senpai", "naruto", "otaku", "goku", "sigma", "skibidi", "rizz"),
        "Food" to listOf("pizza", "burger", "taco", "cheese", "banana", "coffee", "sushi", "fries", "cookie")
    )

    fun themeOf(t: KolToken): String {
        val text = (t.sym + " " + t.name).lowercase()
        val words = text.split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
        for ((name, keys) in themes) {
            for (k in keys) {
                if (k.length <= 3) { if (words.contains(k)) return name }
                else if (text.contains(k)) return name
            }
        }
        return "Other"
    }

    fun narratives(coins: List<KolCoin>): List<KolTheme> {
        val minPeak = KolStore.minPeakMc
        val pool = coins.filter { it.peak >= minPeak }
        val g = HashMap<String, ArrayList<KolCoin>>()
        for (c in pool) g.getOrPut(themeOf(c.tok)) { ArrayList() }.add(c)
        return g.map { KolTheme(it.key, it.value.sortedByDescending { c -> c.peak }) }
            .sortedByDescending { it.count }
    }

    // ------------------------------------------------------------------
    // helpers shared by the screens
    // ------------------------------------------------------------------
    private val b58 = Regex("^[1-9A-HJ-NP-Za-km-z]{32,44}$")

    /** Reads pasted text: one wallet per line, "label address" or "address label" or just the address. */
    fun parseBatch(text: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        for (line in text.split("\n")) {
            val parts = line.split(Regex("[\\s,;=|\\t]+")).map { it.trim() }.filter { it.isNotEmpty() }
            val addrs = parts.filter { b58.matches(it) }
            if (addrs.isEmpty()) continue
            val label = parts.filter { !b58.matches(it) }.joinToString(" ")
            for (a in addrs) out.add(Pair(a, if (addrs.size == 1) label else ""))
        }
        return out
    }

    fun money(v: Double): String = when {
        v >= 1e9 -> String.format("$%.2fB", v / 1e9)
        v >= 1e6 -> String.format("$%.2fM", v / 1e6)
        v >= 1e3 -> String.format("$%.0fK", v / 1e3)
        v > 0.0 -> String.format("$%.0f", v)
        else -> "n/a"
    }

    fun dur(sec: Long): String = when {
        sec < 90L -> sec.toString() + "s"
        sec < 5400L -> (sec / 60L).toString() + "m"
        sec < 48 * 3600L -> String.format("%dh %dm", sec / 3600L, (sec % 3600L) / 60L)
        else -> String.format("%dd %dh", sec / 86400L, (sec % 86400L) / 3600L)
    }
}
