# PocketFlip paid-platform backend roadmap

This document separates features that now work on-device from services that must be deployed
before a public paid release. It is not evidence that a backend has been deployed.

## Why a backend is needed

The Android app must not contain a shared Helius, X, market-data or AI-provider secret. A public
APK can be inspected and secrets extracted. Paid users also need authentication, synchronized
records, rate limits, entitlement checks and server-side purchase verification.

## Proposed services

1. **Wallet collector**
   - Store tracked wallet addresses and user ownership.
   - Poll new swap activity with pagination and provider backoff.
   - Deduplicate signatures and token mints.
   - Persist the raw transaction reference, timestamp, provider and parser confidence.
   - Reconcile wallet fills against token/pool metadata without treating wallet PnL as a
     guaranteed tradable exit.

2. **Historical evidence collector**
   - Cache pool OHLCV and market snapshots by chain, mint, pool, interval and timestamp.
   - Use the primary provider first, then configured fallback providers only for missing data.
   - Persist source, request time, data coverage and any gaps.
   - Save public X post URLs and metadata when legally and contractually available. Never
     fabricate deleted-account content or bypass access controls.

3. **Academy case generator**
   - Produce a decision-time snapshot that contains no future prices or future wallet actions.
   - Cluster repeated buys of the same mint into one underlying case while retaining each
     wallet's separate entry timestamp.
   - Sample winners, losers, false breakouts, stagnant tokens and untracked-market controls.
   - Keep outcome data in a separate table that is inaccessible to the decision screen until
     the user submits.
   - Quarantine incomplete cases instead of manufacturing an outcome.

4. **Outcome reconstruction**
   - Calculate time-to-target, maximum adverse excursion and maximum favourable excursion.
   - Prefer transaction-level swaps for executable fill estimates.
   - Where only candles exist, apply conservative liquidity/slippage assumptions and label the
     result as candle-derived rather than a verified executable fill.

5. **AI coach**
   - Send only the minimum user-approved records needed for a review.
   - Retrieve source-linked user decisions and market evidence before generation.
   - Separate model-generated hypotheses from measured statistics.
   - Return citations, sample size, uncertainty and data coverage with each observation.
   - Never generate buy/sell signals as a substitute for the user's judgement.

6. **Membership and synchronization**
   - Authenticate users and isolate their journals, watchlists and Academy decisions.
   - Verify Google Play purchase tokens server-side and handle renewals, refunds and revocation.
   - Enforce Pro/Elite entitlements on the server, not only through client-side flags.
   - Provide export and account deletion workflows before collecting personal data.

## Required secrets and accounts

Store provider credentials only as server-side environment secrets. Likely integrations include
Helius, the selected OHLCV/historical provider, X API where permitted, and an AI model provider.
The owner must create and control hosting, database, API billing and Google Play product IDs.
No credentials were present in the source package, so these integrations are not active.

## Minimum public-beta readiness gates

- Android release build succeeds and is tested on multiple devices.
- Paper-fill model is documented and checked against realistic slippage/liquidity assumptions.
- Academy no-lookahead tests pass, including timezone boundaries and missing history.
- Wallet and token records are deduplicated and source provenance is retained.
- Authentication, privacy policy, data deletion, API rate limits and abuse controls are live.
- Play Billing purchase verification and entitlement restoration pass sandbox testing.
- Performance claims distinguish simulated from real trading and include losing trades, fees,
  methodology and sample size.
