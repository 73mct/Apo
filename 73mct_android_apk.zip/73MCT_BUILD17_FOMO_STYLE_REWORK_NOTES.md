# 73MCT Build 17.0 — FOMO-style visual rework

## Reference review

The new 73MCT recording was compared with the supplied FOMO recording. The most visible mismatches were the tall branded header, strong outlined panels, oversized profile banner, full-width rigid bottom navigation, rounded/large filter controls, and the KOL screen opening directly into its wallet-configuration form when no wallets were saved.

## Changes in this build

- Reworked the top chrome into a short, full-bleed cyan market strip, with smaller brand, balance and settings controls.
- Replaced the full-width boxed bottom bar with a floating translucent capsule, icon-only destinations and a compact selected-state highlight.
- Reduced the main content's vertical chrome and kept the content inset close to the FOMO reference's edge spacing.
- Flattened the common card surfaces: removed most one-pixel outlines, reduced padding and standardised a more restrained corner treatment.
- Tightened button and filter-chip sizing and restyled the KOL subtabs as text tabs with a short selected underline.
- Reduced the profile cover/avatar block so it no longer consumes such a large portion of the Portfolio screen.
- Changed the bundled default palette to a dark neutral + electric-blue market palette. A theme-version migration updates users who were still on the previous bundled default while preserving a custom saved palette.
- Fixed the first-open KOL behaviour: the KOL tab now opens on the leaderboard. Wallet management opens only when the user selects Wallets or taps the empty-state action.
- Added a compact, actionable first-run leaderboard state and feed empty state instead of leaving a lone line of text in a mostly blank page.
- Incremented the app version to `17.0-73MCT` / versionCode `19`.

## Files changed

- `app/src/main/java/com/pocketflip/overlay/MainActivity.kt`
- `app/src/main/java/com/pocketflip/overlay/KolScreen.kt`
- `app/src/main/java/com/pocketflip/overlay/Theme.kt`
- `app/build.gradle`

## Protected functionality

No edits were made to `DexScreenerClient.kt`, `TradeRepository.kt`, `Models.kt`, KOL history/engine calculations, the paper buy/sell/PnL calculations, the signing keystore, or `.github/workflows/build-apk.yml`.

The feed still represents this app's own paper fills, tracked-wallet swaps and saved thesis notes. It is not a global public social feed like FOMO; that would require a separate backend/data source. This build changes the visual treatment and navigation, not that data capability.

## Verification status

- The ZIP archive was checked with `unzip -t`.
- The edited Kotlin source was inspected for parser/syntax diagnostics, but a full Android Gradle build was not run here because this environment does not have an Android SDK or Gradle installation.
- Therefore this build is **not claimed as locally compiled**. Please run the existing GitHub Actions workflow; send the next log if it reports a compiler error.

This is a closer FOMO-inspired visual pass, not a pixel-identical reproduction of FOMO's proprietary app or backend.
