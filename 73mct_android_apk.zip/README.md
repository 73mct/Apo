# 73MCT v2 - Complete Android Project Suite

## Included Features in v2:
1. **Permanent Bugfix:** Resolved the `"MEME"` replay fallback bug by implementing live on-demand RPC signature scanning and token balance diffing.
2. **Cabal Confluence Engine:** Multi-wallet cluster detection for tracked KOLs.
3. **Rug & Bundle Shield:** Live contract audit scanning for mint/freeze authority and holder concentration.
4. **1-Tap Break-Even ("INIT") Button:** Instantly sells exact token percentage to reclaim initial SOL principal.
5. **Pro Replay Studio:** Interactive OHLCV candles, MCap milestones, and "Ghost Trade Against KOL" mode.
6. **Anti-Tilt Circuit Breaker & 73 Dark Share Cards:** Obsidian PnL card exporter and drawdown protection.