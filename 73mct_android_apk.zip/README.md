# PocketFlip Native — Build 14.0

Android Solana meme-coin paper-trading and training app.

## Main areas

- **Trade** — existing live-quote paper-trading flow and floating bubble.
- **Journal** — closed-trade history, replay and PnL card/video export.
- **Thesis / Profile / Settings** — existing supporting tools and personalisation.
- **KOLs** — existing tracked-wallet intelligence.
- **Academy** — separate historical Game and Results sections.
- **Lab** — connected paper-account overview, mint watchlist, strategy rules, risk sizing,
  evidence-based personal coach, trade replay, creator studio, personal challenges and a
  transparent future membership outline.

## Build

Open in Android Studio or upload the complete repository root to a separate GitHub repository
and run `.github/workflows/build-apk.yml`. The app uses application ID
`com.pocketflip.overlay`; this package retains the existing debug signing key for in-place
updates of the same install.

## Important

This source package is not a real-money trading client. The live market quotes feed a simulated
paper account. Build 14.0 has not been built or tested on a device in the current environment.
The current personal coach is local statistical analysis, not a connected generative AI model.
Subscription payments, public leaderboards, account synchronization and remote historical-data
collection are not activated. See `BUILD-14.0-POCKETFLIP-NOTES.txt` and
`docs/PAID-PLATFORM-BACKEND-ROADMAP.md` before planning a public paid release.
