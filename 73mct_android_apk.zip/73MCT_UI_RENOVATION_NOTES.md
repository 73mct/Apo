# 73MCT UI Renovation — Build 15.0

## Source base

This update is based on the uploaded Build 14.0-73MCT Android project (`versionCode 16`). The app package ID and debug signing key are unchanged. The Android version is now `15.0-73MCT` (`versionCode 17`).

## What changed

### Shared visual system

- Replaced the one-level near-black surface treatment with a deeper midnight palette, layered card gradients, brighter edge treatment and soft accent glow.
- Added a primary accent, secondary accent, inner-surface, ambient-glow and navigation color slots.
- Added the Violet Pulse default plus Chrome 73, Chrome + Green/Red PnL, Ocean Drive, Emerald Terminal, Black & White, B&W + Green/Red PnL, Paper and Midnight presets.
- All 14 theme color slots are editable in Settings and continue to restyle the main app and floating trade panel.
- Theme migration preserves saved custom palettes. If the stored palette was still the untouched previous Chrome 73 default, it upgrades to Violet Pulse. Existing custom palettes and other presets are preserved.

### Main app

- Added a branded top bar with app identity and paper-trading label.
- Added a layered Paper Wallet hero panel with a clear SIMULATED indicator.
- Reworked card surfaces, buttons, input surfaces, section labels, chips, navigation highlight and accent colors.
- Added clearer headings and descriptions to Performance, Thesis, Profile and Settings.
- Increased visual depth and accent contrast without changing data or trade actions.
- Added a persistent Motion effects setting for the main tab transitions, press feedback and ambient header glow.
- Made the device-permission setup panel collapsible so the Trade page stays cleaner after initial setup.

### Other app areas

- Applied the same surface, chip and button language to the KOL Tracker, KOL training game, floating trade panel, PnL card editor and trade replay.
- Added subtle entry transitions to KOL sub-page content and PnL editor panes.
- Restyled replay and KOL chart surfaces and accent paths.

## Protected files

The following files are byte-identical to the uploaded Build 14.0 source:

- `app/src/main/java/com/pocketflip/overlay/DexScreenerClient.kt`
- `app/src/main/java/com/pocketflip/overlay/TradeRepository.kt`
- `app/src/main/java/com/pocketflip/overlay/Models.kt`
- `.github/workflows/build-apk.yml`

The floating overlay's presentation code was updated, but its buy/sell handlers and calculations were not intentionally changed.

## Files changed

- `app/build.gradle` — version name/code only.
- `app/src/main/java/com/pocketflip/overlay/Theme.kt`
- `app/src/main/java/com/pocketflip/overlay/MainActivity.kt`
- `app/src/main/java/com/pocketflip/overlay/KolScreen.kt`
- `app/src/main/java/com/pocketflip/overlay/KolGame.kt`
- `app/src/main/java/com/pocketflip/overlay/OverlayService.kt`
- `app/src/main/java/com/pocketflip/overlay/CardActivity.kt`
- `app/src/main/java/com/pocketflip/overlay/ReplayActivity.kt`

## Build and test status

This environment does not contain Gradle or an Android SDK, so I could not compile an APK or run the app on a device here. The ZIP contains the Android project and the original GitHub Actions workflow. The first compile test must be run by the repository's Actions workflow.

After installing the GitHub artifact, check:

1. All six top-level tabs open and switch correctly.
2. The floating buy/sell panel opens, pastes a CA and performs paper buys/sells as before.
3. Settings preset selection and all 14 custom color fields apply correctly to the app and floating panel.
4. The Motion effects switch changes main-screen transitions and glow behavior.
5. Journal, Thesis, Profile/equity curve, KOL Tracker, KOL Game, PnL PNG/MP4 editor and Replay still open and display their existing data.
6. Existing journal and balance data remain after updating over Build 14.0.

If GitHub Actions fails, use the build log to identify the compile error before installing. This is a source-project delivery, not a precompiled APK.
