# 73MCT UI Structural Redesign — Build 16.0

## Purpose

This pass restructures the existing native Android application around the information architecture and compact trading presentation observed in the FOMO mobile app. It is a substantial navigation and screen-layout change, not another palette-only update. The app remains native Kotlin Views; it has not been ported to React Native.

The redesign borrows general product patterns visible in FOMO—five primary destinations, compact token rows, trader rankings, activity timelines, a discovery screen and a portfolio area—while retaining 73MCT's existing features and identity. It does not use FOMO's private source code, proprietary assets or private backend.

## Primary navigation

The app now has five persistent destinations:

1. **Home** — paper balance, simulated-trading status and controls, open paper positions, a compact tracked-market block, and shortcuts to discovery/activity.
2. **Feed** — a chronological personal activity stream that combines the user's paper fills, saved thesis notes and swaps from wallets already tracked by the user.
3. **Search** — a separate read-only Solana token search using the documented DexScreener pair-search API, plus coins already surfaced by tracked wallets.
4. **KOLs** — the leaderboard destination, retaining the existing Coins, KOLs, Themes, Wallets and Game sections.
5. **Portfolio** — Overview, Trades (the existing journal) and Thesis sub-sections.

Settings is opened from the top-bar gear or the Portfolio shortcut. Trade details, Replay and PnL Studio remain reachable through the existing trade/detail flows. The existing KOL training game remains in the KOL section.

## Visual direction

- Reduced card stacking and removed the large ambient radial background glow from the main experience.
- Replaced repeated large rounded list cards with compact, aligned rows and thin separators for tracked coins, KOL rankings, wallet-derived market items and activity events.
- Increased information density while retaining clear image/name/metric columns.
- Kept color accents primarily for selected navigation, filters, primary actions and positive/negative performance rather than tinting every surface.
- Kept the current theme/customization preferences and the rest of the app's existing appearance settings. This pass does not reset saved theme colors.
- The KOL detail, wallet setup, theme analysis, game and existing trade-detail tools retain specialized panels where a denser list is not appropriate.

## New useful functionality

### Home: Tracked market

A short list of up to four valid cached tokens from the user's tracked-wallet scans is shown on Home, ordered by cached market cap. Each row shows the token image, symbol/name, market cap and cached USD price. Tapping opens the token's DexScreener page; long-press copies its mint address. This list is explicitly sourced from the user's tracked-wallet cache, not represented as an all-market feed.

### Feed: Personal activity timeline

The Feed merges, newest first:
- Fill events from completed paper trades.
- Fill events from currently open paper positions.
- Saved thesis notes attached to trades/positions.
- Swaps stored from the user's tracked KOL wallets.

Filters are All, My trades, Tracked wallets and Thesis notes. Recent rows display the actor, action, token, SOL amount when available, market cap when available, timestamp and realized slice PnL when the stored fill provides it. Tapping a completed paper-trade event opens the existing trade detail; tapping other token events copies the contract address.

**Important limitation:** this is a personal/local feed. It does not fetch FOMO's social feed, other people's posts, or a global stream of all Solana traders. Tracked-wallet events appear only after the user's wallets have been scanned and their swaps are stored locally.

### Search: Read-only Solana market search

New file: `app/src/main/java/com/pocketflip/overlay/MarketSearchClient.kt`.

- Calls `GET https://api.dexscreener.com/latest/dex/search?q=...` and filters the returned pairs to Solana.
- Supports token name, ticker and contract-address queries. The search field also submits from the keyboard's Search action.
- Deduplicates results by base-token mint, retaining the highest-liquidity returned pool for each token.
- Sorts by available liquidity and then 24-hour volume; shows up to 25 token results.
- Displays token image, symbol/name, DEX, price, market cap (or FDV where MC is unavailable), 24-hour change, volume and liquidity.
- Offers client-side minimum-liquidity filters: All, $10K+, $100K+ and $1M+.
- Tapping a result opens its DexScreener pair page; long-press copies the token mint.
- Shows a short list of coins surfaced by the user's own tracked-wallet scans below the network results.
- Uses a separate read-only OkHttp client and does not alter the existing market-price updater, its subscriptions, or paper-trading execution path.

Official API reference: https://docs.dexscreener.com/api/reference

**Search limitations:** it depends on an internet connection and DexScreener's API response. It shows up to 25 deduplicated Solana matches returned for the query, not a complete token registry or a guaranteed exhaustive market-wide ranking. Results are not automatically added to the paper-trading watchlist or used as a live-price subscription.

## Preservation and compatibility

- `applicationId` remains `com.pocketflip.overlay`.
- Version: `16.0-73MCT`; `versionCode`: `18`.
- Existing debug signing keystore is byte-for-byte unchanged so the app can update over the previous signed build when installed using the matching signing configuration.
- No app data directory, SharedPreferences namespace, journal structure or KOL storage schema was intentionally reset or migrated.
- The existing five-tab change is presentation/navigation only; existing Journal and Thesis screens remain nested under Portfolio.
- `DexScreenerClient.kt`, `TradeRepository.kt` and `Models.kt` are byte-for-byte unchanged against the supplied Build 14.0 source.
- `.github/workflows/build-apk.yml` is byte-for-byte unchanged.
- `OverlayService.kt` contains prior UI appearance adjustments from the preceding renovation; this pass did not alter its buy/sell handling or trading calculations.
- `AndroidManifest.xml` is unchanged; existing Internet permission is used by the new read-only search client.

## Changed source paths relative to the supplied Build 14.0 project

- `app/build.gradle` — version code/name only.
- `app/src/main/java/com/pocketflip/overlay/MainActivity.kt` — new root navigation, Home tracked-market block, Feed and Portfolio sections.
- `app/src/main/java/com/pocketflip/overlay/KolScreen.kt` — dedicated Search view, compact token/KOL rows, search filters and detail navigation.
- `app/src/main/java/com/pocketflip/overlay/MarketSearchClient.kt` — new separate read-only Solana search client.
- `app/src/main/java/com/pocketflip/overlay/LineIcon.kt` — Feed and Search icons.
- `app/src/main/java/com/pocketflip/overlay/Theme.kt` — existing theme presentation changes retained from the previous visual pass.
- `app/src/main/java/com/pocketflip/overlay/CardActivity.kt` — existing presentation changes retained from the previous visual pass.
- `app/src/main/java/com/pocketflip/overlay/KolGame.kt` — existing presentation changes retained from the previous visual pass.
- `app/src/main/java/com/pocketflip/overlay/OverlayService.kt` — existing UI styling changes retained; trading behavior not intentionally changed.
- `app/src/main/java/com/pocketflip/overlay/ReplayActivity.kt` — existing presentation changes retained from the previous visual pass.

## Verification performed

- Confirmed `DexScreenerClient.kt`, `TradeRepository.kt`, `Models.kt`, `.github/workflows/build-apk.yml` and `app/debug.keystore` match the supplied Build 14.0 files byte-for-byte.
- Ran a delimiter-balance scan on the changed Kotlin screens/theme/icon/search-client files; all passed.
- Ran Kotlin compiler parsing over the changed screen/search files. It reported unresolved Android and app/dependency symbols because this environment lacks the Android SDK and project classpath; no parser-level syntax diagnostics (`expecting`, `unexpected tokens`, missing delimiter, etc.) were found.
- A complete APK build and device/runtime test were **not** possible here: no Gradle executable or Android SDK (`android.jar`) is installed in this environment. Do not treat the source checks as a successful Android build.

## Build and test

1. Extract this project ZIP into the root of the existing GitHub repository, preserving the `.github` and `app` directories.
2. Commit and push the extracted project files. Do not merely upload the ZIP alongside the old source: the workflow sees `app/build.gradle` and will not auto-extract a ZIP in that case.
3. Open the existing GitHub Actions run and download its `PocketFlip-PocoX6Pro-APK` artifact if the build succeeds.
4. Install the generated debug APK over the previous build signed with the same key.
5. Verify Home balance/positions and the floating trader first; then test Feed filters, Search by name/ticker/mint and liquidity thresholds, KOL wallet scanning/leaderboard/game, Portfolio Overview/Trades/Thesis, Settings, Replay and PnL Studio.

If GitHub Actions fails, retain the complete build log. A compile error must be corrected before treating the package as installable.
